-- =============================================================================
-- PRODIGI — onboard one factory + first admin (RBC operators only)
-- Run in Supabase SQL Editor. Replace ALL placeholders below.
-- Prerequisite: create admin in Auth → Users first, copy UUID into step 2.
-- =============================================================================

-- STEP 1: Factory (edit name, code, and optional app entitlements)
INSERT INTO public.factories (
  name, code, country,
  transaction_apps, production_apps, workforce_apps, audit_apps, shipment_apps
)
VALUES (
  'Acme Garments', 'acme-garments-a1b2', 'IN',
  '["transaction"]'::jsonb,
  '["hourly","qc_log"]'::jsonb,
  '["workforce_log","attendance"]'::jsonb,
  '["audit"]'::jsonb,
  '["shipment_log","final_rejection_log"]'::jsonb
)
ON CONFLICT (code) DO NOTHING;

-- STEP 2: Admin profile — replace AUTH_USER_UUID
INSERT INTO public.profiles (id, factory_id, full_name, email, user_role, status)
SELECT
  'AUTH_USER_UUID'::uuid,
  f.id,
  'Plant Admin',
  'admin@acmegarments.com',
  'admin',
  'Active'
FROM public.factories f
WHERE f.code = 'acme-garments-a1b2'
ON CONFLICT (id) DO UPDATE SET
  factory_id = EXCLUDED.factory_id,
  full_name = EXCLUDED.full_name,
  email = EXCLUDED.email,
  user_role = 'admin',
  status = 'Active';

-- STEP 3: Starter departments (skipped if departments already exist)
INSERT INTO public.departments (factory_id, name, sequence, apps)
SELECT f.id, d.name, d.seq, d.apps::jsonb
FROM public.factories f
CROSS JOIN (VALUES
  ('Cutting',   1, '["transaction","hourly"]'),
  ('Sewing',    2, '["transaction","hourly","workforce_log"]'),
  ('Finishing', 3, '["transaction","qc_log"]'),
  ('Packing',   4, '["transaction","hourly"]')
) AS d(name, seq, apps)
WHERE f.code = 'acme-garments-a1b2'
  AND NOT EXISTS (SELECT 1 FROM public.departments dep WHERE dep.factory_id = f.id);

-- STEP 4: Starter shift
INSERT INTO public.shifts (factory_id, name, type, start_time, end_time)
SELECT f.id, 'Day', 'Regular', '08:00'::time, '17:00'::time
FROM public.factories f
WHERE f.code = 'acme-garments-a1b2'
  AND NOT EXISTS (SELECT 1 FROM public.shifts s WHERE s.factory_id = f.id);

-- Verify
SELECT f.id AS factory_id, f.code, p.email, p.user_role, p.status
FROM public.factories f
JOIN public.profiles p ON p.factory_id = f.id
WHERE f.code = 'acme-garments-a1b2';
