import fs from 'fs'

const p = 'supabase/migrations/20260616100000_phase9_5_catchup.sql'
let sql = fs.readFileSync(p, 'utf8')

const jEnd = sql.indexOf(
  "COMMENT ON FUNCTION public.get_cut_to_ship_journey(uuid, uuid) IS\n  'Department journey rows for one order. One row per colorway × dept."
)
if (jEnd < 0) throw new Error('journey comment not found')

const dStart = sql.indexOf('CREATE OR REPLACE FUNCTION public.get_cut_to_ship_detail', jEnd)
const dEnd = sql.indexOf('-- >>> 20260613103000', dStart)
if (dStart < 0 || dEnd < 0) throw new Error(`detail block ${dStart} ${dEnd}`)

sql =
  sql.slice(0, dStart) +
  '-- get_cut_to_ship_detail deferred until get_order_wip exists (see 11160000 / 14100000)\n\n' +
  sql.slice(dEnd)

const wipBlock = `-- Early define get_order_wip (required by journey/detail RPCs below)
CREATE OR REPLACE FUNCTION public.get_order_wip(
  p_factory_id uuid,
  p_order_id uuid
)
RETURNS SETOF public.v_wip_order
LANGUAGE sql
STABLE
SECURITY INVOKER
SET search_path = public
AS $$
  WITH ranked AS (
    SELECT
      w.*,
      ROW_NUMBER() OVER (
        PARTITION BY w.colorway_id, w.department_id
        ORDER BY w.log_date DESC NULLS LAST
      ) AS rn
    FROM public.v_wip_order w
    WHERE w.factory_id = p_factory_id
      AND w.order_id = p_order_id
  )
  SELECT
    factory_id, order_id, colorway_id, log_date, flow_step, department_id, wip_qty
  FROM ranked
  WHERE rn = 1
  ORDER BY flow_step, colorway_id NULLS LAST, department_id;
$$;

COMMENT ON FUNCTION public.get_order_wip(uuid, uuid) IS
  'Latest colorway-grained WIP per process-flow department for an order. Wraps v_wip_order.';

`

const ins = sql.indexOf('-- >>> 20260612120000_mes_cut_to_ship_journey_view.sql')
sql = sql.slice(0, ins) + wipBlock + sql.slice(ins)

fs.writeFileSync(p, sql)
console.log('Fixed order. Lines:', sql.split('\n').length)
