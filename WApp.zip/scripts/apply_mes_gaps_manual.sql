-- Run in Supabase SQL Editor if `supabase db push` fails (migration history drift).
-- Safe to re-run (idempotent grants + IF NOT EXISTS column).

-- 1. Planning remarks on colorways
ALTER TABLE public.colorways
  ADD COLUMN IF NOT EXISTS planning_remarks text;

COMMENT ON COLUMN public.colorways.planning_remarks IS
  'Per-colorway production planning notes (summary modal, print).';

-- 2. Reporting view grants (SECURITY INVOKER RPCs)
GRANT SELECT ON public.v_daily_quality TO authenticated;
GRANT SELECT ON public.v_daily_kpis_by_shift TO authenticated;
GRANT SELECT ON public.v_daily_kpis TO authenticated;
GRANT SELECT ON public.v_daily_output TO authenticated;
GRANT SELECT ON public.v_daily_target TO authenticated;
GRANT SELECT ON public.v_daily_workforce TO authenticated;
GRANT SELECT ON public.v_wip_dept TO authenticated;
GRANT SELECT ON public.v_shift_minutes TO authenticated;
GRANT SELECT ON public.v_cut_to_ship TO authenticated;
GRANT SELECT ON public.v_cut_to_ship_dept_journey TO authenticated;

-- 3. If get_factory_kpis RPC is missing, apply:
--    supabase/migrations/20260618100000_mes_factory_kpis_reporting.sql
