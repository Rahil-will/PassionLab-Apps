-- =============================================================================
-- PRODIGI — bootstrap RBC platform superadmin (run once in Supabase SQL Editor)
--
-- BEFORE running step 2:
--   Auth → Users → Add user
--   Email: rahil@rajeshbheda.com
--   Password: <strong password>
--   Auto Confirm User: ON
--   Copy the user's UUID into AUTH_USER_UUID below
-- =============================================================================

-- STEP 1: Platform "home" factory (superadmin is tied to one factory_id in schema)
INSERT INTO public.factories (name, code, country)
VALUES ('RBC Platform', 'rbc-platform', 'IN')
ON CONFLICT (code) DO NOTHING;

-- STEP 2: Superadmin profile — replace AUTH_USER_UUID
INSERT INTO public.profiles (id, factory_id, full_name, email, user_role, status)
SELECT
  '569e699f-a7eb-4a64-8ffd-04a9f3a78ce7'::uuid,
  f.id,
  'Rahil',
  'rahil@rajeshbheda.com',
  'superadmin',
  'Active'
FROM public.factories f
WHERE f.code = 'rbc-platform'
ON CONFLICT (id) DO UPDATE SET
  factory_id = EXCLUDED.factory_id,
  full_name = EXCLUDED.full_name,
  email = EXCLUDED.email,
  user_role = 'superadmin',
  status = 'Active';

-- Verify
SELECT p.id, p.email, p.user_role, p.status, f.name AS home_factory, f.code AS factory_code
FROM public.profiles p
JOIN public.factories f ON f.id = p.factory_id
WHERE p.email = 'rahil@rajeshbheda.com';
