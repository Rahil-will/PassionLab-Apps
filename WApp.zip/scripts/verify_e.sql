SELECT proname FROM pg_proc p
JOIN pg_namespace n ON n.oid = p.pronamespace
WHERE n.nspname='public'
  AND has_function_privilege('anon', p.oid, 'EXECUTE')
  AND p.proname LIKE 'get_%'
  AND p.proname NOT IN ('get_floor_bootstrap','get_floor_users','get_my_profile');
