-- Rollback-style Cut-to-Ship test. ROLLBACK leaves live DB unchanged.
-- Factory 11111111-0000-0000-0000-000000000001
-- Order   008c2fab-1633-46e2-ac5a-9dc475640788
-- Colorway OFFWHITE 74997d27-a46a-45e2-8d5b-e5ed8a697efb
-- Colorway NAVY BLU 4420e915-068f-48c9-b614-fa494b0515d9
-- Cutting 08c15b12-a298-4efc-ab61-e096edcc233b
-- Sewing  22834dc3-6c4f-41ec-b433-fa1666e3f261
-- Finishing ccedc6bc-6a1e-4101-843c-4f6ae3392efc
-- QA      83a4781f-e283-4cdd-99ea-a8296900588f
-- Shipment 188c6b75-2cfa-4814-a207-4f15062a9f78
-- Profile 6cfa030c-b6c5-43cb-9d61-ccdb1234288c

BEGIN;

UPDATE public.style_orders
SET adj_qty = 1000
WHERE id = '008c2fab-1633-46e2-ac5a-9dc475640788';

-- OFFWHITE: cut 950, ship 900, reject 30, wip 20 → balanced
INSERT INTO public.hourly_counts (
  id, factory_id, order_id, colorway_id, department_id, hour_slot, log_date, count, logged_by
) VALUES
  ('bbbbbbbb-0001-4000-8000-000000000001', '11111111-0000-0000-0000-000000000001',
   '008c2fab-1633-46e2-ac5a-9dc475640788', '74997d27-a46a-45e2-8d5b-e5ed8a697efb',
   '08c15b12-a298-4efc-ab61-e096edcc233b', '10:00', '2026-06-15', 500,
   '6cfa030c-b6c5-43cb-9d61-ccdb1234288c'),
  ('bbbbbbbb-0002-4000-8000-000000000001', '11111111-0000-0000-0000-000000000001',
   '008c2fab-1633-46e2-ac5a-9dc475640788', '74997d27-a46a-45e2-8d5b-e5ed8a697efb',
   '08c15b12-a298-4efc-ab61-e096edcc233b', '11:00', '2026-06-15', 450,
   '6cfa030c-b6c5-43cb-9d61-ccdb1234288c');

INSERT INTO public.handover_slips (
  id, factory_id, order_id, colorway_id, from_department_id, to_department_id,
  sent_qty, sent_by, sent_at, status
) VALUES (
  'bbbbbbbb-0003-4000-8000-000000000001', '11111111-0000-0000-0000-000000000001',
  '008c2fab-1633-46e2-ac5a-9dc475640788', '74997d27-a46a-45e2-8d5b-e5ed8a697efb',
  '08c15b12-a298-4efc-ab61-e096edcc233b', '22834dc3-6c4f-41ec-b433-fa1666e3f261',
  950, '6cfa030c-b6c5-43cb-9d61-ccdb1234288c', '2026-06-15 14:00:00+00', 'pending'
);

INSERT INTO public.hourly_counts (
  id, factory_id, order_id, colorway_id, department_id, hour_slot, log_date, count, logged_by
) VALUES (
  'bbbbbbbb-0004-4000-8000-000000000001', '11111111-0000-0000-0000-000000000001',
  '008c2fab-1633-46e2-ac5a-9dc475640788', '74997d27-a46a-45e2-8d5b-e5ed8a697efb',
  '22834dc3-6c4f-41ec-b433-fa1666e3f261', '10:00', '2026-06-15', 100,
  '6cfa030c-b6c5-43cb-9d61-ccdb1234288c'
);

INSERT INTO public.handover_slips (
  id, factory_id, order_id, colorway_id, from_department_id, to_department_id,
  sent_qty, sent_by, sent_at, status
) VALUES (
  'bbbbbbbb-0005-4000-8000-000000000001', '11111111-0000-0000-0000-000000000001',
  '008c2fab-1633-46e2-ac5a-9dc475640788', '74997d27-a46a-45e2-8d5b-e5ed8a697efb',
  '22834dc3-6c4f-41ec-b433-fa1666e3f261', 'ccedc6bc-6a1e-4101-843c-4f6ae3392efc',
  80, '6cfa030c-b6c5-43cb-9d61-ccdb1234288c', '2026-06-15 16:00:00+00', 'pending'
);

INSERT INTO public.rejections (
  id, factory_id, order_id, colorway_id, qty, reason_code, stage, rejected_date, logged_by
) VALUES
  ('bbbbbbbb-0006-4000-8000-000000000001', '11111111-0000-0000-0000-000000000001',
   '008c2fab-1633-46e2-ac5a-9dc475640788', '74997d27-a46a-45e2-8d5b-e5ed8a697efb',
   20, 'Stained', 'inline', '2026-06-15', '6cfa030c-b6c5-43cb-9d61-ccdb1234288c'),
  ('bbbbbbbb-0007-4000-8000-000000000001', '11111111-0000-0000-0000-000000000001',
   '008c2fab-1633-46e2-ac5a-9dc475640788', '74997d27-a46a-45e2-8d5b-e5ed8a697efb',
   10, 'Damaged', 'final_audit', '2026-06-15', '6cfa030c-b6c5-43cb-9d61-ccdb1234288c');

INSERT INTO public.shipments (
  id, factory_id, order_id, colorway_id, shipped_qty, shipment_date, shipment_type, logged_by
) VALUES (
  'bbbbbbbb-0008-4000-8000-000000000001', '11111111-0000-0000-0000-000000000001',
  '008c2fab-1633-46e2-ac5a-9dc475640788', '74997d27-a46a-45e2-8d5b-e5ed8a697efb',
  900, '2026-06-15', 'main', '6cfa030c-b6c5-43cb-9d61-ccdb1234288c'
);

-- NAVY BLU: cut 500, ship 460, reject 15, wip 25 → balanced
INSERT INTO public.hourly_counts (
  id, factory_id, order_id, colorway_id, department_id, hour_slot, log_date, count, logged_by
) VALUES
  ('bbbbbbbb-0011-4000-8000-000000000001', '11111111-0000-0000-0000-000000000001',
   '008c2fab-1633-46e2-ac5a-9dc475640788', '4420e915-068f-48c9-b614-fa494b0515d9',
   '08c15b12-a298-4efc-ab61-e096edcc233b', '10:00', '2026-06-15', 300,
   '6cfa030c-b6c5-43cb-9d61-ccdb1234288c'),
  ('bbbbbbbb-0012-4000-8000-000000000001', '11111111-0000-0000-0000-000000000001',
   '008c2fab-1633-46e2-ac5a-9dc475640788', '4420e915-068f-48c9-b614-fa494b0515d9',
   '08c15b12-a298-4efc-ab61-e096edcc233b', '11:00', '2026-06-15', 200,
   '6cfa030c-b6c5-43cb-9d61-ccdb1234288c');

INSERT INTO public.handover_slips (
  id, factory_id, order_id, colorway_id, from_department_id, to_department_id,
  sent_qty, sent_by, sent_at, status
) VALUES (
  'bbbbbbbb-0013-4000-8000-000000000001', '11111111-0000-0000-0000-000000000001',
  '008c2fab-1633-46e2-ac5a-9dc475640788', '4420e915-068f-48c9-b614-fa494b0515d9',
  '08c15b12-a298-4efc-ab61-e096edcc233b', '22834dc3-6c4f-41ec-b433-fa1666e3f261',
  480, '6cfa030c-b6c5-43cb-9d61-ccdb1234288c', '2026-06-15 14:00:00+00', 'pending'
);

INSERT INTO public.hourly_counts (
  id, factory_id, order_id, colorway_id, department_id, hour_slot, log_date, count, logged_by
) VALUES (
  'bbbbbbbb-0014-4000-8000-000000000001', '11111111-0000-0000-0000-000000000001',
  '008c2fab-1633-46e2-ac5a-9dc475640788', '4420e915-068f-48c9-b614-fa494b0515d9',
  '22834dc3-6c4f-41ec-b433-fa1666e3f261', '11:00', '2026-06-15', 30,
  '6cfa030c-b6c5-43cb-9d61-ccdb1234288c'
);

INSERT INTO public.handover_slips (
  id, factory_id, order_id, colorway_id, from_department_id, to_department_id,
  sent_qty, sent_by, sent_at, status
) VALUES (
  'bbbbbbbb-0015-4000-8000-000000000001', '11111111-0000-0000-0000-000000000001',
  '008c2fab-1633-46e2-ac5a-9dc475640788', '4420e915-068f-48c9-b614-fa494b0515d9',
  '22834dc3-6c4f-41ec-b433-fa1666e3f261', 'ccedc6bc-6a1e-4101-843c-4f6ae3392efc',
  25, '6cfa030c-b6c5-43cb-9d61-ccdb1234288c', '2026-06-15 16:00:00+00', 'pending'
);

INSERT INTO public.rejections (
  id, factory_id, order_id, colorway_id, qty, reason_code, stage, rejected_date, logged_by
) VALUES (
  'bbbbbbbb-0016-4000-8000-000000000001', '11111111-0000-0000-0000-000000000001',
  '008c2fab-1633-46e2-ac5a-9dc475640788', '4420e915-068f-48c9-b614-fa494b0515d9',
  15, 'Stained', 'inline', '2026-06-15', '6cfa030c-b6c5-43cb-9d61-ccdb1234288c'
);

INSERT INTO public.shipments (
  id, factory_id, order_id, colorway_id, shipped_qty, shipment_date, shipment_type, logged_by
) VALUES (
  'bbbbbbbb-0017-4000-8000-000000000001', '11111111-0000-0000-0000-000000000001',
  '008c2fab-1633-46e2-ac5a-9dc475640788', '4420e915-068f-48c9-b614-fa494b0515d9',
  460, '2026-06-15', 'main', '6cfa030c-b6c5-43cb-9d61-ccdb1234288c'
);

-- Setup-incomplete: process flow with no flow_step = 1
INSERT INTO public.process_flows (
  id, factory_id, name, is_current
) VALUES (
  'bbbbbbbb-00f1-4000-8000-000000000001',
  '11111111-0000-0000-0000-000000000001',
  'TEST_NO_STEP_ONE', false
);

INSERT INTO public.process_flow_steps (
  id, flow_id, department_id, dept_name, flow_step
) VALUES (
  'bbbbbbbb-00f2-4000-8000-000000000001',
  'bbbbbbbb-00f1-4000-8000-000000000001',
  '22834dc3-6c4f-41ec-b433-fa1666e3f261',
  'Sewing',
  2
);

INSERT INTO public.style_orders (
  id, factory_id, style_name, buyer_name, po_number, order_qty, adj_qty,
  process_flow_id, status
) VALUES (
  'bbbbbbbb-00f3-4000-8000-000000000001',
  '11111111-0000-0000-0000-000000000001',
  'TEST-NO-CUT', 'Test Buyer', 'PO-NOCUT', 100, 100,
  'bbbbbbbb-00f1-4000-8000-000000000001',
  'Not Started'
);

INSERT INTO public.colorways (
  id, order_id, name, color_code
) VALUES (
  'bbbbbbbb-00f4-4000-8000-000000000001',
  'bbbbbbbb-00f3-4000-8000-000000000001',
  'RED', 'RED'
);

-- Hide Cutting by name so rule 2 cannot match (rule 1 already absent on test flow)
UPDATE public.departments
SET name = 'Prep Room'
WHERE id = '08c15b12-a298-4efc-ab61-e096edcc233b'
  AND factory_id = '11111111-0000-0000-0000-000000000001';

CREATE TEMP TABLE recon_offwhite AS
SELECT * FROM public.v_cut_to_ship
WHERE order_id = '008c2fab-1633-46e2-ac5a-9dc475640788'
  AND colorway_id = '74997d27-a46a-45e2-8d5b-e5ed8a697efb';

CREATE TEMP TABLE recon_navy AS
SELECT * FROM public.v_cut_to_ship
WHERE order_id = '008c2fab-1633-46e2-ac5a-9dc475640788'
  AND colorway_id = '4420e915-068f-48c9-b614-fa494b0515d9';

CREATE TEMP TABLE capture_tests (scenario text, result jsonb);

-- Shipment/rejection auth: profiles.assigned_apps or quality_manager (rejection only), not department.apps
UPDATE public.profiles
SET department_id = '08c15b12-a298-4efc-ab61-e096edcc233b', assigned_apps = '[]'::jsonb
WHERE id = '6cfa030c-b6c5-43cb-9d61-ccdb1234288c';
INSERT INTO capture_tests SELECT 'cutting_shipment_log_denied',
  public.floor_capture('11111111-0000-0000-0000-000000000001', '6cfa030c-b6c5-43cb-9d61-ccdb1234288c', 'shipment_log',
    jsonb_build_object('orderId', '008c2fab-1633-46e2-ac5a-9dc475640788', 'shippedQty', 1, 'shipmentType', 'main'));

UPDATE public.profiles
SET department_id = '83a4781f-e283-4cdd-99ea-a8296900588f', assigned_apps = '[]'::jsonb, user_role = 'operator'
WHERE id = '6cfa030c-b6c5-43cb-9d61-ccdb1234288c';
INSERT INTO capture_tests SELECT 'qa_shipment_log_denied',
  public.floor_capture('11111111-0000-0000-0000-000000000001', '6cfa030c-b6c5-43cb-9d61-ccdb1234288c', 'shipment_log',
    jsonb_build_object('orderId', '008c2fab-1633-46e2-ac5a-9dc475640788', 'shippedQty', 1, 'shipmentType', 'main'));

UPDATE public.profiles
SET department_id = NULL, assigned_apps = '["shipment_log"]'::jsonb
WHERE id = '6cfa030c-b6c5-43cb-9d61-ccdb1234288c';
INSERT INTO capture_tests SELECT 'factory_function_shipment_log',
  public.floor_capture('11111111-0000-0000-0000-000000000001', '6cfa030c-b6c5-43cb-9d61-ccdb1234288c', 'shipment_log',
    jsonb_build_object('orderId', '008c2fab-1633-46e2-ac5a-9dc475640788', 'shippedQty', 1, 'shipmentType', 'main'));

UPDATE public.profiles
SET department_id = '188c6b75-2cfa-4814-a207-4f15062a9f78', assigned_apps = '[]'::jsonb
WHERE id = '6cfa030c-b6c5-43cb-9d61-ccdb1234288c';
INSERT INTO capture_tests SELECT 'shipment_dept_without_app_denied',
  public.floor_capture('11111111-0000-0000-0000-000000000001', '6cfa030c-b6c5-43cb-9d61-ccdb1234288c', 'shipment_log',
    jsonb_build_object('orderId', '008c2fab-1633-46e2-ac5a-9dc475640788', 'shippedQty', 1, 'shipmentType', 'main'));

UPDATE public.profiles
SET department_id = '83a4781f-e283-4cdd-99ea-a8296900588f', user_role = 'quality_manager', assigned_apps = '[]'::jsonb
WHERE id = '6cfa030c-b6c5-43cb-9d61-ccdb1234288c';
INSERT INTO capture_tests SELECT 'qa_rejection_log',
  public.floor_capture('11111111-0000-0000-0000-000000000001', '6cfa030c-b6c5-43cb-9d61-ccdb1234288c', 'rejection_log',
    jsonb_build_object('orderId', '008c2fab-1633-46e2-ac5a-9dc475640788', 'qty', 1, 'stage', 'final_audit', 'reasonCode', 'Stained'));

INSERT INTO capture_tests SELECT 'qa_invalid_stage',
  public.floor_capture('11111111-0000-0000-0000-000000000001', '6cfa030c-b6c5-43cb-9d61-ccdb1234288c', 'rejection_log',
    jsonb_build_object('orderId', '008c2fab-1633-46e2-ac5a-9dc475640788', 'qty', 1, 'stage', 'invalid', 'reasonCode', 'Stained'));

UPDATE public.profiles SET department_id = '08c15b12-a298-4efc-ab61-e096edcc233b'
WHERE id = '6cfa030c-b6c5-43cb-9d61-ccdb1234288c';
INSERT INTO capture_tests SELECT 'handover_with_colorway',
  public.floor_capture('11111111-0000-0000-0000-000000000001', '6cfa030c-b6c5-43cb-9d61-ccdb1234288c', 'handover_send',
    jsonb_build_object(
      'orderId', '008c2fab-1633-46e2-ac5a-9dc475640788',
      'colorwayId', '74997d27-a46a-45e2-8d5b-e5ed8a697efb',
      'fromDepartmentId', '08c15b12-a298-4efc-ab61-e096edcc233b',
      'toDepartmentId', '22834dc3-6c4f-41ec-b433-fa1666e3f261',
      'sentQty', 1
    ));

UPDATE public.profiles SET department_id = '22834dc3-6c4f-41ec-b433-fa1666e3f261'
WHERE id = '6cfa030c-b6c5-43cb-9d61-ccdb1234288c';
INSERT INTO capture_tests SELECT 'inspection_with_colorway',
  public.floor_capture('11111111-0000-0000-0000-000000000001', '6cfa030c-b6c5-43cb-9d61-ccdb1234288c', 'inspection',
    jsonb_build_object(
      'orderId', '008c2fab-1633-46e2-ac5a-9dc475640788',
      'colorwayId', '74997d27-a46a-45e2-8d5b-e5ed8a697efb',
      'departmentId', '22834dc3-6c4f-41ec-b433-fa1666e3f261',
      'result', 'pass'
    ));

SELECT jsonb_build_object(
  'offwhite', (SELECT to_jsonb(o) FROM recon_offwhite o),
  'navy', (SELECT to_jsonb(n) FROM recon_navy n),
  'two_colorway_rows', (
    SELECT COUNT(*)::integer FROM public.v_cut_to_ship
    WHERE order_id = '008c2fab-1633-46e2-ac5a-9dc475640788'
      AND colorway_id IN (
        '74997d27-a46a-45e2-8d5b-e5ed8a697efb',
        '4420e915-068f-48c9-b614-fa494b0515d9'
      )
  ),
  'order_rollup', (
    SELECT jsonb_build_object(
      'cut_qty', SUM(cut_qty),
      'shipped_qty', SUM(shipped_qty),
      'rejected_qty', SUM(rejected_qty),
      'wip_qty', SUM(wip_qty),
      'reconciliation_gap', SUM(reconciliation_gap),
      'is_balanced', bool_and(is_balanced)
    )
    FROM public.v_cut_to_ship
    WHERE order_id = '008c2fab-1633-46e2-ac5a-9dc475640788'
      AND colorway_id IN (
        '74997d27-a46a-45e2-8d5b-e5ed8a697efb',
        '4420e915-068f-48c9-b614-fa494b0515d9'
      )
  ),
  'unbalanced_offwhite', (
    SELECT jsonb_build_object(
      'shipped_qty', 890,
      'reconciliation_gap', cut_qty - (890 + rejected_qty + wip_qty),
      'is_balanced', (cut_qty = 890 + rejected_qty + wip_qty)
    )
    FROM public.v_cut_to_ship
    WHERE order_id = '008c2fab-1633-46e2-ac5a-9dc475640788'
      AND colorway_id = '74997d27-a46a-45e2-8d5b-e5ed8a697efb'
  ),
  'no_cutting_dept', (
    SELECT jsonb_build_object(
      'cut_qty', cut_qty,
      'cut_qty_source', cut_qty_source
    )
    FROM public.v_order_cut_qty
    WHERE order_id = 'bbbbbbbb-00f3-4000-8000-000000000001'
      AND colorway_id = 'bbbbbbbb-00f4-4000-8000-000000000001'
  ),
  'setup_check_flags_test_flow', EXISTS (
    SELECT 1 FROM public.v_factories_missing_flow_step_one
    WHERE process_flow_id = 'bbbbbbbb-00f1-4000-8000-000000000001'
  ),
  'capture_tests', (SELECT jsonb_agg(jsonb_build_object('scenario', scenario, 'result', result)) FROM capture_tests),
  'handover_colorway_persisted', (
    SELECT colorway_id::text FROM public.handover_slips
    WHERE id = (SELECT (result->>'id')::uuid FROM capture_tests WHERE scenario = 'handover_with_colorway')
  ),
  'inspection_colorway_persisted', (
    SELECT colorway_id::text FROM public.inspections
    WHERE id = (SELECT (result->>'id')::uuid FROM capture_tests WHERE scenario = 'inspection_with_colorway')
  )
) AS test_results;

ROLLBACK;
