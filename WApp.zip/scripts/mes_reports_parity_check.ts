/**
 * Compare legacy client-side day report (lib/mesReports) vs RPC-backed report (lib/mesReportsApi).
 * Usage: npx tsx scripts/mes_reports_parity_check.ts [factoryId] [date]
 */
import { createClient } from '@supabase/supabase-js';
import { buildDayReport, fetchMesRawData } from '../lib/mesReports';
import { buildDayReportFromRpc, fetchFactoryKpis, fetchReportMeta } from '../lib/mesReportsApi';

const factoryId = process.argv[2] ?? process.env.MES_FACTORY_ID;
const date = process.argv[3] ?? new Date().toISOString().slice(0, 10);

if (!factoryId) {
  console.error('Usage: npx tsx scripts/mes_reports_parity_check.ts <factoryId> [yyyy-mm-dd]');
  process.exit(1);
}

const url = process.env.VITE_SUPABASE_URL ?? process.env.SUPABASE_URL;
const key = process.env.VITE_SUPABASE_ANON_KEY ?? process.env.SUPABASE_ANON_KEY;
if (!url || !key) {
  console.error('Set VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY');
  process.exit(1);
}

const supabase = createClient(url, key);

async function main() {
  const [raw, meta, kpiRows] = await Promise.all([
    fetchMesRawData(factoryId, date),
    fetchReportMeta(factoryId),
    fetchFactoryKpis(factoryId, date, date),
  ]);

  const legacy = buildDayReport(raw);
  const rpc = buildDayReportFromRpc(kpiRows, meta.departments, date, date);

  const legacyMap = new Map(legacy.map((r) => [r.departmentId, r]));
  let mismatches = 0;

  for (const row of rpc) {
    const leg = legacyMap.get(row.departmentId);
    if (!leg) {
      console.warn(`[missing legacy] ${row.departmentName}`);
      mismatches++;
      continue;
    }
    const fields: Array<keyof typeof row> = ['output', 'target', 'efficiency', 'dhu', 'wip'];
    for (const f of fields) {
      const a = leg[f];
      const b = row[f];
      const same = a === b || (a == null && b == null);
      if (!same) {
        console.warn(`[${row.departmentName}] ${f}: legacy=${a} rpc=${b}`);
        mismatches++;
      }
    }
  }

  if (mismatches === 0) {
    console.log(`OK: ${rpc.length} departments match for ${factoryId} on ${date}`);
  } else {
    console.error(`${mismatches} field mismatch(es)`);
    process.exit(1);
  }
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
