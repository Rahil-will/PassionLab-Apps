-- Phase 5 floor_capture hardening tests. Wrapped in ROLLBACK — live DB unchanged.
-- Factory 11111111-0000-0000-0000-000000000001
-- Profile 6cfa030c-b6c5-43cb-9d61-ccdb1234288c

BEGIN;

CREATE TEMP TABLE fc_test (
  case_name text PRIMARY KEY,
  expect_code text,
  actual jsonb,
  pass boolean GENERATED ALWAYS AS (
    CASE
      WHEN expect_code = 'OK' THEN actual ? 'id' OR actual ? 'ok' OR actual ? 'challanNumber'
      ELSE actual->>'code' = expect_code
    END
  ) STORED
);

DO $$
DECLARE
  v_factory uuid := '11111111-0000-0000-0000-000000000001';
  v_user uuid := '6cfa030c-b6c5-43cb-9d61-ccdb1234288c';
  v_order uuid := '008c2fab-1633-46e2-ac5a-9dc475640788';
  v_cw uuid := '74997d27-a46a-45e2-8d5b-e5ed8a697efb';
  v_cut uuid := '08c15b12-a298-4efc-ab61-e096edcc233b';
  v_sew uuid := '22834dc3-6c4f-41ec-b433-fa1666e3f261';
  v_qa uuid := '83a4781f-e283-4cdd-99ea-a8296900588f';
  v_ship uuid := '188c6b75-2cfa-4814-a207-4f15062a9f78';
  v_reg_shift uuid := '3a8b5dba-2d63-45e7-bfd6-c14b67833f29';
  v_ot_shift uuid := '02d43a0c-f11e-4570-9b8b-d4bdac5df7d8';
  v_r jsonb;
  v_slip uuid;
BEGIN
  UPDATE public.profiles SET department_id = v_qa WHERE id = v_user;

  INSERT INTO fc_test VALUES ('hourly REQUIRE_APP_HOURLY', 'REQUIRE_APP_HOURLY',
    public.floor_capture(v_factory, v_user, 'hourly_upsert', jsonb_build_object(
      'orderId', v_order, 'departmentId', v_qa, 'hourSlot', '10:00', 'count', 1)));

  UPDATE public.profiles SET department_id = v_sew WHERE id = v_user;
  INSERT INTO fc_test VALUES ('hourly on QC dept', 'REQUIRE_APP_HOURLY',
    public.floor_capture(v_factory, v_user, 'hourly_upsert', jsonb_build_object(
      'orderId', v_order, 'departmentId', v_sew, 'hourSlot', '10:00', 'count', 1)));

  UPDATE public.profiles SET department_id = v_cut WHERE id = v_user;
  INSERT INTO fc_test VALUES ('hourly INVALID_ORDER', 'INVALID_ORDER',
    public.floor_capture(v_factory, v_user, 'hourly_upsert', jsonb_build_object(
      'orderId', '00000000-0000-0000-0000-000000000099',
      'departmentId', v_cut, 'hourSlot', '10:00', 'count', 1)));

  INSERT INTO fc_test VALUES ('hourly DEPT_MISMATCH', 'DEPT_MISMATCH',
    public.floor_capture(v_factory, v_user, 'hourly_upsert', jsonb_build_object(
      'orderId', v_order, 'departmentId', v_sew, 'hourSlot', '10:00', 'count', 1)));

  INSERT INTO fc_test VALUES ('hourly MISSING_HOUR_SLOT', 'MISSING_HOUR_SLOT',
    public.floor_capture(v_factory, v_user, 'hourly_upsert', jsonb_build_object(
      'orderId', v_order, 'departmentId', v_cut, 'count', 1)));

  INSERT INTO fc_test VALUES ('hourly INVALID_HOUR_SLOT', 'INVALID_HOUR_SLOT',
    public.floor_capture(v_factory, v_user, 'hourly_upsert', jsonb_build_object(
      'orderId', v_order, 'departmentId', v_cut, 'hourSlot', '08:00', 'count', 1)));

  INSERT INTO fc_test VALUES ('hourly INVALID_COUNT', 'INVALID_COUNT',
    public.floor_capture(v_factory, v_user, 'hourly_upsert', jsonb_build_object(
      'orderId', v_order, 'departmentId', v_cut, 'hourSlot', '10:00', 'count', -5)));

  INSERT INTO fc_test VALUES ('hourly BACKFILL_TOO_OLD', 'BACKFILL_TOO_OLD',
    public.floor_capture(v_factory, v_user, 'hourly_upsert', jsonb_build_object(
      'orderId', v_order, 'departmentId', v_cut, 'hourSlot', '10:00', 'count', 1,
      'logDate', (CURRENT_DATE - 30)::text)));

  INSERT INTO fc_test VALUES ('hourly OT_OUTPUT_WITHOUT_WORKFORCE', 'OT_OUTPUT_WITHOUT_WORKFORCE',
    public.floor_capture(v_factory, v_user, 'hourly_upsert', jsonb_build_object(
      'orderId', v_order, 'departmentId', v_cut, 'hourSlot', '17:30', 'count', 10,
      'logDate', CURRENT_DATE::text)));

  INSERT INTO fc_test VALUES ('hourly OK regular slot', 'OK',
    public.floor_capture(v_factory, v_user, 'hourly_upsert', jsonb_build_object(
      'orderId', v_order, 'departmentId', v_cut, 'colorwayId', v_cw,
      'hourSlot', '10:00', 'count', 50, 'logDate', CURRENT_DATE::text)));

  UPDATE public.profiles SET department_id = v_cut WHERE id = v_user;
  INSERT INTO fc_test VALUES ('inspection REQUIRE_APP_QC', 'REQUIRE_APP_QC',
    public.floor_capture(v_factory, v_user, 'inspection', jsonb_build_object(
      'orderId', v_order, 'departmentId', v_cut, 'result', 'pass')));

  UPDATE public.profiles SET department_id = v_sew WHERE id = v_user;
  INSERT INTO fc_test VALUES ('inspection INVALID_RESULT', 'INVALID_RESULT',
    public.floor_capture(v_factory, v_user, 'inspection', jsonb_build_object(
      'orderId', v_order, 'departmentId', v_sew, 'result', 'maybe')));

  INSERT INTO fc_test VALUES ('inspection OK pass', 'OK',
    public.floor_capture(v_factory, v_user, 'inspection', jsonb_build_object(
      'orderId', v_order, 'departmentId', v_sew, 'colorwayId', v_cw, 'result', 'pass')));

  UPDATE public.profiles SET department_id = v_cut WHERE id = v_user;
  INSERT INTO fc_test VALUES ('workforce EMPTY_HEADCOUNT', 'EMPTY_HEADCOUNT',
    public.floor_capture(v_factory, v_user, 'workforce_upsert', jsonb_build_object(
      'departmentId', v_cut, 'shiftId', v_reg_shift, 'logDate', CURRENT_DATE::text,
      'operators', 0, 'helpers', 0)));

  INSERT INTO fc_test VALUES ('workforce OK', 'OK',
    public.floor_capture(v_factory, v_user, 'workforce_upsert', jsonb_build_object(
      'departmentId', v_cut, 'shiftId', v_ot_shift, 'logDate', CURRENT_DATE::text,
      'operators', 5)));

  INSERT INTO fc_test VALUES ('hourly OT OK after workforce', 'OK',
    public.floor_capture(v_factory, v_user, 'hourly_upsert', jsonb_build_object(
      'orderId', v_order, 'departmentId', v_cut, 'colorwayId', v_cw,
      'hourSlot', '17:30', 'count', 10, 'logDate', CURRENT_DATE::text)));

  INSERT INTO fc_test VALUES ('handover OVERSENT', 'OVERSENT',
    public.floor_capture(v_factory, v_user, 'handover_send', jsonb_build_object(
      'orderId', v_order, 'fromDepartmentId', v_cut, 'toDepartmentId', v_sew,
      'colorwayId', v_cw, 'sentQty', 9999)));

  INSERT INTO fc_test VALUES ('handover INVALID_DESTINATION', 'INVALID_DESTINATION',
    public.floor_capture(v_factory, v_user, 'handover_send', jsonb_build_object(
      'orderId', v_order, 'fromDepartmentId', v_cut, 'toDepartmentId', v_qa,
      'colorwayId', v_cw, 'sentQty', 10)));

  INSERT INTO fc_test VALUES ('handover CANT_SEND_FROM_OTHER_DEPT', 'CANT_SEND_FROM_OTHER_DEPT',
    public.floor_capture(v_factory, v_user, 'handover_send', jsonb_build_object(
      'orderId', v_order, 'fromDepartmentId', v_sew, 'toDepartmentId', v_sew,
      'colorwayId', v_cw, 'sentQty', 10)));

  v_r := public.floor_capture(v_factory, v_user, 'handover_send', jsonb_build_object(
    'orderId', v_order, 'fromDepartmentId', v_cut, 'toDepartmentId', v_sew,
    'colorwayId', v_cw, 'sentQty', 40));
  INSERT INTO fc_test VALUES ('handover OK', 'OK', v_r);
  v_slip := (v_r->>'id')::uuid;

  UPDATE public.profiles SET department_id = v_sew WHERE id = v_user;
  INSERT INTO fc_test VALUES ('handover_receive OK', 'OK',
    public.floor_capture(v_factory, v_user, 'handover_receive', jsonb_build_object(
      'slipId', v_slip, 'receivedQty', 40)));

  INSERT INTO fc_test VALUES ('handover_receive SLIP_NOT_PENDING', 'SLIP_NOT_PENDING',
    public.floor_capture(v_factory, v_user, 'handover_receive', jsonb_build_object(
      'slipId', v_slip, 'receivedQty', 40)));

  UPDATE public.profiles SET department_id = v_cut WHERE id = v_user;
  INSERT INTO fc_test VALUES ('audit INVALID_LOT', 'INVALID_LOT',
    public.floor_capture(v_factory, v_user, 'audit_session', jsonb_build_object(
      'orderId', v_order, 'departmentId', v_cut,
      'lotSize', 0, 'sampleSize', 5, 'passed', 5, 'failed', 0)));

  UPDATE public.profiles
  SET department_id = v_qa, user_role = 'quality_manager', assigned_apps = '[]'::jsonb
  WHERE id = v_user;
  INSERT INTO fc_test VALUES ('rejection OK', 'OK',
    public.floor_capture(v_factory, v_user, 'rejection_log', jsonb_build_object(
      'orderId', v_order, 'colorwayId', v_cw, 'qty', 2, 'stage', 'inline')));

  UPDATE public.profiles
  SET department_id = NULL, assigned_apps = '["shipment_log"]'::jsonb
  WHERE id = v_user;
  INSERT INTO fc_test VALUES ('shipment OK', 'OK',
    public.floor_capture(v_factory, v_user, 'shipment_log', jsonb_build_object(
      'orderId', v_order, 'colorwayId', v_cw, 'shippedQty', 5, 'shipmentType', 'main')));

  UPDATE public.profiles
  SET department_id = v_ship, assigned_apps = '[]'::jsonb
  WHERE id = v_user;
  INSERT INTO fc_test VALUES ('shipment dept without app', 'APP_NOT_ALLOWED',
    public.floor_capture(v_factory, v_user, 'shipment_log', jsonb_build_object(
      'orderId', v_order, 'colorwayId', v_cw, 'shippedQty', 5, 'shipmentType', 'main')));

  INSERT INTO fc_test VALUES ('unknown type', 'UNKNOWN_CAPTURE_TYPE',
    public.floor_capture(v_factory, v_user, 'not_a_type', '{}'::jsonb));
END $$;

SELECT
  case_name,
  expect_code,
  COALESCE(actual->>'code', 'OK') AS got_code,
  pass
FROM fc_test
ORDER BY case_name;

SELECT
  count(*) FILTER (WHERE pass) AS passed,
  count(*) FILTER (WHERE NOT pass) AS failed,
  count(*) AS total
FROM fc_test;

ROLLBACK;
