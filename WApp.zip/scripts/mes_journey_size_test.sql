-- Rollback test: size-aware v_cut_to_ship_dept_journey + v_cut_to_ship.wip_qty_by_size
-- Factory 11111111-0000-0000-0000-000000000001
-- Order   008c2fab-1633-46e2-ac5a-9dc475640788 (4-dept flow: Cutting→Sewing→Printing→Finishing)
-- OFFWHITE 74997d27-a46a-45e2-8d5b-e5ed8a697efb | NAVY 4420e915-068f-48c9-b614-fa494b0515d9

BEGIN;

UPDATE public.style_orders SET adj_qty = 1000
WHERE id = '008c2fab-1633-46e2-ac5a-9dc475640788';

-- OFFWHITE: cut 950, ship 900, reject 30, wip 20
INSERT INTO public.hourly_counts (
  id, factory_id, order_id, colorway_id, department_id, hour_slot, log_date, count, logged_by
) VALUES
  ('cccccccc-0001-4000-8000-000000000001', '11111111-0000-0000-0000-000000000001',
   '008c2fab-1633-46e2-ac5a-9dc475640788', '74997d27-a46a-45e2-8d5b-e5ed8a697efb',
   '08c15b12-a298-4efc-ab61-e096edcc233b', '10:00', '2026-06-16', 500,
   '6cfa030c-b6c5-43cb-9d61-ccdb1234288c'),
  ('cccccccc-0002-4000-8000-000000000001', '11111111-0000-0000-0000-000000000001',
   '008c2fab-1633-46e2-ac5a-9dc475640788', '74997d27-a46a-45e2-8d5b-e5ed8a697efb',
   '08c15b12-a298-4efc-ab61-e096edcc233b', '11:00', '2026-06-16', 450,
   '6cfa030c-b6c5-43cb-9d61-ccdb1234288c');

INSERT INTO public.handover_slips (
  id, factory_id, order_id, colorway_id, from_department_id, to_department_id,
  sent_qty, qty_by_size, sent_by, sent_at, status
) VALUES (
  'cccccccc-0003-4000-8000-000000000001', '11111111-0000-0000-0000-000000000001',
  '008c2fab-1633-46e2-ac5a-9dc475640788', '74997d27-a46a-45e2-8d5b-e5ed8a697efb',
  '08c15b12-a298-4efc-ab61-e096edcc233b', '22834dc3-6c4f-41ec-b433-fa1666e3f261',
  950, '{"S":240,"M":240,"L":235,"XL":235}'::jsonb,
  '6cfa030c-b6c5-43cb-9d61-ccdb1234288c', '2026-06-16 14:00:00+00', 'pending'
);

INSERT INTO public.hourly_counts (
  id, factory_id, order_id, colorway_id, department_id, hour_slot, log_date, count, logged_by
) VALUES (
  'cccccccc-0004-4000-8000-000000000001', '11111111-0000-0000-0000-000000000001',
  '008c2fab-1633-46e2-ac5a-9dc475640788', '74997d27-a46a-45e2-8d5b-e5ed8a697efb',
  '22834dc3-6c4f-41ec-b433-fa1666e3f261', '10:00', '2026-06-16', 100,
  '6cfa030c-b6c5-43cb-9d61-ccdb1234288c'
);

INSERT INTO public.handover_slips (
  id, factory_id, order_id, colorway_id, from_department_id, to_department_id,
  sent_qty, qty_by_size, sent_by, sent_at, status
) VALUES (
  'cccccccc-0005-4000-8000-000000000001', '11111111-0000-0000-0000-000000000001',
  '008c2fab-1633-46e2-ac5a-9dc475640788', '74997d27-a46a-45e2-8d5b-e5ed8a697efb',
  '22834dc3-6c4f-41ec-b433-fa1666e3f261', 'ccedc6bc-6a1e-4101-843c-4f6ae3392efc',
  80, '{"S":20,"M":20,"L":20,"XL":20}'::jsonb,
  '6cfa030c-b6c5-43cb-9d61-ccdb1234288c', '2026-06-16 16:00:00+00', 'pending'
);

INSERT INTO public.rejections (
  id, factory_id, order_id, colorway_id, qty, size, reason_code, stage, rejected_date, logged_by
) VALUES
  ('cccccccc-0006-4000-8000-000000000001', '11111111-0000-0000-0000-000000000001',
   '008c2fab-1633-46e2-ac5a-9dc475640788', '74997d27-a46a-45e2-8d5b-e5ed8a697efb',
   10, 'S', 'Stained', 'inline', '2026-06-16', '6cfa030c-b6c5-43cb-9d61-ccdb1234288c'),
  ('cccccccc-0007-4000-8000-000000000001', '11111111-0000-0000-0000-000000000001',
   '008c2fab-1633-46e2-ac5a-9dc475640788', '74997d27-a46a-45e2-8d5b-e5ed8a697efb',
   10, 'M', 'Stained', 'inline', '2026-06-16', '6cfa030c-b6c5-43cb-9d61-ccdb1234288c'),
  ('cccccccc-0008-4000-8000-000000000001', '11111111-0000-0000-0000-000000000001',
   '008c2fab-1633-46e2-ac5a-9dc475640788', '74997d27-a46a-45e2-8d5b-e5ed8a697efb',
   10, 'L', 'Damaged', 'final_audit', '2026-06-16', '6cfa030c-b6c5-43cb-9d61-ccdb1234288c');

INSERT INTO public.shipments (
  id, factory_id, order_id, colorway_id, shipped_qty, shipped_qty_by_size, shipment_date, shipment_type, logged_by
) VALUES (
  'cccccccc-0009-4000-8000-000000000001', '11111111-0000-0000-0000-000000000001',
  '008c2fab-1633-46e2-ac5a-9dc475640788', '74997d27-a46a-45e2-8d5b-e5ed8a697efb',
  900, '{"S":225,"M":225,"L":225,"XL":225}'::jsonb,
  '2026-06-16', 'main', '6cfa030c-b6c5-43cb-9d61-ccdb1234288c'
);

-- NAVY BLU: cut 500, ship 460, reject 15, wip 25
INSERT INTO public.hourly_counts (
  id, factory_id, order_id, colorway_id, department_id, hour_slot, log_date, count, logged_by
) VALUES
  ('cccccccc-0011-4000-8000-000000000001', '11111111-0000-0000-0000-000000000001',
   '008c2fab-1633-46e2-ac5a-9dc475640788', '4420e915-068f-48c9-b614-fa494b0515d9',
   '08c15b12-a298-4efc-ab61-e096edcc233b', '10:00', '2026-06-16', 300,
   '6cfa030c-b6c5-43cb-9d61-ccdb1234288c'),
  ('cccccccc-0012-4000-8000-000000000001', '11111111-0000-0000-0000-000000000001',
   '008c2fab-1633-46e2-ac5a-9dc475640788', '4420e915-068f-48c9-b614-fa494b0515d9',
   '08c15b12-a298-4efc-ab61-e096edcc233b', '11:00', '2026-06-16', 200,
   '6cfa030c-b6c5-43cb-9d61-ccdb1234288c');

INSERT INTO public.handover_slips (
  id, factory_id, order_id, colorway_id, from_department_id, to_department_id,
  sent_qty, qty_by_size, sent_by, sent_at, status
) VALUES (
  'cccccccc-0013-4000-8000-000000000001', '11111111-0000-0000-0000-000000000001',
  '008c2fab-1633-46e2-ac5a-9dc475640788', '4420e915-068f-48c9-b614-fa494b0515d9',
  '08c15b12-a298-4efc-ab61-e096edcc233b', '22834dc3-6c4f-41ec-b433-fa1666e3f261',
  480, '{"S":120,"M":120,"L":120,"XL":120}'::jsonb,
  '6cfa030c-b6c5-43cb-9d61-ccdb1234288c', '2026-06-16 14:00:00+00', 'pending'
);

INSERT INTO public.handover_slips (
  id, factory_id, order_id, colorway_id, from_department_id, to_department_id,
  sent_qty, qty_by_size, sent_by, sent_at, status
) VALUES (
  'cccccccc-0015-4000-8000-000000000001', '11111111-0000-0000-0000-000000000001',
  '008c2fab-1633-46e2-ac5a-9dc475640788', '4420e915-068f-48c9-b614-fa494b0515d9',
  '22834dc3-6c4f-41ec-b433-fa1666e3f261', 'ccedc6bc-6a1e-4101-843c-4f6ae3392efc',
  25, '{"S":7,"M":6,"L":6,"XL":6}'::jsonb,
  '6cfa030c-b6c5-43cb-9d61-ccdb1234288c', '2026-06-16 16:00:00+00', 'pending'
);

INSERT INTO public.rejections (
  id, factory_id, order_id, colorway_id, qty, size, reason_code, stage, rejected_date, logged_by
) VALUES
  ('cccccccc-0016-4000-8000-000000000001', '11111111-0000-0000-0000-000000000001',
   '008c2fab-1633-46e2-ac5a-9dc475640788', '4420e915-068f-48c9-b614-fa494b0515d9',
   8, 'M', 'Stained', 'inline', '2026-06-16', '6cfa030c-b6c5-43cb-9d61-ccdb1234288c'),
  ('cccccccc-0017-4000-8000-000000000001', '11111111-0000-0000-0000-000000000001',
   '008c2fab-1633-46e2-ac5a-9dc475640788', '4420e915-068f-48c9-b614-fa494b0515d9',
   7, 'L', 'Stained', 'inline', '2026-06-16', '6cfa030c-b6c5-43cb-9d61-ccdb1234288c');

INSERT INTO public.shipments (
  id, factory_id, order_id, colorway_id, shipped_qty, shipped_qty_by_size, shipment_date, shipment_type, logged_by
) VALUES (
  'cccccccc-0018-4000-8000-000000000001', '11111111-0000-0000-0000-000000000001',
  '008c2fab-1633-46e2-ac5a-9dc475640788', '4420e915-068f-48c9-b614-fa494b0515d9',
  460, '{"S":115,"M":115,"L":115,"XL":115}'::jsonb,
  '2026-06-16', 'main', '6cfa030c-b6c5-43cb-9d61-ccdb1234288c'
);

-- Assertions
WITH journey AS (
  SELECT * FROM public.v_cut_to_ship_dept_journey
  WHERE order_id = '008c2fab-1633-46e2-ac5a-9dc475640788'
    AND colorway_id = '74997d27-a46a-45e2-8d5b-e5ed8a697efb'
),
in_flow_checks AS (
  SELECT
    dept_name,
    is_in_flow,
    status,
    qty_received = public.jsonb_sum_int_values(qty_received_by_size) AS recv_match,
    qty_sent = public.jsonb_sum_int_values(qty_sent_by_size) AS sent_match,
    qty_rejected = public.jsonb_sum_int_values(qty_rejected_by_size) AS rej_match,
    CASE
      WHEN dept_name = 'Cutting' THEN qty_produced = public.jsonb_sum_int_values(qty_produced_by_size)
      WHEN qty_produced_by_size IS NULL THEN true
      ELSE qty_produced = public.jsonb_sum_int_values(qty_produced_by_size)
         OR public.jsonb_sum_int_values(qty_produced_by_size) > 0
    END AS prod_ok,
    qty_received_by_size IS NULL AS recv_sz_null,
    qty_produced_by_size IS NULL AS prod_sz_null,
    qty_sent_by_size IS NULL AS sent_sz_null,
    qty_rejected_by_size IS NULL AS rej_sz_null,
    wip_qty_by_size IS NULL AS wip_sz_null
  FROM journey
),
out_of_flow AS (
  SELECT bool_and(
    NOT is_in_flow
    AND status = 'not_in_flow'
    AND qty_received_by_size IS NULL
    AND qty_produced_by_size IS NULL
    AND qty_sent_by_size IS NULL
    AND qty_rejected_by_size IS NULL
    AND wip_qty_by_size IS NULL
  ) AS all_null_oof
  FROM journey
  WHERE dept_name IN ('Quality Audit', 'Shipment')
),
recon AS (
  SELECT * FROM public.v_cut_to_ship
  WHERE order_id = '008c2fab-1633-46e2-ac5a-9dc475640788'
    AND colorway_id = '74997d27-a46a-45e2-8d5b-e5ed8a697efb'
)
SELECT jsonb_build_object(
  'in_flow_depts', (SELECT COUNT(*)::int FROM journey WHERE is_in_flow),
  'in_flow_size_checks', (SELECT jsonb_agg(to_jsonb(in_flow_checks) ORDER BY dept_name) FROM in_flow_checks WHERE is_in_flow),
  'out_of_flow_ok', (SELECT all_null_oof FROM out_of_flow),
  'offwhite_recon', (SELECT to_jsonb(recon) FROM recon),
  'wip_by_size_nonempty', (SELECT wip_qty_by_size <> '{}'::jsonb FROM recon),
  'wip_scalar_matches_size_sum', (
    SELECT wip_qty = public.jsonb_sum_int_values(wip_qty_by_size) FROM recon
  ),
  'journey_rpc_count', (
    SELECT COUNT(*)::int FROM public.get_cut_to_ship_journey(
      '11111111-0000-0000-0000-000000000001',
      '008c2fab-1633-46e2-ac5a-9dc475640788'
    )
  ),
  'two_colorways', (
    SELECT COUNT(DISTINCT colorway_id)::int FROM journey WHERE is_in_flow
  )
) AS test_results;

ROLLBACK;
