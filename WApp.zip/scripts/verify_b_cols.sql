SELECT table_name, column_name FROM information_schema.columns
WHERE table_schema='public'
  AND (
    (table_name='departments' AND column_name IN ('is_production','worker_roles')) OR
    (table_name='inspections' AND column_name='colorway_id') OR
    (table_name='handover_slips' AND column_name IN ('colorway_id','qty_by_size','received_qty_by_size')) OR
    (table_name='shipments' AND column_name='shipped_qty_by_size') OR
    (table_name='hourly_counts' AND column_name='count_by_size') OR
    (table_name='workforce_logs' AND column_name='headcount_by_category') OR
    (table_name='shifts' AND column_name='productive_mins')
  )
ORDER BY table_name, column_name;
