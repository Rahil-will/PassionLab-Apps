-- Run on existing Supabase project if profiles.activity_name already exists
ALTER TABLE public.profiles DROP COLUMN IF EXISTS activity_name;

-- Recreate floor RPCs without activity_name (copy from schema.sql if needed)
