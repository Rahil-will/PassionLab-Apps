-- Rollback-style test for Phase 3 reporting views (8 cases × Regular/OT).
-- Run in a transaction; ROLLBACK at end leaves live DB unchanged.

BEGIN;

-- Test fixtures
-- factory  11111111-0000-0000-0000-000000000001
-- dept     08c15b12-a298-4efc-ab61-e096edcc233b (Cutting, hourly)
-- order    008c2fab-1633-46e2-ac5a-9dc475640788
-- regular  3a8b5dba-2d63-45e7-bfd6-c14b67833f29
-- ot       02d43a0c-f11e-4570-9b8b-d4bdac5df7d8
-- profile  6cfa030c-b6c5-43cb-9d61-ccdb1234288c

INSERT INTO public.line_allocations (
  id, factory_id, order_id, department_id, qty, daily_target,
  start_date, end_date, completed_is_true, status
) VALUES (
  'aaaaaaaa-0001-4000-8000-000000000001',
  '11111111-0000-0000-0000-000000000001',
  '008c2fab-1633-46e2-ac5a-9dc475640788',
  '08c15b12-a298-4efc-ab61-e096edcc233b',
  1000, 480, '2026-06-01', '2026-06-30', false, 'planned'
);

-- Regular shift cases
INSERT INTO public.workforce_logs (id, factory_id, department_id, shift_id, log_date, operators, helpers, supervisors, trainees, logged_by)
VALUES
  ('aaaaaaaa-0101-4000-8000-000000000001', '11111111-0000-0000-0000-000000000001', '08c15b12-a298-4efc-ab61-e096edcc233b', '3a8b5dba-2d63-45e7-bfd6-c14b67833f29', '2026-06-01', 10, 0, 0, 0, '6cfa030c-b6c5-43cb-9d61-ccdb1234288c'),
  ('aaaaaaaa-0102-4000-8000-000000000001', '11111111-0000-0000-0000-000000000001', '08c15b12-a298-4efc-ab61-e096edcc233b', '3a8b5dba-2d63-45e7-bfd6-c14b67833f29', '2026-06-02', 8, 0, 0, 0, '6cfa030c-b6c5-43cb-9d61-ccdb1234288c');

-- hour_slot = active slot start from shifts.hours; stored shift_id intentionally wrong on 06-01 (views re-resolve)
INSERT INTO public.hourly_counts (id, factory_id, order_id, department_id, shift_id, hour_slot, log_date, count, logged_by)
VALUES
  ('aaaaaaaa-0201-4000-8000-000000000001', '11111111-0000-0000-0000-000000000001', '008c2fab-1633-46e2-ac5a-9dc475640788', '08c15b12-a298-4efc-ab61-e096edcc233b', '02d43a0c-f11e-4570-9b8b-d4bdac5df7d8', '10:00', '2026-06-01', 100, '6cfa030c-b6c5-43cb-9d61-ccdb1234288c'),
  ('aaaaaaaa-0203-4000-8000-000000000001', '11111111-0000-0000-0000-000000000001', '008c2fab-1633-46e2-ac5a-9dc475640788', '08c15b12-a298-4efc-ab61-e096edcc233b', NULL, '10:00', '2026-06-03', 50, '6cfa030c-b6c5-43cb-9d61-ccdb1234288c');

-- OT shift cases
INSERT INTO public.workforce_logs (id, factory_id, department_id, shift_id, log_date, operators, helpers, supervisors, trainees, logged_by)
VALUES
  ('aaaaaaaa-0501-4000-8000-000000000001', '11111111-0000-0000-0000-000000000001', '08c15b12-a298-4efc-ab61-e096edcc233b', '02d43a0c-f11e-4570-9b8b-d4bdac5df7d8', '2026-06-05', 5, 0, 0, 0, '6cfa030c-b6c5-43cb-9d61-ccdb1234288c'),
  ('aaaaaaaa-0502-4000-8000-000000000001', '11111111-0000-0000-0000-000000000001', '08c15b12-a298-4efc-ab61-e096edcc233b', '02d43a0c-f11e-4570-9b8b-d4bdac5df7d8', '2026-06-06', 4, 0, 0, 0, '6cfa030c-b6c5-43cb-9d61-ccdb1234288c');

INSERT INTO public.hourly_counts (id, factory_id, order_id, department_id, shift_id, hour_slot, log_date, count, logged_by)
VALUES
  ('aaaaaaaa-0605-4000-8000-000000000001', '11111111-0000-0000-0000-000000000001', '008c2fab-1633-46e2-ac5a-9dc475640788', '08c15b12-a298-4efc-ab61-e096edcc233b', NULL, '17:30', '2026-06-05', 30, '6cfa030c-b6c5-43cb-9d61-ccdb1234288c'),
  ('aaaaaaaa-0607-4000-8000-000000000001', '11111111-0000-0000-0000-000000000001', '008c2fab-1633-46e2-ac5a-9dc475640788', '08c15b12-a298-4efc-ab61-e096edcc233b', NULL, '17:30', '2026-06-07', 40, '6cfa030c-b6c5-43cb-9d61-ccdb1234288c');

-- Snapshot before OT back-fill (2026-06-07)
CREATE TEMP TABLE kpi_before_backfill AS
SELECT log_date, shift_name, data_completeness, shift_output, shift_headcount,
       shift_efficiency_pct, shift_productivity
FROM public.v_daily_kpis_by_shift
WHERE department_id = '08c15b12-a298-4efc-ab61-e096edcc233b'
  AND log_date = '2026-06-07';

-- Back-fill workforce for prior date (logged "next day")
INSERT INTO public.workforce_logs (id, factory_id, department_id, shift_id, log_date, operators, helpers, supervisors, trainees, logged_by, logged_at)
VALUES (
  'aaaaaaaa-0707-4000-8000-000000000001',
  '11111111-0000-0000-0000-000000000001',
  '08c15b12-a298-4efc-ab61-e096edcc233b',
  '02d43a0c-f11e-4570-9b8b-d4bdac5df7d8',
  '2026-06-07', 6, 0, 0, 0,
  '6cfa030c-b6c5-43cb-9d61-ccdb1234288c',
  '2026-06-08 08:00:00+00'
);

CREATE TEMP TABLE kpi_after_backfill AS
SELECT log_date, shift_name, data_completeness, shift_output, shift_headcount,
       shift_efficiency_pct, shift_productivity
FROM public.v_daily_kpis_by_shift
WHERE department_id = '08c15b12-a298-4efc-ab61-e096edcc233b'
  AND log_date = '2026-06-07';

-- Single JSON result (execute_sql returns one result set)
SELECT jsonb_build_object(
  'by_shift', (
    SELECT COALESCE(jsonb_agg(jsonb_build_object(
      'log_date', log_date, 'shift_name', shift_name, 'data_completeness', data_completeness,
      'shift_output', shift_output, 'shift_headcount', shift_headcount,
      'shift_efficiency_pct', shift_efficiency_pct, 'shift_productivity', shift_productivity
    ) ORDER BY log_date, shift_name), '[]'::jsonb)
    FROM public.v_daily_kpis_by_shift
    WHERE department_id = '08c15b12-a298-4efc-ab61-e096edcc233b'
      AND log_date BETWEEN '2026-06-01' AND '2026-06-08'
  ),
  'daily', (
    SELECT COALESCE(jsonb_agg(jsonb_build_object(
      'log_date', log_date, 'day_completeness', day_completeness, 'daily_output', daily_output,
      'daily_available_mins', daily_available_mins, 'daily_efficiency_pct', daily_efficiency_pct,
      'daily_productivity', daily_productivity
    ) ORDER BY log_date), '[]'::jsonb)
    FROM public.v_daily_kpis
    WHERE department_id = '08c15b12-a298-4efc-ab61-e096edcc233b'
      AND log_date BETWEEN '2026-06-01' AND '2026-06-08'
  ),
  'backfill_before', (SELECT COALESCE(jsonb_agg(to_jsonb(b)), '[]'::jsonb) FROM kpi_before_backfill b),
  'backfill_after', (SELECT COALESCE(jsonb_agg(to_jsonb(a)), '[]'::jsonb) FROM kpi_after_backfill a),
  'neither_regular', NOT EXISTS (
    SELECT 1 FROM public.v_daily_kpis_by_shift
    WHERE department_id = '08c15b12-a298-4efc-ab61-e096edcc233b' AND log_date = '2026-06-04'
  ),
  'neither_ot', NOT EXISTS (
    SELECT 1 FROM public.v_daily_kpis_by_shift
    WHERE department_id = '08c15b12-a298-4efc-ab61-e096edcc233b' AND log_date = '2026-06-08'
  )
) AS test_results;

ROLLBACK;
