SELECT count(*) AS view_count FROM pg_views WHERE schemaname='public';

SELECT viewname FROM pg_views WHERE schemaname='public' ORDER BY viewname;

SELECT column_name FROM information_schema.columns
WHERE table_schema='public' AND table_name='v_cut_to_ship_dept_journey'
  AND column_name LIKE '%_by_size'
ORDER BY column_name;
