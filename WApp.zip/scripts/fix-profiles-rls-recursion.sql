-- Run in Supabase SQL Editor if login returns 500 on profiles fetch.
-- Cause: current_factory_id() read profiles inside profiles RLS → infinite recursion.

CREATE OR REPLACE FUNCTION public.current_factory_id()
RETURNS uuid
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT p.factory_id
  FROM public.profiles p
  WHERE p.id = auth.uid()
$$;

CREATE OR REPLACE FUNCTION public.is_factory_admin()
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.profiles p
    WHERE p.id = auth.uid() AND p.user_role IN ('admin', 'superadmin')
  )
$$;

CREATE OR REPLACE FUNCTION public.get_my_profile()
RETURNS jsonb
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT to_jsonb(p)
  FROM public.profiles p
  WHERE p.id = auth.uid()
  LIMIT 1
$$;

REVOKE ALL ON FUNCTION public.current_factory_id() FROM PUBLIC;
REVOKE ALL ON FUNCTION public.is_factory_admin() FROM PUBLIC;
REVOKE ALL ON FUNCTION public.get_my_profile() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.current_factory_id() TO authenticated;
GRANT EXECUTE ON FUNCTION public.is_factory_admin() TO authenticated;
GRANT EXECUTE ON FUNCTION public.get_my_profile() TO authenticated;

DROP POLICY IF EXISTS profiles_insert_factory_admin ON public.profiles;
CREATE POLICY profiles_insert_factory_admin ON public.profiles
  FOR INSERT TO authenticated
  WITH CHECK (
    factory_id = public.current_factory_id()
    AND public.is_factory_admin()
  );

DROP POLICY IF EXISTS profiles_delete_factory_admin ON public.profiles;
CREATE POLICY profiles_delete_factory_admin ON public.profiles
  FOR DELETE TO authenticated
  USING (
    factory_id = public.current_factory_id()
    AND id <> auth.uid()
    AND public.is_factory_admin()
  );
