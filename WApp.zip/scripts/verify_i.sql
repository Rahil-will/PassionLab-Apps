SELECT public.floor_capture(
  NULL::uuid, NULL::uuid, 'unknown'::text, '{}'::jsonb
) AS session_test;
