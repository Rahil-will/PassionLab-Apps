SELECT factory_id, name, is_production, apps 
FROM departments 
WHERE name IN ('Quality Audit','Shipment')
ORDER BY factory_id, name;

SELECT factory_id, category, jsonb_array_length(values) AS reason_count
FROM support_dropdowns 
WHERE category='rejection_reasons';

SELECT name, type, productive_mins, hours 
FROM shifts ORDER BY name;
