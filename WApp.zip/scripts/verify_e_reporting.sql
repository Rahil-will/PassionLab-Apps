SELECT proname FROM pg_proc p
JOIN pg_namespace n ON n.oid = p.pronamespace
WHERE n.nspname='public'
  AND has_function_privilege('anon', p.oid, 'EXECUTE')
  AND p.proname IN (
    'get_factory_kpis','get_department_kpis','get_department_kpis_by_shift',
    'get_style_kpis','get_order_wip','get_audit_report','get_cut_to_ship_report',
    'get_cut_to_ship_detail','get_cut_to_ship_journey','get_live_dept_kpi',
    'get_today_rejections_for_order','get_dept_quality_for_date',
    'get_order_dept_progress','get_pseudo_dept_daily_summary'
  );
