-- =============================================================================
-- get_factory_kpis — verify install
-- =============================================================================
-- Install (recommended):
--   npx supabase db push
--
-- Migration file:
--   supabase/migrations/20260618100000_mes_factory_kpis_reporting.sql
--
-- App caller:
--   lib/mesReportsApi.ts → supabase.rpc('get_factory_kpis', { p_factory_id, p_date_from, p_date_to })
-- =============================================================================

-- Function registered?
SELECT
  p.proname AS function_name,
  pg_get_function_identity_arguments(p.oid) AS arguments
FROM pg_proc p
JOIN pg_namespace n ON n.oid = p.pronamespace
WHERE n.nspname = 'public'
  AND p.proname = 'get_factory_kpis';

-- Views present?
SELECT table_name
FROM information_schema.views
WHERE table_schema = 'public'
  AND table_name IN ('v_daily_kpis', 'v_daily_kpis_by_shift', 'v_daily_quality')
ORDER BY table_name;

-- Sample call — replace UUID and dates
SELECT
  factory_id,
  order_id,
  department_id,
  log_date,
  daily_target,
  daily_output,
  daily_efficiency_pct,
  day_completeness,
  dhu,
  wip_qty
FROM public.get_factory_kpis(
  '11111111-0000-0000-0000-000000000001'::uuid,
  CURRENT_DATE - 14,
  CURRENT_DATE
)
LIMIT 20;
