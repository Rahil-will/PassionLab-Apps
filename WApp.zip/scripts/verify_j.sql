WITH fn AS (
  SELECT pg_get_functiondef(
    'public.floor_capture(uuid,uuid,text,jsonb)'::regprocedure
  ) AS def
)
SELECT 
  def ILIKE '%headcount_by_category%' AS has_workforce_jsonb,
  def ILIKE '%wl.operators%' AS still_has_legacy_wl_ref,
  def ILIKE '%(p_payload->>''operators'')%' AS still_has_legacy_payload_ref,
  def ILIKE '%count_by_size%' AS has_count_by_size,
  def ILIKE '%profile_has_capture_app%' AS has_capture_auth,
  def ILIKE '%SIZE_TOTAL_MISMATCH%' AS has_size_validation,
  def ILIKE '%rejection_log%' AS has_rejection_capture,
  def ILIKE '%shipment_log%' AS has_shipment_capture
FROM fn;
