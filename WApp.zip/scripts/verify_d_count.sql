SELECT count(*) AS fn_count FROM pg_proc 
WHERE pronamespace='public'::regnamespace AND prokind='f';
