-- MES reporting RPC smoke test (read-only)
-- Factory 11111111-0000-0000-0000-000000000001
-- Cutting 08c15b12-a298-4efc-ab61-e096edcc233b
-- Order   008c2fab-1633-46e2-ac5a-9dc475640788

-- -----------------------------------------------------------------------------
-- get_factory_kpis — primary Reports RPC (lib/mesReportsApi.ts)
-- -----------------------------------------------------------------------------
SELECT
  log_date,
  department_id,
  order_id,
  daily_target,
  daily_output,
  daily_efficiency_pct,
  day_completeness,
  dhu,
  wip_qty
FROM public.get_factory_kpis(
  '11111111-0000-0000-0000-000000000001',
  '2026-06-01',
  '2026-06-08'
)
ORDER BY log_date, department_id, order_id;

-- -----------------------------------------------------------------------------
-- All reporting RPCs (compact JSON summary)
-- -----------------------------------------------------------------------------
SELECT jsonb_build_object(
  'get_factory_kpis', (
    SELECT COALESCE(jsonb_agg(jsonb_build_object(
      'log_date', log_date,
      'department_id', department_id,
      'order_id', order_id,
      'daily_output', daily_output,
      'daily_target', daily_target,
      'day_completeness', day_completeness
    )), '[]'::jsonb)
    FROM public.get_factory_kpis(
      '11111111-0000-0000-0000-000000000001', '2026-06-01', '2026-06-08'
    )
  ),
  'get_department_kpis', (
    SELECT COALESCE(jsonb_agg(jsonb_build_object(
      'log_date', log_date, 'order_id', order_id, 'daily_output', daily_output
    )), '[]'::jsonb)
    FROM public.get_department_kpis(
      '11111111-0000-0000-0000-000000000001',
      '08c15b12-a298-4efc-ab61-e096edcc233b',
      '2026-06-01', '2026-06-08'
    )
  ),
  'get_department_kpis_by_shift', (
    SELECT COALESCE(jsonb_agg(jsonb_build_object(
      'log_date', log_date, 'shift_name', shift_name, 'shift_output', shift_output
    )), '[]'::jsonb)
    FROM public.get_department_kpis_by_shift(
      '11111111-0000-0000-0000-000000000001',
      '08c15b12-a298-4efc-ab61-e096edcc233b',
      '2026-06-01', '2026-06-08'
    )
  ),
  'get_style_kpis', (
    SELECT COALESCE(jsonb_agg(jsonb_build_object(
      'log_date', log_date, 'department_id', department_id, 'daily_output', daily_output
    )), '[]'::jsonb)
    FROM public.get_style_kpis(
      '11111111-0000-0000-0000-000000000001',
      '008c2fab-1633-46e2-ac5a-9dc475640788'
    )
  ),
  'get_order_wip', (
    SELECT COALESCE(jsonb_agg(jsonb_build_object(
      'colorway_id', colorway_id, 'department_id', department_id, 'wip_qty', wip_qty
    )), '[]'::jsonb)
    FROM public.get_order_wip(
      '11111111-0000-0000-0000-000000000001',
      '008c2fab-1633-46e2-ac5a-9dc475640788'
    )
  ),
  'get_cut_to_ship_report', (
    SELECT COALESCE(jsonb_agg(jsonb_build_object(
      'order_id', order_id, 'colorway_id', colorway_id, 'cut_qty', cut_qty, 'is_balanced', is_balanced
    )), '[]'::jsonb)
    FROM public.get_cut_to_ship_report('11111111-0000-0000-0000-000000000001')
  ),
  'get_live_dept_kpi', (
    SELECT COALESCE(jsonb_agg(jsonb_build_object(
      'order_id', order_id, 'daily_output', daily_output
    )), '[]'::jsonb)
    FROM public.get_live_dept_kpi(
      '11111111-0000-0000-0000-000000000001',
      '08c15b12-a298-4efc-ab61-e096edcc233b'
    )
  )
) AS rpc_test_results;
