SELECT count(*) AS table_count FROM information_schema.tables 
WHERE table_schema='public' 
  AND table_name IN (
    'rejections','shipments','order_department_mode',
    'departments','shifts','workers','workforce_logs',
    'hourly_counts','inspections','handover_slips',
    'attendance_records','audit_sessions'
  );
