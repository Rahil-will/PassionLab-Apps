-- =============================================================================
-- PRODIGI — create one floor (mobile) user for a factory (RBC / onboarding app)
--
-- Prerequisite:
--   1. Factory exists (factories.code)
--   2. Department exists with desired apps in departments.apps
--   3. Auth user created (Dashboard → Users → Add user) OR onboarding API
--      Use synthetic email: floor.<employee-id>.<factory-code>@prodigi.local
--
-- assigned_apps MUST be a subset of that department's apps column.
-- Example: Sewing has ["transaction","qc_log","audit"] → user can have QC only,
-- audit only, or both (+ transaction).
-- =============================================================================

-- Replace placeholders:
--   AUTH_USER_UUID, FACTORY_CODE, DEPT_NAME, EMPLOYEE_ID, FLOOR_PIN
--   ASSIGNED_APPS_JSON e.g. '["transaction","qc_log"]'

INSERT INTO public.profiles (
  id,
  factory_id,
  full_name,
  email,
  user_role,
  department_id,
  employee_id,
  floor_pin,
  assigned_apps,
  status
)
SELECT
  'AUTH_USER_UUID'::uuid,
  f.id,
  'Floor Operator Name',
  'floor.employee-id.factory-code@prodigi.local',
  'operator',
  d.id,
  'EMP-001',
  '1234',
  '["transaction","qc_log"]'::jsonb,
  'Active'
FROM public.factories f
JOIN public.departments d ON d.factory_id = f.id AND d.name = 'Sewing'
WHERE f.code = 'acme-garments-a1b2'
ON CONFLICT (id) DO UPDATE SET
  factory_id = EXCLUDED.factory_id,
  full_name = EXCLUDED.full_name,
  user_role = EXCLUDED.user_role,
  department_id = EXCLUDED.department_id,
  employee_id = EXCLUDED.employee_id,
  floor_pin = EXCLUDED.floor_pin,
  assigned_apps = EXCLUDED.assigned_apps,
  status = EXCLUDED.status;

-- Verify
SELECT p.full_name, p.employee_id, p.user_role, p.assigned_apps, d.name AS department, f.code
FROM public.profiles p
JOIN public.factories f ON f.id = p.factory_id
LEFT JOIN public.departments d ON d.id = p.department_id
WHERE p.employee_id = 'EMP-001' AND f.code = 'acme-garments-a1b2';
