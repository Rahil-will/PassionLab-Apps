SELECT count(*) AS view_count FROM pg_views WHERE schemaname='public';
