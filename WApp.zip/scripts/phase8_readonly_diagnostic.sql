-- Read-only Phase 8 / 9.5 schema diagnostic (xtfljldeceonqyzgkoyp)

\echo '=== 1. schema_migrations ==='
SELECT version, name FROM supabase_migrations.schema_migrations ORDER BY version;

\echo '=== 2. hourly_counts columns ==='
SELECT column_name FROM information_schema.columns
WHERE table_schema='public' AND table_name='hourly_counts'
ORDER BY ordinal_position;

\echo '=== 3. handover_slips columns ==='
SELECT column_name FROM information_schema.columns
WHERE table_schema='public' AND table_name='handover_slips'
ORDER BY ordinal_position;

\echo '=== 4. shipments columns ==='
SELECT column_name FROM information_schema.columns
WHERE table_schema='public' AND table_name='shipments'
ORDER BY ordinal_position;

\echo '=== 5. public views ==='
SELECT viewname FROM pg_views WHERE schemaname='public' ORDER BY viewname;

\echo '=== 6. v_cut_to_ship_dept_journey columns ==='
SELECT column_name FROM information_schema.columns
WHERE table_schema='public' AND table_name='v_cut_to_ship_dept_journey'
ORDER BY ordinal_position;

\echo '=== 7. public functions ==='
SELECT routine_name FROM information_schema.routines
WHERE routine_schema='public' AND routine_type='FUNCTION'
ORDER BY routine_name;

\echo '=== 8. get_* and floor_capture ACLs ==='
SELECT proname, proacl FROM pg_proc
WHERE pronamespace='public'::regnamespace
  AND (proname LIKE 'get_%' OR proname = 'floor_capture')
ORDER BY proname;
