-- CHECK A
SELECT count(*) AS table_count FROM information_schema.tables 
WHERE table_schema='public' 
  AND table_name IN (
    'rejections','shipments','order_department_mode',
    'departments','shifts','workers','workforce_logs',
    'hourly_counts','inspections','handover_slips',
    'attendance_records','audit_sessions'
  );

-- CHECK B columns present
SELECT table_name, column_name FROM information_schema.columns
WHERE table_schema='public'
  AND (
    (table_name='departments' AND column_name IN ('is_production','worker_roles')) OR
    (table_name='inspections' AND column_name='colorway_id') OR
    (table_name='handover_slips' AND column_name IN ('colorway_id','qty_by_size','received_qty_by_size')) OR
    (table_name='shipments' AND column_name='shipped_qty_by_size') OR
    (table_name='hourly_counts' AND column_name='count_by_size') OR
    (table_name='workforce_logs' AND column_name='headcount_by_category') OR
    (table_name='shifts' AND column_name='productive_mins')
  )
ORDER BY table_name, column_name;

-- CHECK B legacy gone
SELECT count(*) AS legacy_workforce_cols FROM information_schema.columns
WHERE table_schema='public' AND table_name='workforce_logs'
  AND column_name IN ('operators','helpers','supervisors','trainees');

-- CHECK C views
SELECT count(*) AS view_count, array_agg(viewname ORDER BY viewname) AS views
FROM pg_views WHERE schemaname='public';

-- CHECK C journey size columns
SELECT column_name FROM information_schema.columns
WHERE table_schema='public' AND table_name='v_cut_to_ship_dept_journey'
  AND column_name LIKE '%_by_size'
ORDER BY column_name;

-- CHECK D function count
SELECT count(*) AS fn_count FROM pg_proc 
WHERE pronamespace='public'::regnamespace AND prokind='f';

-- CHECK D required functions
SELECT proname FROM pg_proc p
JOIN pg_namespace n ON n.oid = p.pronamespace
WHERE n.nspname='public' AND p.prokind='f'
  AND proname IN (
    'get_factory_kpis','get_department_kpis','get_department_kpis_by_shift',
    'get_style_kpis','get_order_wip','get_audit_report','get_cut_to_ship_report',
    'get_cut_to_ship_detail','get_cut_to_ship_journey','get_live_dept_kpi',
    'get_today_rejections_for_order','get_dept_quality_for_date',
    'get_order_dept_progress','get_pseudo_dept_daily_summary',
    'floor_capture','floor_capture_fail','profile_dept_has_app','profile_has_capture_app'
  )
ORDER BY proname;

-- CHECK E anon grants on reporting RPCs
SELECT proname FROM pg_proc p
JOIN pg_namespace n ON n.oid = p.pronamespace
WHERE n.nspname='public'
  AND has_function_privilege('anon', p.oid, 'EXECUTE')
  AND p.proname LIKE 'get_%'
  AND p.proname NOT IN ('get_floor_bootstrap','get_floor_users','get_my_profile');

-- CHECK F pseudo-depts
SELECT factory_id, name, is_production, apps 
FROM departments 
WHERE name IN ('Quality Audit','Shipment')
ORDER BY factory_id, name;

-- CHECK G rejection reasons
SELECT factory_id, category, jsonb_array_length(values) AS reason_count
FROM support_dropdowns 
WHERE category='rejection_reasons';

-- CHECK H shifts productive_mins
SELECT name, type, productive_mins, hours 
FROM shifts ORDER BY name;

-- CHECK I floor_capture session error
SELECT public.floor_capture(
  NULL::uuid, NULL::uuid, 'unknown'::text, '{}'::jsonb
) AS session_test;

-- CHECK J floor_capture body
WITH fn AS (
  SELECT pg_get_functiondef(
    'public.floor_capture(uuid,uuid,text,jsonb)'::regprocedure
  ) AS def
)
SELECT 
  def ILIKE '%headcount_by_category%' AS has_workforce_jsonb,
  def ILIKE '%wl.operators%' AS still_has_legacy_wl_ref,
  def ILIKE '%(p_payload->>''operators'')%' AS still_has_legacy_payload_ref,
  def ILIKE '%count_by_size%' AS has_count_by_size,
  def ILIKE '%profile_has_capture_app%' AS has_capture_auth,
  def ILIKE '%SIZE_TOTAL_MISMATCH%' AS has_size_validation,
  def ILIKE '%rejection_log%' AS has_rejection_capture,
  def ILIKE '%shipment_log%' AS has_shipment_capture
FROM fn;
