SELECT factory_id, category, jsonb_array_length(values) AS reason_count
FROM support_dropdowns 
WHERE category='rejection_reasons';
