/**
 * Assembles supabase/migrations/20260616100000_phase9_5_catchup.sql
 */
import fs from 'fs'
import path from 'path'
import { fileURLToPath } from 'url'

const __dirname = path.dirname(fileURLToPath(import.meta.url))
const migDir = path.join(path.dirname(__dirname), 'supabase', 'migrations')
const outPath = path.join(migDir, '20260616100000_phase9_5_catchup.sql')

function read(name) {
  return fs.readFileSync(path.join(migDir, name), 'utf8')
}

function stripFromDoBlock(sql) {
  const marker = '\nDO $$\nDECLARE\n  def text;'
  const idx = sql.indexOf(marker)
  if (idx < 0) {
    const alt = '\nDO $$\nDECLARE'
    const idx2 = sql.indexOf(alt)
    if (idx2 < 0) return sql.trim()
    return sql.slice(0, idx2).trim()
  }
  return sql.slice(0, idx).trim()
}

function stripDropWorkforceCols(sql) {
  return sql
    .replace(/\nALTER TABLE public\.workforce_logs DROP COLUMN IF EXISTS operators;\n?/g, '\n')
    .replace(/\nALTER TABLE public\.workforce_logs DROP COLUMN IF EXISTS helpers;\n?/g, '\n')
    .replace(/\nALTER TABLE public\.workforce_logs DROP COLUMN IF EXISTS supervisors;\n?/g, '\n')
    .replace(/\nALTER TABLE public\.workforce_logs DROP COLUMN IF EXISTS trainees;\n?/g, '\n')
    .trim()
}

function patchCutToShipSeeds(sql) {
  return sql
    .replace(
      /INSERT INTO public\.departments \(factory_id, name, sequence, is_production, apps\)\s*SELECT f\.id, 'Quality Audit', 98, false, '\["transaction","final_rejection_log"\]'::jsonb\s*FROM public\.factories f\s*WHERE NOT EXISTS \(\s*SELECT 1 FROM public\.departments d\s*WHERE d\.factory_id = f\.id AND d\.name = 'Quality Audit'\s*\);/s,
      `INSERT INTO public.departments (factory_id, name, sequence, is_production, apps)
SELECT f.id, 'Quality Audit', 98, false, '["transaction","final_rejection_log"]'::jsonb
FROM public.factories f
ON CONFLICT (factory_id, name) DO NOTHING;`
    )
    .replace(
      /INSERT INTO public\.departments \(factory_id, name, sequence, is_production, apps\)\s*SELECT f\.id, 'Shipment', 99, false, '\["transaction","shipment_log"\]'::jsonb\s*FROM public\.factories f\s*WHERE NOT EXISTS \(\s*SELECT 1 FROM public\.departments d\s*WHERE d\.factory_id = f\.id AND d\.name = 'Shipment'\s*\);/s,
      `INSERT INTO public.departments (factory_id, name, sequence, is_production, apps)
SELECT f.id, 'Shipment', 99, false, '["transaction","shipment_log"]'::jsonb
FROM public.factories f
ON CONFLICT (factory_id, name) DO NOTHING;`
    )
    .replace(
      /INSERT INTO public\.support_dropdowns \(factory_id, category, values\)\s*SELECT f\.id, 'rejection_reasons',\s*'\["Stained","Damaged","Wrong measurement","Color mismatch","Construction defect","Buyer audit fail","Pattern issue","Print\/Embroidery defect","Other"\]'::jsonb\s*FROM public\.factories f\s*WHERE NOT EXISTS \(\s*SELECT 1 FROM public\.support_dropdowns sd\s*WHERE sd\.factory_id = f\.id AND sd\.category = 'rejection_reasons'\s*\);/s,
      `INSERT INTO public.support_dropdowns (factory_id, category, values)
SELECT f.id, 'rejection_reasons',
  '["Stained","Damaged","Wrong measurement","Color mismatch","Construction defect","Buyer audit fail","Pattern issue","Print/Embroidery defect","Other"]'::jsonb
FROM public.factories f
ON CONFLICT (factory_id, category) DO NOTHING;`
    )
}

function extractDoBlock(sql) {
  const marker = '\nDO $$\nDECLARE\n  def text;'
  const idx = sql.indexOf(marker)
  if (idx < 0) return ''
  const end = sql.indexOf('\nEND $$;', idx)
  if (end < 0) return ''
  return sql.slice(idx, end + '\nEND $$;'.length).trim()
}

function stripFloorCaptureBody(sql) {
  const idx = sql.indexOf('CREATE OR REPLACE FUNCTION public.floor_capture(')
  if (idx < 0) return sql.trim()
  return sql.slice(0, idx).trim()
}

function profileDeptHasAppOnly() {
  const full = read('20260611110000_floor_capture_rejection_shipment.sql')
  const end = full.indexOf('CREATE OR REPLACE FUNCTION public.floor_capture')
  return full.slice(0, end).trim()
}

const PREAMBLE = `-- =============================================================================
-- Phase 9.5 catch-up: bring xtfljldeceonqyzgkoyp from mid-Phase-3 to Phase 9.5+9c.
-- Idempotent: IF NOT EXISTS, CREATE OR REPLACE, ON CONFLICT DO NOTHING.
-- Single transaction — rolls back entirely on failure.
-- =============================================================================

BEGIN;

-- Pre-flight: reject departments with both hourly and qc_log before XOR trigger
DO $$
DECLARE
  v_bad jsonb;
BEGIN
  SELECT COALESCE(jsonb_agg(jsonb_build_object('id', d.id, 'name', d.name, 'apps', d.apps)), '[]'::jsonb)
  INTO v_bad
  FROM public.departments d
  WHERE COALESCE(d.apps, '[]'::jsonb) @> '["hourly"]'::jsonb
    AND COALESCE(d.apps, '[]'::jsonb) @> '["qc_log"]'::jsonb;

  IF jsonb_array_length(v_bad) > 0 THEN
    RAISE EXCEPTION 'Cannot enable XOR trigger: departments have both hourly and qc_log: %', v_bad;
  END IF;
END $$;

-- =============================================================================
-- A. Schema additions
-- =============================================================================
ALTER TABLE public.departments
  ADD COLUMN IF NOT EXISTS is_production boolean NOT NULL DEFAULT true;

COMMENT ON COLUMN public.departments.is_production IS
  'false for support functions like Shipment and Quality Audit — excluded from production KPI calcs.';

ALTER TABLE public.inspections
  ADD COLUMN IF NOT EXISTS colorway_id uuid REFERENCES public.colorways(id) ON DELETE SET NULL;

ALTER TABLE public.handover_slips
  ADD COLUMN IF NOT EXISTS colorway_id uuid REFERENCES public.colorways(id) ON DELETE SET NULL;

ALTER TABLE public.handover_slips
  ADD COLUMN IF NOT EXISTS qty_by_size jsonb NOT NULL DEFAULT '{}'::jsonb;

ALTER TABLE public.handover_slips
  ADD COLUMN IF NOT EXISTS received_qty_by_size jsonb NOT NULL DEFAULT '{}'::jsonb;

ALTER TABLE public.hourly_counts
  ADD COLUMN IF NOT EXISTS count_by_size jsonb NOT NULL DEFAULT '{}'::jsonb;

COMMENT ON COLUMN public.hourly_counts.count_by_size IS
  'Hourly output by size label. count column stores the total (sum of values).';

ALTER TABLE public.workforce_logs
  ADD COLUMN IF NOT EXISTS headcount_by_category jsonb NOT NULL DEFAULT '{}'::jsonb;

COMMENT ON COLUMN public.workforce_logs.headcount_by_category IS
  'Headcount by category label (from departments.worker_roles). Keys are labels, values are counts.';

-- Unique department names per factory (for seed ON CONFLICT)
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint
    WHERE conname = 'departments_factory_id_name_key'
      AND conrelid = 'public.departments'::regclass
  ) THEN
    ALTER TABLE public.departments
      ADD CONSTRAINT departments_factory_id_name_key UNIQUE (factory_id, name);
  END IF;
END $$;

`

const FOOTER = `COMMIT;`

const BOOTSTRAP = read('20260609100000_floor_bootstrap_rpc.sql')
  .replace(
    /'allocations', COALESCE\(\(\s*SELECT jsonb_agg\(to_jsonb\(a\)\)\s*FROM public\.line_allocations a\s*WHERE a\.factory_id = p_factory_id\s*\), '\[\]'::jsonb\)/s,
    `'allocations', COALESCE((
      SELECT jsonb_agg(to_jsonb(a))
      FROM public.line_allocations a
      WHERE a.factory_id = p_factory_id
    ), '[]'::jsonb),
    'shipments', COALESCE((
      SELECT jsonb_agg(to_jsonb(s) ORDER BY s.logged_at DESC)
      FROM (
        SELECT * FROM public.shipments
        WHERE factory_id = p_factory_id
        ORDER BY logged_at DESC
        LIMIT 200
      ) s
    ), '[]'::jsonb),
    'rejections', COALESCE((
      SELECT jsonb_agg(to_jsonb(r) ORDER BY r.logged_at DESC)
      FROM (
        SELECT * FROM public.rejections
        WHERE factory_id = p_factory_id
        ORDER BY logged_at DESC
        LIMIT 200
      ) r
    ), '[]'::jsonb)`
  )

const GRANTS_EXTRA = `
-- Phase 9.5 RPCs — anon revoke + authenticated grant (extends Phase 9a)
REVOKE EXECUTE ON FUNCTION public.get_order_dept_progress(uuid, uuid, uuid, uuid, date) FROM anon;
REVOKE EXECUTE ON FUNCTION public.get_pseudo_dept_daily_summary(uuid, uuid, date) FROM anon;
REVOKE EXECUTE ON FUNCTION public.get_cut_to_ship_journey(uuid, uuid) FROM anon;

GRANT EXECUTE ON FUNCTION public.get_order_dept_progress(uuid, uuid, uuid, uuid, date) TO authenticated;
GRANT EXECUTE ON FUNCTION public.get_pseudo_dept_daily_summary(uuid, uuid, date) TO authenticated;
GRANT EXECUTE ON FUNCTION public.get_cut_to_ship_journey(uuid, uuid) TO authenticated;
`

const CHAIN = [
  ['20260611100000_mes_cut_to_ship_schema.sql', 'full'],
  ['20260610110000_mes_schema_polish.sql', 'full'],
  ['20260611180000_department_worker_roles.sql', 'full'],
  ['20260613100000_handover_slips_size_breakdown.sql', 'full'],
  ['20260613101000_shipments_size_breakdown.sql', 'full'],
  ['20260613101500_size_json_helpers.sql', 'full'],
  ['20260610120000_mes_reporting_views.sql', 'full'],
  ['20260610130000_mes_hour_slot_shift_attribution.sql', 'full'],
  ['20260611120000_mes_views_production_and_cut_to_ship.sql', 'full'],
  ['20260611130000_mes_colorway_scoped_wip.sql', 'full'],
  ['20260611140000_mes_cut_to_ship_views_v2.sql', 'full'],
  ['20260611150000_hourly_counts_slot_unique_with_colorway.sql', 'index_only'],
  ['20260612115000_mes_quality_dhu_semantics_fix.sql', 'full'],
  ['20260612110000_mes_reporting_rpcs_v2_kpi_columns.sql', 'full'],
  ['20260612120000_mes_cut_to_ship_journey_view.sql', 'full'],
  ['20260613103000_get_order_dept_progress_and_size_views.sql', 'full'],
  ['20260614100000_mes_journey_size_aware.sql', 'full'],
  ['20260614110000_mes_wip_by_size_proportional.sql', 'full'],
  ['20260615200000_workforce_dynamic_categories.sql', 'no_do'],
  ['20260611160000_mes_reporting_rpcs.sql', 'full'],
  ['20260611190000_mes_floor_kpi_rpcs.sql', 'full'],
  ['20260612100000_revoke_anon_reporting_rpcs.sql', 'full'],
]

const parts = [PREAMBLE]

let workforceFloorCapturePatch = ''

for (const [file, mode] of CHAIN) {
  let sql = read(file)
  if (file === '20260611100000_mes_cut_to_ship_schema.sql') {
    sql = patchCutToShipSeeds(sql)
  }
  if (mode === 'index_only') {
    sql = stripFloorCaptureBody(stripFromDoBlock(sql))
  } else if (mode === 'no_do') {
    workforceFloorCapturePatch = extractDoBlock(sql)
    sql = stripDropWorkforceCols(stripFromDoBlock(sql))
  }
  parts.push(`\n-- >>> ${file}\n${sql}\n`)
}

parts.push(`\n-- >>> profile_dept_has_app (from 20260611110000)\n${profileDeptHasAppOnly()}\n`)

parts.push(`
-- =============================================================================
-- I. Hardened floor_capture — drop old, install v3 + workforce + auth + size patches
-- =============================================================================
DROP FUNCTION IF EXISTS public.floor_capture(uuid, uuid, text, jsonb) CASCADE;
`)

for (const file of [
  '20260613102000_floor_capture_v3_size_aware.sql',
  '20260615300000_factory_function_capture_auth.sql',
  '20260615400000_hourly_count_by_size.sql',
]) {
  parts.push(`\n-- >>> ${file}\n${read(file)}\n`)
}

if (workforceFloorCapturePatch) {
  parts.push(`\n-- >>> workforce floor_capture patch (from 20260615200000)\n${workforceFloorCapturePatch}\n`)
  parts.push(`
ALTER TABLE public.workforce_logs DROP COLUMN IF EXISTS operators;
ALTER TABLE public.workforce_logs DROP COLUMN IF EXISTS helpers;
ALTER TABLE public.workforce_logs DROP COLUMN IF EXISTS supervisors;
ALTER TABLE public.workforce_logs DROP COLUMN IF EXISTS trainees;
`)
}

parts.push(`\n-- >>> get_floor_bootstrap (enhanced with shipments/rejections)\n${BOOTSTRAP}\n`)
parts.push(GRANTS_EXTRA)
parts.push(FOOTER)

const output = parts.join('\n')
fs.writeFileSync(outPath, output, 'utf8')
console.log(`Wrote ${outPath}`)
console.log(`Total lines: ${output.split('\n').length}`)
