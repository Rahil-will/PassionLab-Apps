SELECT name, type, productive_mins FROM shifts ORDER BY name;
