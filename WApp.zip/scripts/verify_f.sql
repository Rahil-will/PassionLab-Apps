SELECT factory_id, name, is_production, apps 
FROM departments 
WHERE name IN ('Quality Audit','Shipment')
ORDER BY factory_id, name;
