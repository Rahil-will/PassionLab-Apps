import { create } from "zustand";
import { useNavigationStore } from "./navigationStore";
import { useNotificationStore } from "./notificationStore";
import { supabase } from "../lib/supabase";
import { ensureSupportDropdownsIfNeeded, filterCanonicalSupportDropdowns } from "../lib/ensureSupportDropdowns";
import { filterProductionDepartments } from "../lib/departmentFilters";
import {
  mapDepartmentResourceFromDb,
  syncDepartmentResourcesToDb,
} from "../lib/departmentResourceSync";
import {
  mapProcessFlowFromDb,
  processFlowStepToDbRow,
  processFlowToDbRow,
  processFlowUpdatePayload,
} from "../lib/processFlowDb";
import {
  mapDepartmentDefectFromDb,
  defectsToDb,
} from "../lib/defectDb";
import { defaultDefectsForDepartment } from "../lib/defectSeeds";
import {
  DEFAULT_FACTORY_ENTITLEMENTS,
  factoryEntitlementsFromDb,
  sanitizeDepartmentApps,
  type FactoryEntitlements,
} from "../lib/factoryEntitlements";
import type {
  Buyer,
  DepartmentEntity,
  Shift,
  ProcessFlow,
  Rack,
  SizeGroup,
  SupportDropdown,
  DepartmentResource,
  DepartmentResourceSession,
  DefectItem,
  DepartmentDefectRecord,
} from "../types/settings";

function mapBuyerFromDb(b: Record<string, unknown>): Buyer {
  return {
    id: b.id as string,
    factory_id: b.factory_id as string,
    name: b.name as string,
    code: (b.code as string) ?? null,
    country: (b.country as string) ?? null,
    type: (b.type as string) ?? null,
    status: (b.status as string) ?? null,
    contactName: (b.contact_name as string) ?? null,
    contactEmail: (b.contact_email as string) ?? null,
    contactRole: (b.contact_role as string) ?? null,
    overShipmentAllowance: (b.over_shipment_pct as number) ?? null,
    underShipmentAllowance: (b.under_shipment_pct as number) ?? null,
    packingRule: (b.packing_rule as string) ?? null,
  };
}

function hasWorkforceLog(apps: unknown): boolean {
  return Array.isArray(apps) && apps.includes('workforce_log');
}

function workerRolesForDb(apps: unknown, workerRoles: string[] | undefined, rawDbRoles?: unknown): string[] {
  if (!hasWorkforceLog(apps)) return [];
  if (workerRoles?.length) return workerRoles;
  const fromDb = normalizeSizes(rawDbRoles);
  return fromDb.length ? fromDb : [];
}

function normalizeSizes(raw: unknown): string[] {
  if (Array.isArray(raw)) return raw.map(String);
  if (typeof raw === 'string') {
    try {
      const parsed = JSON.parse(raw);
      return Array.isArray(parsed) ? parsed.map(String) : [];
    } catch {
      return raw.split(',').map((s) => s.trim()).filter(Boolean);
    }
  }
  return [];
}

let departmentResourceLoadSeq = 0;

function mapSizeGroupFromDb(sg: Record<string, unknown>): SizeGroup {
  return {
    id: sg.id as string,
    factory_id: sg.factory_id as string,
    buyerId: (sg.buyer_id as string) ?? null,
    name: sg.name as string,
    sizes: normalizeSizes(sg.sizes),
  };
}

// --- SETTINGS STORE (Supabase-backed, multi-tenant) ---
interface SettingsState {
  buyers: Buyer[];
  departments: DepartmentEntity[];
  shifts: Shift[];
  processFlows: ProcessFlow[];
  racks: Rack[];
  sizeGroups: SizeGroup[];
  deptPlanningInputs: any[];
  deptPlanningOutputs: any[];
  supportDropdowns: SupportDropdown[];
  departmentDefects: DepartmentDefectRecord[];
  departmentResourceSession: DepartmentResourceSession | null;
  departmentWorkerRevision: number;
  factoryEntitlements: FactoryEntitlements;
  loading: boolean;
  bumpDepartmentWorkerRevision: () => void;
  fetchSettings: () => Promise<void>;
  selectDepartmentForEdit: (deptId: string) => void;
  loadDepartmentResources: (deptId: string, departmentName: string) => Promise<void>;
  setDepartmentResourceDraft: (resources: DepartmentResource[]) => void;
  promoteDepartmentResourceSession: (newDeptId: string) => void;
  clearDepartmentResourceSession: () => void;
  syncDepartmentResources: (
    deptId: string,
    factoryId: string,
    isOutsourced: boolean,
  ) => Promise<DepartmentResource[]>;
  addBuyer: (buyer: Partial<Buyer> & { factory_id: string; name: string }) => Promise<string>;
  updateBuyer: (id: string, buyer: Partial<Buyer>) => Promise<void>;
  deleteBuyer: (id: string) => Promise<void>;
  addDepartment: (dept: DepartmentEntity) => Promise<string>;
  updateDepartment: (id: string, dept: Partial<DepartmentEntity>) => Promise<void>;
  deleteDepartment: (id: string) => Promise<void>;
  addShift: (shift: Omit<Shift, 'id'>) => Promise<void>;
  updateShift: (id: string, shift: Partial<Shift>) => Promise<void>;
  deleteShift: (id: string) => Promise<void>;
  addProcessFlow: (flow: ProcessFlow) => Promise<void>;
  versionCurrentProcessFlow: (oldId: string, newFlow: ProcessFlow) => Promise<void>;
  updateProcessFlow: (id: string, flow: Partial<ProcessFlow>) => Promise<void>;
  deleteProcessFlow: (id: string) => Promise<void>;
  addRack: (rack: Rack) => Promise<void>;
  deleteRack: (id: string) => Promise<void>;
  addSizeGroup: (group: SizeGroup) => Promise<void>;
  updateSizeGroup: (id: string, group: Partial<SizeGroup>) => Promise<void>;
  deleteSizeGroup: (id: string) => Promise<void>;
  addSupportDropdown: (sd: SupportDropdown) => Promise<void>;
  updateSupportDropdown: (id: string, sd: Partial<SupportDropdown>) => Promise<void>;
  deleteSupportDropdown: (id: string) => Promise<void>;
  getDepartmentDefects: (departmentId: string) => DefectItem[];
  saveDepartmentDefects: (departmentId: string, defects: DefectItem[]) => Promise<void>;
  ensureDepartmentDefects: (departmentId: string, departmentName: string) => Promise<void>;
}

export const useSettingsStore = create<SettingsState>((set, get) => ({
  buyers: [],
  departments: [],
  shifts: [],
  processFlows: [],
  racks: [],
  sizeGroups: [],
  deptPlanningInputs: [],
  deptPlanningOutputs: [],
  supportDropdowns: [],
  departmentDefects: [],
  departmentResourceSession: null,
  departmentWorkerRevision: 0,
  factoryEntitlements: { ...DEFAULT_FACTORY_ENTITLEMENTS },
  loading: false,

  bumpDepartmentWorkerRevision: () => {
    set((s) => ({ departmentWorkerRevision: s.departmentWorkerRevision + 1 }));
  },

  selectDepartmentForEdit: (deptId) => {
    departmentResourceLoadSeq += 1;
    set({
      departmentResourceSession: {
        deptId,
        draft: [],
        baseline: [],
        status: deptId.startsWith('temp_') ? 'ready' : 'loading',
        draftTouched: false,
      },
    });
  },

  loadDepartmentResources: async (deptId, departmentName) => {
    if (deptId.startsWith('temp_')) return;
    const factoryId = useNavigationStore.getState().factoryId;
    if (!factoryId) return;
    const seq = ++departmentResourceLoadSeq;

    const { data, error } = await supabase
      .from('assigned_resources')
      .select('*')
      .eq('factory_id', factoryId)
      .eq('department_id', deptId)
      .order('resource_name');

    if (departmentResourceLoadSeq !== seq) return;
    if (error) throw error;

    const session = get().departmentResourceSession;
    if (session?.deptId !== deptId) return;

    const resources = (data || []).map((row) =>
      mapDepartmentResourceFromDb(row as Record<string, unknown>, deptId, departmentName),
    );
    const snapshot = resources.map((r) => ({ ...r }));

    if (session.draftTouched) {
      set({
        departmentResourceSession: {
          ...session,
          baseline: resources.map((r) => ({ ...r })),
          status: 'ready',
        },
      });
      return;
    }

    set({
      departmentResourceSession: {
        deptId,
        draft: snapshot,
        baseline: resources.map((r) => ({ ...r })),
        status: 'ready',
        draftTouched: false,
      },
    });
  },

  setDepartmentResourceDraft: (resources) => {
    const session = get().departmentResourceSession;
    if (!session) return;
    set({
      departmentResourceSession: {
        ...session,
        draft: resources.map((r) => ({ ...r })),
        draftTouched: true,
      },
    });
  },

  promoteDepartmentResourceSession: (newDeptId) => {
    const session = get().departmentResourceSession;
    if (!session) return;
    set({
      departmentResourceSession: {
        deptId: newDeptId,
        draft: session.draft.map((r) => ({ ...r, departmentId: newDeptId })),
        baseline: [],
        status: 'ready',
        draftTouched: session.draftTouched,
      },
    });
  },

  clearDepartmentResourceSession: () => {
    departmentResourceLoadSeq += 1;
    set({ departmentResourceSession: null });
  },

  syncDepartmentResources: async (deptId, factoryId, isOutsourced) => {
    const session = get().departmentResourceSession;
    if (!session || session.deptId !== deptId) {
      return [];
    }
    if (session.status === 'loading') {
      throw new Error('Department resources are still loading — try again in a moment');
    }

    const saved = await syncDepartmentResourcesToDb(supabase, {
      departmentId: deptId,
      factoryId,
      isOutsourced,
      draft: session.draft,
      baseline: session.baseline,
    });

    const snapshot = saved.map((r) => ({ ...r }));
    set({
      departmentResourceSession: {
        deptId,
        draft: snapshot,
        baseline: saved.map((r) => ({ ...r })),
        status: 'ready',
        draftTouched: false,
      },
    });

    return saved;
  },

  fetchSettings: async () => {
    set({ loading: true });
    const factoryId = useNavigationStore.getState().factoryId;
    if (!factoryId) { set({ loading: false }); return; }

    const [
      buyersRes,
      departmentsRes,
      shiftsRes,
      processFlowsRes,
      sizeGroupsRes,
      supportDropdownsRes,
      defectsRes,
      factoryRes,
    ] = await Promise.all([
      supabase.from('buyers').select('*').eq('factory_id', factoryId).order('name'),
      supabase.from('departments').select('*').eq('factory_id', factoryId).order('sequence'),
      supabase.from('shifts').select('*').eq('factory_id', factoryId).order('name'),
      supabase.from('process_flows').select('*, process_flow_steps(*)').eq('factory_id', factoryId).order('name'),
      supabase.from('size_groups').select('*').eq('factory_id', factoryId),
      supabase.from('support_dropdowns').select('*').eq('factory_id', factoryId).order('category'),
      supabase.from('defects').select('*').eq('factory_id', factoryId),
      supabase
        .from('factories')
        .select('transaction_apps, production_apps, workforce_apps, audit_apps, shipment_apps')
        .eq('id', factoryId)
        .maybeSingle(),
    ]);

    const fetchError =
      buyersRes.error ||
      departmentsRes.error ||
      shiftsRes.error ||
      processFlowsRes.error ||
      sizeGroupsRes.error ||
      supportDropdownsRes.error ||
      defectsRes.error;
    if (fetchError) {
      useNotificationStore.getState().showNotification(
        `Failed to load settings: ${fetchError.message}`,
        'error',
      );
      set({ loading: false });
      return;
    }

    const buyers = buyersRes.data;
    const departments = departmentsRes.data;
    const shifts = shiftsRes.data;
    const processFlows = processFlowsRes.data;
    const sizeGroups = sizeGroupsRes.data;
    const support_dropdowns = supportDropdownsRes.data;
    const departmentDefects = (defectsRes.data || []).map((row) =>
      mapDepartmentDefectFromDb(row as Record<string, unknown>),
    );
    const factoryEntitlements = factoryRes.error
      ? (() => {
          useNotificationStore.getState().showNotification(
            'Could not load factory app entitlements — using defaults. Apply migration 20260627100000 if not run.',
            'error',
          );
          return { ...DEFAULT_FACTORY_ENTITLEMENTS };
        })()
      : factoryEntitlementsFromDb((factoryRes.data as Record<string, unknown>) ?? null);

    // Map DB columns to app shape
    const mappedBuyers = (buyers || []).map((b: any) => mapBuyerFromDb(b));

    const mappedDepts = filterProductionDepartments(
      (departments || []).map((d: any) => {
        const apps = d.apps || ['transaction'];
        return {
          ...d,
          apps,
          workerRoles: hasWorkforceLog(apps) ? normalizeSizes(d.worker_roles) : [],
          isOutsourced: d.is_outsourced || false,
          isProduction: d.is_production !== false,
        };
      }),
    );

    const mappedShifts = (shifts || []).map((s: any) => ({
      ...s, startTime: s.start_time, endTime: s.end_time,
      breakStart: s.break_start, breakEnd: s.break_end,
      hours: s.hours || [], type: s.type || 'Regular',
    }));

    const mappedFlows = (processFlows || []).map((f: Record<string, unknown>) =>
      mapProcessFlowFromDb(f),
    );

    const mappedSizeGroups = (sizeGroups || []).map((sg: any) => mapSizeGroupFromDb(sg));

    await ensureSupportDropdownsIfNeeded(factoryId);
    const { data: refreshedDropdowns, error: dropdownRefreshError } = await supabase
      .from('support_dropdowns')
      .select('*')
      .eq('factory_id', factoryId)
      .order('category');
    if (dropdownRefreshError) {
      useNotificationStore.getState().showNotification(
        `Failed to load dropdowns: ${dropdownRefreshError.message}`,
        'error',
      );
    }
    const mappedSupportDropdowns = filterCanonicalSupportDropdowns(
      (refreshedDropdowns || support_dropdowns || []).map((sd: any) => ({
        ...sd, values: sd.values || [], app_name: sd.app_name || null,
      })),
    ).sort((a: any, b: any) => (a.app_name || a.category).localeCompare(b.app_name || b.category));

    set({
      buyers: mappedBuyers, departments: mappedDepts, shifts: mappedShifts,
      processFlows: mappedFlows, sizeGroups: mappedSizeGroups, supportDropdowns: mappedSupportDropdowns,
      departmentDefects,
      factoryEntitlements,
      loading: false,
    });
  },

  // --- BUYER CRUD ---
  addBuyer: async (b) => {
    const newId = b.id || crypto.randomUUID();
    const { data, error } = await supabase.from('buyers').insert({
      id: newId, factory_id: b.factory_id, name: b.name, code: b.code ?? null, country: b.country ?? null,
      type: b.type ?? 'Retail', status: b.status ?? 'Active', contact_name: b.contactName ?? null,
      contact_email: b.contactEmail ?? null, contact_role: b.contactRole ?? null,
      over_shipment_pct: b.overShipmentAllowance ?? 0, under_shipment_pct: b.underShipmentAllowance ?? 0,
      packing_rule: b.packingRule ?? 'Ratio',
    }).select().single();
    if (error) throw error;
    const mapped = mapBuyerFromDb(data);
    set((s) => ({ buyers: [...s.buyers, mapped] }));
    return mapped.id;
  },
  updateBuyer: async (id, b) => {
    const { error } = await supabase.from('buyers').update({
      name: b.name, code: b.code ?? null, country: b.country ?? null, type: b.type ?? null,
      status: b.status ?? 'Active', contact_name: b.contactName ?? null, contact_email: b.contactEmail ?? null,
      contact_role: b.contactRole ?? null, over_shipment_pct: b.overShipmentAllowance ?? 0,
      under_shipment_pct: b.underShipmentAllowance ?? 0, packing_rule: b.packingRule ?? null,
    }).eq('id', id);
    if (error) throw error;
    set((s) => ({ buyers: s.buyers.map((x) => (x.id === id ? { ...x, ...b } : x)) }));
  },
  deleteBuyer: async (id) => {
    const { error: sgError } = await supabase.from('size_groups').delete().eq('buyer_id', id);
    if (sgError) throw sgError;
    const { error } = await supabase.from('buyers').delete().eq('id', id);
    if (error) throw error;
    set((s) => ({
      buyers: s.buyers.filter((x) => x.id !== id),
      sizeGroups: s.sizeGroups.filter((x) => x.buyerId !== id),
    }));
  },

  // --- DEPARTMENT CRUD ---
  addDepartment: async (dept) => {
    const { departments, factoryEntitlements } = get();
    const maxSeq = departments.length > 0 ? Math.max(...departments.map((d) => d.sequence || 0)) : 0;
    const newDept = { ...dept, id: dept.id || crypto.randomUUID(), sequence: dept.sequence ?? maxSeq + 1 };
    const apps = sanitizeDepartmentApps(newDept.apps, factoryEntitlements);
    const { data, error } = await supabase.from('departments').insert({
      id: newDept.id, factory_id: newDept.factory_id, name: newDept.name, sequence: newDept.sequence,
      apps,
      worker_roles: workerRolesForDb(newDept.apps, newDept.workerRoles, (newDept as { worker_roles?: unknown }).worker_roles),
      is_outsourced: newDept.isOutsourced || false,
    }).select().single();
    if (error) throw error;
    const deptId = data.id as string;
    set((s) => ({
      departments: [...s.departments, { ...newDept, id: deptId, workerRoles: newDept.workerRoles ?? [] }],
    }));
    await get().ensureDepartmentDefects(deptId, newDept.name);
    useNotificationStore.getState().showNotification('Department added');
    return deptId;
  },
  updateDepartment: async (id, dept) => {
    const apps = sanitizeDepartmentApps(dept.apps, get().factoryEntitlements);
    const { error } = await supabase.from('departments').update({
      name: dept.name, sequence: dept.sequence,
      apps,
      worker_roles: workerRolesForDb(dept.apps, dept.workerRoles, (dept as { worker_roles?: unknown }).worker_roles),
      is_outsourced: dept.isOutsourced || false,
      updated_at: new Date().toISOString(),
    }).eq('id', id);
    if (error) throw error;
    set((s) => ({ departments: s.departments.map((x) => (x.id === id ? { ...x, ...dept } : x)) }));
    useNotificationStore.getState().showNotification('Department updated');
  },
  deleteDepartment: async (id) => {
    const { error } = await supabase.from('departments').delete().eq('id', id);
    if (error) throw error;
    set((s) => ({
      departments: s.departments.filter((x) => x.id !== id),
      departmentResourceSession:
        s.departmentResourceSession?.deptId === id ? null : s.departmentResourceSession,
    }));
    useNotificationStore.getState().showNotification("Department deleted");
  },

  // --- SHIFT CRUD ---
  addShift: async (sh) => {
    const { data, error } = await supabase.from('shifts').insert({
      factory_id: sh.factory_id, name: sh.name, type: sh.type || 'Regular',
      start_time: sh.startTime, end_time: sh.endTime, break_start: sh.breakStart, break_end: sh.breakEnd,
      hours: sh.hours || [],
    }).select().single();
    if (error) throw error;
    const newShift = { ...sh, id: data?.id, startTime: sh.startTime, endTime: sh.endTime, hours: sh.hours || [], type: sh.type || 'Regular' };
    set((s) => ({ shifts: [...s.shifts, newShift] }));
    useNotificationStore.getState().showNotification("Shift added");
  },
  updateShift: async (id, sh) => {
    const { error } = await supabase.from('shifts').update({
      name: sh.name, type: sh.type || 'Regular', start_time: sh.startTime, end_time: sh.endTime,
      break_start: sh.breakStart, break_end: sh.breakEnd,
      hours: sh.hours || [],
    }).eq('id', id);
    if (error) throw error;
    set((s) => ({ shifts: s.shifts.map((x) => (x.id === id ? { ...x, name: sh.name, type: sh.type || 'Regular', startTime: sh.startTime, endTime: sh.endTime, breakStart: sh.breakStart, breakEnd: sh.breakEnd, hours: sh.hours || [] } : x)) }));
    useNotificationStore.getState().showNotification("Shift updated");
  },
  deleteShift: async (id) => {
    const { error } = await supabase.from('shifts').delete().eq('id', id);
    if (error) throw error;
    set((s) => ({ shifts: s.shifts.filter((x) => x.id !== id) }));
    useNotificationStore.getState().showNotification("Shift deleted");
  },

  // --- PROCESS FLOW CRUD ---
  addProcessFlow: async (f) => {
    const flow = { ...f, id: f.id || crypto.randomUUID(), version: f.version || 1, is_current: f.is_current ?? true };
    const { data, error } = await supabase
      .from('process_flows')
      .insert(processFlowToDbRow(flow))
      .select()
      .single();
    if (error) throw error;
    if (data && flow.steps?.length) {
      const { error: stepError } = await supabase
        .from('process_flow_steps')
        .insert(flow.steps.map((s) => processFlowStepToDbRow(data.id, s)));
      if (stepError) throw stepError;
    }
    set((s) => ({ processFlows: [...s.processFlows, flow] }));
    useNotificationStore.getState().showNotification("Process flow created");
  },
  versionCurrentProcessFlow: async (oldId, newFlow) => {
    const { error: archiveErr } = await supabase
      .from('process_flows')
      .update({ is_current: false })
      .eq('id', oldId);
    if (archiveErr) throw archiveErr;

    set((s) => ({
      processFlows: s.processFlows.map((x) =>
        x.id === oldId ? { ...x, is_current: false } : x,
      ),
    }));

    try {
      await get().addProcessFlow(newFlow);
    } catch (e) {
      await supabase.from('process_flows').delete().eq('id', newFlow.id);
      const { error: rollbackErr } = await supabase
        .from('process_flows')
        .update({ is_current: true })
        .eq('id', oldId);
      set((s) => ({
        processFlows: s.processFlows.map((x) =>
          x.id === oldId ? { ...x, is_current: true } : x,
        ),
      }));
      if (rollbackErr) {
        throw new Error(
          `Could not save the new version and failed to restore the previous flow: ${rollbackErr.message}`,
        );
      }
      throw e;
    }
  },
  updateProcessFlow: async (id, f) => {
    const payload = processFlowUpdatePayload(f);
    if (Object.keys(payload).length > 0) {
      const { error } = await supabase.from('process_flows').update(payload).eq('id', id);
      if (error) throw error;
    }
    if (f.steps) {
      const { error: delError } = await supabase.from('process_flow_steps').delete().eq('flow_id', id);
      if (delError) throw delError;
      if (f.steps.length) {
        const { error: insError } = await supabase
          .from('process_flow_steps')
          .insert(f.steps.map((s) => processFlowStepToDbRow(id, s)));
        if (insError) throw insError;
      }
    }
    set((s) => ({ processFlows: s.processFlows.map((x) => (x.id === id ? { ...x, ...f } : x)) }));
    useNotificationStore.getState().showNotification("Process flow updated");
  },
  deleteProcessFlow: async (id) => {
    const { error } = await supabase.from('process_flows').delete().eq('id', id);
    if (error) throw error;
    set((s) => ({ processFlows: s.processFlows.filter((x) => x.id !== id) }));
    useNotificationStore.getState().showNotification("Process flow deleted");
  },

  // --- SUPPORT DROPDOWNS CRUD ---
  addSupportDropdown: async (sd) => {
    const { data, error } = await supabase.from('support_dropdowns').insert({
      id: sd.id || crypto.randomUUID(), factory_id: sd.factory_id, category: sd.category, app_name: sd.app_name || null, values: sd.values || [],
    }).select().single();
    if (error) throw error;
    if (data) {
      set((s) => ({
        supportDropdowns: [
          ...s.supportDropdowns,
          { ...data, values: data.values || [], app_name: data.app_name || null },
        ],
      }));
    }
    useNotificationStore.getState().showNotification("Dropdown created");
  },
  updateSupportDropdown: async (id, sd) => {
    const { error } = await supabase
      .from('support_dropdowns')
      .update({ values: sd.values || [], app_name: sd.app_name || null })
      .eq('id', id);
    if (error) throw error;
    set((s) => ({
      supportDropdowns: s.supportDropdowns.map((x) =>
        x.id === id ? { ...x, values: sd.values || [], app_name: sd.app_name || null } : x,
      ),
    }));
    useNotificationStore.getState().showNotification("Dropdown updated");
  },
  deleteSupportDropdown: async (id) => {
    const { error } = await supabase.from('support_dropdowns').delete().eq('id', id);
    if (error) throw error;
    set((s) => ({ supportDropdowns: s.supportDropdowns.filter((x) => x.id !== id) }));
    useNotificationStore.getState().showNotification("Dropdown deleted");
  },

  // --- RACK CRUD (local only — no DB table yet) ---
  addRack: async (rack) => {
    set((s) => ({ racks: [...s.racks, rack] }));
    useNotificationStore.getState().showNotification("Rack added");
  },
  deleteRack: async (id) => {
    set((s) => ({ racks: s.racks.filter((x) => x.id !== id) }));
    useNotificationStore.getState().showNotification("Rack deleted");
  },

  // --- SIZE GROUP CRUD ---
  addSizeGroup: async (g) => {
    const groupId = g.id || crypto.randomUUID();
    const { data, error } = await supabase.from('size_groups').insert({
      id: groupId,
      factory_id: g.factory_id,
      buyer_id: g.buyerId,
      name: g.name,
      sizes: normalizeSizes(g.sizes),
    }).select().single();
    if (error) throw error;
    const mapped = mapSizeGroupFromDb(data);
    set((s) => ({ sizeGroups: [...s.sizeGroups, mapped] }));
  },
  updateSizeGroup: async (id, g) => {
    const { data, error } = await supabase.from('size_groups').update({
      name: g.name,
      sizes: normalizeSizes(g.sizes),
      buyer_id: g.buyerId ?? undefined,
    }).eq('id', id).select().single();
    if (error) throw error;
    const mapped = mapSizeGroupFromDb(data);
    set((s) => ({ sizeGroups: s.sizeGroups.map((x) => (x.id === id ? mapped : x)) }));
  },
  deleteSizeGroup: async (id) => {
    const { error } = await supabase.from('size_groups').delete().eq('id', id);
    if (error) throw error;
    set((s) => ({ sizeGroups: s.sizeGroups.filter((x) => x.id !== id) }));
  },

  getDepartmentDefects: (departmentId) => {
    const record = get().departmentDefects.find((d) => d.department_id === departmentId);
    return record?.defects ?? [];
  },

  ensureDepartmentDefects: async (departmentId, departmentName) => {
    const factoryId = useNavigationStore.getState().factoryId;
    if (!factoryId) return;

    const existing = get().departmentDefects.find((d) => d.department_id === departmentId);
    if (existing) return;

    const seeded = defaultDefectsForDepartment(departmentName);
    const { data, error } = await supabase
      .from('defects')
      .insert({
        factory_id: factoryId,
        department_id: departmentId,
        defects: defectsToDb(seeded),
      })
      .select()
      .single();

    if (error) {
      const { data: refetched } = await supabase
        .from('defects')
        .select('*')
        .eq('factory_id', factoryId)
        .eq('department_id', departmentId)
        .maybeSingle();
      if (refetched) {
        const mapped = mapDepartmentDefectFromDb(refetched as Record<string, unknown>);
        set((s) => ({
          departmentDefects: s.departmentDefects.some((d) => d.department_id === departmentId)
            ? s.departmentDefects.map((d) => (d.department_id === departmentId ? mapped : d))
            : [...s.departmentDefects, mapped],
        }));
      }
      return;
    }

    if (data) {
      const mapped = mapDepartmentDefectFromDb(data as Record<string, unknown>);
      set((s) => ({ departmentDefects: [...s.departmentDefects, mapped] }));
    }
  },

  saveDepartmentDefects: async (departmentId, defects) => {
    const factoryId = useNavigationStore.getState().factoryId;
    if (!factoryId) throw new Error('No factory selected');

    const payload = defectsToDb(defects);
    const existing = get().departmentDefects.find((d) => d.department_id === departmentId);

    if (existing) {
      const { data, error } = await supabase
        .from('defects')
        .update({ defects: payload, updated_at: new Date().toISOString() })
        .eq('id', existing.id)
        .select()
        .single();
      if (error) throw error;
      const mapped = mapDepartmentDefectFromDb(data as Record<string, unknown>);
      set((s) => ({
        departmentDefects: s.departmentDefects.map((d) => (d.id === existing.id ? mapped : d)),
      }));
    } else {
      const dept = get().departments.find((d) => d.id === departmentId);
      const { data, error } = await supabase
        .from('defects')
        .insert({
          factory_id: factoryId,
          department_id: departmentId,
          defects: payload.length ? payload : defectsToDb(defaultDefectsForDepartment(dept?.name ?? '')),
        })
        .select()
        .single();
      if (error) throw error;
      const mapped = mapDepartmentDefectFromDb(data as Record<string, unknown>);
      set((s) => ({ departmentDefects: [...s.departmentDefects, mapped] }));
    }
    useNotificationStore.getState().showNotification('Defects saved');
  },

}));
