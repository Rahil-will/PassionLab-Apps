import { create } from 'zustand';
import {
  StyleOrder,
  AssignedResource,
  LineAllocation,
  Garment,
  ProductionSummaryRow,
} from '../types';
import { useNavigationStore } from './navigationStore';
import { useNotificationStore } from './notificationStore';
import { supabase } from '../lib/supabase';
import { assignedResourceToDbRow } from '../lib/assignedResourceDb';
import { allocationColorwayId, allocationSamValue } from '../lib/allocationUtils';
import {
  deleteStyleOrder,
  mapStyleOrderFromDb,
} from '../lib/styleOrderDb';
import { saveStyleOrderAtomic } from '../lib/saveStyleOrder';
import { fetchProductionSummaryFromViews } from '../lib/orderProgressApi';
import { syncOrdersWithProduction } from '../lib/orderProductionStatus';
import { sortResourcesBySequence } from '../lib/ganttSchedule';

interface DataState {
  orders: StyleOrder[];
  assignedResources: AssignedResource[];
  productionLines: AssignedResource[];
  allocations: LineAllocation[];
  garments: Garment[];
  productionSummary: ProductionSummaryRow[];
  wipOrder: StyleOrder | null;
  loading: boolean;
  setWipOrder: (order: StyleOrder | null) => void;
  fetchData: (opts?: { silent?: boolean }) => Promise<void>;
  refreshAssignedResources: () => Promise<void>;
  refreshProductionSummary: () => Promise<void>;
  addOrder: (order: StyleOrder) => Promise<boolean>;
  updateOrder: (id: string, order: Partial<StyleOrder>) => Promise<boolean>;
  deleteOrder: (id: string) => Promise<void>;
  updateColorwayPlanningRemarks: (colorwayId: string, orderId: string, remarks: string) => Promise<void>;
  addResource: (resource: AssignedResource) => Promise<void>;
  updateResource: (id: string, updates: Partial<AssignedResource>) => Promise<void>;
  deleteResource: (id: string) => Promise<void>;
  addGarments: (garments: Garment[]) => Promise<void>;
  getProcessFlowJourney: (processFlowId: string) => Promise<unknown[]>;
}

function mapResourceRow(r: Record<string, unknown>): AssignedResource {
  const dept = r.departments as { name?: string } | null;
  const resourceType = r.resource_type === 'outsourced' ? 'outsourced' : 'inhouse';
  return {
    id: r.id as string,
    factory_id: r.factory_id as string,
    departmentId: (r.department_id as string) || '',
    departmentName: dept?.name || '',
    resourceName: (r.resource_name as string) || '',
    resourceType,
    dailyTarget: (r.capacity as number) || 0,
    defaultPcs: (r.capacity as number) || 0,
  };
}

function mapAllocationRow(row: Record<string, unknown>): LineAllocation {
  const colorwayId = (row.colorway_id as string) || undefined;
  const orderId = (row.order_id as string) || '';
  return {
    id: row.id as string,
    lineId: (row.line_id as string) || '',
    orderId,
    colorwayId,
    departmentId: (row.department_id as string) || undefined,
    styleName: (row.style_name as string) || '',
    poNumber: (row.po_number as string) || '',
    colorway: (row.colorway as string) || '',
    qty: (row.qty as number) ?? (row.planned_qty as number) ?? 0,
    dailyTarget: (row.daily_target as number) || 0,
    hourlyTarget: row.hourly_target != null ? Number(row.hourly_target) : null,
    startDate: (row.start_date as string) || '',
    endDate: (row.end_date as string) || '',
    status: (row.status as string) || 'planned',
    progress: 0,
    completed_is_true: row.completed_is_true as boolean | undefined,
    sam: (() => {
      const v = allocationSamValue({
        sam: row.sam as number | null,
        kpi_inputs: row.kpi_inputs as { sam?: number } | null,
      });
      return v > 0 ? v : null;
    })(),
    kpiInputs: row.kpi_inputs as LineAllocation['kpiInputs'],
    actualQty: row.actual_qty as number | undefined,
  };
}

export const useDataStore = create<DataState>((set, get) => ({
  orders: [],
  assignedResources: [],
  productionLines: [],
  allocations: [],
  garments: [],
  productionSummary: [],
  wipOrder: null,
  loading: false,

  setWipOrder: (order) => set({ wipOrder: order }),

  refreshAssignedResources: async () => {
    const factoryId = useNavigationStore.getState().factoryId;
    if (!factoryId) return;
    const { data, error } = await supabase
      .from('assigned_resources')
      .select('*, departments(name)')
      .eq('factory_id', factoryId)
      .order('resource_name');
    if (error) throw error;
    const mapped = sortResourcesBySequence(
      (data || []).map((r) => mapResourceRow(r as Record<string, unknown>)),
    );
    set({ assignedResources: mapped, productionLines: mapped });
  },

  refreshProductionSummary: async () => {
    const factoryId = useNavigationStore.getState().factoryId;
    if (!factoryId) {
      set({ productionSummary: [] });
      return;
    }
    try {
      const rows = await fetchProductionSummaryFromViews(factoryId);
      set((state) => ({
        productionSummary: rows,
        orders: syncOrdersWithProduction(state.orders, rows),
      }));
    } catch (err) {
      console.error('Failed to load production summary from views', err);
      set({ productionSummary: [] });
    }
  },

  fetchData: async (opts) => {
    const silent = opts?.silent === true;
    if (!silent) set({ loading: true });
    const factoryId = useNavigationStore.getState().factoryId;
    if (!factoryId) {
      if (!silent) set({ loading: false });
      return;
    }
    try {
      const [ordersRes, allocationsRes, resourcesRes] = await Promise.all([
        supabase
          .from('style_orders')
          .select('*, colorways(*)')
          .eq('factory_id', factoryId)
          .order('created_at', { ascending: false }),
        supabase.from('line_allocations').select('*').eq('factory_id', factoryId),
        supabase
          .from('assigned_resources')
          .select('*, departments(name)')
          .eq('factory_id', factoryId)
          .order('resource_name'),
      ]);

      const firstError = ordersRes.error || allocationsRes.error || resourcesRes.error;
      if (firstError) throw firstError;

      const mappedOrders = (ordersRes.data || []).map((o) =>
        mapStyleOrderFromDb(o as Record<string, unknown>),
      );
      const mappedResources = sortResourcesBySequence(
        (resourcesRes.data || []).map((r) => mapResourceRow(r as Record<string, unknown>)),
      );
      const mappedAllocations = (allocationsRes.data || []).map((a) => mapAllocationRow(a as Record<string, unknown>));

      set({
        orders: mappedOrders,
        allocations: mappedAllocations,
        assignedResources: mappedResources,
        productionLines: mappedResources,
        loading: false,
      });
      await get().refreshProductionSummary();
    } catch (err) {
      console.error('Failed to fetch data', err);
      useNotificationStore.getState().showNotification(
        `Failed to load factory data: ${err instanceof Error ? err.message : 'Unknown error'}`,
        'error',
      );
      set({ loading: false });
    }
  },

  addOrder: async (order) => {
    const factoryId = useNavigationStore.getState().factoryId;
    if (!factoryId) return false;
    if (!order.buyerId) {
      useNotificationStore.getState().showNotification(
        'Buyer is required — select a buyer before saving.',
        'error',
      );
      return false;
    }
    try {
      await saveStyleOrderAtomic(factoryId, order, order.id);
      await get().fetchData({ silent: true });
      set({ wipOrder: null });
      return true;
    } catch (err) {
      console.error('addOrder failed', err);
      const message = err instanceof Error ? err.message : 'Failed to save order';
      useNotificationStore.getState().showNotification(message, 'error');
      return false;
    }
  },

  updateOrder: async (id, updates) => {
    const factoryId = useNavigationStore.getState().factoryId;
    if (!factoryId) return false;
    if (updates.buyerId === undefined && updates.buyer !== undefined && !updates.buyer) {
      useNotificationStore.getState().showNotification(
        'Buyer is required — select a buyer before saving.',
        'error',
      );
      return false;
    }
    try {
      await saveStyleOrderAtomic(factoryId, updates, id);
      await get().fetchData({ silent: true });
      set({ wipOrder: null });
      return true;
    } catch (err) {
      console.error('updateOrder failed', err);
      const message = err instanceof Error ? err.message : 'Failed to update order';
      useNotificationStore.getState().showNotification(message, 'error');
      return false;
    }
  },

  deleteOrder: async (id) => {
    const factoryId = useNavigationStore.getState().factoryId;
    if (!factoryId) throw new Error('No factory selected');

    const order = get().orders.find((o) => o.id === id);
    const colorwayIds = order?.colorways?.map((c) => c.id).filter(Boolean) ?? [];

    await deleteStyleOrder(factoryId, id);

    set((state) => ({
      orders: state.orders.filter((o) => o.id !== id),
      allocations: state.allocations.filter(
        (a) => !colorwayIds.includes(allocationColorwayId(a)) && a.orderId !== id,
      ),
      wipOrder: state.wipOrder?.id === id ? null : state.wipOrder,
    }));
    useNotificationStore.getState().showNotification('Order deleted', 'success');
  },

  updateColorwayPlanningRemarks: async (colorwayId, orderId, remarks) => {
    const { error } = await supabase
      .from('colorways')
      .update({ planning_remarks: remarks.trim() || null })
      .eq('id', colorwayId);
    if (error) throw error;
    set((state) => ({
      orders: state.orders.map((o) =>
        o.id !== orderId
          ? o
          : {
              ...o,
              colorways: o.colorways.map((cw) =>
                cw.id === colorwayId ? { ...cw, planningRemarks: remarks } : cw,
              ),
            },
      ),
    }));
  },

  addResource: async (res) => {
    const factoryId = useNavigationStore.getState().factoryId;
    if (!factoryId) return;
    const { error } = await supabase.from('assigned_resources').insert(
      assignedResourceToDbRow(
        {
          id: res.id,
          resourceName: res.resourceName,
          defaultPcs: res.dailyTarget,
        },
        {
          factoryId,
          departmentId: res.departmentId || null,
          resourceType: res.resourceType === 'outsourced' ? 'outsourced' : 'inhouse',
        },
      ),
    );
    if (error) {
      useNotificationStore.getState().showNotification(
        `Failed to add resource: ${error.message}`,
        'error',
      );
      throw error;
    }
    set((s) => {
      const newResources = [...s.assignedResources, res];
      return { assignedResources: newResources, productionLines: newResources };
    });
  },

  updateResource: async (id, updates) => {
    const { error } = await supabase
      .from('assigned_resources')
      .update({
        resource_name: updates.resourceName,
        capacity: updates.dailyTarget,
        status: 'active',
      })
      .eq('id', id);
    if (error) {
      useNotificationStore.getState().showNotification(
        `Failed to update resource: ${error.message}`,
        'error',
      );
      throw error;
    }
    set((s) => {
      const newResources = s.assignedResources.map((r) => (r.id === id ? { ...r, ...updates } : r));
      return { assignedResources: newResources, productionLines: newResources };
    });
  },

  deleteResource: async (id) => {
    const { error } = await supabase.from('assigned_resources').delete().eq('id', id);
    if (error) {
      useNotificationStore.getState().showNotification(
        `Failed to delete resource: ${error.message}`,
        'error',
      );
      throw error;
    }
    set((s) => {
      const newResources = s.assignedResources.filter((r) => r.id !== id);
      return { assignedResources: newResources, productionLines: newResources };
    });
  },

  addGarments: async (garments) => {
    set((state) => ({ garments: [...state.garments, ...garments] }));
    useNotificationStore.getState().showNotification(`${garments.length} garments added`);
  },

  getProcessFlowJourney: async (processFlowId) => {
    const { data } = await supabase
      .from('process_flow_steps')
      .select('*, departments(*)')
      .eq('flow_id', processFlowId)
      .order('flow_step');
    return data || [];
  },
}));
