import type { Department } from './shared';

export interface Material {
  id: string;
  category: 'Fabric' | 'Trim';
  name: string;
  placement?: string;
  type?: string;
  trimType?: string;
  composition?: string;
  fabricCategory?: 'Main' | 'Allied';
  avgCons?: number;
  perPc?: number;
  unit: string;
  wastage?: number;
  reqQty?: number;
  rcvdQty?: number;
  balanceQty?: number;
  totalRolls?: number;
  status?: string;
  supplier?: string;
  supplierRef?: string;
  colorCode?: string;
  remarks?: string;
}

export interface ProductionProgress {
  planned: number;
  actual: number;
  rejected: number;
  status: "pending" | "active" | "completed" | "delayed";
  sizeBreakdown?: Record<string, { planned: number; actual: number }>;
}

/** Per order / colorway / department counts for Status Tracker pipeline UI */
export interface ProductionSummaryRow {
  order_id: string;
  colorway_id: string;
  department: string;
  total_passed?: number;
  total_scanned?: number;
  /** First day with floor output (from v_daily_output). */
  first_output_date?: string;
  /** Last day with floor output (from v_daily_output). */
  last_output_date?: string;
}

export interface SizeQty {
  size: string;
  order_qty: number;
  adj_qty: number;
  /** @deprecated legacy reads only */
  qty?: number;
  /** @deprecated legacy reads only */
  plannedQty?: number;
}

export type ColorwayCompletionStatus = 'ongoing' | 'complete' | 'short_closed';

export interface Colorway {
  id: string;
  name: string;
  colorCode?: string;
  orderQty: number;
  adjQty: number;
  totalQty?: number;
  sizes: SizeQty[];
  materials?: Material[];
  /** Production planning notes (persisted on colorways.planning_remarks) */
  planningRemarks?: string;
  completionStatus?: ColorwayCompletionStatus;
  closedAt?: string | null;
  closeReason?: string | null;
}

export type OrderPriority = 'critical' | 'high' | 'normal';

export interface StyleOrder {
  id: string;
  styleId?: string;
  styleName: string;
  styleRef: string;
  poNumber: string;
  buyer: string;
  buyerId?: string;
  orderQty: number;
  adjQty: number;
  totalQty?: number;
  deliveryDate: string;
  orderDate: string;
  jobCardDate?: string;
  garmentType?: string;
  /** Reference sewing SAM (min/pc) — planning uses line_allocations.sam. */
  sewingSam?: number | null;
  /** @deprecated Use sewingSam */
  sam?: number;
  priority?: OrderPriority;
  washType?: string;
  /** Snapshot label from size group at creation (display only). */
  sizeGroupName?: string;
  /** Comma-separated size labels frozen on this order. */
  sizeLabels?: string;
  /** @deprecated Legacy FK — removed from DB */
  sizeGroup?: string;
  processFlow?: string;
  currentDept: string;
  status: string;
  image?: string;
  progress: Record<Department, ProductionProgress>;
  colorways: Colorway[];
  materials?: Material[];
  cuttingAllowance?: number;
  shipmentAllowance?: number;
  remarks?: string;
  activity_versions?: OrderActivityLock[];
}

export interface AssignedResource {
  id: string;
  factory_id?: string;
  departmentId: string;
  departmentName: string;
  resourceName: string;
  resourceType: 'inhouse' | 'outsourced';
  vendorId?: string;
  vendorName?: string;
  avgWF?: number;
  availableEstMins?: number;
  defaultPcs?: number;
  activeWorkers?: number;
  efficiency?: number;
  dailyTarget?: number;
  dailyActual?: number;
  currentStyleId?: string;
}

export interface PlannedMetrics {
  workers?: number;
  plannedEfficiency?: number;
  sam?: number;
  availableMins?: number;
  producedMins?: number;
  learningCurveType?: string;
  dailyOutputs?: { day: number; qty: number; pct: number }[];
  productivity?: number;
  avgDailyOutput?: number;
}

export interface LineAllocation {
  id: string;
  lineId: string;
  /** Parent style_orders id */
  orderId: string;
  /** Colorway this row plans (each allocation row is colorway-scoped) */
  colorwayId?: string;
  departmentId?: string;
  styleName: string;
  poNumber: string;
  colorway: string;
  qty: number;
  dailyTarget: number;
  /** Planned pieces per hour — saved from planning (daily ÷ regular shift hours). */
  hourlyTarget?: number | null;
  startDate: string;
  endDate: string;
  status: string;
  progress: number;
  completed_is_true?: boolean;
  /** Planned SAM (min/pc) — authoritative for KPIs. */
  sam?: number | null;
  kpiInputs?: AllocationKpiInputs;
  actualQty?: number;
  actualEndDate?: string;
  plannedMetrics?: PlannedMetrics;
  learningCurveId?: string;
}

export interface LearningCurve {
  id: string;
  name: string;
  days: number;
  levels: number[];
  isDefault?: boolean;
}

export interface CuttingRollRef {
  roll_id: string;
  roll_no: string;
  lot_no?: string;
  qty_used?: number;
}

export interface CuttingReport {
  id: string;
  date: string;
  orderId: string;
  styleName: string;
  color: string;
  poNumber: string;
  markerId: string;
  markerLength: number;
  totalPlys: number;
  totalPieces: number;
  status: "Pending" | "Processed";
  rollsUsed: CuttingRollRef[];
  ratio: { size: string; count: number }[];
  generatedBatchIds?: string[];
}

export interface CuttingBatchRollEntry {
  roll: {
    plies: number;
    width: number;
    lot_no: string;
    balance: number;
    end_bit: number;
    roll_id: string;
    roll_no: string;
    lay_used: number;
    shortage: number;
    available_qty: number;
  };
  sizes: Record<string, number>;
}

export interface CuttingBatchOverallMetrics {
  metric: "yards" | "meter" | "inches";
  entries: Record<string, CuttingBatchRollEntry>;
  totals: {
    total_pieces: number;
    fabric_consumed: number;
    size_wise_ratio: Record<string, number>;
    size_wise_pieces: Record<string, number>;
  };
  balance: Record<string, { balance: number }>;
}

export interface CuttingBatch {
  id: string;
  orderId: string;
  colorwayId: string;
  layermanId?: string;
  cutNumber: string;
  cuttingDate: string;
  status: "Pending" | "In Progress" | "Completed" | "Cancelled";
  markerNumber?: string;
  markerLength?: number;
  markerWidth?: number;
  patternNumber?: string;
  layLength: number;
  overallMetrics: CuttingBatchOverallMetrics;
  alreadyGenerated: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface Batch {
  id: string;
  reportId: string;
  date: string;
  style: string;
  po: string;
  color: string;
  qty: number;
  status: string;
  markerLength: number;
  fabricInfo: string;
  plies: number;
  efficiency: number;
}

export interface DepartmentActivity {
  id: string;
  name: string;
  isQc: boolean;
  allowedRoles?: string[];
  isHidden?: boolean;
}

export interface ActivityItem {
  name: string;
  order: number;
  is_qc: boolean;
}

export interface ActivityVersion {
  id: string;
  dept_id: string;
  factory_id: string;
  activities: ActivityItem[];
  version: number;
  is_current: boolean;
  created_at: string;
}

export interface OrderActivityLock {
  dept_id: string;
  activity_list_id: string;
}

export interface OrderJourneyStep {
  dept_id: string;
  dept_name: string;
  sequence: number;
  version: number;
  activities: ActivityItem[];
}

export interface DepartmentConfig {
  id: string;
  name: string;
  sequence: number | null;
  isOutsourced?: boolean;
  workerRoles?: string[];
  apps?: {
    hourlyOutput?: boolean;
    qcCheck?: boolean;
    audit?: boolean;
    transaction?: boolean;
    workforceLog?: boolean;
    attendance?: boolean;
  };
  isDetailedPlan?: boolean;
  isDefault?: boolean;
}

export interface DailyProduction {
  id: string;
  date: string;
  allocationId?: string;
  lineId?: string;
  orderId?: string;
  colorway?: string;
  operators: number;
  helpers: number;
  checkers: number;
  totalWorkers: number;
  targetQty: number;
  actualQty: number;
  rejectedQty: number;
  availableMins?: number;
  producedMins?: number;
  efficiency?: number;
  shiftStart?: string;
  shiftEnd?: string;
}

export interface Garment {
  id: string;
  qrCode: string;
  orderId?: string;
  orderColorId?: string;
  size: string;
  pieceNo: number;
  cuttingBatchId?: string;
  fabricRollId?: string;
  currentDepartmentId?: string;
  currentActivity?: string;
  upcomingActivity?: string;
  status?: string;
  isRework?: boolean;
  factoryId?: string;
  processFlowId?: string;
  createdAt: string;
  updatedAt: string;
}

export type InputSource = 'order' | 'shift' | 'resource' | 'manual' | 'default';
export type InputType = 'number' | 'percent' | 'select';
export type PlanningMode = 'capacity' | 'efficiency' | 'throughput' | 'manual';

export interface DeptPlanningInput {
  id: string;
  departmentId: string;
  fieldKey: string;
  label: string;
  source: InputSource;
  sourceField?: string;
  defaultValue?: number;
  inputType: InputType;
  isEditable: boolean;
  sortOrder: number;
}

export interface DeptPlanningOutput {
  id: string;
  departmentId: string;
  fieldKey: string;
  label: string;
  formula: string;
  unit?: string;
  isPrimary: boolean;
  sortOrder: number;
}

export interface DepartmentConfigExtended extends DepartmentConfig {
  planningMode?: PlanningMode;
}

export interface AllocationKpiInputs {
  [fieldKey: string]: number;
}
