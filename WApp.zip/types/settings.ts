export interface Buyer {
  id: string;
  factory_id: string;
  name: string;
  code: string | null;
  country: string | null;
  type: string | null;
  status: string | null;
  contactName: string | null;
  contactEmail: string | null;
  contactRole: string | null;
  overShipmentAllowance: number | null;
  underShipmentAllowance: number | null;
  packingRule: string | null;
}

export interface Vendor {
  id: string;
  factory_id: string;
  name: string;
  code: string | null;
  type: string | null;
  status: string | null;
  location: string | null;
}

export interface DepartmentEntity {
  id: string;
  factory_id: string;
  name: string;
  sequence: number;
  apps: string[];
  workerRoles: string[];
  isOutsourced: boolean;
  isProduction?: boolean;
}

/** Per-department resource row in Settings (lazy-loaded, separate from department form). */
export interface DepartmentResource {
  id: string;
  resourceName: string;
  departmentId?: string;
  departmentName?: string;
  defaultPcs?: number;
}

export interface DepartmentResourceSession {
  deptId: string;
  draft: DepartmentResource[];
  baseline: DepartmentResource[];
  status: 'loading' | 'ready';
  /** True once the user edits resources after select/load. */
  draftTouched?: boolean;
}

export interface ShiftHourBlock {
  start: string;
  end: string;
  type: 'active' | 'break' | string;
}

export interface Shift {
  id: string;
  factory_id: string;
  name: string;
  type: 'Regular' | 'Overtime' | string;
  startTime: string | null;
  endTime: string | null;
  breakStart: string | null;
  breakEnd: string | null;
  hours: ShiftHourBlock[];
}

export interface ProcessFlowStep {
  flow_step: number;
  dept_id: string;
  dept_name: string;
}

export interface ProcessFlow {
  id: string;
  factory_id: string;
  name: string;
  description?: string | null;
  version: number;
  is_current: boolean;
  parent_flow_id?: string | null;
  steps: ProcessFlowStep[];
}

export interface Rack {
  id: string;
  factory_id: string;
  name: string;
  location?: string | null;
}

export interface SizeGroup {
  id: string;
  factory_id?: string;
  buyerId: string | null;
  name: string;
  sizes: string[];
  baseSize?: string | null;
  garmentType?: string | null;
}

export interface SupportDropdown {
  id: string;
  factory_id: string;
  category: string;
  app_name: string | null;
  values: string[];
}

export interface DefectItem {
  category: string;
  name: string;
  code: string;
}

export interface DepartmentDefectRecord {
  id: string;
  factory_id: string;
  department_id: string | null;
  defects: DefectItem[];
  created_at?: string;
  updated_at?: string;
}
