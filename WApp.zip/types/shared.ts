export type RoutePath =
  | "#/dashboard"
  | "#/create-order"
  | "#/style-details/:id"
  | "#/style-color-details/:id/:colorId"
  | "#/line-assignment"
  | "#/planning-detail"
  | "#/dept-schedule"
  | "#/status-tracker"
  | "#/admin"
  | "#/settings"
  | "#/user-management"
  | "#/workforce"
  | "#/reports"
  | "#/reports/day"
  | "#/reports/style"
  | "#/production/order-completion"
  | "#/planning/transaction-report";

export const RoutePath = {
  DASHBOARD: "#/dashboard",
  CREATE_ORDER: "#/create-order",
  STYLE_DETAILS: "#/style-details/:id",
  STYLE_COLOR_DETAILS: "#/style-color-details/:id/:colorId",
  LINE_ASSIGNMENT: "#/line-assignment",
  PLANNING_DETAIL: "#/planning-detail",
  DEPT_SCHEDULE: "#/dept-schedule",
  STATUS_TRACKER: "#/status-tracker",
  ADMIN: "#/admin",
  SETTINGS: "#/settings",
  USER_MANAGEMENT: "#/user-management",
  WORKFORCE: "#/workforce",
  REPORTS: "#/reports",
  REPORTS_DAY: "#/reports/day",
  REPORTS_STYLE: "#/reports/style",
  ORDER_COMPLETION: "#/production/order-completion",
  TRANSACTION_REPORT: "#/planning/transaction-report",
} as const;

export type Department =
  | "Cutting"
  | "Sewing"
  | "Washing"
  | "Finishing"
  | "Packing";
