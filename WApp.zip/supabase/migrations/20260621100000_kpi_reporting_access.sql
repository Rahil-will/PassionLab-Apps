-- KPI reporting: SECURITY DEFINER RPCs (bypass RLS on underlying capture tables)
-- + grants on view chain for direct PostgREST reads from v_daily_kpis.

-- Reporting views
GRANT SELECT ON public.v_daily_quality TO authenticated;
GRANT SELECT ON public.v_daily_kpis_by_shift TO authenticated;
GRANT SELECT ON public.v_daily_kpis TO authenticated;
GRANT SELECT ON public.v_daily_output TO authenticated;
GRANT SELECT ON public.v_daily_target TO authenticated;
GRANT SELECT ON public.v_daily_workforce TO authenticated;
GRANT SELECT ON public.v_wip_dept TO authenticated;
GRANT SELECT ON public.v_shift_minutes TO authenticated;

GRANT SELECT ON public.hourly_counts TO authenticated;
GRANT SELECT ON public.workforce_logs TO authenticated;
GRANT SELECT ON public.handover_slips TO authenticated;
GRANT SELECT ON public.shifts TO authenticated;

CREATE OR REPLACE FUNCTION public.get_factory_kpis(
  p_factory_id uuid,
  p_date_from date,
  p_date_to date
)
RETURNS SETOF public.v_daily_kpis
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT *
  FROM public.v_daily_kpis
  WHERE factory_id = p_factory_id
    AND p_factory_id = public.current_factory_id()
    AND log_date >= p_date_from
    AND log_date <= p_date_to
  ORDER BY log_date, department_id, order_id;
$$;

CREATE OR REPLACE FUNCTION public.get_department_kpis(
  p_factory_id uuid,
  p_department_id uuid,
  p_date_from date,
  p_date_to date
)
RETURNS SETOF public.v_daily_kpis
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT *
  FROM public.v_daily_kpis
  WHERE factory_id = p_factory_id
    AND p_factory_id = public.current_factory_id()
    AND department_id = p_department_id
    AND log_date >= p_date_from
    AND log_date <= p_date_to
  ORDER BY log_date, order_id;
$$;

CREATE OR REPLACE FUNCTION public.get_department_kpis_by_shift(
  p_factory_id uuid,
  p_department_id uuid,
  p_date_from date,
  p_date_to date
)
RETURNS SETOF public.v_daily_kpis_by_shift
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT *
  FROM public.v_daily_kpis_by_shift
  WHERE factory_id = p_factory_id
    AND p_factory_id = public.current_factory_id()
    AND department_id = p_department_id
    AND log_date >= p_date_from
    AND log_date <= p_date_to
  ORDER BY log_date, shift_name, order_id;
$$;

CREATE OR REPLACE FUNCTION public.get_style_kpis(
  p_factory_id uuid,
  p_order_id uuid
)
RETURNS SETOF public.v_daily_kpis
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT k.*
  FROM public.v_daily_kpis k
  JOIN public.style_orders so
    ON so.id = k.order_id
   AND so.factory_id = k.factory_id
  WHERE k.factory_id = p_factory_id
    AND p_factory_id = public.current_factory_id()
    AND k.order_id = p_order_id
    AND (
      so.process_flow_id IS NULL
      OR k.department_id IN (
        SELECT pfs.department_id
        FROM public.process_flow_steps pfs
        WHERE pfs.flow_id = so.process_flow_id
      )
    )
  ORDER BY k.log_date, k.department_id;
$$;

CREATE OR REPLACE FUNCTION public.get_live_dept_kpi(
  p_factory_id uuid,
  p_department_id uuid
)
RETURNS SETOF public.v_daily_kpis
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT *
  FROM public.v_daily_kpis
  WHERE factory_id = p_factory_id
    AND p_factory_id = public.current_factory_id()
    AND department_id = p_department_id
    AND log_date = CURRENT_DATE
  ORDER BY order_id;
$$;

CREATE OR REPLACE FUNCTION public.get_dept_quality_for_date(
  p_factory_id uuid,
  p_department_id uuid,
  p_log_date date
)
RETURNS SETOF public.v_daily_quality
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT *
  FROM public.v_daily_quality
  WHERE factory_id = p_factory_id
    AND p_factory_id = public.current_factory_id()
    AND department_id = p_department_id
    AND log_date = p_log_date
  ORDER BY order_id;
$$;

REVOKE ALL ON FUNCTION public.get_factory_kpis(uuid, date, date) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.get_department_kpis(uuid, uuid, date, date) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.get_department_kpis_by_shift(uuid, uuid, date, date) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.get_style_kpis(uuid, uuid) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.get_live_dept_kpi(uuid, uuid) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.get_dept_quality_for_date(uuid, uuid, date) FROM PUBLIC;

GRANT EXECUTE ON FUNCTION public.get_factory_kpis(uuid, date, date) TO authenticated;
GRANT EXECUTE ON FUNCTION public.get_department_kpis(uuid, uuid, date, date) TO authenticated;
GRANT EXECUTE ON FUNCTION public.get_department_kpis_by_shift(uuid, uuid, date, date) TO authenticated;
GRANT EXECUTE ON FUNCTION public.get_style_kpis(uuid, uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.get_live_dept_kpi(uuid, uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.get_dept_quality_for_date(uuid, uuid, date) TO authenticated;

REVOKE EXECUTE ON FUNCTION public.get_factory_kpis(uuid, date, date) FROM anon;
REVOKE EXECUTE ON FUNCTION public.get_department_kpis(uuid, uuid, date, date) FROM anon;
REVOKE EXECUTE ON FUNCTION public.get_department_kpis_by_shift(uuid, uuid, date, date) FROM anon;
REVOKE EXECUTE ON FUNCTION public.get_style_kpis(uuid, uuid) FROM anon;
REVOKE EXECUTE ON FUNCTION public.get_live_dept_kpi(uuid, uuid) FROM anon;
REVOKE EXECUTE ON FUNCTION public.get_dept_quality_for_date(uuid, uuid, date) FROM anon;
