-- Department defect catalog: one row per department, defects stored as JSONB array.

CREATE TABLE IF NOT EXISTS public.defects (
  id uuid NOT NULL DEFAULT gen_random_uuid(),
  factory_id uuid NOT NULL REFERENCES public.factories(id) ON DELETE CASCADE,
  department_id uuid NULL REFERENCES public.departments(id) ON DELETE CASCADE,
  defects jsonb NOT NULL DEFAULT '[]'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT defects_pkey PRIMARY KEY (id),
  CONSTRAINT defects_factory_id_department_id_key UNIQUE (factory_id, department_id)
);

CREATE INDEX IF NOT EXISTS defects_factory_id_idx ON public.defects (factory_id);
CREATE INDEX IF NOT EXISTS defects_department_id_idx ON public.defects (department_id);

COMMENT ON TABLE public.defects IS
  'Per-department QC defect catalog. defects JSON: [{category, name, code}, ...].';

-- Default defect sets keyed by department name (Cutting, Sewing, Finishing).
CREATE OR REPLACE FUNCTION public.default_defects_for_department(p_dept_name text)
RETURNS jsonb
LANGUAGE sql
IMMUTABLE
AS $$
  SELECT CASE
    WHEN lower(trim(coalesce(p_dept_name, ''))) LIKE '%cut%' THEN
      '[
        {"category":"Fabric","name":"Shading","code":"CUT-F-01"},
        {"category":"Fabric","name":"Hole","code":"CUT-F-02"},
        {"category":"Fabric","name":"Stain","code":"CUT-F-03"},
        {"category":"Fabric","name":"Weaving fault","code":"CUT-F-04"},
        {"category":"Cutting","name":"Wrong size cut","code":"CUT-C-01"},
        {"category":"Cutting","name":"Missing notch","code":"CUT-C-02"},
        {"category":"Cutting","name":"Overcut","code":"CUT-C-03"},
        {"category":"Cutting","name":"Undercut","code":"CUT-C-04"}
      ]'::jsonb
    WHEN lower(trim(coalesce(p_dept_name, ''))) LIKE '%sew%' THEN
      '[
        {"category":"Stitching","name":"Open seam","code":"SEW-S-01"},
        {"category":"Stitching","name":"Skipped stitch","code":"SEW-S-02"},
        {"category":"Stitching","name":"Broken stitch","code":"SEW-S-03"},
        {"category":"Stitching","name":"Uneven stitch","code":"SEW-S-04"},
        {"category":"Assembly","name":"Wrong label","code":"SEW-A-01"},
        {"category":"Assembly","name":"Missing trim","code":"SEW-A-02"},
        {"category":"Assembly","name":"Puckering","code":"SEW-A-03"},
        {"category":"Assembly","name":"Raw edge","code":"SEW-A-04"}
      ]'::jsonb
    WHEN lower(trim(coalesce(p_dept_name, ''))) LIKE '%finish%' THEN
      '[
        {"category":"Pressing","name":"Shiny mark","code":"FIN-P-01"},
        {"category":"Pressing","name":"Crease mark","code":"FIN-P-02"},
        {"category":"Pressing","name":"Burn mark","code":"FIN-P-03"},
        {"category":"Appearance","name":"Stain","code":"FIN-A-01"},
        {"category":"Appearance","name":"Loose thread","code":"FIN-A-02"},
        {"category":"Appearance","name":"Wrong button","code":"FIN-A-03"},
        {"category":"Appearance","name":"Color bleeding","code":"FIN-A-04"}
      ]'::jsonb
    ELSE
      '[
        {"category":"General","name":"Defect","code":"GEN-01"},
        {"category":"General","name":"Rework needed","code":"GEN-02"}
      ]'::jsonb
  END;
$$;

COMMENT ON FUNCTION public.default_defects_for_department(text) IS
  'Seed defect catalog for a department. Matches Cutting, Sewing, Finishing by name; generic fallback otherwise.';

CREATE OR REPLACE FUNCTION public.seed_department_defects()
RETURNS trigger
LANGUAGE plpgsql
SECURITY INVOKER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.defects (factory_id, department_id, defects)
  VALUES (
    NEW.factory_id,
    NEW.id,
    public.default_defects_for_department(NEW.name)
  )
  ON CONFLICT (factory_id, department_id) DO NOTHING;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_seed_department_defects ON public.departments;
CREATE TRIGGER trg_seed_department_defects
  AFTER INSERT ON public.departments
  FOR EACH ROW
  EXECUTE FUNCTION public.seed_department_defects();

-- Backfill existing departments missing a defects row.
INSERT INTO public.defects (factory_id, department_id, defects)
SELECT d.factory_id, d.id, public.default_defects_for_department(d.name)
FROM public.departments d
WHERE NOT EXISTS (
  SELECT 1
  FROM public.defects df
  WHERE df.factory_id = d.factory_id
    AND df.department_id IS NOT DISTINCT FROM d.id
);

-- updated_at maintenance
CREATE OR REPLACE FUNCTION public.set_defects_updated_at()
RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
  NEW.updated_at := now();
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_defects_updated_at ON public.defects;
CREATE TRIGGER trg_defects_updated_at
  BEFORE UPDATE ON public.defects
  FOR EACH ROW
  EXECUTE FUNCTION public.set_defects_updated_at();

ALTER TABLE public.defects ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS defects_select ON public.defects;
DROP POLICY IF EXISTS defects_insert ON public.defects;
DROP POLICY IF EXISTS defects_update ON public.defects;
DROP POLICY IF EXISTS defects_delete ON public.defects;

CREATE POLICY defects_select ON public.defects
  FOR SELECT TO authenticated
  USING (factory_id = public.current_factory_id());

CREATE POLICY defects_insert ON public.defects
  FOR INSERT TO authenticated
  WITH CHECK (factory_id = public.current_factory_id());

CREATE POLICY defects_update ON public.defects
  FOR UPDATE TO authenticated
  USING (factory_id = public.current_factory_id())
  WITH CHECK (factory_id = public.current_factory_id());

CREATE POLICY defects_delete ON public.defects
  FOR DELETE TO authenticated
  USING (factory_id = public.current_factory_id());

GRANT SELECT, INSERT, UPDATE, DELETE ON public.defects TO authenticated;
