-- Shipment QA audits (logged from shipment floor app; read-only in main desktop reports).

CREATE TABLE IF NOT EXISTS public.shipment_audits (
  id uuid NOT NULL DEFAULT gen_random_uuid(),
  factory_id uuid NOT NULL,
  order_id uuid NOT NULL,
  colorway_id uuid NOT NULL,
  audit_type text NOT NULL,
  audit_date date NOT NULL DEFAULT CURRENT_DATE,
  lot_size integer NOT NULL,
  sample_size integer NOT NULL,
  aql_level text NULL,
  passed integer NOT NULL DEFAULT 0,
  failed integer NOT NULL DEFAULT 0,
  major_failed integer NOT NULL DEFAULT 0,
  minor_failed integer NOT NULL DEFAULT 0,
  result text NULL,
  pieces_json jsonb NOT NULL DEFAULT '[]'::jsonb,
  status text NOT NULL DEFAULT 'completed'::text,
  notes text NULL,
  logged_by uuid NOT NULL,
  logged_at timestamptz NOT NULL DEFAULT now(),
  completed_at timestamptz NULL,
  reaudit_of uuid NULL,
  CONSTRAINT shipment_audits_pkey PRIMARY KEY (id),
  CONSTRAINT shipment_audits_reaudit_of_fkey FOREIGN KEY (reaudit_of)
    REFERENCES shipment_audits (id) ON DELETE SET NULL,
  CONSTRAINT shipment_audits_colorway_id_fkey FOREIGN KEY (colorway_id)
    REFERENCES colorways (id) ON DELETE CASCADE,
  CONSTRAINT shipment_audits_factory_id_fkey FOREIGN KEY (factory_id)
    REFERENCES factories (id) ON DELETE CASCADE,
  CONSTRAINT shipment_audits_logged_by_fkey FOREIGN KEY (logged_by)
    REFERENCES profiles (id),
  CONSTRAINT shipment_audits_order_id_fkey FOREIGN KEY (order_id)
    REFERENCES style_orders (id) ON DELETE CASCADE,
  CONSTRAINT shipment_audits_status_check CHECK (
    status = ANY (ARRAY['in_progress'::text, 'completed'::text])
  ),
  CONSTRAINT shipment_audits_result_check CHECK (
    result IS NULL OR result = ANY (ARRAY['pass'::text, 'fail'::text])
  ),
  CONSTRAINT shipment_audits_audit_type_check CHECK (
    audit_type = ANY (
      ARRAY['midline'::text, 'internal_final'::text, 'shipment'::text, 'reaudit'::text]
    )
  )
);

CREATE INDEX IF NOT EXISTS idx_shipment_audits_order_colorway
  ON public.shipment_audits USING btree (factory_id, order_id, colorway_id, logged_at DESC);

CREATE UNIQUE INDEX IF NOT EXISTS idx_shipment_audits_one_pause_per_user
  ON public.shipment_audits USING btree (factory_id, order_id, colorway_id, logged_by)
  WHERE status = 'in_progress'::text;

ALTER TABLE public.shipment_audits ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS shipment_audits_factory ON public.shipment_audits;
CREATE POLICY shipment_audits_factory ON public.shipment_audits
  FOR ALL
  USING (factory_id = public.current_factory_id())
  WITH CHECK (factory_id = public.current_factory_id());

CREATE OR REPLACE VIEW public.v_shipment_audits AS
SELECT
  sa.id,
  sa.factory_id,
  sa.order_id,
  sa.colorway_id,
  sa.audit_type,
  sa.audit_date,
  sa.lot_size,
  sa.sample_size,
  sa.aql_level,
  sa.passed,
  sa.failed,
  sa.major_failed,
  sa.minor_failed,
  sa.result,
  sa.pieces_json,
  sa.status,
  sa.notes,
  sa.logged_by,
  sa.logged_at,
  sa.completed_at,
  sa.reaudit_of,
  so.style_name,
  so.po_number,
  cw.name AS colorway_name,
  p.full_name AS logged_by_name
FROM public.shipment_audits sa
JOIN public.style_orders so ON so.id = sa.order_id
JOIN public.colorways cw ON cw.id = sa.colorway_id
LEFT JOIN public.profiles p ON p.id = sa.logged_by;

COMMENT ON VIEW public.v_shipment_audits IS
  'Shipment QA audits with order/colorway labels for reports and order completion.';

GRANT SELECT ON public.shipment_audits TO authenticated;
GRANT SELECT ON public.v_shipment_audits TO authenticated;
