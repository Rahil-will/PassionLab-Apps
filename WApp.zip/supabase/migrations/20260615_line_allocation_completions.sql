-- Completion state lives on line_allocations (no separate completions table).
-- QC uses inspection_sessions only (inspections table dropped).

ALTER TABLE public.line_allocations
  ADD COLUMN IF NOT EXISTS production_completed_at timestamptz,
  ADD COLUMN IF NOT EXISTS production_completed_by uuid REFERENCES public.profiles(id),
  ADD COLUMN IF NOT EXISTS production_comments text,
  ADD COLUMN IF NOT EXISTS production_planned_qty integer,
  ADD COLUMN IF NOT EXISTS production_produced_qty integer,
  ADD COLUMN IF NOT EXISTS handover_completed_at timestamptz,
  ADD COLUMN IF NOT EXISTS handover_completed_by uuid REFERENCES public.profiles(id),
  ADD COLUMN IF NOT EXISTS handover_comments text,
  ADD COLUMN IF NOT EXISTS handover_sent_qty integer,
  ADD COLUMN IF NOT EXISTS handover_available_qty integer,
  ADD COLUMN IF NOT EXISTS handover_produced_qty integer;

ALTER TABLE public.rejections
  ADD COLUMN IF NOT EXISTS defect_summary jsonb DEFAULT '{}'::jsonb,
  ADD COLUMN IF NOT EXISTS rejected_qty_by_size jsonb DEFAULT '{}'::jsonb,
  ADD COLUMN IF NOT EXISTS image_urls text[] DEFAULT '{}';

CREATE OR REPLACE FUNCTION public.floor_capture_allocation_complete(p_payload jsonb)
RETURNS jsonb
LANGUAGE plpgsql
AS $$
DECLARE
  v_factory_id uuid := (p_payload->>'factoryId')::uuid;
  v_user_id uuid := (p_payload->>'userId')::uuid;
  v_line_id uuid := NULLIF(p_payload->>'resourceId', '')::uuid;
  v_order_id uuid := (p_payload->>'orderId')::uuid;
  v_colorway_id uuid := NULLIF(p_payload->>'colorwayId', '')::uuid;
  v_department_id uuid := (p_payload->>'departmentId')::uuid;
  v_completion_type text := COALESCE(NULLIF(p_payload->>'completionType', ''), 'production');
  v_updated integer;
BEGIN
  IF v_line_id IS NULL OR v_order_id IS NULL OR v_department_id IS NULL THEN
    RETURN public.floor_capture_fail('resourceId, orderId and departmentId are required', 'MISSING_FIELDS');
  END IF;

  IF v_completion_type NOT IN ('production', 'handover') THEN
    RETURN public.floor_capture_fail('Invalid completionType', 'INVALID_COMPLETION_TYPE');
  END IF;

  IF v_completion_type = 'production' THEN
    UPDATE public.line_allocations
    SET
      production_completed_at = COALESCE((p_payload->>'loggedAt')::timestamptz, now()),
      production_completed_by = v_user_id,
      production_comments = NULLIF(p_payload->>'comments', ''),
      production_planned_qty = NULLIF(p_payload->>'plannedQty', '')::integer,
      production_produced_qty = NULLIF(p_payload->>'producedQty', '')::integer
    WHERE factory_id = v_factory_id
      AND line_id = v_line_id
      AND order_id = v_order_id
      AND colorway_id IS NOT DISTINCT FROM v_colorway_id
      AND department_id = v_department_id;
  ELSE
    UPDATE public.line_allocations
    SET
      handover_completed_at = COALESCE((p_payload->>'loggedAt')::timestamptz, now()),
      handover_completed_by = v_user_id,
      handover_comments = NULLIF(p_payload->>'comments', ''),
      handover_produced_qty = NULLIF(p_payload->>'producedQty', '')::integer,
      handover_sent_qty = NULLIF(p_payload->>'sentQty', '')::integer,
      handover_available_qty = NULLIF(p_payload->>'availableQty', '')::integer
    WHERE factory_id = v_factory_id
      AND line_id = v_line_id
      AND order_id = v_order_id
      AND colorway_id IS NOT DISTINCT FROM v_colorway_id
      AND department_id = v_department_id;
  END IF;

  GET DIAGNOSTICS v_updated = ROW_COUNT;
  IF v_updated = 0 THEN
    RETURN public.floor_capture_fail('No matching line allocation found', 'ALLOCATION_NOT_FOUND');
  END IF;

  RETURN jsonb_build_object('ok', true);
END;
$$;

CREATE OR REPLACE FUNCTION public.floor_capture_allocation_reopen(p_payload jsonb)
RETURNS jsonb
LANGUAGE plpgsql
AS $$
DECLARE
  v_factory_id uuid := (p_payload->>'factoryId')::uuid;
  v_line_id uuid := NULLIF(p_payload->>'resourceId', '')::uuid;
  v_order_id uuid := (p_payload->>'orderId')::uuid;
  v_colorway_id uuid := NULLIF(p_payload->>'colorwayId', '')::uuid;
  v_department_id uuid := NULLIF(p_payload->>'departmentId', '')::uuid;
  v_completion_type text := COALESCE(NULLIF(p_payload->>'completionType', ''), 'production');
BEGIN
  IF v_completion_type = 'production' THEN
    UPDATE public.line_allocations
    SET
      production_completed_at = NULL,
      production_completed_by = NULL,
      production_comments = NULL,
      production_planned_qty = NULL,
      production_produced_qty = NULL
    WHERE factory_id = v_factory_id
      AND line_id = v_line_id
      AND order_id = v_order_id
      AND colorway_id IS NOT DISTINCT FROM v_colorway_id
      AND (v_department_id IS NULL OR department_id = v_department_id);
  ELSE
    UPDATE public.line_allocations
    SET
      handover_completed_at = NULL,
      handover_completed_by = NULL,
      handover_comments = NULL,
      handover_produced_qty = NULL,
      handover_sent_qty = NULL,
      handover_available_qty = NULL
    WHERE factory_id = v_factory_id
      AND line_id = v_line_id
      AND order_id = v_order_id
      AND colorway_id IS NOT DISTINCT FROM v_colorway_id
      AND (v_department_id IS NULL OR department_id = v_department_id);
  END IF;

  RETURN jsonb_build_object('ok', true);
END;
$$;

DROP TABLE IF EXISTS public.line_allocation_completions;
-- inspections dropped in 20260616_qc_sessions_replace_inspections.sql after views migrate

DO $patch$
DECLARE
  v_old text := E'  IF p_type = ''allocation_complete'' THEN\n    RETURN jsonb_build_object(''ok'', true);\n  END IF;\n\n  RETURN public.floor_capture_fail(''Unknown capture type'', ''UNKNOWN_CAPTURE_TYPE'');';
  v_new text := E'  IF p_type = ''allocation_complete'' THEN\n    IF p_payload->>''orderId'' IS NULL OR p_payload->>''resourceId'' IS NULL OR p_payload->>''departmentId'' IS NULL THEN\n      RETURN public.floor_capture_fail(''orderId, resourceId and departmentId are required'', ''MISSING_FIELDS'');\n    END IF;\n    IF v_profile_department_id IS NULL OR (p_payload->>''departmentId'')::uuid IS DISTINCT FROM v_profile_department_id THEN\n      RETURN public.floor_capture_fail(''departmentId must match user department'', ''DEPT_MISMATCH'',\n        jsonb_build_object(''expectedDepartmentId'', v_profile_department_id));\n    END IF;\n    RETURN public.floor_capture_allocation_complete(\n      p_payload || jsonb_build_object(''factoryId'', p_factory_id, ''userId'', p_user_id)\n    );\n  END IF;\n\n  IF p_type = ''allocation_reopen'' THEN\n    IF p_payload->>''orderId'' IS NULL OR p_payload->>''resourceId'' IS NULL THEN\n      RETURN public.floor_capture_fail(''orderId and resourceId are required'', ''MISSING_FIELDS'');\n    END IF;\n    RETURN public.floor_capture_allocation_reopen(\n      p_payload || jsonb_build_object(''factoryId'', p_factory_id)\n    );\n  END IF;\n\n  RETURN public.floor_capture_fail(''Unknown capture type'', ''UNKNOWN_CAPTURE_TYPE'');';
  v_def text;
BEGIN
  v_def := pg_get_functiondef('public.floor_capture(uuid,uuid,text,jsonb)'::regprocedure);
  IF position(v_old in v_def) = 0 THEN
    RAISE NOTICE 'floor_capture allocation_complete stub not found — skip patch';
    RETURN;
  END IF;
  v_def := replace(v_def, v_old, v_new);
  EXECUTE v_def;
END;
$patch$;
