-- inspection_sessions.rework duplicated rework_passed and is unused by reporting views.
-- Canonical: passed = total pass (incl. rework pass); defective = failed; pending rework = failed - rework_passed.

ALTER TABLE public.inspection_sessions
  DROP COLUMN IF EXISTS rework;

COMMENT ON COLUMN public.inspection_sessions.rework_passed IS
  'Pieces that passed after rework. Pending rework = failed - rework_passed (per size via rework_by_size).';

NOTIFY pgrst, 'reload schema';
  