-- Grant SELECT on KPI reporting views to authenticated role.
-- SECURITY INVOKER RPCs (get_factory_kpis, etc.) require the caller to have view access.

GRANT SELECT ON public.v_daily_quality TO authenticated;
GRANT SELECT ON public.v_daily_kpis_by_shift TO authenticated;
GRANT SELECT ON public.v_daily_kpis TO authenticated;

-- Underlying views referenced by v_daily_kpis (chain must be readable)
GRANT SELECT ON public.v_daily_output TO authenticated;
GRANT SELECT ON public.v_daily_target TO authenticated;
GRANT SELECT ON public.v_daily_workforce TO authenticated;
GRANT SELECT ON public.v_wip_dept TO authenticated;
GRANT SELECT ON public.v_shift_minutes TO authenticated;
