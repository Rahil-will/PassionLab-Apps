-- Factory-level floor app entitlements (set at onboarding; filters Settings + User Management).

ALTER TABLE public.factories
  ADD COLUMN IF NOT EXISTS transaction_apps jsonb NOT NULL DEFAULT '["transaction"]'::jsonb,
  ADD COLUMN IF NOT EXISTS production_apps jsonb NOT NULL DEFAULT '["hourly","qc_log"]'::jsonb,
  ADD COLUMN IF NOT EXISTS workforce_apps jsonb NOT NULL DEFAULT '["workforce_log","attendance"]'::jsonb,
  ADD COLUMN IF NOT EXISTS audit_apps jsonb NOT NULL DEFAULT '["audit"]'::jsonb,
  ADD COLUMN IF NOT EXISTS shipment_apps jsonb NOT NULL DEFAULT '["shipment_log","final_rejection_log"]'::jsonb;

COMMENT ON COLUMN public.factories.transaction_apps IS
  'Enabled transaction apps for this factory (department.apps). Default: ["transaction"].';
COMMENT ON COLUMN public.factories.production_apps IS
  'Enabled production capture apps: hourly, qc_log. Department editor shows only these.';
COMMENT ON COLUMN public.factories.workforce_apps IS
  'Enabled workforce apps: workforce_log, attendance.';
COMMENT ON COLUMN public.factories.audit_apps IS
  'Enabled optional audit apps: audit.';
COMMENT ON COLUMN public.factories.shipment_apps IS
  'Enabled factory-function shipment/QA apps: shipment_log, final_rejection_log.';

ALTER TABLE public.factories
  ADD CONSTRAINT factories_transaction_apps_is_array CHECK (jsonb_typeof(transaction_apps) = 'array'),
  ADD CONSTRAINT factories_production_apps_is_array CHECK (jsonb_typeof(production_apps) = 'array'),
  ADD CONSTRAINT factories_workforce_apps_is_array CHECK (jsonb_typeof(workforce_apps) = 'array'),
  ADD CONSTRAINT factories_audit_apps_is_array CHECK (jsonb_typeof(audit_apps) = 'array'),
  ADD CONSTRAINT factories_shipment_apps_is_array CHECK (jsonb_typeof(shipment_apps) = 'array');
