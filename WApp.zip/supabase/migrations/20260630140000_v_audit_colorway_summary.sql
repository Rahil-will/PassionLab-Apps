-- Colorway-scoped floor audits (shipment / buyer QA departments log via audit_sessions).
ALTER TABLE public.audit_sessions
  ADD COLUMN IF NOT EXISTS colorway_id uuid REFERENCES public.colorways (id) ON DELETE CASCADE;

CREATE INDEX IF NOT EXISTS audit_sessions_factory_order_colorway_dept_date_idx
  ON public.audit_sessions (factory_id, order_id, colorway_id, department_id, logged_at DESC)
  WHERE colorway_id IS NOT NULL;

CREATE OR REPLACE VIEW public.v_audit_colorway_summary AS
SELECT
  a.factory_id,
  a.order_id,
  a.colorway_id,
  a.department_id,
  a.logged_at::date AS log_date,
  COUNT(*)::integer AS lots_total,
  SUM(
    CASE
      WHEN a.result = 'pass' OR (COALESCE(a.failed, 0) <= 0 AND COALESCE(a.sample_size, 0) > 0) THEN 1
      ELSE 0
    END
  )::integer AS lots_passed,
  SUM(
    CASE
      WHEN a.result = 'fail' OR COALESCE(a.failed, 0) > 0 THEN 1
      ELSE 0
    END
  )::integer AS lots_failed,
  CASE
    WHEN COUNT(*) = 0 THEN NULL
    ELSE ROUND(
      100.0 * SUM(
        CASE
          WHEN a.result = 'pass' OR (COALESCE(a.failed, 0) <= 0 AND COALESCE(a.sample_size, 0) > 0) THEN 1
          ELSE 0
        END
      ) / NULLIF(COUNT(*), 0),
      2
    )::numeric
  END AS lots_pass_pct,
  SUM(COALESCE(a.sample_size, 0))::integer AS pieces_sampled,
  SUM(COALESCE(a.failed, 0))::integer AS failed_pieces,
  CASE
    WHEN SUM(COALESCE(a.sample_size, 0)) = 0 THEN NULL
    ELSE ROUND(
      100.0 * SUM(COALESCE(a.failed, 0)) / NULLIF(SUM(COALESCE(a.sample_size, 0)), 0),
      2
    )::numeric
  END AS defective_pct,
  CASE
    WHEN SUM(COALESCE(a.sample_size, 0)) = 0 THEN NULL
    ELSE ROUND(
      100.0 * SUM(COALESCE(a.failed, 0)) / NULLIF(SUM(COALESCE(a.sample_size, 0)), 0),
      2
    )::numeric
  END AS dhu,
  '[]'::jsonb AS top_defects
FROM public.audit_sessions a
WHERE a.colorway_id IS NOT NULL
GROUP BY
  a.factory_id,
  a.order_id,
  a.colorway_id,
  a.department_id,
  a.logged_at::date;

COMMENT ON VIEW public.v_audit_colorway_summary IS
  'Daily audit summary per colorway and department from audit_sessions.';

GRANT SELECT ON public.v_audit_colorway_summary TO authenticated;
