-- Orders store a comma-separated size label snapshot only (no size_group_id FK).

ALTER TABLE public.style_orders
  ADD COLUMN IF NOT EXISTS size_labels text;

COMMENT ON COLUMN public.style_orders.size_labels IS
  'Comma-separated size labels frozen on this order (e.g. XS,S,M,L). Authoritative qtys live on colorways.sizes.';

-- Backfill from colorway JSONB where possible.
UPDATE public.style_orders so
SET size_labels = agg.labels
FROM (
  SELECT
    cw.order_id,
    string_agg(DISTINCT trim(both '"' from (elem->>'size')), ', ' ORDER BY trim(both '"' from (elem->>'size'))) AS labels
  FROM public.colorways cw
  CROSS JOIN LATERAL jsonb_array_elements(COALESCE(cw.sizes, '[]'::jsonb)) AS elem
  WHERE elem->>'size' IS NOT NULL AND trim(elem->>'size') <> ''
  GROUP BY cw.order_id
) agg
WHERE so.id = agg.order_id
  AND (so.size_labels IS NULL OR so.size_labels = '');

-- Legacy FK removed; size_group_name kept as optional display label.
ALTER TABLE public.style_orders
  DROP CONSTRAINT IF EXISTS style_orders_size_group_id_fkey;

ALTER TABLE public.style_orders
  DROP COLUMN IF EXISTS size_group_id;
