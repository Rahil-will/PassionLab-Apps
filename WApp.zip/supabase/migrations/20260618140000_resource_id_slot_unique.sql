-- Per-line hourly output and QC sessions: include resource_id in slot uniqueness.
-- Prevents two lines on the same order/hour/day from overwriting each other.

-- Dedupe rows that would violate the new keys (keep newest logged_at).
DELETE FROM public.hourly_counts h
WHERE h.id IN (
  SELECT id FROM (
    SELECT id,
      ROW_NUMBER() OVER (
        PARTITION BY factory_id, order_id, department_id,
          COALESCE(colorway_id, '00000000-0000-0000-0000-000000000000'::uuid),
          COALESCE(resource_id, '00000000-0000-0000-0000-000000000000'::uuid),
          hour_slot, log_date
        ORDER BY logged_at DESC NULLS LAST
      ) AS rn
    FROM public.hourly_counts
  ) t WHERE rn > 1
);

DELETE FROM public.inspection_sessions s
WHERE s.id IN (
  SELECT id FROM (
    SELECT id,
      ROW_NUMBER() OVER (
        PARTITION BY factory_id, order_id, department_id, log_date,
          COALESCE(hour_slot, ''),
          COALESCE(colorway_id, '00000000-0000-0000-0000-000000000000'::uuid),
          COALESCE(resource_id, '00000000-0000-0000-0000-000000000000'::uuid)
        ORDER BY logged_at DESC NULLS LAST
      ) AS rn
    FROM public.inspection_sessions
  ) t WHERE rn > 1
);

-- hourly_counts: add resource_id to unique index
DROP INDEX IF EXISTS public.hourly_counts_slot_unique;

CREATE UNIQUE INDEX hourly_counts_slot_unique
  ON public.hourly_counts (
    factory_id,
    order_id,
    department_id,
    COALESCE(colorway_id, '00000000-0000-0000-0000-000000000000'::uuid),
    COALESCE(resource_id, '00000000-0000-0000-0000-000000000000'::uuid),
    hour_slot,
    log_date
  );

COMMENT ON INDEX public.hourly_counts_slot_unique IS
  'One hourly capture per factory/order/dept/colorway/resource/slot/date. NULL ids use sentinel UUID.';

-- inspection_sessions: replace table UNIQUE with index including resource_id
DO $$
DECLARE r record;
BEGIN
  FOR r IN
    SELECT conname FROM pg_constraint
    WHERE conrelid = 'public.inspection_sessions'::regclass AND contype = 'u'
  LOOP
    EXECUTE format('ALTER TABLE public.inspection_sessions DROP CONSTRAINT %I', r.conname);
  END LOOP;
END $$;

DROP INDEX IF EXISTS public.inspection_sessions_slot_unique;

CREATE UNIQUE INDEX inspection_sessions_slot_unique
  ON public.inspection_sessions (
    factory_id,
    order_id,
    department_id,
    log_date,
    COALESCE(hour_slot, ''),
    COALESCE(colorway_id, '00000000-0000-0000-0000-000000000000'::uuid),
    COALESCE(resource_id, '00000000-0000-0000-0000-000000000000'::uuid)
  );

COMMENT ON INDEX public.inspection_sessions_slot_unique IS
  'One QC session per factory/order/dept/date/hour/colorway/resource. NULL ids use sentinels.';

-- floor_capture: match upsert lookups to new unique keys
DO $$
DECLARE
  v_def text;
  v_old_hourly text;
  v_new_hourly text;
  v_old_qc text;
  v_new_qc text;
BEGIN
  v_def := pg_get_functiondef('public.floor_capture(uuid,uuid,text,jsonb)'::regprocedure);
  IF v_def IS NULL THEN
    RAISE EXCEPTION 'floor_capture not found';
  END IF;

  IF v_def LIKE '%COALESCE(resource_id, ''00000000-0000-0000-0000-000000000000''::uuid)%'
     AND v_def LIKE '%FROM public.hourly_counts%' THEN
    RAISE NOTICE 'floor_capture hourly lookup already includes resource_id';
  ELSE
    v_old_hourly := E'      AND COALESCE(colorway_id, ''00000000-0000-0000-0000-000000000000''::uuid)\n        = COALESCE(v_colorway_id, ''00000000-0000-0000-0000-000000000000''::uuid)\n      AND hour_slot = p_payload->>''hourSlot''\n      AND log_date = v_log_date';
    v_new_hourly := E'      AND COALESCE(colorway_id, ''00000000-0000-0000-0000-000000000000''::uuid)\n        = COALESCE(v_colorway_id, ''00000000-0000-0000-0000-000000000000''::uuid)\n      AND COALESCE(resource_id, ''00000000-0000-0000-0000-000000000000''::uuid)\n        = COALESCE(NULLIF(p_payload->>''resourceId'', '''')::uuid, ''00000000-0000-0000-0000-000000000000''::uuid)\n      AND hour_slot = p_payload->>''hourSlot''\n      AND log_date = v_log_date';
    IF position(v_old_hourly in v_def) = 0 THEN
      RAISE EXCEPTION 'hourly_counts lookup block not found in floor_capture';
    END IF;
    v_def := replace(v_def, v_old_hourly, v_new_hourly);
  END IF;

  IF v_def LIKE '%inspection_sessions%'
     AND substring(v_def from position('inspection_session_upsert' in v_def)) LIKE '%COALESCE(resource_id%' THEN
    RAISE NOTICE 'floor_capture inspection_session lookup already includes resource_id';
  ELSE
    v_old_qc := E'      AND log_date = v_log_date\n      AND hour_slot IS NOT DISTINCT FROM NULLIF(p_payload->>''hourSlot'', '''')\n      AND colorway_id IS NOT DISTINCT FROM v_colorway_id\n    LIMIT 1';
    v_new_qc := E'      AND log_date = v_log_date\n      AND hour_slot IS NOT DISTINCT FROM NULLIF(p_payload->>''hourSlot'', '''')\n      AND colorway_id IS NOT DISTINCT FROM v_colorway_id\n      AND COALESCE(resource_id, ''00000000-0000-0000-0000-000000000000''::uuid)\n        = COALESCE(NULLIF(p_payload->>''resourceId'', '''')::uuid, ''00000000-0000-0000-0000-000000000000''::uuid)\n    LIMIT 1';
    IF position(v_old_qc in v_def) = 0 THEN
      RAISE EXCEPTION 'inspection_sessions lookup block not found in floor_capture';
    END IF;
    v_def := replace(v_def, v_old_qc, v_new_qc);
  END IF;

  EXECUTE v_def;
END $$;
