-- Floor bootstrap for plapps when service role is not available on the API server.
-- Called with anon key after floor session cookie validates factory scope.

CREATE OR REPLACE FUNCTION public.get_floor_bootstrap(p_factory_id uuid)
RETURNS jsonb
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_result jsonb;
BEGIN
  IF p_factory_id IS NULL OR NOT EXISTS (SELECT 1 FROM public.factories f WHERE f.id = p_factory_id) THEN
    RETURN NULL;
  END IF;

  SELECT jsonb_build_object(
    'departments', COALESCE((
      SELECT jsonb_agg(to_jsonb(d) ORDER BY d.sequence)
      FROM public.departments d
      WHERE d.factory_id = p_factory_id
    ), '[]'::jsonb),
    'orders', COALESCE((
      SELECT jsonb_agg(
        to_jsonb(o) || jsonb_build_object(
          'colorways', COALESCE((
            SELECT jsonb_agg(to_jsonb(c) ORDER BY c.created_at)
            FROM public.colorways c
            WHERE c.order_id = o.id
          ), '[]'::jsonb)
        )
        ORDER BY o.created_at DESC
      )
      FROM public.style_orders o
      WHERE o.factory_id = p_factory_id
    ), '[]'::jsonb),
    'resources', COALESCE((
      SELECT jsonb_agg(to_jsonb(r) ORDER BY r.resource_name)
      FROM public.assigned_resources r
      WHERE r.factory_id = p_factory_id
    ), '[]'::jsonb),
    'shifts', COALESCE((
      SELECT jsonb_agg(to_jsonb(s) ORDER BY s.name)
      FROM public.shifts s
      WHERE s.factory_id = p_factory_id
    ), '[]'::jsonb),
    'workers', COALESCE((
      SELECT jsonb_agg(to_jsonb(w) ORDER BY w.name)
      FROM public.workers w
      WHERE w.factory_id = p_factory_id AND w.is_active = true
    ), '[]'::jsonb),
    'flows', COALESCE((
      SELECT jsonb_agg(
        to_jsonb(f) || jsonb_build_object(
          'process_flow_steps', COALESCE((
            SELECT jsonb_agg(to_jsonb(s) ORDER BY s.flow_step)
            FROM public.process_flow_steps s
            WHERE s.flow_id = f.id
          ), '[]'::jsonb)
        )
      )
      FROM public.process_flows f
      WHERE f.factory_id = p_factory_id
    ), '[]'::jsonb),
    'hourly', COALESCE((
      SELECT jsonb_agg(to_jsonb(h) ORDER BY h.logged_at DESC)
      FROM (
        SELECT * FROM public.hourly_counts
        WHERE factory_id = p_factory_id
        ORDER BY logged_at DESC
        LIMIT 500
      ) h
    ), '[]'::jsonb),
    'slips', COALESCE((
      SELECT jsonb_agg(to_jsonb(s) ORDER BY s.sent_at DESC)
      FROM (
        SELECT * FROM public.handover_slips
        WHERE factory_id = p_factory_id
        ORDER BY sent_at DESC
        LIMIT 500
      ) s
    ), '[]'::jsonb),
    'inspections', COALESCE((
      SELECT jsonb_agg(to_jsonb(i) ORDER BY i.logged_at DESC)
      FROM (
        SELECT * FROM public.inspections
        WHERE factory_id = p_factory_id
        ORDER BY logged_at DESC
        LIMIT 500
      ) i
    ), '[]'::jsonb),
    'workforce', COALESCE((
      SELECT jsonb_agg(to_jsonb(w) ORDER BY w.logged_at DESC)
      FROM (
        SELECT * FROM public.workforce_logs
        WHERE factory_id = p_factory_id
        ORDER BY logged_at DESC
        LIMIT 200
      ) w
    ), '[]'::jsonb),
    'attendance', COALESCE((
      SELECT jsonb_agg(to_jsonb(a) ORDER BY a.logged_at DESC)
      FROM (
        SELECT * FROM public.attendance_records
        WHERE factory_id = p_factory_id
        ORDER BY logged_at DESC
        LIMIT 500
      ) a
    ), '[]'::jsonb),
    'audits', COALESCE((
      SELECT jsonb_agg(to_jsonb(a) ORDER BY a.logged_at DESC)
      FROM (
        SELECT * FROM public.audit_sessions
        WHERE factory_id = p_factory_id
        ORDER BY logged_at DESC
        LIMIT 200
      ) a
    ), '[]'::jsonb),
    'allocations', COALESCE((
      SELECT jsonb_agg(to_jsonb(a))
      FROM public.line_allocations a
      WHERE a.factory_id = p_factory_id
    ), '[]'::jsonb)
  ) INTO v_result;

  RETURN v_result;
END;
$$;

REVOKE ALL ON FUNCTION public.get_floor_bootstrap(uuid) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.get_floor_bootstrap(uuid) TO anon, authenticated;
