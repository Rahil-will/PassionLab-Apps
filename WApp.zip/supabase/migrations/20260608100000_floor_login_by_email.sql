-- Floor login by email + PIN (replaces factory code + employee ID on mobile)

CREATE OR REPLACE FUNCTION public.verify_floor_login_by_email(
  p_email text,
  p_pin text
)
RETURNS jsonb
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_profile public.profiles%ROWTYPE;
BEGIN
  SELECT p.* INTO v_profile
  FROM public.profiles p
  WHERE lower(trim(p.email)) = lower(trim(p_email))
    AND p.status = 'Active'
    AND p.user_role IN ('operator', 'supervisor', 'auditor', 'quality_manager')
  LIMIT 1;

  IF NOT FOUND OR v_profile.floor_pin IS NULL OR v_profile.floor_pin <> trim(p_pin) THEN
    RETURN NULL;
  END IF;

  RETURN jsonb_build_object(
    'id', v_profile.id,
    'full_name', v_profile.full_name,
    'email', v_profile.email,
    'user_role', v_profile.user_role,
    'department_id', v_profile.department_id,
    'assigned_apps', v_profile.assigned_apps,
    'factory_id', v_profile.factory_id,
    'employee_id', v_profile.employee_id
  );
END;
$$;

REVOKE ALL ON FUNCTION public.verify_floor_login_by_email(text, text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.verify_floor_login_by_email(text, text) TO anon, authenticated;
