-- Phase 7: Floor PWA KPI RPCs — rejections running total + dept quality for date.

-- -----------------------------------------------------------------------------
-- get_today_rejections_for_order
-- Running rejection total for an order on a given date (default today).
-- -----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.get_today_rejections_for_order(
  p_factory_id uuid,
  p_order_id uuid,
  p_rejected_date date DEFAULT CURRENT_DATE
)
RETURNS jsonb
LANGUAGE sql
STABLE
SECURITY INVOKER
SET search_path = public
AS $$
  SELECT jsonb_build_object(
    'total_qty', COALESCE((
      SELECT SUM(qty)::integer
      FROM public.rejections
      WHERE factory_id = p_factory_id
        AND order_id = p_order_id
        AND rejected_date = p_rejected_date
    ), 0),
    'by_reason', COALESCE((
      SELECT jsonb_agg(jsonb_build_object('reason_code', reason_code, 'qty', qty) ORDER BY qty DESC)
      FROM (
        SELECT reason_code, SUM(qty)::integer AS qty
        FROM public.rejections
        WHERE factory_id = p_factory_id
          AND order_id = p_order_id
          AND rejected_date = p_rejected_date
        GROUP BY reason_code
      ) x
    ), '[]'::jsonb),
    'by_stage', COALESCE((
      SELECT jsonb_agg(jsonb_build_object('stage', stage, 'qty', qty) ORDER BY qty DESC)
      FROM (
        SELECT stage, SUM(qty)::integer AS qty
        FROM public.rejections
        WHERE factory_id = p_factory_id
          AND order_id = p_order_id
          AND rejected_date = p_rejected_date
        GROUP BY stage
      ) y
    ), '[]'::jsonb)
  );
$$;

COMMENT ON FUNCTION public.get_today_rejections_for_order(uuid, uuid, date) IS
  'Rejection totals for one order on a date: total_qty, by_reason, by_stage.';

-- -----------------------------------------------------------------------------
-- get_dept_quality_for_date
-- QC metrics from v_daily_quality for a department on a date.
-- -----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.get_dept_quality_for_date(
  p_factory_id uuid,
  p_department_id uuid,
  p_log_date date DEFAULT CURRENT_DATE
)
RETURNS SETOF public.v_daily_quality
LANGUAGE sql
STABLE
SECURITY INVOKER
SET search_path = public
AS $$
  SELECT *
  FROM public.v_daily_quality
  WHERE factory_id = p_factory_id
    AND department_id = p_department_id
    AND log_date = p_log_date
  ORDER BY order_id;
$$;

COMMENT ON FUNCTION public.get_dept_quality_for_date(uuid, uuid, date) IS
  'Department QC KPI rows for a date (DHU, defective_pct, inspected). Wraps v_daily_quality.';

REVOKE ALL ON FUNCTION public.get_today_rejections_for_order(uuid, uuid, date) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.get_dept_quality_for_date(uuid, uuid, date) FROM PUBLIC;

GRANT EXECUTE ON FUNCTION public.get_today_rejections_for_order(uuid, uuid, date) TO authenticated;
GRANT EXECUTE ON FUNCTION public.get_dept_quality_for_date(uuid, uuid, date) TO authenticated;
