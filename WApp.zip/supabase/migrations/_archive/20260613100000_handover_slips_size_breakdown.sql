-- Phase 9.5: Size-wise handover capture on handover_slips.

ALTER TABLE public.handover_slips
  ADD COLUMN IF NOT EXISTS qty_by_size jsonb NOT NULL DEFAULT '{}'::jsonb,
  ADD COLUMN IF NOT EXISTS received_qty_by_size jsonb NOT NULL DEFAULT '{}'::jsonb;

COMMENT ON COLUMN public.handover_slips.qty_by_size IS
  'Size breakdown sent on handover. Sum of values should equal sent_qty (validated in floor_capture). Example: {"S":50,"M":100}.';

COMMENT ON COLUMN public.handover_slips.received_qty_by_size IS
  'Size breakdown confirmed on receive. Sum should equal received_qty; keys must be subset of qty_by_size keys when send had size split.';
