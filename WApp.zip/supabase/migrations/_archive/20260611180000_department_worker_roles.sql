-- Phase 6A: department worker_roles for workforce capture categories.

ALTER TABLE public.departments
  ADD COLUMN IF NOT EXISTS worker_roles jsonb NOT NULL DEFAULT '["Operators", "Helpers", "Supervisors", "Trainees"]'::jsonb;

COMMENT ON COLUMN public.departments.worker_roles IS
  'Display labels for workforce_log headcount categories (max 4 map to operators/helpers/supervisors/trainees).';
