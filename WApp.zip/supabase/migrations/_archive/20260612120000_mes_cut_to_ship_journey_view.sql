-- Phase 9c: Cut-to-Ship department journey view + RPC + detail JSON extension.
-- One row per (factory, order, colorway, department). Cross-joins all factory depts;
-- depts not in the order process flow get status = not_in_flow with NULL qtys.

CREATE OR REPLACE FUNCTION public.resolve_rejection_department_id(
  p_factory_id uuid,
  p_order_id uuid,
  p_stage text
)
RETURNS uuid
LANGUAGE sql
STABLE
SET search_path = public
AS $$
  SELECT CASE p_stage
    WHEN 'end_line' THEN (
      SELECT d.id FROM public.departments d
      WHERE d.factory_id = p_factory_id AND d.name ILIKE 'sewing'
      ORDER BY d.id LIMIT 1
    )
    WHEN 'final_audit' THEN (
      SELECT d.id FROM public.departments d
      WHERE d.factory_id = p_factory_id AND d.name ILIKE 'quality audit'
      ORDER BY d.id LIMIT 1
    )
    WHEN 'pre_pack' THEN (
      SELECT d.id FROM public.departments d
      WHERE d.factory_id = p_factory_id
        AND (d.name ILIKE 'finishing' OR d.name ILIKE 'packing')
      ORDER BY CASE WHEN d.name ILIKE 'finishing' THEN 0 ELSE 1 END, d.id
      LIMIT 1
    )
    WHEN 'post_pack' THEN (
      SELECT d.id FROM public.departments d
      WHERE d.factory_id = p_factory_id
        AND (d.name ILIKE 'packing' OR d.name ILIKE 'finishing')
      ORDER BY CASE WHEN d.name ILIKE 'packing' THEN 0 ELSE 1 END, d.id
      LIMIT 1
    )
    WHEN 'customer_return' THEN (
      SELECT d.id FROM public.departments d
      WHERE d.factory_id = p_factory_id AND d.name ILIKE 'shipment'
      ORDER BY d.id LIMIT 1
    )
    WHEN 'inline' THEN (
      SELECT pfs.department_id
      FROM public.style_orders so
      JOIN public.process_flow_steps pfs ON pfs.flow_id = so.process_flow_id
      JOIN public.departments d ON d.id = pfs.department_id AND d.is_production = true
      WHERE so.id = p_order_id AND so.factory_id = p_factory_id
      ORDER BY CASE WHEN d.name ILIKE 'sewing' THEN 0 ELSE 1 END, pfs.flow_step DESC
      LIMIT 1
    )
    ELSE (
      SELECT pfs.department_id
      FROM public.style_orders so
      JOIN public.process_flow_steps pfs ON pfs.flow_id = so.process_flow_id
      WHERE so.id = p_order_id AND so.factory_id = p_factory_id
      ORDER BY pfs.flow_step DESC
      LIMIT 1
    )
  END;
$$;

COMMENT ON FUNCTION public.resolve_rejection_department_id(uuid, uuid, text) IS
  'Maps rejection.stage to a department for journey qty_rejected. inline → Sewing if in flow; final_audit → Quality Audit; customer_return → Shipment; ambiguous → max flow_step dept.';

CREATE OR REPLACE VIEW public.v_cut_to_ship_dept_journey AS
WITH order_colorways AS (
  SELECT so.factory_id, so.id AS order_id, so.process_flow_id, cw.id AS colorway_id
  FROM public.style_orders so
  LEFT JOIN public.colorways cw ON cw.order_id = so.id
),
dept_grid AS (
  SELECT
    oc.factory_id,
    oc.order_id,
    oc.colorway_id,
    oc.process_flow_id,
    d.id AS dept_id,
    d.name AS dept_name,
    d.is_production,
    d.apps,
    pfs.flow_step,
    (pfs.department_id IS NOT NULL) AS is_in_flow,
    (d.id = public.get_cutting_department_id(oc.factory_id)) AS is_cutting,
    (d.name ILIKE 'shipment' OR COALESCE(d.apps, '[]'::jsonb) @> '["shipment_log"]'::jsonb) AS is_shipment,
    (d.name ILIKE 'quality audit') AS is_quality_audit
  FROM order_colorways oc
  JOIN public.departments d ON d.factory_id = oc.factory_id
  LEFT JOIN public.process_flow_steps pfs
    ON pfs.flow_id = oc.process_flow_id AND pfs.department_id = d.id
),
handover_received AS (
  SELECT
    hs.factory_id, hs.order_id, hs.colorway_id, hs.to_department_id AS dept_id,
    SUM(COALESCE(NULLIF(hs.received_qty, 0), hs.sent_qty))::integer AS qty_received
  FROM public.handover_slips hs
  GROUP BY hs.factory_id, hs.order_id, hs.colorway_id, hs.to_department_id
),
handover_sent AS (
  SELECT
    hs.factory_id, hs.order_id, hs.colorway_id, hs.from_department_id AS dept_id,
    SUM(hs.sent_qty)::integer AS qty_sent
  FROM public.handover_slips hs
  GROUP BY hs.factory_id, hs.order_id, hs.colorway_id, hs.from_department_id
),
hourly_produced AS (
  SELECT
    h.factory_id, h.order_id, h.colorway_id, h.department_id AS dept_id,
    SUM(h.count)::integer AS qty_produced
  FROM public.hourly_counts h
  JOIN public.departments d ON d.id = h.department_id
  WHERE COALESCE(d.apps, '[]'::jsonb) @> '["hourly"]'::jsonb
  GROUP BY h.factory_id, h.order_id, h.colorway_id, h.department_id
),
qc_produced AS (
  SELECT
    i.factory_id, i.order_id, i.colorway_id, i.department_id AS dept_id,
    COUNT(*) FILTER (WHERE i.result IN ('pass', 'rework_pass'))::integer AS qty_produced
  FROM public.inspections i
  JOIN public.departments d ON d.id = i.department_id
  WHERE COALESCE(d.apps, '[]'::jsonb) @> '["qc_log"]'::jsonb
  GROUP BY i.factory_id, i.order_id, i.colorway_id, i.department_id
),
shipped AS (
  SELECT factory_id, order_id, colorway_id, SUM(shipped_qty)::integer AS qty_shipped
  FROM public.shipments
  GROUP BY factory_id, order_id, colorway_id
),
rejected_by_dept AS (
  SELECT
    r.factory_id, r.order_id, r.colorway_id,
    public.resolve_rejection_department_id(r.factory_id, r.order_id, r.stage) AS dept_id,
    SUM(r.qty)::integer AS qty_rejected
  FROM public.rejections r
  GROUP BY r.factory_id, r.order_id, r.colorway_id,
    public.resolve_rejection_department_id(r.factory_id, r.order_id, r.stage)
),
assembled AS (
  SELECT
    g.factory_id,
    g.order_id,
    g.colorway_id,
    g.dept_id,
    g.dept_name,
    g.flow_step,
    g.is_in_flow,
    CASE WHEN g.is_in_flow THEN
      CASE WHEN g.is_cutting THEN NULL ELSE hr.qty_received END
    END AS qty_received,
    CASE WHEN g.is_in_flow THEN
      CASE
        WHEN g.is_cutting THEN hp.qty_produced
        WHEN COALESCE(g.apps, '[]'::jsonb) @> '["hourly"]'::jsonb THEN hp.qty_produced
        WHEN COALESCE(g.apps, '[]'::jsonb) @> '["qc_log"]'::jsonb THEN qp.qty_produced
        ELSE COALESCE(hp.qty_produced, qp.qty_produced)
      END
    END AS qty_produced,
    CASE WHEN g.is_in_flow THEN
      CASE WHEN g.is_shipment THEN sh.qty_shipped ELSE hs.qty_sent END
    END AS qty_sent,
    CASE WHEN g.is_in_flow THEN rb.qty_rejected END AS qty_rejected
  FROM dept_grid g
  LEFT JOIN handover_received hr
    ON hr.factory_id = g.factory_id AND hr.order_id = g.order_id
   AND hr.colorway_id IS NOT DISTINCT FROM g.colorway_id AND hr.dept_id = g.dept_id
  LEFT JOIN handover_sent hs
    ON hs.factory_id = g.factory_id AND hs.order_id = g.order_id
   AND hs.colorway_id IS NOT DISTINCT FROM g.colorway_id AND hs.dept_id = g.dept_id
  LEFT JOIN hourly_produced hp
    ON hp.factory_id = g.factory_id AND hp.order_id = g.order_id
   AND hp.colorway_id IS NOT DISTINCT FROM g.colorway_id AND hp.dept_id = g.dept_id
  LEFT JOIN qc_produced qp
    ON qp.factory_id = g.factory_id AND qp.order_id = g.order_id
   AND qp.colorway_id IS NOT DISTINCT FROM g.colorway_id AND qp.dept_id = g.dept_id
  LEFT JOIN shipped sh
    ON sh.factory_id = g.factory_id AND sh.order_id = g.order_id
   AND sh.colorway_id IS NOT DISTINCT FROM g.colorway_id AND g.is_shipment
  LEFT JOIN rejected_by_dept rb
    ON rb.factory_id = g.factory_id AND rb.order_id = g.order_id
   AND rb.colorway_id IS NOT DISTINCT FROM g.colorway_id AND rb.dept_id = g.dept_id
)
SELECT
  a.factory_id,
  a.order_id,
  a.colorway_id,
  a.dept_id,
  a.dept_name,
  a.flow_step,
  a.is_in_flow,
  a.qty_received,
  a.qty_produced,
  a.qty_sent,
  a.qty_rejected,
  CASE WHEN NOT a.is_in_flow THEN NULL
    WHEN a.qty_received IS NULL AND a.qty_produced IS NOT NULL
      THEN GREATEST(COALESCE(a.qty_produced, 0) - COALESCE(a.qty_sent, 0), 0)
    WHEN a.qty_received IS NOT NULL
      THEN GREATEST(COALESCE(a.qty_received, 0) - COALESCE(a.qty_sent, 0), 0)
    ELSE NULL
  END::integer AS wip_qty,
  CASE
    WHEN NOT a.is_in_flow THEN 'not_in_flow'
    WHEN a.qty_received IS NULL AND COALESCE(a.qty_produced, 0) = 0 THEN 'pending'
    WHEN a.qty_received IS NULL AND COALESCE(a.qty_sent, 0) = 0 AND COALESCE(a.qty_produced, 0) > 0 THEN 'in_progress'
    WHEN a.qty_received IS NULL AND COALESCE(a.qty_sent, 0) >= COALESCE(a.qty_produced, 0)
      AND COALESCE(a.qty_sent, 0) > 0 THEN 'completed'
    WHEN COALESCE(a.qty_received, 0) = 0 THEN 'pending'
    WHEN COALESCE(a.qty_received, 0) > COALESCE(a.qty_sent, 0) THEN 'in_progress'
    WHEN COALESCE(a.qty_sent, 0) >= COALESCE(a.qty_received, 0) AND COALESCE(a.qty_sent, 0) > 0 THEN 'completed'
    ELSE 'pending'
  END AS status
FROM assembled a;

COMMENT ON VIEW public.v_cut_to_ship_dept_journey IS
  'Per order/colorway department journey for Cut-to-Ship drill-down. Cross-joins all factory depts; not-in-flow depts get NULL qtys. Cutting: qty_received NULL, produced from hourly. Shipment: qty_sent = shipped_qty. Rejection stage mapping via resolve_rejection_department_id.';

CREATE OR REPLACE FUNCTION public.get_cut_to_ship_journey(
  p_factory_id uuid,
  p_order_id uuid
)
RETURNS SETOF public.v_cut_to_ship_dept_journey
LANGUAGE sql
STABLE
SECURITY INVOKER
SET search_path = public
AS $$
  SELECT *
  FROM public.v_cut_to_ship_dept_journey
  WHERE factory_id = p_factory_id AND order_id = p_order_id
  ORDER BY colorway_id NULLS LAST, flow_step NULLS LAST, dept_name;
$$;

COMMENT ON FUNCTION public.get_cut_to_ship_journey(uuid, uuid) IS
  'Department journey rows for one order. One row per colorway × dept. Ordered by colorway, flow_step, dept_name.';

CREATE OR REPLACE FUNCTION public.get_cut_to_ship_detail(
  p_factory_id uuid,
  p_order_id uuid
)
RETURNS jsonb
LANGUAGE sql
STABLE
SECURITY INVOKER
SET search_path = public
AS $$
  SELECT jsonb_build_object(
    'reconciliation',
      COALESCE((
        SELECT jsonb_agg(to_jsonb(c) ORDER BY c.colorway_id NULLS LAST)
        FROM public.v_cut_to_ship c
        WHERE c.factory_id = p_factory_id AND c.order_id = p_order_id
      ), '[]'::jsonb),
    'shipments',
      COALESCE((
        SELECT jsonb_agg(to_jsonb(s) ORDER BY s.shipment_date DESC, s.logged_at DESC)
        FROM public.shipments s
        WHERE s.factory_id = p_factory_id AND s.order_id = p_order_id
      ), '[]'::jsonb),
    'rejections',
      COALESCE((
        SELECT jsonb_agg(to_jsonb(r) ORDER BY r.rejected_date DESC, r.logged_at DESC)
        FROM public.rejections r
        WHERE r.factory_id = p_factory_id AND r.order_id = p_order_id
      ), '[]'::jsonb),
    'wip_by_dept',
      COALESCE((
        SELECT jsonb_agg(to_jsonb(w) ORDER BY w.flow_step, w.colorway_id NULLS LAST, w.department_id)
        FROM public.get_order_wip(p_factory_id, p_order_id) w
      ), '[]'::jsonb),
    'journey',
      COALESCE((
        SELECT jsonb_agg(to_jsonb(j) ORDER BY j.colorway_id NULLS LAST, j.flow_step NULLS LAST, j.dept_name)
        FROM public.get_cut_to_ship_journey(p_factory_id, p_order_id) j
      ), '[]'::jsonb)
  );
$$;

COMMENT ON FUNCTION public.get_cut_to_ship_detail(uuid, uuid) IS
  'Order cut-to-ship drill-down: reconciliation, shipments, rejections, wip_by_dept, journey.';

REVOKE ALL ON FUNCTION public.get_cut_to_ship_journey(uuid, uuid) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.get_cut_to_ship_journey(uuid, uuid) TO authenticated;
REVOKE EXECUTE ON FUNCTION public.get_cut_to_ship_journey(uuid, uuid) FROM anon;
