-- Phase 9.5: get_order_dept_progress RPC + size-wise cut-to-ship views.

CREATE OR REPLACE VIEW public.v_order_rejected_qty_by_size AS
SELECT
  r.factory_id,
  r.order_id,
  r.colorway_id,
  COALESCE(r.size, 'UNSPEC') AS size,
  SUM(r.qty)::integer AS rejected_qty
FROM public.rejections r
GROUP BY r.factory_id, r.order_id, r.colorway_id, COALESCE(r.size, 'UNSPEC');

COMMENT ON VIEW public.v_order_rejected_qty_by_size IS
  'Rejected qty per size from rejections.size column. UNSPEC when size is null.';

CREATE OR REPLACE FUNCTION public.get_order_dept_progress(
  p_factory_id uuid,
  p_order_id uuid,
  p_colorway_id uuid,
  p_department_id uuid,
  p_date date DEFAULT CURRENT_DATE
)
RETURNS jsonb
LANGUAGE plpgsql
STABLE
SECURITY INVOKER
SET search_path = public
AS $$
DECLARE
  v_planned jsonb;
  v_planned_total integer;
  v_cutting_id uuid;
  v_is_cutting boolean;
  v_cum_produced integer := 0;
  v_today_produced integer := 0;
  v_cum_sent integer := 0;
  v_today_sent integer := 0;
  v_produced_by_size jsonb := '{}'::jsonb;
  v_sent_by_size jsonb := '{}'::jsonb;
  v_hourly_total integer := 0;
  v_today_target integer := 0;
  v_remaining integer;
BEGIN
  v_planned := public.colorway_planned_by_size(p_colorway_id);
  v_planned_total := public.jsonb_sum_int_values(v_planned);
  v_cutting_id := public.get_cutting_department_id(p_factory_id);
  v_is_cutting := (p_department_id = v_cutting_id);

  SELECT COALESCE(SUM(daily_target), 0)::integer INTO v_today_target
  FROM public.v_daily_target t
  WHERE t.factory_id = p_factory_id
    AND t.order_id = p_order_id
    AND t.department_id = p_department_id
    AND t.log_date = p_date;

  SELECT COALESCE(SUM(o.output_qty), 0)::integer INTO v_cum_produced
  FROM public.v_daily_output o
  WHERE o.factory_id = p_factory_id
    AND o.order_id = p_order_id
    AND o.colorway_id IS NOT DISTINCT FROM p_colorway_id
    AND o.department_id = p_department_id;

  SELECT COALESCE(SUM(o.output_qty), 0)::integer INTO v_today_produced
  FROM public.v_daily_output o
  WHERE o.factory_id = p_factory_id
    AND o.order_id = p_order_id
    AND o.colorway_id IS NOT DISTINCT FROM p_colorway_id
    AND o.department_id = p_department_id
    AND o.log_date = p_date;

  SELECT COALESCE(SUM(hs.sent_qty), 0)::integer INTO v_cum_sent
  FROM public.handover_slips hs
  WHERE hs.factory_id = p_factory_id
    AND hs.order_id = p_order_id
    AND hs.colorway_id IS NOT DISTINCT FROM p_colorway_id
    AND hs.from_department_id = p_department_id;

  SELECT COALESCE(SUM(hs.sent_qty), 0)::integer INTO v_today_sent
  FROM public.handover_slips hs
  WHERE hs.factory_id = p_factory_id
    AND hs.order_id = p_order_id
    AND hs.colorway_id IS NOT DISTINCT FROM p_colorway_id
    AND hs.from_department_id = p_department_id
    AND hs.sent_at::date = p_date;

  SELECT public.jsonb_merge_sum_maps(ARRAY_AGG(hs.qty_by_size))
  INTO v_sent_by_size
  FROM public.handover_slips hs
  WHERE hs.factory_id = p_factory_id
    AND hs.order_id = p_order_id
    AND hs.colorway_id IS NOT DISTINCT FROM p_colorway_id
    AND hs.from_department_id = p_department_id
    AND hs.qty_by_size <> '{}'::jsonb;

  IF v_is_cutting THEN
    SELECT COALESCE(SUM(h.count), 0)::integer INTO v_hourly_total
    FROM public.hourly_counts h
    WHERE h.factory_id = p_factory_id
      AND h.order_id = p_order_id
      AND h.colorway_id IS NOT DISTINCT FROM p_colorway_id
      AND h.department_id = p_department_id;
    v_produced_by_size := public.proportional_qty_by_size(v_hourly_total, v_planned);
  ELSE
    SELECT public.jsonb_merge_sum_maps(ARRAY_AGG(hs.qty_by_size))
    INTO v_produced_by_size
    FROM public.handover_slips hs
    WHERE hs.factory_id = p_factory_id
      AND hs.order_id = p_order_id
      AND hs.colorway_id IS NOT DISTINCT FROM p_colorway_id
      AND hs.from_department_id = p_department_id
      AND hs.qty_by_size <> '{}'::jsonb;
    IF v_produced_by_size = '{}'::jsonb AND v_cum_produced > 0 THEN
      v_produced_by_size := public.proportional_qty_by_size(v_cum_produced, v_planned);
    END IF;
  END IF;

  v_remaining := GREATEST(v_planned_total - GREATEST(v_cum_produced, v_cum_sent), 0);

  RETURN jsonb_build_object(
    'cumulative_produced', v_cum_produced,
    'today_produced', v_today_produced,
    'today_target', v_today_target,
    'cumulative_sent', v_cum_sent,
    'today_sent', v_today_sent,
    'available_to_send', GREATEST(v_cum_produced - v_cum_sent, 0),
    'planned_qty_by_size', v_planned,
    'produced_qty_by_size', COALESCE(v_produced_by_size, '{}'::jsonb),
    'sent_qty_by_size', COALESCE(v_sent_by_size, '{}'::jsonb),
    'remaining_qty', v_remaining
  );
END;
$$;

COMMENT ON FUNCTION public.get_order_dept_progress(uuid, uuid, uuid, uuid, date) IS
  'Dept progress for order/colorway: produced, sent, targets, size maps. Cutting uses proportional hourly split; other depts use handover qty_by_size.';

CREATE OR REPLACE FUNCTION public.get_pseudo_dept_daily_summary(
  p_factory_id uuid,
  p_department_id uuid,
  p_date date DEFAULT CURRENT_DATE
)
RETURNS jsonb
LANGUAGE sql
STABLE
SECURITY INVOKER
SET search_path = public
AS $$
  SELECT CASE
    WHEN EXISTS (
      SELECT 1 FROM public.departments d
      WHERE d.id = p_department_id AND d.factory_id = p_factory_id
        AND (d.name ILIKE 'shipment' OR COALESCE(d.apps, '[]'::jsonb) @> '["shipment_log"]'::jsonb)
    ) THEN jsonb_build_object(
      'kind', 'shipment',
      'shipment_count', (SELECT COUNT(*)::integer FROM public.shipments s WHERE s.factory_id = p_factory_id AND s.shipment_date = p_date),
      'shipped_qty', (SELECT COALESCE(SUM(shipped_qty), 0)::integer FROM public.shipments s WHERE s.factory_id = p_factory_id AND s.shipment_date = p_date)
    )
    WHEN EXISTS (
      SELECT 1 FROM public.departments d
      WHERE d.id = p_department_id AND d.factory_id = p_factory_id
        AND d.name ILIKE 'quality audit'
    ) THEN jsonb_build_object(
      'kind', 'rejection',
      'rejection_count', (SELECT COUNT(*)::integer FROM public.rejections r WHERE r.factory_id = p_factory_id AND r.rejected_date = p_date),
      'rejected_qty', (SELECT COALESCE(SUM(qty), 0)::integer FROM public.rejections r WHERE r.factory_id = p_factory_id AND r.rejected_date = p_date)
    )
    ELSE jsonb_build_object('kind', 'production')
  END;
$$;

COMMENT ON FUNCTION public.get_pseudo_dept_daily_summary(uuid, uuid, date) IS
  'Today summary for Shipment or Quality Audit pseudo-depts on floor home tiles.';

REVOKE ALL ON FUNCTION public.get_order_dept_progress(uuid, uuid, uuid, uuid, date) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.get_order_dept_progress(uuid, uuid, uuid, uuid, date) TO authenticated;
REVOKE EXECUTE ON FUNCTION public.get_order_dept_progress(uuid, uuid, uuid, uuid, date) FROM anon;

REVOKE ALL ON FUNCTION public.get_pseudo_dept_daily_summary(uuid, uuid, date) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.get_pseudo_dept_daily_summary(uuid, uuid, date) TO authenticated;
REVOKE EXECUTE ON FUNCTION public.get_pseudo_dept_daily_summary(uuid, uuid, date) FROM anon;

-- Extend v_cut_to_ship with size-wise reconciliation columns.
CREATE OR REPLACE VIEW public.v_cut_to_ship AS
WITH rej_by_size AS (
  SELECT factory_id, order_id, colorway_id,
    jsonb_object_agg(size, rejected_qty) AS rejected_qty_by_size
  FROM public.v_order_rejected_qty_by_size
  GROUP BY factory_id, order_id, colorway_id
),
ship_by_size AS (
  SELECT factory_id, order_id, colorway_id,
    public.jsonb_merge_sum_maps(ARRAY_AGG(shipped_qty_by_size)) AS shipped_qty_by_size
  FROM public.shipments
  WHERE shipped_qty_by_size <> '{}'::jsonb
  GROUP BY factory_id, order_id, colorway_id
),
cut_by_size AS (
  SELECT h.factory_id, h.order_id, h.colorway_id,
    public.proportional_qty_by_size(SUM(h.count)::integer, public.colorway_planned_by_size(h.colorway_id)) AS cut_qty_by_size
  FROM public.hourly_counts h
  WHERE h.department_id = public.get_cutting_department_id(h.factory_id)
  GROUP BY h.factory_id, h.order_id, h.colorway_id, public.colorway_planned_by_size(h.colorway_id)
)
SELECT
  so.factory_id,
  so.id AS order_id,
  cw.id AS colorway_id,
  so.style_name,
  so.buyer_name,
  so.po_number,
  COALESCE(so.adj_qty, so.order_qty, 0)::integer AS order_qty,
  COALESCE(cq.cut_qty, 0)::integer AS cut_qty,
  COALESCE(cq.cut_qty_source, 'planned') AS cut_qty_source,
  COALESCE(sq.shipped_qty, 0)::integer AS shipped_qty,
  COALESCE(rq.rejected_qty, 0)::integer AS rejected_qty,
  COALESCE(wt.wip_qty, 0)::integer AS wip_qty,
  (COALESCE(cq.cut_qty, 0)
    - (COALESCE(sq.shipped_qty, 0) + COALESCE(rq.rejected_qty, 0) + COALESCE(wt.wip_qty, 0)))::integer
    AS reconciliation_gap,
  COALESCE(rq.rejected_by_reason, '{}'::jsonb) AS rejected_by_reason,
  COALESCE(rq.rejected_by_stage, '{}'::jsonb) AS rejected_by_stage,
  (COALESCE(cq.cut_qty, 0)
    = COALESCE(sq.shipped_qty, 0) + COALESCE(rq.rejected_qty, 0) + COALESCE(wt.wip_qty, 0)) AS is_balanced,
  ROUND(100.0 * COALESCE(sq.shipped_qty, 0) / NULLIF(COALESCE(so.adj_qty, so.order_qty, 0), 0), 2) AS completion_pct,
  so.status AS order_status,
  sq.last_shipment_date,
  COALESCE(cbs.cut_qty_by_size, '{}'::jsonb) AS cut_qty_by_size,
  COALESCE(sbs.shipped_qty_by_size, '{}'::jsonb) AS shipped_qty_by_size,
  COALESCE(rbs.rejected_qty_by_size, '{}'::jsonb) AS rejected_qty_by_size,
  '{}'::jsonb AS wip_qty_by_size
FROM public.style_orders so
LEFT JOIN public.colorways cw ON cw.order_id = so.id
LEFT JOIN public.v_order_cut_qty cq
  ON cq.factory_id = so.factory_id AND cq.order_id = so.id
 AND cq.colorway_id IS NOT DISTINCT FROM cw.id
LEFT JOIN public.v_order_shipped_qty sq
  ON sq.factory_id = so.factory_id AND sq.order_id = so.id
 AND sq.colorway_id IS NOT DISTINCT FROM cw.id
LEFT JOIN public.v_order_rejected_qty rq
  ON rq.factory_id = so.factory_id AND rq.order_id = so.id
 AND rq.colorway_id IS NOT DISTINCT FROM cw.id
LEFT JOIN public.v_order_wip_total wt
  ON wt.factory_id = so.factory_id AND wt.order_id = so.id
 AND wt.colorway_id IS NOT DISTINCT FROM cw.id
LEFT JOIN cut_by_size cbs
  ON cbs.factory_id = so.factory_id AND cbs.order_id = so.id
 AND cbs.colorway_id IS NOT DISTINCT FROM cw.id
LEFT JOIN ship_by_size sbs
  ON sbs.factory_id = so.factory_id AND sbs.order_id = so.id
 AND sbs.colorway_id IS NOT DISTINCT FROM cw.id
LEFT JOIN rej_by_size rbs
  ON rbs.factory_id = so.factory_id AND rbs.order_id = so.id
 AND rbs.colorway_id IS NOT DISTINCT FROM cw.id;

COMMENT ON VIEW public.v_cut_to_ship IS
  'Cut-to-ship per colorway with size-wise columns. cut_qty_by_size from proportional hourly; shipped/rejected from size JSONB aggregates.';
