-- Phase 4: SECURITY INVOKER reporting RPCs wrapping MES views.

-- -----------------------------------------------------------------------------
-- 1. get_factory_kpis
-- Purpose: Factory-wide daily KPI rows for a date range.
-- Inputs: factory_id, date_from, date_to (inclusive).
-- Returns: SETOF v_daily_kpis (factory_id, order_id, department_id, log_date, targets, output, efficiency, shift_breakdown).
-- Source: v_daily_kpis
-- -----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.get_factory_kpis(
  p_factory_id uuid,
  p_date_from date,
  p_date_to date
)
RETURNS SETOF public.v_daily_kpis
LANGUAGE sql
STABLE
SECURITY INVOKER
SET search_path = public
AS $$
  SELECT *
  FROM public.v_daily_kpis
  WHERE factory_id = p_factory_id
    AND log_date >= p_date_from
    AND log_date <= p_date_to
  ORDER BY log_date, department_id, order_id;
$$;

COMMENT ON FUNCTION public.get_factory_kpis(uuid, date, date) IS
  'Factory daily KPIs for date range. Wraps v_daily_kpis.';

-- -----------------------------------------------------------------------------
-- 2. get_department_kpis
-- Purpose: Daily KPI rows for one production department.
-- Returns: SETOF v_daily_kpis filtered to department_id.
-- Source: v_daily_kpis
-- -----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.get_department_kpis(
  p_factory_id uuid,
  p_department_id uuid,
  p_date_from date,
  p_date_to date
)
RETURNS SETOF public.v_daily_kpis
LANGUAGE sql
STABLE
SECURITY INVOKER
SET search_path = public
AS $$
  SELECT *
  FROM public.v_daily_kpis
  WHERE factory_id = p_factory_id
    AND department_id = p_department_id
    AND log_date >= p_date_from
    AND log_date <= p_date_to
  ORDER BY log_date, order_id;
$$;

COMMENT ON FUNCTION public.get_department_kpis(uuid, uuid, date, date) IS
  'Department daily KPIs for date range. Wraps v_daily_kpis.';

-- -----------------------------------------------------------------------------
-- 3. get_department_kpis_by_shift
-- Purpose: Shift-level drilldown for one department.
-- Returns: SETOF v_daily_kpis_by_shift.
-- Source: v_daily_kpis_by_shift
-- -----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.get_department_kpis_by_shift(
  p_factory_id uuid,
  p_department_id uuid,
  p_date_from date,
  p_date_to date
)
RETURNS SETOF public.v_daily_kpis_by_shift
LANGUAGE sql
STABLE
SECURITY INVOKER
SET search_path = public
AS $$
  SELECT *
  FROM public.v_daily_kpis_by_shift
  WHERE factory_id = p_factory_id
    AND department_id = p_department_id
    AND log_date >= p_date_from
    AND log_date <= p_date_to
  ORDER BY log_date, shift_name, order_id;
$$;

COMMENT ON FUNCTION public.get_department_kpis_by_shift(uuid, uuid, date, date) IS
  'Department shift KPIs for date range. Wraps v_daily_kpis_by_shift.';

-- -----------------------------------------------------------------------------
-- 4. get_style_kpis
-- Purpose: Order KPIs across production-flow departments for full captured duration.
-- Returns: SETOF v_daily_kpis for departments in the order process_flow.
-- Source: v_daily_kpis JOIN style_orders / process_flow_steps
-- -----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.get_style_kpis(
  p_factory_id uuid,
  p_order_id uuid
)
RETURNS SETOF public.v_daily_kpis
LANGUAGE sql
STABLE
SECURITY INVOKER
SET search_path = public
AS $$
  SELECT k.*
  FROM public.v_daily_kpis k
  JOIN public.style_orders so
    ON so.id = k.order_id AND so.factory_id = k.factory_id
  WHERE k.factory_id = p_factory_id
    AND k.order_id = p_order_id
    AND (
      so.process_flow_id IS NULL
      OR k.department_id IN (
        SELECT pfs.department_id
        FROM public.process_flow_steps pfs
        WHERE pfs.flow_id = so.process_flow_id
      )
    )
  ORDER BY k.log_date, k.department_id;
$$;

COMMENT ON FUNCTION public.get_style_kpis(uuid, uuid) IS
  'Order KPIs for all departments in the order process flow. Wraps v_daily_kpis.';

-- -----------------------------------------------------------------------------
-- 5. get_order_wip
-- Purpose: Colorway-grained WIP along process flow for an order.
-- Returns: SETOF v_wip_order ordered by flow_step, colorway_id.
-- Source: v_wip_order (latest log_date per colorway/dept only)
-- -----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.get_order_wip(
  p_factory_id uuid,
  p_order_id uuid
)
RETURNS SETOF public.v_wip_order
LANGUAGE sql
STABLE
SECURITY INVOKER
SET search_path = public
AS $$
  WITH ranked AS (
    SELECT
      w.*,
      ROW_NUMBER() OVER (
        PARTITION BY w.colorway_id, w.department_id
        ORDER BY w.log_date DESC NULLS LAST
      ) AS rn
    FROM public.v_wip_order w
    WHERE w.factory_id = p_factory_id
      AND w.order_id = p_order_id
  )
  SELECT
    factory_id, order_id, colorway_id, log_date, flow_step, department_id, wip_qty
  FROM ranked
  WHERE rn = 1
  ORDER BY flow_step, colorway_id NULLS LAST, department_id;
$$;

COMMENT ON FUNCTION public.get_order_wip(uuid, uuid) IS
  'Latest colorway-grained WIP per process-flow department for an order. Wraps v_wip_order.';

-- -----------------------------------------------------------------------------
-- 6. get_audit_report
-- Purpose: Daily audit summary for a factory date range.
-- Returns: SETOF v_audit_summary.
-- Source: v_audit_summary
-- -----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.get_audit_report(
  p_factory_id uuid,
  p_date_from date,
  p_date_to date
)
RETURNS SETOF public.v_audit_summary
LANGUAGE sql
STABLE
SECURITY INVOKER
SET search_path = public
AS $$
  SELECT *
  FROM public.v_audit_summary
  WHERE factory_id = p_factory_id
    AND log_date >= p_date_from
    AND log_date <= p_date_to
  ORDER BY log_date, department_id, order_id;
$$;

COMMENT ON FUNCTION public.get_audit_report(uuid, date, date) IS
  'Audit summary for date range. Wraps v_audit_summary.';

-- -----------------------------------------------------------------------------
-- 7. get_cut_to_ship_report
-- Purpose: Cut-to-ship reconciliation list with optional filters.
-- Date filter: COALESCE(style_orders.delivery_date, style_orders.order_date) — delivery preferred for fulfillment window.
-- p_balanced_only: NULL = all, true = balanced only, false = unbalanced only.
-- Returns: SETOF v_cut_to_ship.
-- Source: v_cut_to_ship JOIN style_orders (buyer + date filters)
-- -----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.get_cut_to_ship_report(
  p_factory_id uuid,
  p_date_from date DEFAULT NULL,
  p_date_to date DEFAULT NULL,
  p_buyer_id uuid DEFAULT NULL,
  p_balanced_only boolean DEFAULT NULL
)
RETURNS SETOF public.v_cut_to_ship
LANGUAGE sql
STABLE
SECURITY INVOKER
SET search_path = public
AS $$
  SELECT c.*
  FROM public.v_cut_to_ship c
  JOIN public.style_orders so
    ON so.id = c.order_id AND so.factory_id = c.factory_id
  WHERE c.factory_id = p_factory_id
    AND (
      p_date_from IS NULL
      OR COALESCE(so.delivery_date, so.order_date) >= p_date_from
    )
    AND (
      p_date_to IS NULL
      OR COALESCE(so.delivery_date, so.order_date) <= p_date_to
    )
    AND (p_buyer_id IS NULL OR so.buyer_id = p_buyer_id)
    AND (p_balanced_only IS NULL OR c.is_balanced = p_balanced_only)
  ORDER BY so.style_name, c.colorway_id NULLS LAST;
$$;

COMMENT ON FUNCTION public.get_cut_to_ship_report(uuid, date, date, uuid, boolean) IS
  'Cut-to-ship list with optional delivery_date/order_date range, buyer, balanced filter. Wraps v_cut_to_ship.';

-- -----------------------------------------------------------------------------
-- 8. get_cut_to_ship_detail
-- Purpose: Drill-down JSON for one order: reconciliation, shipments, rejections, wip_by_dept.
-- Returns: JSONB { reconciliation, shipments, rejections, wip_by_dept }.
-- Sources: v_cut_to_ship, shipments, rejections, get_order_wip (v_wip_order)
-- -----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.get_cut_to_ship_detail(
  p_factory_id uuid,
  p_order_id uuid
)
RETURNS jsonb
LANGUAGE sql
STABLE
SECURITY INVOKER
SET search_path = public
AS $$
  SELECT jsonb_build_object(
    'reconciliation',
      COALESCE((
        SELECT jsonb_agg(to_jsonb(c) ORDER BY c.colorway_id NULLS LAST)
        FROM public.v_cut_to_ship c
        WHERE c.factory_id = p_factory_id AND c.order_id = p_order_id
      ), '[]'::jsonb),
    'shipments',
      COALESCE((
        SELECT jsonb_agg(to_jsonb(s) ORDER BY s.shipment_date DESC, s.logged_at DESC)
        FROM public.shipments s
        WHERE s.factory_id = p_factory_id AND s.order_id = p_order_id
      ), '[]'::jsonb),
    'rejections',
      COALESCE((
        SELECT jsonb_agg(to_jsonb(r) ORDER BY r.rejected_date DESC, r.logged_at DESC)
        FROM public.rejections r
        WHERE r.factory_id = p_factory_id AND r.order_id = p_order_id
      ), '[]'::jsonb),
    'wip_by_dept',
      COALESCE((
        SELECT jsonb_agg(to_jsonb(w) ORDER BY w.flow_step, w.colorway_id NULLS LAST, w.department_id)
        FROM public.get_order_wip(p_factory_id, p_order_id) w
      ), '[]'::jsonb)
  );
$$;

COMMENT ON FUNCTION public.get_cut_to_ship_detail(uuid, uuid) IS
  'Order cut-to-ship drill-down: reconciliation per colorway, shipment/rejection rows, latest wip_by_dept.';

-- -----------------------------------------------------------------------------
-- 9. get_live_dept_kpi
-- Purpose: Today''s daily KPI rows for a department (floor tile).
-- Returns: SETOF v_daily_kpis for CURRENT_DATE.
-- Source: v_daily_kpis
-- -----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.get_live_dept_kpi(
  p_factory_id uuid,
  p_department_id uuid
)
RETURNS SETOF public.v_daily_kpis
LANGUAGE sql
STABLE
SECURITY INVOKER
SET search_path = public
AS $$
  SELECT *
  FROM public.v_daily_kpis
  WHERE factory_id = p_factory_id
    AND department_id = p_department_id
    AND log_date = CURRENT_DATE
  ORDER BY order_id;
$$;

COMMENT ON FUNCTION public.get_live_dept_kpi(uuid, uuid) IS
  'Today''s department KPI rows for floor display. Wraps v_daily_kpis.';

-- Grants: authenticated only
REVOKE ALL ON FUNCTION public.get_factory_kpis(uuid, date, date) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.get_department_kpis(uuid, uuid, date, date) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.get_department_kpis_by_shift(uuid, uuid, date, date) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.get_style_kpis(uuid, uuid) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.get_order_wip(uuid, uuid) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.get_audit_report(uuid, date, date) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.get_cut_to_ship_report(uuid, date, date, uuid, boolean) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.get_cut_to_ship_detail(uuid, uuid) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.get_live_dept_kpi(uuid, uuid) FROM PUBLIC;

GRANT EXECUTE ON FUNCTION public.get_factory_kpis(uuid, date, date) TO authenticated;
GRANT EXECUTE ON FUNCTION public.get_department_kpis(uuid, uuid, date, date) TO authenticated;
GRANT EXECUTE ON FUNCTION public.get_department_kpis_by_shift(uuid, uuid, date, date) TO authenticated;
GRANT EXECUTE ON FUNCTION public.get_style_kpis(uuid, uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.get_order_wip(uuid, uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.get_audit_report(uuid, date, date) TO authenticated;
GRANT EXECUTE ON FUNCTION public.get_cut_to_ship_report(uuid, date, date, uuid, boolean) TO authenticated;
GRANT EXECUTE ON FUNCTION public.get_cut_to_ship_detail(uuid, uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.get_live_dept_kpi(uuid, uuid) TO authenticated;
