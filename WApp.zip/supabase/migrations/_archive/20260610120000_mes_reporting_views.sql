-- Phase 3: MES reporting views (shift-aware, back-fill safe — always reads current table state)

-- -----------------------------------------------------------------------------
-- Helpers: shift window + inspection shift inference
-- -----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.time_in_shift_bounds(p_t time, p_start time, p_end time)
RETURNS boolean
LANGUAGE sql
IMMUTABLE
AS $$
  SELECT CASE
    WHEN p_start IS NULL OR p_end IS NULL THEN false
    WHEN p_start <= p_end THEN p_t >= p_start AND p_t < p_end
    ELSE p_t >= p_start OR p_t < p_end
  END;
$$;

COMMENT ON FUNCTION public.time_in_shift_bounds(time, time, time) IS
  'True when p_t falls in [start, end), including overnight shifts when end < start.';

CREATE OR REPLACE FUNCTION public.inspection_time_in_active_slot(p_hours jsonb, p_t time)
RETURNS boolean
LANGUAGE sql
IMMUTABLE
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM jsonb_array_elements(COALESCE(p_hours, '[]'::jsonb)) slot
    WHERE slot->>'type' = 'active'
      AND (
        ((slot->>'start')::time <= (slot->>'end')::time
          AND p_t >= (slot->>'start')::time AND p_t < (slot->>'end')::time)
        OR
        ((slot->>'start')::time > (slot->>'end')::time
          AND (p_t >= (slot->>'start')::time OR p_t < (slot->>'end')::time))
      )
  );
$$;

COMMENT ON FUNCTION public.inspection_time_in_active_slot(jsonb, time) IS
  'True when p_t falls inside any active slot in shifts.hours JSONB.';

CREATE OR REPLACE FUNCTION public.infer_shift_id_for_inspection(p_factory_id uuid, p_logged_at timestamptz)
RETURNS uuid
LANGUAGE sql
STABLE
AS $$
  WITH slot_match AS (
    SELECT s.id, s.name
    FROM public.shifts s
    WHERE s.factory_id = p_factory_id
      AND public.inspection_time_in_active_slot(s.hours, p_logged_at::time)
  ),
  bounds_match AS (
    SELECT s.id, s.name
    FROM public.shifts s
    WHERE s.factory_id = p_factory_id
      AND public.time_in_shift_bounds(p_logged_at::time, s.start_time, s.end_time)
  ),
  chosen AS (
    SELECT id FROM slot_match
    UNION ALL
    SELECT id FROM bounds_match
    WHERE NOT EXISTS (SELECT 1 FROM slot_match)
  )
  SELECT id
  FROM chosen
  ORDER BY id
  LIMIT 1;
$$;

COMMENT ON FUNCTION public.infer_shift_id_for_inspection(uuid, timestamptz) IS
  'Maps inspection.logged_at to a shift: prefers hours JSONB active slots, else start_time/end_time. NULL if unallocated.';

CREATE OR REPLACE FUNCTION public.normalize_hour_slot_start(p_hour_slot text)
RETURNS time
LANGUAGE sql
IMMUTABLE
AS $$
  SELECT split_part(trim(p_hour_slot), '-', 1)::time;
$$;

COMMENT ON FUNCTION public.normalize_hour_slot_start(text) IS
  'Canonical hour_slot anchor: start of slot (e.g. "10:00" from "10:00" or "10:00-11:00").';

CREATE OR REPLACE FUNCTION public.get_shift_for_hour_slot(p_factory_id uuid, p_hour_slot text)
RETURNS uuid
LANGUAGE sql
STABLE
AS $$
  SELECT s.id
  FROM public.shifts s
  WHERE s.factory_id = p_factory_id
    AND EXISTS (
      SELECT 1
      FROM jsonb_array_elements(COALESCE(s.hours, '[]'::jsonb)) slot
      WHERE slot->>'type' = 'active'
        AND (slot->>'start')::time = public.normalize_hour_slot_start(p_hour_slot)
    )
  ORDER BY s.id
  LIMIT 1;
$$;

COMMENT ON FUNCTION public.get_shift_for_hour_slot(uuid, text) IS
  'Maps hourly_counts.hour_slot to shift_id by matching slot start to shifts.hours active slots. Views always re-resolve (ignore stored hourly_counts.shift_id). NULL if unallocated.';

-- -----------------------------------------------------------------------------
-- v_shift_minutes: shift_id -> productive_mins (from shifts.productive_mins column)
-- Formula: productive_mins = sum of active slots in shifts.hours JSONB (stored column).
-- Output: shift_id, factory_id, shift_name, shift_type, productive_mins
-- -----------------------------------------------------------------------------
CREATE OR REPLACE VIEW public.v_shift_minutes AS
SELECT
  s.id AS shift_id,
  s.factory_id,
  s.name AS shift_name,
  s.type AS shift_type,
  s.productive_mins
FROM public.shifts s;

COMMENT ON VIEW public.v_shift_minutes IS
  'Shift productive minutes per shift row. Source: shifts.productive_mins (derived from hours JSONB active slots).';

-- -----------------------------------------------------------------------------
-- v_daily_target: daily plan target from line_allocations
-- line_allocations.order_id = colorway id; resolve to style_orders via colorways.
-- Output: factory_id, order_id, department_id, log_date, daily_target
-- -----------------------------------------------------------------------------
CREATE OR REPLACE VIEW public.v_daily_target AS
SELECT
  la.factory_id,
  COALESCE(cw.order_id, la.order_id) AS order_id,
  la.department_id,
  d.log_date,
  SUM(la.daily_target)::integer AS daily_target
FROM public.line_allocations la
LEFT JOIN public.colorways cw ON cw.id = la.order_id
CROSS JOIN LATERAL (
  SELECT generate_series(la.start_date, la.end_date, interval '1 day')::date AS log_date
) d
WHERE la.start_date IS NOT NULL
  AND la.end_date IS NOT NULL
  AND la.department_id IS NOT NULL
GROUP BY la.factory_id, COALESCE(cw.order_id, la.order_id), la.department_id, d.log_date;

COMMENT ON VIEW public.v_daily_target IS
  'Daily plan target per factory/order/department/date from line_allocations.daily_target on each day in [start_date,end_date].';

-- -----------------------------------------------------------------------------
-- v_daily_output: output attributed to shifts (back-fill safe — reads raw capture tables)
-- hourly_counts: get_shift_for_hour_slot(hour_slot). inspections: infer_shift_id_for_inspection().
-- Unallocated inspections (shift_id NULL) still count toward daily output.
-- capture_mode per factory/order/dept/date: hourly if any hourly_counts else qc if inspections.
-- Output: factory_id, order_id, department_id, log_date, shift_id, output_qty, capture_mode, is_unallocated
-- -----------------------------------------------------------------------------
CREATE OR REPLACE VIEW public.v_daily_output AS
WITH hourly AS (
  SELECT
    h.factory_id,
    h.order_id,
    h.department_id,
    h.log_date,
    public.get_shift_for_hour_slot(h.factory_id, h.hour_slot) AS shift_id,
    SUM(h.count)::integer AS output_qty
  FROM public.hourly_counts h
  GROUP BY
    h.factory_id,
    h.order_id,
    h.department_id,
    h.log_date,
    public.get_shift_for_hour_slot(h.factory_id, h.hour_slot)
),
inspection_rows AS (
  SELECT
    i.factory_id,
    i.order_id,
    i.department_id,
    i.logged_at::date AS log_date,
    public.infer_shift_id_for_inspection(i.factory_id, i.logged_at) AS shift_id,
    i.result
  FROM public.inspections i
),
inspection AS (
  SELECT
    factory_id,
    order_id,
    department_id,
    log_date,
    shift_id,
    COUNT(*) FILTER (WHERE result IN ('pass', 'rework_pass'))::integer AS output_qty
  FROM inspection_rows
  GROUP BY factory_id, order_id, department_id, log_date, shift_id
),
keys AS (
  SELECT DISTINCT factory_id, order_id, department_id, log_date FROM hourly
  UNION
  SELECT DISTINCT factory_id, order_id, department_id, log_date FROM inspection
),
mode_pick AS (
  SELECT
    k.factory_id,
    k.order_id,
    k.department_id,
    k.log_date,
    CASE
      WHEN EXISTS (
        SELECT 1 FROM public.hourly_counts h
        WHERE h.factory_id = k.factory_id AND h.order_id = k.order_id
          AND h.department_id = k.department_id AND h.log_date = k.log_date
      ) THEN 'hourly'
      WHEN EXISTS (
        SELECT 1 FROM public.inspections i
        WHERE i.factory_id = k.factory_id AND i.order_id = k.order_id
          AND i.department_id = k.department_id AND i.logged_at::date = k.log_date
      ) THEN 'qc'
      ELSE 'none'
    END AS capture_mode
  FROM keys k
)
SELECT
  m.factory_id,
  m.order_id,
  m.department_id,
  m.log_date,
  o.shift_id,
  o.output_qty,
  m.capture_mode,
  (o.shift_id IS NULL) AS is_unallocated
FROM mode_pick m
JOIN LATERAL (
  SELECT h.shift_id, h.output_qty
  FROM hourly h
  WHERE m.capture_mode = 'hourly'
    AND h.factory_id = m.factory_id AND h.order_id = m.order_id
    AND h.department_id = m.department_id AND h.log_date = m.log_date
  UNION ALL
  SELECT i.shift_id, i.output_qty
  FROM inspection i
  WHERE m.capture_mode = 'qc'
    AND i.factory_id = m.factory_id AND i.order_id = m.order_id
    AND i.department_id = m.department_id AND i.log_date = m.log_date
) o ON true;

COMMENT ON VIEW public.v_daily_output IS
  'Output per factory/order/dept/date/shift. Hourly: get_shift_for_hour_slot(hour_slot → hours JSONB active start), not stored shift_id or logged_at. QC: infer_shift_id_for_inspection(logged_at). Unallocated rows have shift_id NULL. No cached state.';

-- -----------------------------------------------------------------------------
-- v_daily_workforce: headcount + available_mins per factory/dept/date/shift (NOT pre-aggregated)
-- Formula: headcount = operators+helpers+supervisors+trainees; available_mins = headcount * productive_mins
-- log_date may be back-dated — views always read current workforce_logs rows.
-- -----------------------------------------------------------------------------
CREATE OR REPLACE VIEW public.v_daily_workforce AS
SELECT
  wl.factory_id,
  wl.department_id,
  wl.log_date,
  wl.shift_id,
  sm.shift_name,
  sm.productive_mins,
  (wl.operators + wl.helpers + wl.supervisors + wl.trainees)::integer AS headcount,
  ((wl.operators + wl.helpers + wl.supervisors + wl.trainees) * sm.productive_mins)::numeric AS available_mins
FROM public.workforce_logs wl
JOIN public.v_shift_minutes sm ON sm.shift_id = wl.shift_id;

COMMENT ON VIEW public.v_daily_workforce IS
  'One row per factory/department/log_date/shift_id. Headcount from workforce_logs; available_mins = headcount * productive_mins. Supports back-dated log_date — re-query anytime to pick up late workforce entries.';

-- -----------------------------------------------------------------------------
-- v_daily_quality: quality KPIs per factory/order/dept/date (department-level QC)
-- inspected = pass+fail+rework_pass; DHU% = fail/inspected*100; defective% = (fail+rework)/inspected*100
-- -----------------------------------------------------------------------------
CREATE OR REPLACE VIEW public.v_daily_quality AS
SELECT
  i.factory_id,
  i.order_id,
  i.department_id,
  i.logged_at::date AS log_date,
  COUNT(*) FILTER (WHERE i.result IN ('pass', 'fail', 'rework_pass'))::integer AS inspected,
  COUNT(*) FILTER (WHERE i.result = 'pass')::integer AS passed,
  COUNT(*) FILTER (WHERE i.result = 'fail')::integer AS failed,
  COUNT(*) FILTER (WHERE i.result = 'rework')::integer AS rework,
  COUNT(*) FILTER (WHERE i.result = 'rework_pass')::integer AS rework_pass,
  CASE
    WHEN COUNT(*) FILTER (WHERE i.result IN ('pass', 'fail', 'rework_pass')) = 0 THEN NULL
    ELSE ROUND(
      100.0 * COUNT(*) FILTER (WHERE i.result = 'fail')
      / NULLIF(COUNT(*) FILTER (WHERE i.result IN ('pass', 'fail', 'rework_pass')), 0)
    )::numeric
  END AS dhu_pct,
  CASE
    WHEN COUNT(*) FILTER (WHERE i.result IN ('pass', 'fail', 'rework_pass')) = 0 THEN NULL
    ELSE ROUND(
      100.0 * COUNT(*) FILTER (WHERE i.result IN ('fail', 'rework'))
      / NULLIF(COUNT(*) FILTER (WHERE i.result IN ('pass', 'fail', 'rework_pass')), 0)
    )::numeric
  END AS defective_pct
FROM public.inspections i
GROUP BY i.factory_id, i.order_id, i.department_id, i.logged_at::date;

COMMENT ON VIEW public.v_daily_quality IS
  'Daily QC metrics from inspections. DHU% = fail/inspected*100. defective% = (fail+rework)/inspected*100.';

-- -----------------------------------------------------------------------------
-- v_wip_dept: cumulative produced - sent per factory/order/dept through log_date
-- produced: hourly sum or QC inspected count (same mode rule as output)
-- -----------------------------------------------------------------------------
CREATE OR REPLACE VIEW public.v_wip_dept AS
WITH daily_prod AS (
  SELECT factory_id, order_id, department_id, log_date, SUM(output_qty)::integer AS produced
  FROM public.v_daily_output
  GROUP BY factory_id, order_id, department_id, log_date
),
daily_sent AS (
  SELECT
    hs.factory_id,
    hs.order_id,
    hs.from_department_id AS department_id,
    hs.sent_at::date AS log_date,
    SUM(hs.sent_qty)::integer AS sent_qty
  FROM public.handover_slips hs
  GROUP BY hs.factory_id, hs.order_id, hs.from_department_id, hs.sent_at::date
),
prod_cum AS (
  SELECT
    factory_id,
    order_id,
    department_id,
    log_date,
    SUM(produced) OVER (
      PARTITION BY factory_id, order_id, department_id
      ORDER BY log_date
      ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
    )::integer AS cumulative_produced
  FROM daily_prod
),
sent_cum AS (
  SELECT
    factory_id,
    order_id,
    department_id,
    log_date,
    SUM(sent_qty) OVER (
      PARTITION BY factory_id, order_id, department_id
      ORDER BY log_date
      ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
    )::integer AS cumulative_sent
  FROM daily_sent
),
dates AS (
  SELECT DISTINCT factory_id, order_id, department_id, log_date FROM daily_prod
  UNION
  SELECT DISTINCT factory_id, order_id, department_id, log_date FROM daily_sent
)
SELECT
  d.factory_id,
  d.order_id,
  d.department_id,
  d.log_date,
  COALESCE(pc.cumulative_produced, 0) AS cumulative_produced,
  COALESCE(sc.cumulative_sent, 0) AS cumulative_sent,
  GREATEST(COALESCE(pc.cumulative_produced, 0) - COALESCE(sc.cumulative_sent, 0), 0)::integer AS wip_qty
FROM dates d
LEFT JOIN prod_cum pc
  ON pc.factory_id = d.factory_id AND pc.order_id = d.order_id
 AND pc.department_id = d.department_id AND pc.log_date = d.log_date
LEFT JOIN sent_cum sc
  ON sc.factory_id = d.factory_id AND sc.order_id = d.order_id
 AND sc.department_id = d.department_id AND sc.log_date = d.log_date;

COMMENT ON VIEW public.v_wip_dept IS
  'Running WIP per factory/order/dept/date: cumulative produced minus cumulative sent (handover_slips). Produced from v_daily_output.';

-- -----------------------------------------------------------------------------
-- v_wip_order: cross-department WIP along process flow
-- For each order/date: WIP at each dept in flow sequence
-- -----------------------------------------------------------------------------
CREATE OR REPLACE VIEW public.v_wip_order AS
WITH order_flow AS (
  SELECT
    so.id AS order_id,
    so.factory_id,
    so.process_flow_id,
    pfs.flow_step,
    pfs.department_id
  FROM public.style_orders so
  JOIN public.process_flow_steps pfs ON pfs.flow_id = so.process_flow_id
  WHERE so.process_flow_id IS NOT NULL
),
wip AS (
  SELECT * FROM public.v_wip_dept
)
SELECT
  of.factory_id,
  of.order_id,
  w.log_date,
  of.flow_step,
  of.department_id,
  COALESCE(w.wip_qty, 0) AS wip_qty
FROM order_flow of
LEFT JOIN wip w
  ON w.order_id = of.order_id AND w.department_id = of.department_id;

COMMENT ON VIEW public.v_wip_order IS
  'Per order/date/dept in process flow: WIP qty from v_wip_dept aligned to process_flow_steps sequence.';

-- -----------------------------------------------------------------------------
-- v_audit_summary: AQL audit aggregates
-- -----------------------------------------------------------------------------
CREATE OR REPLACE VIEW public.v_audit_summary AS
SELECT
  a.factory_id,
  a.order_id,
  a.department_id,
  a.logged_at::date AS log_date,
  COUNT(*)::integer AS lots,
  SUM(a.sample_size)::integer AS total_samples,
  SUM(a.passed)::integer AS total_passed,
  SUM(a.failed)::integer AS total_failed,
  CASE
    WHEN SUM(a.sample_size) = 0 THEN NULL
    ELSE ROUND(100.0 * SUM(a.passed) / NULLIF(SUM(a.sample_size), 0))::numeric
  END AS aql_pass_pct
FROM public.audit_sessions a
GROUP BY a.factory_id, a.order_id, a.department_id, a.logged_at::date;

COMMENT ON VIEW public.v_audit_summary IS
  'Daily audit summary: lots, samples, pass rate from audit_sessions.';

-- -----------------------------------------------------------------------------
-- v_daily_kpis_by_shift: shift-level KPI building block
-- Shift active if workforce OR output exists for factory/dept/date/shift.
-- Efficiency/productivity NULL unless BOTH workforce AND output exist for shift.
-- data_completeness: complete | workforce_only | output_only | none
-- BACK-FILL: never caches absence — always reads workforce_logs + capture tables as-of query time.
-- -----------------------------------------------------------------------------
CREATE OR REPLACE VIEW public.v_daily_kpis_by_shift AS
WITH output_shift AS (
  SELECT
    factory_id,
    order_id,
    department_id,
    log_date,
    shift_id,
    SUM(output_qty)::integer AS shift_output
  FROM public.v_daily_output
  WHERE shift_id IS NOT NULL
  GROUP BY factory_id, order_id, department_id, log_date, shift_id
),
output_unalloc AS (
  SELECT
    factory_id,
    order_id,
    department_id,
    log_date,
    SUM(output_qty)::integer AS unallocated_output
  FROM public.v_daily_output
  WHERE shift_id IS NULL
  GROUP BY factory_id, order_id, department_id, log_date
),
workforce AS (
  SELECT * FROM public.v_daily_workforce
),
shift_keys AS (
  SELECT factory_id, department_id, log_date, shift_id FROM workforce
  UNION
  SELECT
    h.factory_id,
    h.department_id,
    h.log_date,
    public.get_shift_for_hour_slot(h.factory_id, h.hour_slot) AS shift_id
  FROM public.hourly_counts h
  WHERE public.get_shift_for_hour_slot(h.factory_id, h.hour_slot) IS NOT NULL
  UNION
  SELECT i.factory_id, i.department_id, i.logged_at::date AS log_date, inf.shift_id
  FROM public.inspections i
  CROSS JOIN LATERAL (
    SELECT public.infer_shift_id_for_inspection(i.factory_id, i.logged_at) AS shift_id
  ) inf
  WHERE inf.shift_id IS NOT NULL
),
order_keys AS (
  SELECT DISTINCT factory_id, order_id, department_id, log_date FROM public.v_daily_output
  UNION
  SELECT DISTINCT factory_id, order_id, department_id, log_date FROM public.v_daily_target
),
base AS (
  SELECT
    ok.factory_id,
    ok.order_id,
    ok.department_id,
    ok.log_date,
    sk.shift_id
  FROM order_keys ok
  JOIN shift_keys sk
    ON sk.factory_id = ok.factory_id
   AND sk.department_id = ok.department_id
   AND sk.log_date = ok.log_date
),
enriched AS (
  SELECT
    b.factory_id,
    b.order_id,
    b.department_id,
    b.log_date,
    b.shift_id,
    sm.shift_name,
    sm.productive_mins,
    COALESCE(os.shift_output, 0) AS shift_output,
    COALESCE(wf.headcount, 0) AS shift_headcount,
    COALESCE(wf.available_mins, 0) AS shift_available_mins,
    (wf.shift_id IS NOT NULL) AS has_workforce,
    (COALESCE(os.shift_output, 0) > 0) AS has_output
  FROM base b
  JOIN public.v_shift_minutes sm ON sm.shift_id = b.shift_id
  LEFT JOIN output_shift os
    ON os.factory_id = b.factory_id AND os.order_id = b.order_id
   AND os.department_id = b.department_id AND os.log_date = b.log_date
   AND os.shift_id = b.shift_id
  LEFT JOIN workforce wf
    ON wf.factory_id = b.factory_id AND wf.department_id = b.department_id
   AND wf.log_date = b.log_date AND wf.shift_id = b.shift_id
),
with_flags AS (
  SELECT
    e.*,
    CASE
      WHEN NOT e.has_workforce AND NOT e.has_output THEN 'none'
      WHEN e.has_workforce AND e.has_output THEN 'complete'
      WHEN e.has_workforce THEN 'workforce_only'
      ELSE 'output_only'
    END AS data_completeness
  FROM enriched e
),
prorated AS (
  SELECT
    wf.*,
    t.daily_target,
    SUM(wf.productive_mins) OVER (
      PARTITION BY wf.factory_id, wf.order_id, wf.department_id, wf.log_date
    ) AS active_productive_mins
  FROM with_flags wf
  LEFT JOIN public.v_daily_target t
    ON t.factory_id = wf.factory_id AND t.order_id = wf.order_id
   AND t.department_id = wf.department_id AND t.log_date = wf.log_date
)
SELECT
  p.factory_id,
  p.order_id,
  p.department_id,
  p.log_date,
  p.shift_id,
  p.shift_name,
  p.shift_output,
  p.shift_headcount,
  p.shift_available_mins,
  p.has_workforce,
  p.has_output,
  p.data_completeness,
  CASE
    WHEN p.data_completeness = 'complete' AND COALESCE(p.daily_target, 0) > 0
      THEN ROUND(100.0 * p.shift_output / NULLIF(
        p.daily_target * (p.productive_mins / NULLIF(p.active_productive_mins, 0)), 0))::numeric
    ELSE NULL
  END AS shift_efficiency_pct,
  CASE
    WHEN p.data_completeness = 'complete' AND p.shift_headcount > 0
      THEN ROUND(p.shift_output::numeric / p.shift_headcount, 2)
    ELSE NULL
  END AS shift_productivity
FROM prorated p;

COMMENT ON VIEW public.v_daily_kpis_by_shift IS
  'Shift-level KPIs. Workforce one row per factory/dept/date/shift (activation source of truth). Hourly output shift from hour_slot→hours JSONB; QC from logged_at. output_only on OT: pending back-fill or data mistake. Efficiency only when BOTH workforce and output. BACK-FILL SAFE.';

-- -----------------------------------------------------------------------------
-- v_daily_kpis: master daily KPI row per factory/order/dept/date with rollups + day_completeness
-- daily_output = SUM shift output (incl. unallocated) where output exists
-- daily_available_mins = SUM available_mins for shifts with workforce
-- daily_efficiency = SUM(complete shift output) / daily_target * 100
-- daily_productivity = SUM(complete shift output) / SUM(complete shift headcount)
-- day_completeness: complete | partial | output_only | workforce_only | none
-- -----------------------------------------------------------------------------
CREATE OR REPLACE VIEW public.v_daily_kpis AS
WITH shift_rows AS (
  SELECT * FROM public.v_daily_kpis_by_shift
),
unalloc AS (
  SELECT factory_id, order_id, department_id, log_date, unallocated_output
  FROM (
    SELECT
      factory_id,
      order_id,
      department_id,
      log_date,
      SUM(output_qty)::integer AS unallocated_output
    FROM public.v_daily_output
    WHERE shift_id IS NULL
    GROUP BY factory_id, order_id, department_id, log_date
  ) u
),
daily AS (
  SELECT
    sr.factory_id,
    sr.order_id,
    sr.department_id,
    sr.log_date,
    COALESCE(t.daily_target, 0) AS daily_target,
    COALESCE(SUM(sr.shift_output), 0)
      + COALESCE(MAX(u.unallocated_output), 0) AS daily_output,
    COALESCE(SUM(sr.shift_available_mins) FILTER (
      WHERE sr.data_completeness IN ('complete', 'workforce_only')
    ), 0) AS daily_available_mins,
    COALESCE(SUM(sr.shift_output) FILTER (WHERE sr.data_completeness = 'complete'), 0) AS complete_output,
    COALESCE(SUM(sr.shift_headcount) FILTER (WHERE sr.data_completeness = 'complete'), 0) AS complete_headcount,
    BOOL_OR(sr.data_completeness = 'complete') AS any_complete,
    BOOL_OR(sr.data_completeness = 'output_only') AS any_output_only,
    BOOL_OR(sr.data_completeness = 'workforce_only') AS any_workforce_only,
    BOOL_OR(sr.data_completeness <> 'none') AS any_active
  FROM shift_rows sr
  LEFT JOIN public.v_daily_target t
    ON t.factory_id = sr.factory_id AND t.order_id = sr.order_id
   AND t.department_id = sr.department_id AND t.log_date = sr.log_date
  LEFT JOIN unalloc u
    ON u.factory_id = sr.factory_id AND u.order_id = sr.order_id
   AND u.department_id = sr.department_id AND u.log_date = sr.log_date
  GROUP BY sr.factory_id, sr.order_id, sr.department_id, sr.log_date, t.daily_target
)
SELECT
  d.factory_id,
  d.order_id,
  d.department_id,
  d.log_date,
  d.daily_target,
  d.daily_output,
  d.daily_available_mins,
  CASE
    WHEN d.daily_target > 0 AND d.complete_output > 0
      THEN ROUND(100.0 * d.complete_output / d.daily_target)::numeric
    ELSE NULL
  END AS daily_efficiency_pct,
  CASE
    WHEN d.complete_headcount > 0
      THEN ROUND(d.complete_output::numeric / d.complete_headcount, 2)
    ELSE NULL
  END AS daily_productivity,
  CASE
    WHEN NOT d.any_active THEN 'none'
    WHEN d.any_complete AND NOT d.any_output_only AND NOT d.any_workforce_only THEN 'complete'
    WHEN d.any_complete THEN 'partial'
    WHEN d.any_output_only AND NOT d.any_workforce_only THEN 'output_only'
    WHEN d.any_workforce_only AND NOT d.any_output_only THEN 'workforce_only'
    ELSE 'none'
  END AS day_completeness,
  (
    SELECT COALESCE(jsonb_agg(jsonb_build_object(
      'shift_id', s.shift_id,
      'shift_name', s.shift_name,
      'shift_output', s.shift_output,
      'shift_headcount', s.shift_headcount,
      'shift_available_mins', s.shift_available_mins,
      'data_completeness', s.data_completeness,
      'shift_efficiency_pct', s.shift_efficiency_pct,
      'shift_productivity', s.shift_productivity
    ) ORDER BY s.shift_name), '[]'::jsonb)
    FROM public.v_daily_kpis_by_shift s
    WHERE s.factory_id = d.factory_id AND s.order_id = d.order_id
      AND s.department_id = d.department_id AND s.log_date = d.log_date
  ) AS shifts
FROM daily d;

COMMENT ON VIEW public.v_daily_kpis IS
  'Master daily KPI per factory/order/dept/date. BACK-FILL BEHAVIOR: efficiency and completeness are NEVER frozen — they recompute from workforce_logs and capture tables on every SELECT. Example: Monday evening OT output exists but workforce missing → OT efficiency NULL (output_only). Tuesday morning workforce back-filled with log_date=Monday → re-query shows complete and efficiency computes. daily_output counts all captured output; daily_efficiency uses only shifts where BOTH workforce and output exist (partial days flagged via day_completeness=partial). shifts JSON array exposes per-shift data_completeness for UI messaging.';
