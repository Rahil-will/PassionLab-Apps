-- Phase 3.5: Cut-to-Ship schema — pseudo-departments, rejections, shipments.
-- Purpose: model Shipment + Quality Audit as non-production departments; capture rejections/shipments.
-- Inputs: existing factories, departments, style_orders.
-- Outputs: is_production flag, rejections + shipments tables with RLS, seeded pseudo-depts + rejection reasons.

ALTER TABLE public.departments
  ADD COLUMN IF NOT EXISTS is_production boolean NOT NULL DEFAULT true;

COMMENT ON COLUMN public.departments.is_production IS
  'false for support functions like Shipment and Quality Audit — captured data but excluded from production KPI calcs.';

-- -----------------------------------------------------------------------------
-- rejections: post-production rejection log (Quality Audit desk)
-- Output shape: one row per rejection entry (factory, order, colorway, qty, reason, stage, date)
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.rejections (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  factory_id      uuid NOT NULL REFERENCES public.factories(id) ON DELETE CASCADE,
  order_id        uuid NOT NULL REFERENCES public.style_orders(id) ON DELETE CASCADE,
  colorway_id     uuid REFERENCES public.colorways(id) ON DELETE SET NULL,
  size            text,
  qty             integer NOT NULL CHECK (qty > 0),
  reason_code     text NOT NULL,
  reason_detail   text,
  stage           text NOT NULL CHECK (stage IN (
    'inline', 'end_line', 'final_audit', 'pre_pack', 'post_pack', 'customer_return'
  )),
  rejected_date   date NOT NULL DEFAULT CURRENT_DATE,
  notes           text,
  logged_by       uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  logged_at       timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS rejections_factory_order_idx
  ON public.rejections(factory_id, order_id);
CREATE INDEX IF NOT EXISTS rejections_factory_date_idx
  ON public.rejections(factory_id, rejected_date);
CREATE INDEX IF NOT EXISTS rejections_factory_reason_idx
  ON public.rejections(factory_id, reason_code);

COMMENT ON TABLE public.rejections IS
  'Post-production rejection entries from Quality Audit. Used in cut-to-ship reconciliation (rejected_qty).';

-- -----------------------------------------------------------------------------
-- shipments: PO-level dispatch log (Shipment desk)
-- Output shape: one row per shipment event
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.shipments (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  factory_id      uuid NOT NULL REFERENCES public.factories(id) ON DELETE CASCADE,
  order_id        uuid NOT NULL REFERENCES public.style_orders(id) ON DELETE CASCADE,
  colorway_id     uuid REFERENCES public.colorways(id) ON DELETE SET NULL,
  po_number       text,
  shipped_qty     integer NOT NULL CHECK (shipped_qty > 0),
  shipment_date   date NOT NULL DEFAULT CURRENT_DATE,
  invoice_number  text,
  awb_number      text,
  destination     text,
  shipment_type   text NOT NULL CHECK (shipment_type IN (
    'main', 'partial', 'replacement', 'sample', 'rejection_return'
  )),
  notes           text,
  logged_by       uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  logged_at       timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS shipments_factory_order_idx
  ON public.shipments(factory_id, order_id);
CREATE INDEX IF NOT EXISTS shipments_factory_date_idx
  ON public.shipments(factory_id, shipment_date);

COMMENT ON TABLE public.shipments IS
  'Dispatch/shipment log from Shipment desk. Used in cut-to-ship reconciliation (shipped_qty).';

ALTER TABLE public.rejections ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.shipments ENABLE ROW LEVEL SECURITY;

DO $$
DECLARE
  t text;
  tables text[] := ARRAY['rejections', 'shipments'];
BEGIN
  FOREACH t IN ARRAY tables LOOP
    EXECUTE format('DROP POLICY IF EXISTS %I ON public.%I', t || '_select', t);
    EXECUTE format('DROP POLICY IF EXISTS %I ON public.%I', t || '_insert', t);
    EXECUTE format('DROP POLICY IF EXISTS %I ON public.%I', t || '_update', t);
    EXECUTE format('DROP POLICY IF EXISTS %I ON public.%I', t || '_delete', t);
    EXECUTE format(
      'CREATE POLICY %I ON public.%I FOR SELECT TO authenticated USING (factory_id = public.current_factory_id())',
      t || '_select', t
    );
    EXECUTE format(
      'CREATE POLICY %I ON public.%I FOR INSERT TO authenticated WITH CHECK (factory_id = public.current_factory_id())',
      t || '_insert', t
    );
    EXECUTE format(
      'CREATE POLICY %I ON public.%I FOR UPDATE TO authenticated USING (factory_id = public.current_factory_id()) WITH CHECK (factory_id = public.current_factory_id())',
      t || '_update', t
    );
    EXECUTE format(
      'CREATE POLICY %I ON public.%I FOR DELETE TO authenticated USING (factory_id = public.current_factory_id())',
      t || '_delete', t
    );
  END LOOP;
END $$;

GRANT SELECT, INSERT, UPDATE, DELETE ON public.rejections TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.shipments TO authenticated;

-- -----------------------------------------------------------------------------
-- Seed pseudo-departments + rejection_reasons dropdown (per factory, idempotent)
-- -----------------------------------------------------------------------------
INSERT INTO public.departments (factory_id, name, sequence, is_production, apps)
SELECT f.id, 'Quality Audit', 98, false, '["transaction","final_rejection_log"]'::jsonb
FROM public.factories f
WHERE NOT EXISTS (
  SELECT 1 FROM public.departments d
  WHERE d.factory_id = f.id AND d.name = 'Quality Audit'
);

INSERT INTO public.departments (factory_id, name, sequence, is_production, apps)
SELECT f.id, 'Shipment', 99, false, '["transaction","shipment_log"]'::jsonb
FROM public.factories f
WHERE NOT EXISTS (
  SELECT 1 FROM public.departments d
  WHERE d.factory_id = f.id AND d.name = 'Shipment'
);

INSERT INTO public.support_dropdowns (factory_id, category, values)
SELECT f.id, 'rejection_reasons',
  '["Stained","Damaged","Wrong measurement","Color mismatch","Construction defect","Buyer audit fail","Pattern issue","Print/Embroidery defect","Other"]'::jsonb
FROM public.factories f
WHERE NOT EXISTS (
  SELECT 1 FROM public.support_dropdowns sd
  WHERE sd.factory_id = f.id AND sd.category = 'rejection_reasons'
);
