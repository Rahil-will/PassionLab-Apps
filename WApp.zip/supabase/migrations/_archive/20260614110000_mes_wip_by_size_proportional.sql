-- Phase 9c follow-up: wip_qty_by_size sums to scalar wip_qty via proportional split.

CREATE OR REPLACE VIEW public.v_cut_to_ship AS
WITH rej_by_size AS (
  SELECT factory_id, order_id, colorway_id,
    jsonb_object_agg(size, rejected_qty) AS rejected_qty_by_size
  FROM public.v_order_rejected_qty_by_size
  GROUP BY factory_id, order_id, colorway_id
),
ship_by_size AS (
  SELECT factory_id, order_id, colorway_id,
    public.jsonb_merge_sum_maps(ARRAY_AGG(shipped_qty_by_size)) AS shipped_qty_by_size
  FROM public.shipments
  WHERE shipped_qty_by_size <> '{}'::jsonb
  GROUP BY factory_id, order_id, colorway_id
),
cut_by_size AS (
  SELECT h.factory_id, h.order_id, h.colorway_id,
    public.proportional_qty_by_size(
      SUM(h.count)::integer,
      public.colorway_planned_by_size(h.colorway_id)
    ) AS cut_qty_by_size
  FROM public.hourly_counts h
  WHERE h.department_id = public.get_cutting_department_id(h.factory_id)
  GROUP BY h.factory_id, h.order_id, h.colorway_id,
    public.colorway_planned_by_size(h.colorway_id)
)
SELECT
  so.factory_id,
  so.id AS order_id,
  cw.id AS colorway_id,
  so.style_name,
  so.buyer_name,
  so.po_number,
  COALESCE(so.adj_qty, so.order_qty, 0)::integer AS order_qty,
  COALESCE(cq.cut_qty, 0)::integer AS cut_qty,
  COALESCE(cq.cut_qty_source, 'planned') AS cut_qty_source,
  COALESCE(sq.shipped_qty, 0)::integer AS shipped_qty,
  COALESCE(rq.rejected_qty, 0)::integer AS rejected_qty,
  COALESCE(wt.wip_qty, 0)::integer AS wip_qty,
  (COALESCE(cq.cut_qty, 0)
    - (COALESCE(sq.shipped_qty, 0) + COALESCE(rq.rejected_qty, 0) + COALESCE(wt.wip_qty, 0)))::integer
    AS reconciliation_gap,
  COALESCE(rq.rejected_by_reason, '{}'::jsonb) AS rejected_by_reason,
  COALESCE(rq.rejected_by_stage, '{}'::jsonb) AS rejected_by_stage,
  (COALESCE(cq.cut_qty, 0)
    = COALESCE(sq.shipped_qty, 0) + COALESCE(rq.rejected_qty, 0) + COALESCE(wt.wip_qty, 0)) AS is_balanced,
  ROUND(100.0 * COALESCE(sq.shipped_qty, 0) / NULLIF(COALESCE(so.adj_qty, so.order_qty, 0), 0), 2) AS completion_pct,
  so.status AS order_status,
  sq.last_shipment_date,
  COALESCE(cbs.cut_qty_by_size, '{}'::jsonb) AS cut_qty_by_size,
  COALESCE(sbs.shipped_qty_by_size, '{}'::jsonb) AS shipped_qty_by_size,
  COALESCE(rbs.rejected_qty_by_size, '{}'::jsonb) AS rejected_qty_by_size,
  CASE
    WHEN COALESCE(wt.wip_qty, 0) > 0 AND COALESCE(cbs.cut_qty_by_size, '{}'::jsonb) <> '{}'::jsonb THEN
      public.proportional_qty_by_size(wt.wip_qty, cbs.cut_qty_by_size)
    WHEN COALESCE(wt.wip_qty, 0) > 0 THEN
      public.proportional_qty_by_size(wt.wip_qty, public.colorway_planned_by_size(cw.id))
    ELSE '{}'::jsonb
  END AS wip_qty_by_size
FROM public.style_orders so
LEFT JOIN public.colorways cw ON cw.order_id = so.id
LEFT JOIN public.v_order_cut_qty cq
  ON cq.factory_id = so.factory_id AND cq.order_id = so.id
 AND cq.colorway_id IS NOT DISTINCT FROM cw.id
LEFT JOIN public.v_order_shipped_qty sq
  ON sq.factory_id = so.factory_id AND sq.order_id = so.id
 AND sq.colorway_id IS NOT DISTINCT FROM cw.id
LEFT JOIN public.v_order_rejected_qty rq
  ON rq.factory_id = so.factory_id AND rq.order_id = so.id
 AND rq.colorway_id IS NOT DISTINCT FROM cw.id
LEFT JOIN public.v_order_wip_total wt
  ON wt.factory_id = so.factory_id AND wt.order_id = so.id
 AND wt.colorway_id IS NOT DISTINCT FROM cw.id
LEFT JOIN cut_by_size cbs
  ON cbs.factory_id = so.factory_id AND cbs.order_id = so.id
 AND cbs.colorway_id IS NOT DISTINCT FROM cw.id
LEFT JOIN ship_by_size sbs
  ON sbs.factory_id = so.factory_id AND sbs.order_id = so.id
 AND sbs.colorway_id IS NOT DISTINCT FROM cw.id
LEFT JOIN rej_by_size rbs
  ON rbs.factory_id = so.factory_id AND rbs.order_id = so.id
 AND rbs.colorway_id IS NOT DISTINCT FROM cw.id;

COMMENT ON VIEW public.v_cut_to_ship IS
  'Cut-to-ship per colorway. wip_qty_by_size = proportional split of scalar wip_qty across cut size mix (sums match wip_qty).';
