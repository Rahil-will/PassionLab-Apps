-- mes_schema_polish (Phase 2b)
-- productive_mins, order_department_mode, reporting indexes, dept XOR trigger, core MES RLS.

-- -----------------------------------------------------------------------------
-- productive_mins: sum active slots from shifts.hours JSONB (not start_time/end_time)
-- -----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.shift_productive_mins_from_hours(p_hours jsonb)
RETURNS numeric
LANGUAGE sql
IMMUTABLE
AS $$
  SELECT COALESCE(SUM(
    CASE
      WHEN slot->>'type' = 'active' THEN
        EXTRACT(EPOCH FROM (
          (slot->>'end')::time - (slot->>'start')::time
          + CASE
              WHEN (slot->>'end')::time < (slot->>'start')::time THEN interval '24 hours'
              ELSE interval '0'
            END
        )) / 60.0
      ELSE 0
    END
  ), 0)
  FROM jsonb_array_elements(COALESCE(p_hours, '[]'::jsonb)) AS slot;
$$;

COMMENT ON FUNCTION public.shift_productive_mins_from_hours(jsonb) IS
  'Derives productive minutes from shifts.hours JSONB by summing slots where type=active.';

ALTER TABLE public.shifts
  ADD COLUMN IF NOT EXISTS productive_mins numeric;

UPDATE public.shifts
SET productive_mins = public.shift_productive_mins_from_hours(hours)
WHERE productive_mins IS NULL;

ALTER TABLE public.shifts
  ALTER COLUMN productive_mins SET DEFAULT 0;

UPDATE public.shifts SET productive_mins = 0 WHERE productive_mins IS NULL;

ALTER TABLE public.shifts
  ALTER COLUMN productive_mins SET NOT NULL;

COMMENT ON COLUMN public.shifts.productive_mins IS
  'Productive minutes per shift day, derived from hours JSONB active slots (not start_time/end_time).';

-- -----------------------------------------------------------------------------
-- order_department_mode: lock capture mode per order x department
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.order_department_mode (
  order_id       uuid NOT NULL REFERENCES public.style_orders(id) ON DELETE CASCADE,
  department_id  uuid NOT NULL REFERENCES public.departments(id) ON DELETE CASCADE,
  mode           text NOT NULL CHECK (mode IN ('hourly', 'qc', 'none')),
  PRIMARY KEY (order_id, department_id)
);

COMMENT ON TABLE public.order_department_mode IS
  'Locks capture mode per style_order x department. hourly = hourly_counts only; qc = inspections only; none = no capture.';

ALTER TABLE public.order_department_mode ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS order_department_mode_select ON public.order_department_mode;
DROP POLICY IF EXISTS order_department_mode_insert ON public.order_department_mode;
DROP POLICY IF EXISTS order_department_mode_update ON public.order_department_mode;
DROP POLICY IF EXISTS order_department_mode_delete ON public.order_department_mode;

CREATE POLICY order_department_mode_select ON public.order_department_mode
  FOR SELECT TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.style_orders o
      WHERE o.id = order_department_mode.order_id
        AND o.factory_id = public.current_factory_id()
    )
  );

CREATE POLICY order_department_mode_insert ON public.order_department_mode
  FOR INSERT TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.style_orders o
      WHERE o.id = order_department_mode.order_id
        AND o.factory_id = public.current_factory_id()
    )
  );

CREATE POLICY order_department_mode_update ON public.order_department_mode
  FOR UPDATE TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.style_orders o
      WHERE o.id = order_department_mode.order_id
        AND o.factory_id = public.current_factory_id()
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.style_orders o
      WHERE o.id = order_department_mode.order_id
        AND o.factory_id = public.current_factory_id()
    )
  );

CREATE POLICY order_department_mode_delete ON public.order_department_mode
  FOR DELETE TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.style_orders o
      WHERE o.id = order_department_mode.order_id
        AND o.factory_id = public.current_factory_id()
    )
  );

-- -----------------------------------------------------------------------------
-- Reporting indexes on capture tables
-- -----------------------------------------------------------------------------
CREATE INDEX IF NOT EXISTS hourly_counts_factory_log_date_idx
  ON public.hourly_counts(factory_id, log_date);

CREATE INDEX IF NOT EXISTS inspections_factory_dept_logged_at_idx
  ON public.inspections(factory_id, department_id, logged_at);

CREATE INDEX IF NOT EXISTS handover_slips_factory_order_idx
  ON public.handover_slips(factory_id, order_id);

CREATE INDEX IF NOT EXISTS workforce_logs_factory_log_date_idx
  ON public.workforce_logs(factory_id, log_date);

CREATE INDEX IF NOT EXISTS audit_sessions_factory_dept_logged_at_idx
  ON public.audit_sessions(factory_id, department_id, logged_at);

-- -----------------------------------------------------------------------------
-- departments.apps XOR: reject hourly + qc_log on same department
-- -----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.reject_dept_hourly_qc_both()
RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
  IF COALESCE(NEW.apps, '[]'::jsonb) @> '["hourly"]'::jsonb
     AND COALESCE(NEW.apps, '[]'::jsonb) @> '["qc_log"]'::jsonb THEN
    RAISE EXCEPTION 'Department apps cannot include both hourly and qc_log';
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS departments_reject_hourly_qc_both ON public.departments;
CREATE TRIGGER departments_reject_hourly_qc_both
  BEFORE INSERT OR UPDATE OF apps ON public.departments
  FOR EACH ROW
  EXECUTE FUNCTION public.reject_dept_hourly_qc_both();

-- -----------------------------------------------------------------------------
-- Factory-scoped RLS on core MES master tables
-- -----------------------------------------------------------------------------
ALTER TABLE public.buyers ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.departments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.shifts ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.workers ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.assigned_resources ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.style_orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.line_allocations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.colorways ENABLE ROW LEVEL SECURITY;

DO $$
DECLARE
  t text;
  tables text[] := ARRAY[
    'buyers', 'departments', 'shifts', 'workers', 'assigned_resources',
    'style_orders', 'line_allocations'
  ];
BEGIN
  FOREACH t IN ARRAY tables LOOP
    EXECUTE format('DROP POLICY IF EXISTS %I ON public.%I', t || '_select', t);
    EXECUTE format('DROP POLICY IF EXISTS %I ON public.%I', t || '_insert', t);
    EXECUTE format('DROP POLICY IF EXISTS %I ON public.%I', t || '_update', t);
    EXECUTE format('DROP POLICY IF EXISTS %I ON public.%I', t || '_delete', t);
    EXECUTE format(
      'CREATE POLICY %I ON public.%I FOR SELECT TO authenticated USING (factory_id = public.current_factory_id())',
      t || '_select', t
    );
    EXECUTE format(
      'CREATE POLICY %I ON public.%I FOR INSERT TO authenticated WITH CHECK (factory_id = public.current_factory_id())',
      t || '_insert', t
    );
    EXECUTE format(
      'CREATE POLICY %I ON public.%I FOR UPDATE TO authenticated USING (factory_id = public.current_factory_id()) WITH CHECK (factory_id = public.current_factory_id())',
      t || '_update', t
    );
    EXECUTE format(
      'CREATE POLICY %I ON public.%I FOR DELETE TO authenticated USING (factory_id = public.current_factory_id())',
      t || '_delete', t
    );
  END LOOP;
END $$;

DROP POLICY IF EXISTS colorways_select ON public.colorways;
DROP POLICY IF EXISTS colorways_insert ON public.colorways;
DROP POLICY IF EXISTS colorways_update ON public.colorways;
DROP POLICY IF EXISTS colorways_delete ON public.colorways;

CREATE POLICY colorways_select ON public.colorways
  FOR SELECT TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.style_orders o
      WHERE o.id = colorways.order_id AND o.factory_id = public.current_factory_id()
    )
  );

CREATE POLICY colorways_insert ON public.colorways
  FOR INSERT TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.style_orders o
      WHERE o.id = colorways.order_id AND o.factory_id = public.current_factory_id()
    )
  );

CREATE POLICY colorways_update ON public.colorways
  FOR UPDATE TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.style_orders o
      WHERE o.id = colorways.order_id AND o.factory_id = public.current_factory_id()
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.style_orders o
      WHERE o.id = colorways.order_id AND o.factory_id = public.current_factory_id()
    )
  );

CREATE POLICY colorways_delete ON public.colorways
  FOR DELETE TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.style_orders o
      WHERE o.id = colorways.order_id AND o.factory_id = public.current_factory_id()
    )
  );
