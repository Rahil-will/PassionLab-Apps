-- Dynamic workforce categories: labels on departments.worker_roles, counts in workforce_logs.headcount_by_category only.

-- Backfill legacy four integer columns into headcount_by_category using department labels.
UPDATE public.workforce_logs wl
SET headcount_by_category = (
  SELECT COALESCE(NULLIF(wl.headcount_by_category, '{}'::jsonb), '{}'::jsonb)
    || jsonb_strip_nulls(jsonb_build_object(
      COALESCE(d.worker_roles->>0, 'Operators'), NULLIF(wl.operators, 0),
      COALESCE(d.worker_roles->>1, 'Helpers'), NULLIF(wl.helpers, 0),
      COALESCE(d.worker_roles->>2, 'Supervisors'), NULLIF(wl.supervisors, 0),
      COALESCE(d.worker_roles->>3, 'Trainees'), NULLIF(wl.trainees, 0)
    ))
  FROM public.departments d
  WHERE d.id = wl.department_id
)
WHERE (wl.operators + wl.helpers + wl.supervisors + wl.trainees) > 0;

ALTER TABLE public.departments
  ALTER COLUMN worker_roles SET DEFAULT '[]'::jsonb;

COMMENT ON COLUMN public.departments.worker_roles IS
  'Workforce category labels when apps includes workforce_log. Empty when not using workforce log.';

UPDATE public.departments
SET worker_roles = '[]'::jsonb
WHERE NOT (COALESCE(apps, '[]'::jsonb) @> '["workforce_log"]'::jsonb);

COMMENT ON COLUMN public.workforce_logs.headcount_by_category IS
  'Headcount by category label (from departments.worker_roles). Keys are display labels, values are counts.';

CREATE OR REPLACE FUNCTION public.workforce_log_total_headcount(p_headcount jsonb DEFAULT '{}'::jsonb)
RETURNS integer
LANGUAGE sql
IMMUTABLE
AS $$
  SELECT COALESCE(public.jsonb_sum_int_values(COALESCE(p_headcount, '{}'::jsonb)), 0)::integer;
$$;

CREATE OR REPLACE VIEW public.v_daily_workforce AS
SELECT
  wl.factory_id,
  wl.department_id,
  wl.log_date,
  wl.shift_id,
  sm.shift_name,
  sm.productive_mins,
  public.workforce_log_total_headcount(wl.headcount_by_category) AS headcount,
  (public.workforce_log_total_headcount(wl.headcount_by_category) * sm.productive_mins)::numeric AS available_mins
FROM public.workforce_logs wl
JOIN public.v_shift_minutes sm ON sm.shift_id = wl.shift_id;

COMMENT ON VIEW public.v_daily_workforce IS
  'One row per factory/department/log_date/shift_id. Headcount from workforce_logs.headcount_by_category; available_mins = headcount * productive_mins.';

-- Patch floor_capture: jsonb-only workforce upsert (before dropping legacy columns).
DO $$
DECLARE
  def text;
BEGIN
  def := pg_get_functiondef('public.floor_capture(uuid,uuid,text,jsonb)'::regprocedure);

  def := replace(def,
    'AND public.workforce_log_total_headcount(wl.operators, wl.helpers, wl.supervisors, wl.trainees, wl.headcount_by_category) > 0',
    'AND public.jsonb_sum_int_values(COALESCE(wl.headcount_by_category, ''{}''::jsonb)) > 0'
  );

  def := replace(def,
    'AND (wl.operators + wl.helpers + wl.supervisors + wl.trainees) > 0',
    'AND public.jsonb_sum_int_values(COALESCE(wl.headcount_by_category, ''{}''::jsonb)) > 0'
  );

  def := replace(def,
    E'    IF public.workforce_log_total_headcount(\n      COALESCE((p_payload->>''operators'')::integer, 0),\n      COALESCE((p_payload->>''helpers'')::integer, 0),\n      COALESCE((p_payload->>''supervisors'')::integer, 0),\n      COALESCE((p_payload->>''trainees'')::integer, 0),\n      COALESCE(p_payload->''headcountByCategory'', ''{}''::jsonb)\n    ) <= 0 THEN\n      RETURN public.floor_capture_fail(''At least one headcount field must be > 0'', ''EMPTY_HEADCOUNT'');\n    END IF;',
    E'    IF public.jsonb_sum_int_values(COALESCE(p_payload->''headcountByCategory'', ''{}''::jsonb)) <= 0 THEN\n      RETURN public.floor_capture_fail(''At least one headcount field must be > 0'', ''EMPTY_HEADCOUNT'');\n    END IF;'
  );

  def := replace(def,
    E'    IF COALESCE((p_payload->>''operators'')::integer, 0)\n       + COALESCE((p_payload->>''helpers'')::integer, 0)\n       + COALESCE((p_payload->>''supervisors'')::integer, 0)\n       + COALESCE((p_payload->>''trainees'')::integer, 0) <= 0 THEN\n      RETURN public.floor_capture_fail(''At least one headcount field must be > 0'', ''EMPTY_HEADCOUNT'');\n    END IF;',
    E'    IF public.jsonb_sum_int_values(COALESCE(p_payload->''headcountByCategory'', ''{}''::jsonb)) <= 0 THEN\n      RETURN public.floor_capture_fail(''At least one headcount field must be > 0'', ''EMPTY_HEADCOUNT'');\n    END IF;'
  );

  def := replace(def,
    E'      UPDATE public.workforce_logs SET\n        order_id = NULLIF(p_payload->>''orderId'', '''')::uuid,\n        operators = COALESCE((p_payload->>''operators'')::integer, 0),\n        helpers = COALESCE((p_payload->>''helpers'')::integer, 0),\n        supervisors = COALESCE((p_payload->>''supervisors'')::integer, 0),\n        trainees = COALESCE((p_payload->>''trainees'')::integer, 0),\n        headcount_by_category = COALESCE(p_payload->''headcountByCategory'', ''{}''::jsonb),\n        logged_by = p_user_id,\n        logged_at = COALESCE((p_payload->>''loggedAt'')::timestamptz, now())\n      WHERE id = v_existing;',
    E'      UPDATE public.workforce_logs SET\n        order_id = NULLIF(p_payload->>''orderId'', '''')::uuid,\n        headcount_by_category = COALESCE(p_payload->''headcountByCategory'', ''{}''::jsonb),\n        logged_by = p_user_id,\n        logged_at = COALESCE((p_payload->>''loggedAt'')::timestamptz, now())\n      WHERE id = v_existing;'
  );

  def := replace(def,
    E'    INSERT INTO public.workforce_logs (\n      factory_id, order_id, department_id, shift_id, log_date,\n      operators, helpers, supervisors, trainees, headcount_by_category, logged_by, logged_at\n    ) VALUES (\n      p_factory_id,\n      NULLIF(p_payload->>''orderId'', '''')::uuid,\n      v_payload_dept,\n      NULLIF(p_payload->>''shiftId'', '''')::uuid,\n      v_log_date,\n      COALESCE((p_payload->>''operators'')::integer, 0),\n      COALESCE((p_payload->>''helpers'')::integer, 0),\n      COALESCE((p_payload->>''supervisors'')::integer, 0),\n      COALESCE((p_payload->>''trainees'')::integer, 0),\n      COALESCE(p_payload->''headcountByCategory'', ''{}''::jsonb),\n      p_user_id,\n      COALESCE((p_payload->>''loggedAt'')::timestamptz, now())\n    )',
    E'    INSERT INTO public.workforce_logs (\n      factory_id, order_id, department_id, shift_id, log_date,\n      headcount_by_category, logged_by, logged_at\n    ) VALUES (\n      p_factory_id,\n      NULLIF(p_payload->>''orderId'', '''')::uuid,\n      v_payload_dept,\n      NULLIF(p_payload->>''shiftId'', '''')::uuid,\n      v_log_date,\n      COALESCE(p_payload->''headcountByCategory'', ''{}''::jsonb),\n      p_user_id,\n      COALESCE((p_payload->>''loggedAt'')::timestamptz, now())\n    )'
  );

  -- Older floor_capture bodies (operators-only insert, no headcount_by_category yet).
  def := replace(def,
    E'      UPDATE public.workforce_logs SET\n        order_id = NULLIF(p_payload->>''orderId'', '''')::uuid,\n        operators = COALESCE((p_payload->>''operators'')::integer, 0),\n        helpers = COALESCE((p_payload->>''helpers'')::integer, 0),\n        supervisors = COALESCE((p_payload->>''supervisors'')::integer, 0),\n        trainees = COALESCE((p_payload->>''trainees'')::integer, 0),\n        logged_by = p_user_id,\n        logged_at = COALESCE((p_payload->>''loggedAt'')::timestamptz, now())\n      WHERE id = v_existing;',
    E'      UPDATE public.workforce_logs SET\n        order_id = NULLIF(p_payload->>''orderId'', '''')::uuid,\n        headcount_by_category = COALESCE(p_payload->''headcountByCategory'', ''{}''::jsonb),\n        logged_by = p_user_id,\n        logged_at = COALESCE((p_payload->>''loggedAt'')::timestamptz, now())\n      WHERE id = v_existing;'
  );

  def := replace(def,
    E'    INSERT INTO public.workforce_logs (\n      factory_id, order_id, department_id, shift_id, log_date,\n      operators, helpers, supervisors, trainees, logged_by, logged_at\n    ) VALUES (\n      p_factory_id,\n      NULLIF(p_payload->>''orderId'', '''')::uuid,\n      v_payload_dept,\n      NULLIF(p_payload->>''shiftId'', '''')::uuid,\n      v_log_date,\n      COALESCE((p_payload->>''operators'')::integer, 0),\n      COALESCE((p_payload->>''helpers'')::integer, 0),\n      COALESCE((p_payload->>''supervisors'')::integer, 0),\n      COALESCE((p_payload->>''trainees'')::integer, 0),\n      p_user_id,\n      COALESCE((p_payload->>''loggedAt'')::timestamptz, now())\n    )',
    E'    INSERT INTO public.workforce_logs (\n      factory_id, order_id, department_id, shift_id, log_date,\n      headcount_by_category, logged_by, logged_at\n    ) VALUES (\n      p_factory_id,\n      NULLIF(p_payload->>''orderId'', '''')::uuid,\n      v_payload_dept,\n      NULLIF(p_payload->>''shiftId'', '''')::uuid,\n      v_log_date,\n      COALESCE(p_payload->''headcountByCategory'', ''{}''::jsonb),\n      p_user_id,\n      COALESCE((p_payload->>''loggedAt'')::timestamptz, now())\n    )'
  );

  EXECUTE def;
END $$;

ALTER TABLE public.workforce_logs DROP COLUMN IF EXISTS operators;
ALTER TABLE public.workforce_logs DROP COLUMN IF EXISTS helpers;
ALTER TABLE public.workforce_logs DROP COLUMN IF EXISTS supervisors;
ALTER TABLE public.workforce_logs DROP COLUMN IF EXISTS trainees;
