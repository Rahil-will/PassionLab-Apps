-- Phase 3.5 correction: deterministic per-order Cutting dept identification.

CREATE OR REPLACE FUNCTION public.get_cutting_department_id_for_order(p_order_id uuid)
RETURNS uuid
LANGUAGE sql
STABLE
AS $$
  SELECT COALESCE(
    (
      SELECT pfs.department_id
      FROM public.style_orders so
      JOIN public.process_flow_steps pfs
        ON pfs.flow_id = so.process_flow_id AND pfs.flow_step = 1
      WHERE so.id = p_order_id
      LIMIT 1
    ),
    (
      SELECT d.id
      FROM public.style_orders so
      JOIN public.departments d
        ON d.factory_id = so.factory_id
       AND d.name ILIKE 'cutting'
       AND d.is_production = true
      WHERE so.id = p_order_id
      ORDER BY d.id
      LIMIT 1
    )
  );
$$;

COMMENT ON FUNCTION public.get_cutting_department_id_for_order(uuid) IS
  'Per-order Cutting dept resolution (priority order):
   1) process_flow_steps.flow_step = 1 for the order''s process_flow_id (authoritative first step).
   2) Else departments.name ILIKE ''cutting'' AND is_production = true for the order''s factory.
   3) Returns NULL when neither applies — caller should set cut_qty = 0, cut_qty_source = ''no_cutting_dept''.';

CREATE OR REPLACE VIEW public.v_order_cut_qty AS
WITH order_cutting AS (
  SELECT
    so.factory_id,
    so.id AS order_id,
    public.get_cutting_department_id_for_order(so.id) AS cutting_department_id
  FROM public.style_orders so
),
captured AS (
  SELECT
    h.factory_id,
    h.order_id,
    h.colorway_id,
    SUM(h.count)::integer AS captured_cut,
    true AS has_capture
  FROM public.hourly_counts h
  JOIN order_cutting oc ON oc.order_id = h.order_id AND oc.factory_id = h.factory_id
  WHERE oc.cutting_department_id IS NOT NULL
    AND h.department_id = oc.cutting_department_id
  GROUP BY h.factory_id, h.order_id, h.colorway_id
),
order_rows AS (
  SELECT so.factory_id, so.id AS order_id, cw.id AS colorway_id, so.adj_qty,
    oc.cutting_department_id
  FROM public.style_orders so
  LEFT JOIN public.colorways cw ON cw.order_id = so.id
  LEFT JOIN order_cutting oc ON oc.order_id = so.id
)
SELECT
  o.factory_id,
  o.order_id,
  o.colorway_id,
  CASE
    WHEN o.cutting_department_id IS NULL THEN 0
    WHEN COALESCE(c.has_capture, false) THEN COALESCE(c.captured_cut, 0)
    ELSE COALESCE(o.adj_qty, 0)
  END::integer AS cut_qty,
  CASE
    WHEN o.cutting_department_id IS NULL THEN 'no_cutting_dept'
    WHEN COALESCE(c.has_capture, false) THEN 'captured'
    ELSE 'planned'
  END AS cut_qty_source,
  COALESCE(o.adj_qty, 0)::integer AS cut_qty_fallback
FROM order_rows o
LEFT JOIN captured c ON c.factory_id = o.factory_id AND c.order_id = o.order_id
  AND c.colorway_id IS NOT DISTINCT FROM o.colorway_id;

COMMENT ON VIEW public.v_order_cut_qty IS
  'Cut qty per factory/order/colorway. CUTTING DEPT RULE (deterministic, per order):
   1) process_flow_steps.flow_step = 1 for this order''s process_flow_id — authoritative first step.
   2) If no flow_step = 1 on that flow, fall back to departments WHERE name ILIKE ''cutting''
      AND is_production = true AND factory_id matches the order.
   3) If neither finds a dept: cut_qty = 0, cut_qty_source = ''no_cutting_dept'' (setup incomplete).
   When a cutting dept exists: cut_qty_source = captured when hourly_counts exist for that dept/colorway;
   else planned uses style_orders.adj_qty fallback.';

CREATE OR REPLACE VIEW public.v_factories_missing_flow_step_one AS
SELECT
  pf.factory_id,
  pf.id AS process_flow_id,
  pf.name AS process_flow_name,
  pf.is_current
FROM public.process_flows pf
WHERE NOT EXISTS (
  SELECT 1
  FROM public.process_flow_steps pfs
  WHERE pfs.flow_id = pf.id AND pfs.flow_step = 1
);

COMMENT ON VIEW public.v_factories_missing_flow_step_one IS
  'Setup health check: process flows with no flow_step = 1. Orders on these flows cannot resolve Cutting via rule 1.';
