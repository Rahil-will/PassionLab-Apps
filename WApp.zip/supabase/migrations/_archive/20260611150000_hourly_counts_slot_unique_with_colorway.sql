-- PRE-FIX 1: Include colorway_id in hourly_counts slot uniqueness.
-- Diagnostic (2026-06-08): hourly_counts had 0 rows — no conflicts on index rebuild.

DROP INDEX IF EXISTS public.hourly_counts_slot_unique;

CREATE UNIQUE INDEX hourly_counts_slot_unique
  ON public.hourly_counts (
    factory_id,
    order_id,
    department_id,
    COALESCE(colorway_id, '00000000-0000-0000-0000-000000000000'::uuid),
    hour_slot,
    log_date
  );

COMMENT ON INDEX public.hourly_counts_slot_unique IS
  'One hourly capture per factory/order/dept/colorway/slot/date. NULL colorway_id uses sentinel UUID for uniqueness.';

-- floor_capture hourly_upsert: match lookup key to the unique index (include colorwayId).

CREATE OR REPLACE FUNCTION public.floor_capture(
  p_factory_id uuid,
  p_user_id uuid,
  p_type text,
  p_payload jsonb
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_id uuid;
  v_existing uuid;
  v_challan text;
  v_po text;
  v_colorway_id uuid;
BEGIN
  IF p_factory_id IS NULL OR p_user_id IS NULL THEN
    RETURN jsonb_build_object('error', 'Invalid session', 'code', 'INVALID_SESSION');
  END IF;

  IF p_type = 'hourly_upsert' THEN
    v_colorway_id := NULLIF(p_payload->>'colorwayId', '')::uuid;

    SELECT id INTO v_existing
    FROM public.hourly_counts
    WHERE factory_id = p_factory_id
      AND order_id = (p_payload->>'orderId')::uuid
      AND department_id = (p_payload->>'departmentId')::uuid
      AND COALESCE(colorway_id, '00000000-0000-0000-0000-000000000000'::uuid)
        = COALESCE(v_colorway_id, '00000000-0000-0000-0000-000000000000'::uuid)
      AND hour_slot = p_payload->>'hourSlot'
      AND log_date = COALESCE((p_payload->>'logDate')::date, CURRENT_DATE)
    LIMIT 1;

    IF v_existing IS NOT NULL THEN
      UPDATE public.hourly_counts
      SET count = (p_payload->>'count')::integer,
          logged_at = COALESCE((p_payload->>'loggedAt')::timestamptz, now()),
          shift_id = NULLIF(p_payload->>'shiftId', '')::uuid,
          resource_id = NULLIF(p_payload->>'resourceId', '')::uuid,
          logged_by = p_user_id
      WHERE id = v_existing;
      RETURN jsonb_build_object('id', v_existing);
    END IF;

    INSERT INTO public.hourly_counts (
      factory_id, order_id, colorway_id, department_id, resource_id, shift_id,
      hour_slot, log_date, count, logged_by, logged_at
    ) VALUES (
      p_factory_id,
      (p_payload->>'orderId')::uuid,
      v_colorway_id,
      (p_payload->>'departmentId')::uuid,
      NULLIF(p_payload->>'resourceId', '')::uuid,
      NULLIF(p_payload->>'shiftId', '')::uuid,
      p_payload->>'hourSlot',
      COALESCE((p_payload->>'logDate')::date, CURRENT_DATE),
      (p_payload->>'count')::integer,
      p_user_id,
      COALESCE((p_payload->>'loggedAt')::timestamptz, now())
    )
    RETURNING id INTO v_id;

    RETURN jsonb_build_object('id', v_id);
  END IF;

  IF p_type = 'inspection' THEN
    INSERT INTO public.inspections (
      factory_id, order_id, colorway_id, department_id, piece_ref, result, defects, logged_by, logged_at
    ) VALUES (
      p_factory_id,
      (p_payload->>'orderId')::uuid,
      NULLIF(p_payload->>'colorwayId', '')::uuid,
      (p_payload->>'departmentId')::uuid,
      NULLIF(p_payload->>'pieceRef', ''),
      p_payload->>'result',
      COALESCE(p_payload->'defects', '[]'::jsonb),
      p_user_id,
      COALESCE((p_payload->>'loggedAt')::timestamptz, now())
    )
    RETURNING id INTO v_id;
    RETURN jsonb_build_object('id', v_id);
  END IF;

  IF p_type = 'workforce_upsert' THEN
    SELECT id INTO v_existing
    FROM public.workforce_logs
    WHERE factory_id = p_factory_id
      AND department_id = (p_payload->>'departmentId')::uuid
      AND log_date = (p_payload->>'logDate')::date
      AND shift_id IS NOT DISTINCT FROM NULLIF(p_payload->>'shiftId', '')::uuid
    LIMIT 1;

    IF v_existing IS NOT NULL THEN
      UPDATE public.workforce_logs SET
        order_id = NULLIF(p_payload->>'orderId', '')::uuid,
        operators = COALESCE((p_payload->>'operators')::integer, 0),
        helpers = COALESCE((p_payload->>'helpers')::integer, 0),
        supervisors = COALESCE((p_payload->>'supervisors')::integer, 0),
        trainees = COALESCE((p_payload->>'trainees')::integer, 0),
        logged_by = p_user_id,
        logged_at = COALESCE((p_payload->>'loggedAt')::timestamptz, now())
      WHERE id = v_existing;
      RETURN jsonb_build_object('id', v_existing);
    END IF;

    INSERT INTO public.workforce_logs (
      factory_id, order_id, department_id, shift_id, log_date,
      operators, helpers, supervisors, trainees, logged_by, logged_at
    ) VALUES (
      p_factory_id,
      NULLIF(p_payload->>'orderId', '')::uuid,
      (p_payload->>'departmentId')::uuid,
      NULLIF(p_payload->>'shiftId', '')::uuid,
      (p_payload->>'logDate')::date,
      COALESCE((p_payload->>'operators')::integer, 0),
      COALESCE((p_payload->>'helpers')::integer, 0),
      COALESCE((p_payload->>'supervisors')::integer, 0),
      COALESCE((p_payload->>'trainees')::integer, 0),
      p_user_id,
      COALESCE((p_payload->>'loggedAt')::timestamptz, now())
    )
    RETURNING id INTO v_id;
    RETURN jsonb_build_object('id', v_id);
  END IF;

  IF p_type = 'handover_send' THEN
    v_challan := 'CH-' || to_char(now(), 'YYYY') || '-' || upper(substr(md5(random()::text), 1, 5));
    INSERT INTO public.handover_slips (
      factory_id, order_id, colorway_id, from_department_id, to_department_id,
      sent_qty, received_qty, sent_by, sent_at, notes, status, challan_number
    ) VALUES (
      p_factory_id,
      (p_payload->>'orderId')::uuid,
      NULLIF(p_payload->>'colorwayId', '')::uuid,
      (p_payload->>'fromDepartmentId')::uuid,
      (p_payload->>'toDepartmentId')::uuid,
      (p_payload->>'sentQty')::integer,
      NULL,
      p_user_id,
      COALESCE((p_payload->>'sentAt')::timestamptz, now()),
      NULLIF(p_payload->>'notes', ''),
      'pending',
      v_challan
    )
    RETURNING id INTO v_id;
    RETURN jsonb_build_object('id', v_id, 'challanNumber', v_challan);
  END IF;

  IF p_type = 'handover_receive' THEN
    UPDATE public.handover_slips
    SET received_qty = (p_payload->>'receivedQty')::integer,
        received_by = p_user_id,
        received_at = now(),
        status = 'received'
    WHERE id = (p_payload->>'slipId')::uuid
      AND factory_id = p_factory_id;
    RETURN jsonb_build_object('ok', true);
  END IF;

  IF p_type = 'attendance_upsert' THEN
    SELECT id INTO v_existing
    FROM public.attendance_records
    WHERE worker_id = (p_payload->>'workerId')::uuid
      AND record_date = (p_payload->>'recordDate')::date
      AND shift_id IS NOT DISTINCT FROM NULLIF(p_payload->>'shiftId', '')::uuid
    LIMIT 1;

    IF v_existing IS NOT NULL THEN
      UPDATE public.attendance_records
      SET status = replace(p_payload->>'status', 'half-day', 'half_day'),
          logged_by = p_user_id,
          logged_at = now()
      WHERE id = v_existing;
      RETURN jsonb_build_object('id', v_existing);
    END IF;

    INSERT INTO public.attendance_records (
      factory_id, worker_id, department_id, shift_id, record_date, status, logged_by, logged_at
    ) VALUES (
      p_factory_id,
      (p_payload->>'workerId')::uuid,
      (p_payload->>'departmentId')::uuid,
      NULLIF(p_payload->>'shiftId', '')::uuid,
      (p_payload->>'recordDate')::date,
      replace(p_payload->>'status', 'half-day', 'half_day'),
      p_user_id,
      now()
    )
    RETURNING id INTO v_id;
    RETURN jsonb_build_object('id', v_id);
  END IF;

  IF p_type = 'audit_session' THEN
    INSERT INTO public.audit_sessions (
      factory_id, order_id, department_id, lot_size, sample_size, aql_level,
      passed, failed, result, logged_by, logged_at
    ) VALUES (
      p_factory_id,
      (p_payload->>'orderId')::uuid,
      (p_payload->>'departmentId')::uuid,
      COALESCE((p_payload->>'lotSize')::integer, 0),
      COALESCE((p_payload->>'sampleSize')::integer, 0),
      NULLIF(p_payload->>'aqlLevel', ''),
      COALESCE((p_payload->>'passed')::integer, 0),
      COALESCE((p_payload->>'failed')::integer, 0),
      NULLIF(p_payload->>'result', ''),
      p_user_id,
      COALESCE((p_payload->>'loggedAt')::timestamptz, now())
    )
    RETURNING id INTO v_id;
    RETURN jsonb_build_object('id', v_id);
  END IF;

  IF p_type = 'rejection_log' THEN
    IF NOT public.profile_dept_has_app(p_user_id, p_factory_id, 'final_rejection_log') THEN
      RETURN jsonb_build_object(
        'error', 'Department not authorized for rejection log',
        'code', 'APP_NOT_ALLOWED'
      );
    END IF;

    IF NOT EXISTS (
      SELECT 1 FROM public.style_orders
      WHERE id = (p_payload->>'orderId')::uuid AND factory_id = p_factory_id
    ) THEN
      RETURN jsonb_build_object('error', 'Order not found in factory', 'code', 'ORDER_NOT_FOUND');
    END IF;

    IF COALESCE((p_payload->>'qty')::integer, 0) <= 0 THEN
      RETURN jsonb_build_object('error', 'qty must be a positive integer', 'code', 'INVALID_QTY');
    END IF;

    IF p_payload->>'stage' IS NULL OR p_payload->>'stage' NOT IN (
      'inline', 'end_line', 'final_audit', 'pre_pack', 'post_pack', 'customer_return'
    ) THEN
      RETURN jsonb_build_object('error', 'Invalid rejection stage', 'code', 'INVALID_STAGE');
    END IF;

    INSERT INTO public.rejections (
      factory_id, order_id, colorway_id, size, qty, reason_code, reason_detail,
      stage, rejected_date, notes, logged_by, logged_at
    ) VALUES (
      p_factory_id,
      (p_payload->>'orderId')::uuid,
      NULLIF(p_payload->>'colorwayId', '')::uuid,
      NULLIF(p_payload->>'size', ''),
      (p_payload->>'qty')::integer,
      COALESCE(NULLIF(p_payload->>'reasonCode', ''), 'Other'),
      NULLIF(p_payload->>'reasonDetail', ''),
      p_payload->>'stage',
      COALESCE((p_payload->>'rejectedDate')::date, CURRENT_DATE),
      NULLIF(p_payload->>'notes', ''),
      p_user_id,
      COALESCE((p_payload->>'loggedAt')::timestamptz, now())
    )
    RETURNING id INTO v_id;

    RETURN jsonb_build_object('id', v_id);
  END IF;

  IF p_type = 'shipment_log' THEN
    IF NOT public.profile_dept_has_app(p_user_id, p_factory_id, 'shipment_log') THEN
      RETURN jsonb_build_object(
        'error', 'Department not authorized for shipment log',
        'code', 'APP_NOT_ALLOWED'
      );
    END IF;

    IF NOT EXISTS (
      SELECT 1 FROM public.style_orders
      WHERE id = (p_payload->>'orderId')::uuid AND factory_id = p_factory_id
    ) THEN
      RETURN jsonb_build_object('error', 'Order not found in factory', 'code', 'ORDER_NOT_FOUND');
    END IF;

    IF COALESCE((p_payload->>'shippedQty')::integer, 0) <= 0 THEN
      RETURN jsonb_build_object('error', 'shippedQty must be a positive integer', 'code', 'INVALID_QTY');
    END IF;

    IF p_payload->>'shipmentType' IS NULL OR p_payload->>'shipmentType' NOT IN (
      'main', 'partial', 'replacement', 'sample', 'rejection_return'
    ) THEN
      RETURN jsonb_build_object('error', 'Invalid shipment type', 'code', 'INVALID_SHIPMENT_TYPE');
    END IF;

    SELECT po_number INTO v_po
    FROM public.style_orders
    WHERE id = (p_payload->>'orderId')::uuid AND factory_id = p_factory_id;

    INSERT INTO public.shipments (
      factory_id, order_id, colorway_id, po_number, shipped_qty, shipment_date,
      invoice_number, awb_number, destination, shipment_type, notes, logged_by, logged_at
    ) VALUES (
      p_factory_id,
      (p_payload->>'orderId')::uuid,
      NULLIF(p_payload->>'colorwayId', '')::uuid,
      v_po,
      (p_payload->>'shippedQty')::integer,
      COALESCE((p_payload->>'shipmentDate')::date, CURRENT_DATE),
      NULLIF(p_payload->>'invoiceNumber', ''),
      NULLIF(p_payload->>'awbNumber', ''),
      NULLIF(p_payload->>'destination', ''),
      p_payload->>'shipmentType',
      NULLIF(p_payload->>'notes', ''),
      p_user_id,
      COALESCE((p_payload->>'loggedAt')::timestamptz, now())
    )
    RETURNING id INTO v_id;

    RETURN jsonb_build_object('id', v_id);
  END IF;

  RETURN jsonb_build_object('error', 'Unknown capture type', 'code', 'UNKNOWN_CAPTURE_TYPE');
END;
$$;

REVOKE ALL ON FUNCTION public.floor_capture(uuid, uuid, text, jsonb) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.floor_capture(uuid, uuid, text, jsonb) TO anon, authenticated;
