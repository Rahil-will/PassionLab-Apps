-- Phase 9a: Revoke anon EXECUTE on MES reporting RPCs (defense-in-depth).
-- floor_capture intentionally retains anon — floor login uses anon before JWT session.

REVOKE EXECUTE ON FUNCTION public.get_factory_kpis(uuid, date, date) FROM anon;
REVOKE EXECUTE ON FUNCTION public.get_department_kpis(uuid, uuid, date, date) FROM anon;
REVOKE EXECUTE ON FUNCTION public.get_department_kpis_by_shift(uuid, uuid, date, date) FROM anon;
REVOKE EXECUTE ON FUNCTION public.get_style_kpis(uuid, uuid) FROM anon;
REVOKE EXECUTE ON FUNCTION public.get_order_wip(uuid, uuid) FROM anon;
REVOKE EXECUTE ON FUNCTION public.get_audit_report(uuid, date, date) FROM anon;
REVOKE EXECUTE ON FUNCTION public.get_cut_to_ship_report(uuid, date, date, uuid, boolean) FROM anon;
REVOKE EXECUTE ON FUNCTION public.get_cut_to_ship_detail(uuid, uuid) FROM anon;
REVOKE EXECUTE ON FUNCTION public.get_live_dept_kpi(uuid, uuid) FROM anon;
REVOKE EXECUTE ON FUNCTION public.get_today_rejections_for_order(uuid, uuid, date) FROM anon;
REVOKE EXECUTE ON FUNCTION public.get_dept_quality_for_date(uuid, uuid, date) FROM anon;

-- Re-affirm authenticated access (idempotent)
GRANT EXECUTE ON FUNCTION public.get_factory_kpis(uuid, date, date) TO authenticated;
GRANT EXECUTE ON FUNCTION public.get_department_kpis(uuid, uuid, date, date) TO authenticated;
GRANT EXECUTE ON FUNCTION public.get_department_kpis_by_shift(uuid, uuid, date, date) TO authenticated;
GRANT EXECUTE ON FUNCTION public.get_style_kpis(uuid, uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.get_order_wip(uuid, uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.get_audit_report(uuid, date, date) TO authenticated;
GRANT EXECUTE ON FUNCTION public.get_cut_to_ship_report(uuid, date, date, uuid, boolean) TO authenticated;
GRANT EXECUTE ON FUNCTION public.get_cut_to_ship_detail(uuid, uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.get_live_dept_kpi(uuid, uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.get_today_rejections_for_order(uuid, uuid, date) TO authenticated;
GRANT EXECUTE ON FUNCTION public.get_dept_quality_for_date(uuid, uuid, date) TO authenticated;
