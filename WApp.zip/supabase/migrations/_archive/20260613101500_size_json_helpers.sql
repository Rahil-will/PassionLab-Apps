-- Phase 9.5: JSONB size-map helpers for floor_capture and reporting.

CREATE OR REPLACE FUNCTION public.jsonb_sum_int_values(p_obj jsonb)
RETURNS integer
LANGUAGE sql
IMMUTABLE
AS $$
  SELECT COALESCE(SUM((value)::integer), 0)
  FROM jsonb_each_text(COALESCE(p_obj, '{}'::jsonb));
$$;

COMMENT ON FUNCTION public.jsonb_sum_int_values(jsonb) IS
  'Sum integer values in a JSONB object like {"S":10,"M":20}.';

CREATE OR REPLACE FUNCTION public.colorway_planned_by_size(p_colorway_id uuid)
RETURNS jsonb
LANGUAGE sql
STABLE
SET search_path = public
AS $$
  SELECT COALESCE(
    (
      SELECT jsonb_object_agg(
        elem->>'size',
        COALESCE(
          NULLIF(elem->>'plannedQty', '')::integer,
          NULLIF(elem->>'adj_qty', '')::integer,
          NULLIF(elem->>'qty', '')::integer,
          0
        )
      )
      FROM public.colorways cw
      CROSS JOIN LATERAL jsonb_array_elements(COALESCE(cw.sizes, '[]'::jsonb)) AS elem
      WHERE cw.id = p_colorway_id
    ),
    '{}'::jsonb
  );
$$;

COMMENT ON FUNCTION public.colorway_planned_by_size(uuid) IS
  'Extract planned qty per size from colorways.sizes JSONB array.';

CREATE OR REPLACE FUNCTION public.proportional_qty_by_size(p_total integer, p_planned jsonb)
RETURNS jsonb
LANGUAGE plpgsql
IMMUTABLE
AS $$
DECLARE
  v_plan_total integer;
  v_result jsonb := '{}'::jsonb;
  v_key text;
  v_val integer;
  v_allocated integer := 0;
  v_last_key text;
  v_share integer;
BEGIN
  IF p_total IS NULL OR p_total <= 0 OR COALESCE(p_planned, '{}'::jsonb) = '{}'::jsonb THEN
    RETURN '{}'::jsonb;
  END IF;
  v_plan_total := public.jsonb_sum_int_values(p_planned);
  IF v_plan_total <= 0 THEN
    RETURN '{}'::jsonb;
  END IF;
  FOR v_key, v_val IN SELECT key, value::integer FROM jsonb_each_text(p_planned) LOOP
    v_last_key := v_key;
    v_share := ROUND(p_total::numeric * v_val / v_plan_total)::integer;
    v_result := v_result || jsonb_build_object(v_key, v_share);
    v_allocated := v_allocated + v_share;
  END LOOP;
  IF v_last_key IS NOT NULL AND v_allocated <> p_total THEN
    v_result := jsonb_set(
      v_result,
      ARRAY[v_last_key],
      to_jsonb(GREATEST(0, COALESCE((v_result->>v_last_key)::integer, 0) + (p_total - v_allocated)))
    );
  END IF;
  RETURN v_result;
END;
$$;

COMMENT ON FUNCTION public.proportional_qty_by_size(integer, jsonb) IS
  'Split p_total across size keys proportionally to planned qty map. Used for Cutting hourly until per-size capture exists.';

CREATE OR REPLACE FUNCTION public.jsonb_merge_sum_maps(p_maps jsonb[])
RETURNS jsonb
LANGUAGE sql
IMMUTABLE
AS $$
  SELECT COALESCE(
    (
      SELECT jsonb_object_agg(key, sum_val)
      FROM (
        SELECT key, SUM(value::integer) AS sum_val
        FROM unnest(COALESCE(p_maps, ARRAY[]::jsonb[])) AS m
        CROSS JOIN LATERAL jsonb_each_text(COALESCE(m, '{}'::jsonb))
        GROUP BY key
      ) s
    ),
    '{}'::jsonb
  );
$$;

COMMENT ON FUNCTION public.jsonb_merge_sum_maps(jsonb[]) IS
  'Merge multiple size→qty JSONB maps by summing values per key.';
