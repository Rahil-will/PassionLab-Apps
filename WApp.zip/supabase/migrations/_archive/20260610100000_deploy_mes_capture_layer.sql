-- deploy_mes_capture_layer
-- Source of truth: supabase/schema.sql
-- Deploys MES floor capture tables, line_allocations MES shape, profiles floor fields, floor RPCs.

CREATE OR REPLACE FUNCTION public.set_updated_at()
RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

-- -----------------------------------------------------------------------------
-- profiles: floor login fields (required by verify_floor_login_by_email)
-- -----------------------------------------------------------------------------
ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS floor_pin text;

ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS assigned_apps jsonb NOT NULL DEFAULT '[]'::jsonb;

ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS updated_at timestamptz NOT NULL DEFAULT now();

-- -----------------------------------------------------------------------------
-- line_allocations: legacy table is empty — replace with MES shape
-- order_id = colorway id in the app
-- -----------------------------------------------------------------------------
DROP TABLE IF EXISTS public.line_allocations;

CREATE TABLE public.line_allocations (
  id                  uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  factory_id          uuid NOT NULL REFERENCES public.factories(id) ON DELETE CASCADE,
  order_id            uuid NOT NULL,
  line_id             uuid REFERENCES public.assigned_resources(id) ON DELETE SET NULL,
  department_id       uuid REFERENCES public.departments(id) ON DELETE SET NULL,
  style_name          text,
  po_number           text,
  colorway            text,
  qty                 integer NOT NULL DEFAULT 0,
  daily_target        integer NOT NULL DEFAULT 0,
  start_date          date,
  end_date            date,
  completed_is_true   boolean NOT NULL DEFAULT false,
  kpi_inputs          jsonb,
  planned_qty         integer,
  actual_qty          integer DEFAULT 0,
  efficiency          numeric(6,2),
  status              text NOT NULL DEFAULT 'planned',
  created_at          timestamptz NOT NULL DEFAULT now(),
  updated_at          timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX line_allocations_factory_order_idx
  ON public.line_allocations(factory_id, order_id);

DROP TRIGGER IF EXISTS line_allocations_set_updated_at ON public.line_allocations;
CREATE TRIGGER line_allocations_set_updated_at
  BEFORE UPDATE ON public.line_allocations
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- -----------------------------------------------------------------------------
-- Floor capture tables
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.hourly_counts (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  factory_id      uuid NOT NULL REFERENCES public.factories(id) ON DELETE CASCADE,
  order_id        uuid NOT NULL REFERENCES public.style_orders(id) ON DELETE CASCADE,
  colorway_id     uuid REFERENCES public.colorways(id) ON DELETE SET NULL,
  department_id   uuid NOT NULL REFERENCES public.departments(id) ON DELETE CASCADE,
  resource_id     uuid REFERENCES public.assigned_resources(id) ON DELETE SET NULL,
  shift_id        uuid REFERENCES public.shifts(id) ON DELETE SET NULL,
  hour_slot       text NOT NULL,
  log_date        date NOT NULL DEFAULT (CURRENT_DATE),
  count           integer NOT NULL DEFAULT 0,
  logged_by       uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  logged_at       timestamptz NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX IF NOT EXISTS hourly_counts_slot_unique
  ON public.hourly_counts (
    factory_id, order_id, department_id,
    COALESCE(colorway_id, '00000000-0000-0000-0000-000000000000'::uuid),
    hour_slot, log_date
  );

CREATE TABLE IF NOT EXISTS public.handover_slips (
  id                  uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  factory_id          uuid NOT NULL REFERENCES public.factories(id) ON DELETE CASCADE,
  order_id            uuid NOT NULL REFERENCES public.style_orders(id) ON DELETE CASCADE,
  from_department_id  uuid NOT NULL REFERENCES public.departments(id) ON DELETE CASCADE,
  to_department_id    uuid NOT NULL REFERENCES public.departments(id) ON DELETE CASCADE,
  sent_qty            integer NOT NULL DEFAULT 0,
  received_qty        integer,
  sent_by             uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  sent_at             timestamptz NOT NULL DEFAULT now(),
  received_by         uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  received_at         timestamptz,
  notes               text,
  status              text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'received')),
  challan_number      text
);

CREATE TABLE IF NOT EXISTS public.inspections (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  factory_id      uuid NOT NULL REFERENCES public.factories(id) ON DELETE CASCADE,
  order_id        uuid NOT NULL REFERENCES public.style_orders(id) ON DELETE CASCADE,
  department_id   uuid NOT NULL REFERENCES public.departments(id) ON DELETE CASCADE,
  piece_ref       text,
  result          text NOT NULL CHECK (result IN ('pass', 'fail', 'rework', 'rework_pass')),
  defects         jsonb NOT NULL DEFAULT '[]'::jsonb,
  logged_by       uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  logged_at       timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.audit_sessions (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  factory_id      uuid NOT NULL REFERENCES public.factories(id) ON DELETE CASCADE,
  order_id        uuid NOT NULL REFERENCES public.style_orders(id) ON DELETE CASCADE,
  department_id   uuid NOT NULL REFERENCES public.departments(id) ON DELETE CASCADE,
  lot_size        integer NOT NULL DEFAULT 0,
  sample_size     integer NOT NULL DEFAULT 0,
  aql_level       text,
  passed          integer NOT NULL DEFAULT 0,
  failed          integer NOT NULL DEFAULT 0,
  result          text CHECK (result IN ('pass', 'fail')),
  logged_by       uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  logged_at       timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.workforce_logs (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  factory_id      uuid NOT NULL REFERENCES public.factories(id) ON DELETE CASCADE,
  order_id        uuid REFERENCES public.style_orders(id) ON DELETE SET NULL,
  department_id   uuid NOT NULL REFERENCES public.departments(id) ON DELETE CASCADE,
  shift_id        uuid REFERENCES public.shifts(id) ON DELETE SET NULL,
  log_date        date NOT NULL DEFAULT CURRENT_DATE,
  operators       integer NOT NULL DEFAULT 0,
  helpers         integer NOT NULL DEFAULT 0,
  supervisors     integer NOT NULL DEFAULT 0,
  trainees        integer NOT NULL DEFAULT 0,
  logged_by       uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  logged_at       timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.attendance_records (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  factory_id      uuid NOT NULL REFERENCES public.factories(id) ON DELETE CASCADE,
  worker_id       uuid NOT NULL REFERENCES public.workers(id) ON DELETE CASCADE,
  department_id   uuid NOT NULL REFERENCES public.departments(id) ON DELETE CASCADE,
  shift_id        uuid REFERENCES public.shifts(id) ON DELETE SET NULL,
  record_date     date NOT NULL DEFAULT CURRENT_DATE,
  status          text NOT NULL DEFAULT 'present' CHECK (status IN ('present', 'absent', 'half_day', 'late')),
  logged_by       uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  logged_at       timestamptz NOT NULL DEFAULT now(),
  UNIQUE (worker_id, record_date, shift_id)
);

-- -----------------------------------------------------------------------------
-- RLS on capture tables (factory-scoped)
-- -----------------------------------------------------------------------------
ALTER TABLE public.hourly_counts ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.handover_slips ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.inspections ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.audit_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.workforce_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.attendance_records ENABLE ROW LEVEL SECURITY;

DO $$
DECLARE
  t text;
  tables text[] := ARRAY[
    'hourly_counts', 'handover_slips', 'inspections',
    'audit_sessions', 'workforce_logs', 'attendance_records'
  ];
BEGIN
  FOREACH t IN ARRAY tables LOOP
    EXECUTE format('DROP POLICY IF EXISTS %I ON public.%I', t || '_select', t);
    EXECUTE format('DROP POLICY IF EXISTS %I ON public.%I', t || '_insert', t);
    EXECUTE format('DROP POLICY IF EXISTS %I ON public.%I', t || '_update', t);
    EXECUTE format('DROP POLICY IF EXISTS %I ON public.%I', t || '_delete', t);
    EXECUTE format('CREATE POLICY %I ON public.%I FOR SELECT TO authenticated USING (factory_id = public.current_factory_id())', t || '_select', t);
    EXECUTE format('CREATE POLICY %I ON public.%I FOR INSERT TO authenticated WITH CHECK (factory_id = public.current_factory_id())', t || '_insert', t);
    EXECUTE format('CREATE POLICY %I ON public.%I FOR UPDATE TO authenticated USING (factory_id = public.current_factory_id()) WITH CHECK (factory_id = public.current_factory_id())', t || '_update', t);
    EXECUTE format('CREATE POLICY %I ON public.%I FOR DELETE TO authenticated USING (factory_id = public.current_factory_id())', t || '_delete', t);
  END LOOP;
END $$;

-- -----------------------------------------------------------------------------
-- floor_capture RPC (SECURITY DEFINER — plapps writes via anon + session)
-- -----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.floor_capture(
  p_factory_id uuid,
  p_user_id uuid,
  p_type text,
  p_payload jsonb
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_id uuid;
  v_existing uuid;
  v_challan text;
BEGIN
  IF p_factory_id IS NULL OR p_user_id IS NULL THEN
    RETURN jsonb_build_object('error', 'Invalid session');
  END IF;

  IF p_type = 'hourly_upsert' THEN
    SELECT id INTO v_existing
    FROM public.hourly_counts
    WHERE factory_id = p_factory_id
      AND order_id = (p_payload->>'orderId')::uuid
      AND department_id = (p_payload->>'departmentId')::uuid
      AND hour_slot = p_payload->>'hourSlot'
      AND log_date = COALESCE((p_payload->>'logDate')::date, CURRENT_DATE)
    LIMIT 1;

    IF v_existing IS NOT NULL THEN
      UPDATE public.hourly_counts
      SET count = (p_payload->>'count')::integer,
          logged_at = COALESCE((p_payload->>'loggedAt')::timestamptz, now()),
          shift_id = NULLIF(p_payload->>'shiftId', '')::uuid,
          resource_id = NULLIF(p_payload->>'resourceId', '')::uuid,
          logged_by = p_user_id
      WHERE id = v_existing;
      RETURN jsonb_build_object('id', v_existing);
    END IF;

    INSERT INTO public.hourly_counts (
      factory_id, order_id, colorway_id, department_id, resource_id, shift_id,
      hour_slot, log_date, count, logged_by, logged_at
    ) VALUES (
      p_factory_id,
      (p_payload->>'orderId')::uuid,
      NULLIF(p_payload->>'colorwayId', '')::uuid,
      (p_payload->>'departmentId')::uuid,
      NULLIF(p_payload->>'resourceId', '')::uuid,
      NULLIF(p_payload->>'shiftId', '')::uuid,
      p_payload->>'hourSlot',
      COALESCE((p_payload->>'logDate')::date, CURRENT_DATE),
      (p_payload->>'count')::integer,
      p_user_id,
      COALESCE((p_payload->>'loggedAt')::timestamptz, now())
    )
    RETURNING id INTO v_id;

    RETURN jsonb_build_object('id', v_id);
  END IF;

  IF p_type = 'inspection' THEN
    INSERT INTO public.inspections (
      factory_id, order_id, department_id, piece_ref, result, defects, logged_by, logged_at
    ) VALUES (
      p_factory_id,
      (p_payload->>'orderId')::uuid,
      (p_payload->>'departmentId')::uuid,
      NULLIF(p_payload->>'pieceRef', ''),
      p_payload->>'result',
      COALESCE(p_payload->'defects', '[]'::jsonb),
      p_user_id,
      COALESCE((p_payload->>'loggedAt')::timestamptz, now())
    )
    RETURNING id INTO v_id;
    RETURN jsonb_build_object('id', v_id);
  END IF;

  IF p_type = 'workforce_upsert' THEN
    SELECT id INTO v_existing
    FROM public.workforce_logs
    WHERE factory_id = p_factory_id
      AND department_id = (p_payload->>'departmentId')::uuid
      AND log_date = (p_payload->>'logDate')::date
      AND shift_id IS NOT DISTINCT FROM NULLIF(p_payload->>'shiftId', '')::uuid
    LIMIT 1;

    IF v_existing IS NOT NULL THEN
      UPDATE public.workforce_logs SET
        order_id = NULLIF(p_payload->>'orderId', '')::uuid,
        operators = COALESCE((p_payload->>'operators')::integer, 0),
        helpers = COALESCE((p_payload->>'helpers')::integer, 0),
        supervisors = COALESCE((p_payload->>'supervisors')::integer, 0),
        trainees = COALESCE((p_payload->>'trainees')::integer, 0),
        logged_by = p_user_id,
        logged_at = COALESCE((p_payload->>'loggedAt')::timestamptz, now())
      WHERE id = v_existing;
      RETURN jsonb_build_object('id', v_existing);
    END IF;

    INSERT INTO public.workforce_logs (
      factory_id, order_id, department_id, shift_id, log_date,
      operators, helpers, supervisors, trainees, logged_by, logged_at
    ) VALUES (
      p_factory_id,
      NULLIF(p_payload->>'orderId', '')::uuid,
      (p_payload->>'departmentId')::uuid,
      NULLIF(p_payload->>'shiftId', '')::uuid,
      (p_payload->>'logDate')::date,
      COALESCE((p_payload->>'operators')::integer, 0),
      COALESCE((p_payload->>'helpers')::integer, 0),
      COALESCE((p_payload->>'supervisors')::integer, 0),
      COALESCE((p_payload->>'trainees')::integer, 0),
      p_user_id,
      COALESCE((p_payload->>'loggedAt')::timestamptz, now())
    )
    RETURNING id INTO v_id;
    RETURN jsonb_build_object('id', v_id);
  END IF;

  IF p_type = 'handover_send' THEN
    v_challan := 'CH-' || to_char(now(), 'YYYY') || '-' || upper(substr(md5(random()::text), 1, 5));
    INSERT INTO public.handover_slips (
      factory_id, order_id, from_department_id, to_department_id,
      sent_qty, received_qty, sent_by, sent_at, notes, status, challan_number
    ) VALUES (
      p_factory_id,
      (p_payload->>'orderId')::uuid,
      (p_payload->>'fromDepartmentId')::uuid,
      (p_payload->>'toDepartmentId')::uuid,
      (p_payload->>'sentQty')::integer,
      NULL,
      p_user_id,
      COALESCE((p_payload->>'sentAt')::timestamptz, now()),
      NULLIF(p_payload->>'notes', ''),
      'pending',
      v_challan
    )
    RETURNING id INTO v_id;
    RETURN jsonb_build_object('id', v_id, 'challanNumber', v_challan);
  END IF;

  IF p_type = 'handover_receive' THEN
    UPDATE public.handover_slips
    SET received_qty = (p_payload->>'receivedQty')::integer,
        received_by = p_user_id,
        received_at = now(),
        status = 'received'
    WHERE id = (p_payload->>'slipId')::uuid
      AND factory_id = p_factory_id;
    RETURN jsonb_build_object('ok', true);
  END IF;

  IF p_type = 'attendance_upsert' THEN
    SELECT id INTO v_existing
    FROM public.attendance_records
    WHERE worker_id = (p_payload->>'workerId')::uuid
      AND record_date = (p_payload->>'recordDate')::date
      AND shift_id IS NOT DISTINCT FROM NULLIF(p_payload->>'shiftId', '')::uuid
    LIMIT 1;

    IF v_existing IS NOT NULL THEN
      UPDATE public.attendance_records
      SET status = replace(p_payload->>'status', 'half-day', 'half_day'),
          logged_by = p_user_id,
          logged_at = now()
      WHERE id = v_existing;
      RETURN jsonb_build_object('id', v_existing);
    END IF;

    INSERT INTO public.attendance_records (
      factory_id, worker_id, department_id, shift_id, record_date, status, logged_by, logged_at
    ) VALUES (
      p_factory_id,
      (p_payload->>'workerId')::uuid,
      (p_payload->>'departmentId')::uuid,
      NULLIF(p_payload->>'shiftId', '')::uuid,
      (p_payload->>'recordDate')::date,
      replace(p_payload->>'status', 'half-day', 'half_day'),
      p_user_id,
      now()
    )
    RETURNING id INTO v_id;
    RETURN jsonb_build_object('id', v_id);
  END IF;

  IF p_type = 'audit_session' THEN
    INSERT INTO public.audit_sessions (
      factory_id, order_id, department_id, lot_size, sample_size, aql_level,
      passed, failed, result, logged_by, logged_at
    ) VALUES (
      p_factory_id,
      (p_payload->>'orderId')::uuid,
      (p_payload->>'departmentId')::uuid,
      COALESCE((p_payload->>'lotSize')::integer, 0),
      COALESCE((p_payload->>'sampleSize')::integer, 0),
      NULLIF(p_payload->>'aqlLevel', ''),
      COALESCE((p_payload->>'passed')::integer, 0),
      COALESCE((p_payload->>'failed')::integer, 0),
      NULLIF(p_payload->>'result', ''),
      p_user_id,
      COALESCE((p_payload->>'loggedAt')::timestamptz, now())
    )
    RETURNING id INTO v_id;
    RETURN jsonb_build_object('id', v_id);
  END IF;

  RETURN jsonb_build_object('error', 'Unknown capture type');
END;
$$;

REVOKE ALL ON FUNCTION public.floor_capture(uuid, uuid, text, jsonb) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.floor_capture(uuid, uuid, text, jsonb) TO anon, authenticated;

-- -----------------------------------------------------------------------------
-- Floor login RPCs
-- -----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.get_floor_users(p_factory_code text)
RETURNS TABLE (
  id uuid,
  full_name text,
  user_role text,
  department_id uuid,
  assigned_apps jsonb,
  employee_id text
)
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT p.id, p.full_name, p.user_role, p.department_id, p.assigned_apps, p.employee_id
  FROM public.profiles p
  JOIN public.factories f ON f.id = p.factory_id
  WHERE lower(f.code) = lower(trim(p_factory_code))
    AND p.status = 'Active'
    AND p.user_role IN ('operator', 'supervisor', 'auditor', 'quality_manager')
  ORDER BY p.full_name;
$$;

CREATE OR REPLACE FUNCTION public.verify_floor_pin(p_user_id uuid, p_pin text)
RETURNS jsonb
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_profile public.profiles%ROWTYPE;
BEGIN
  SELECT * INTO v_profile FROM public.profiles WHERE id = p_user_id AND status = 'Active';
  IF NOT FOUND OR v_profile.floor_pin IS NULL OR v_profile.floor_pin <> p_pin THEN
    RETURN NULL;
  END IF;
  RETURN jsonb_build_object(
    'id', v_profile.id,
    'full_name', v_profile.full_name,
    'user_role', v_profile.user_role,
    'department_id', v_profile.department_id,
    'assigned_apps', v_profile.assigned_apps,
    'factory_id', v_profile.factory_id,
    'employee_id', v_profile.employee_id
  );
END;
$$;

CREATE OR REPLACE FUNCTION public.verify_floor_login(
  p_factory_code text,
  p_employee_id text,
  p_pin text
)
RETURNS jsonb
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_profile public.profiles%ROWTYPE;
BEGIN
  SELECT p.* INTO v_profile
  FROM public.profiles p
  JOIN public.factories f ON f.id = p.factory_id
  WHERE lower(f.code) = lower(trim(p_factory_code))
    AND lower(trim(p.employee_id)) = lower(trim(p_employee_id))
    AND p.status = 'Active'
    AND p.user_role IN ('operator', 'supervisor', 'auditor', 'quality_manager')
  LIMIT 1;

  IF NOT FOUND OR v_profile.floor_pin IS NULL OR v_profile.floor_pin <> trim(p_pin) THEN
    RETURN NULL;
  END IF;

  RETURN jsonb_build_object(
    'id', v_profile.id,
    'full_name', v_profile.full_name,
    'user_role', v_profile.user_role,
    'department_id', v_profile.department_id,
    'assigned_apps', v_profile.assigned_apps,
    'factory_id', v_profile.factory_id,
    'employee_id', v_profile.employee_id
  );
END;
$$;

CREATE OR REPLACE FUNCTION public.verify_floor_login_by_email(
  p_email text,
  p_pin text
)
RETURNS jsonb
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_profile public.profiles%ROWTYPE;
BEGIN
  SELECT p.* INTO v_profile
  FROM public.profiles p
  WHERE lower(trim(p.email)) = lower(trim(p_email))
    AND p.status = 'Active'
    AND p.user_role IN ('operator', 'supervisor', 'auditor', 'quality_manager')
  LIMIT 1;

  IF NOT FOUND OR v_profile.floor_pin IS NULL OR v_profile.floor_pin <> trim(p_pin) THEN
    RETURN NULL;
  END IF;

  RETURN jsonb_build_object(
    'id', v_profile.id,
    'full_name', v_profile.full_name,
    'email', v_profile.email,
    'user_role', v_profile.user_role,
    'department_id', v_profile.department_id,
    'assigned_apps', v_profile.assigned_apps,
    'factory_id', v_profile.factory_id,
    'employee_id', v_profile.employee_id
  );
END;
$$;

REVOKE ALL ON FUNCTION public.get_floor_users(text) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.verify_floor_pin(uuid, text) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.verify_floor_login(text, text, text) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.verify_floor_login_by_email(text, text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.get_floor_users(text) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.verify_floor_pin(uuid, text) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.verify_floor_login(text, text, text) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.verify_floor_login_by_email(text, text) TO anon, authenticated;
