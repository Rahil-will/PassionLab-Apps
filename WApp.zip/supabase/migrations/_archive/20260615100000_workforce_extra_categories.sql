-- Support more than 4 workforce categories per department.
-- First 4 map to legacy columns; additional categories stored in headcount_by_category JSONB.

ALTER TABLE public.workforce_logs
  ADD COLUMN IF NOT EXISTS headcount_by_category jsonb NOT NULL DEFAULT '{}'::jsonb;

COMMENT ON COLUMN public.workforce_logs.headcount_by_category IS
  'Headcount for workforce categories beyond the first four (label -> count).';

COMMENT ON COLUMN public.departments.worker_roles IS
  'Display labels for workforce_log headcount categories. First four map to operators/helpers/supervisors/trainees; extras use headcount_by_category.';

CREATE OR REPLACE FUNCTION public.workforce_log_total_headcount(
  p_operators integer,
  p_helpers integer,
  p_supervisors integer,
  p_trainees integer,
  p_extra jsonb DEFAULT '{}'::jsonb
)
RETURNS integer
LANGUAGE sql
IMMUTABLE
AS $$
  SELECT (
    COALESCE(p_operators, 0)
    + COALESCE(p_helpers, 0)
    + COALESCE(p_supervisors, 0)
    + COALESCE(p_trainees, 0)
    + COALESCE((
      SELECT SUM((value)::text::integer)
      FROM jsonb_each(COALESCE(p_extra, '{}'::jsonb))
      WHERE jsonb_typeof(value) = 'number'
    ), 0)
  )::integer;
$$;

CREATE OR REPLACE VIEW public.v_daily_workforce AS
SELECT
  wl.factory_id,
  wl.department_id,
  wl.log_date,
  wl.shift_id,
  sm.shift_name,
  sm.productive_mins,
  public.workforce_log_total_headcount(
    wl.operators,
    wl.helpers,
    wl.supervisors,
    wl.trainees,
    wl.headcount_by_category
  ) AS headcount,
  (
    public.workforce_log_total_headcount(
      wl.operators,
      wl.helpers,
      wl.supervisors,
      wl.trainees,
      wl.headcount_by_category
    ) * sm.productive_mins
  )::numeric AS available_mins
FROM public.workforce_logs wl
JOIN public.v_shift_minutes sm ON sm.shift_id = wl.shift_id;

COMMENT ON VIEW public.v_daily_workforce IS
  'One row per factory/department/log_date/shift_id. Headcount from workforce_logs (legacy four columns + headcount_by_category); available_mins = headcount * productive_mins.';

-- Patch floor_capture workforce_upsert + OT workforce check for extra categories.
DO $$
DECLARE
  def text;
BEGIN
  def := pg_get_functiondef('public.floor_capture(uuid,uuid,text,jsonb)'::regprocedure);

  def := replace(def,
    'AND (wl.operators + wl.helpers + wl.supervisors + wl.trainees) > 0',
    'AND public.workforce_log_total_headcount(wl.operators, wl.helpers, wl.supervisors, wl.trainees, wl.headcount_by_category) > 0'
  );

  def := replace(def,
    E'    IF COALESCE((p_payload->>''operators'')::integer, 0)\n       + COALESCE((p_payload->>''helpers'')::integer, 0)\n       + COALESCE((p_payload->>''supervisors'')::integer, 0)\n       + COALESCE((p_payload->>''trainees'')::integer, 0) <= 0 THEN\n      RETURN public.floor_capture_fail(''At least one headcount field must be > 0'', ''EMPTY_HEADCOUNT'');\n    END IF;',
    E'    IF public.workforce_log_total_headcount(\n      COALESCE((p_payload->>''operators'')::integer, 0),\n      COALESCE((p_payload->>''helpers'')::integer, 0),\n      COALESCE((p_payload->>''supervisors'')::integer, 0),\n      COALESCE((p_payload->>''trainees'')::integer, 0),\n      COALESCE(p_payload->''headcountByCategory'', ''{}''::jsonb)\n    ) <= 0 THEN\n      RETURN public.floor_capture_fail(''At least one headcount field must be > 0'', ''EMPTY_HEADCOUNT'');\n    END IF;'
  );

  def := replace(def,
    E'        trainees = COALESCE((p_payload->>''trainees'')::integer, 0),\n        logged_by = p_user_id,',
    E'        trainees = COALESCE((p_payload->>''trainees'')::integer, 0),\n        headcount_by_category = COALESCE(p_payload->''headcountByCategory'', ''{}''::jsonb),\n        logged_by = p_user_id,'
  );

  def := replace(def,
    'operators, helpers, supervisors, trainees, logged_by, logged_at',
    'operators, helpers, supervisors, trainees, headcount_by_category, logged_by, logged_at'
  );

  def := replace(def,
    E'      COALESCE((p_payload->>''trainees'')::integer, 0),\n      p_user_id,\n      COALESCE((p_payload->>''loggedAt'')::timestamptz, now())\n    )\n    RETURNING id INTO v_id;\n    RETURN jsonb_build_object(''id'', v_id);\n  END IF;\n\n  IF p_type = ''handover_send'' THEN',
    E'      COALESCE((p_payload->>''trainees'')::integer, 0),\n      COALESCE(p_payload->''headcountByCategory'', ''{}''::jsonb),\n      p_user_id,\n      COALESCE((p_payload->>''loggedAt'')::timestamptz, now())\n    )\n    RETURNING id INTO v_id;\n    RETURN jsonb_build_object(''id'', v_id);\n  END IF;\n\n  IF p_type = ''handover_send'' THEN'
  );

  EXECUTE def;
END $$;
