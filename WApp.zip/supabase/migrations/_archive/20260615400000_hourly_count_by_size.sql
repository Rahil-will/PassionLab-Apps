-- Hourly output: size-wise counts in hourly_counts.count_by_size (JSONB). Total count = sum of sizes.

ALTER TABLE public.hourly_counts
  ADD COLUMN IF NOT EXISTS count_by_size jsonb NOT NULL DEFAULT '{}'::jsonb;

COMMENT ON COLUMN public.hourly_counts.count_by_size IS
  'Hourly output by size label. count column stores the total (sum of values).';

DO $$
DECLARE
  def text;
BEGIN
  def := pg_get_functiondef('public.floor_capture(uuid,uuid,text,jsonb)'::regprocedure);

  def := replace(def,
    E'    BEGIN\n      v_count := (p_payload->>''count'')::integer;\n    EXCEPTION WHEN OTHERS THEN\n      RETURN public.floor_capture_fail(''count must be an integer'', ''INVALID_COUNT'');\n    END;\n\n    IF v_count IS NULL OR v_count < 0 THEN\n      RETURN public.floor_capture_fail(''count must be a non-negative integer'', ''INVALID_COUNT'');\n    END IF;',
    E'    IF COALESCE(p_payload->''countBySize'', ''{}''::jsonb) <> ''{}''::jsonb THEN\n      v_count := public.jsonb_sum_int_values(p_payload->''countBySize'');\n    ELSE\n      BEGIN\n        v_count := (p_payload->>''count'')::integer;\n      EXCEPTION WHEN OTHERS THEN\n        RETURN public.floor_capture_fail(''count must be an integer'', ''INVALID_COUNT'');\n      END;\n    END IF;\n\n    IF v_count IS NULL OR v_count < 0 THEN\n      RETURN public.floor_capture_fail(''count must be a non-negative integer'', ''INVALID_COUNT'');\n    END IF;'
  );

  def := replace(def,
    E'      UPDATE public.hourly_counts\n      SET count = v_count,\n          logged_at = COALESCE((p_payload->>''loggedAt'')::timestamptz, now()),\n          shift_id = NULLIF(p_payload->>''shiftId'', '''')::uuid,\n          resource_id = NULLIF(p_payload->>''resourceId'', '''')::uuid,\n          logged_by = p_user_id\n      WHERE id = v_existing;',
    E'      UPDATE public.hourly_counts\n      SET count = v_count,\n          count_by_size = COALESCE(p_payload->''countBySize'', ''{}''::jsonb),\n          logged_at = COALESCE((p_payload->>''loggedAt'')::timestamptz, now()),\n          shift_id = NULLIF(p_payload->>''shiftId'', '''')::uuid,\n          resource_id = NULLIF(p_payload->>''resourceId'', '''')::uuid,\n          logged_by = p_user_id\n      WHERE id = v_existing;'
  );

  def := replace(def,
    E'    INSERT INTO public.hourly_counts (\n      factory_id, order_id, colorway_id, department_id, resource_id, shift_id,\n      hour_slot, log_date, count, logged_by, logged_at\n    ) VALUES (\n      p_factory_id,\n      (p_payload->>''orderId'')::uuid,\n      v_colorway_id,\n      v_payload_dept,\n      NULLIF(p_payload->>''resourceId'', '''')::uuid,\n      NULLIF(p_payload->>''shiftId'', '''')::uuid,\n      p_payload->>''hourSlot'',\n      v_log_date,\n      v_count,\n      p_user_id,\n      COALESCE((p_payload->>''loggedAt'')::timestamptz, now())\n    )',
    E'    INSERT INTO public.hourly_counts (\n      factory_id, order_id, colorway_id, department_id, resource_id, shift_id,\n      hour_slot, log_date, count, count_by_size, logged_by, logged_at\n    ) VALUES (\n      p_factory_id,\n      (p_payload->>''orderId'')::uuid,\n      v_colorway_id,\n      v_payload_dept,\n      NULLIF(p_payload->>''resourceId'', '''')::uuid,\n      NULLIF(p_payload->>''shiftId'', '''')::uuid,\n      p_payload->>''hourSlot'',\n      v_log_date,\n      v_count,\n      COALESCE(p_payload->''countBySize'', ''{}''::jsonb),\n      p_user_id,\n      COALESCE((p_payload->>''loggedAt'')::timestamptz, now())\n    )'
  );

  EXECUTE def;
END $$;

-- Cutting dept progress: prefer stored count_by_size from hourly_counts.
DO $$
DECLARE
  def text;
BEGIN
  def := pg_get_functiondef('public.get_order_dept_progress(uuid,uuid,uuid,uuid,date)'::regprocedure);

  def := replace(def,
    E'  IF v_is_cutting THEN\n    SELECT COALESCE(SUM(h.count), 0)::integer INTO v_hourly_total\n    FROM public.hourly_counts h\n    WHERE h.factory_id = p_factory_id\n      AND h.order_id = p_order_id\n      AND h.colorway_id IS NOT DISTINCT FROM p_colorway_id\n      AND h.department_id = p_department_id;\n    v_produced_by_size := public.proportional_qty_by_size(v_hourly_total, v_planned);',
    E'  IF v_is_cutting THEN\n    SELECT public.jsonb_merge_sum_maps(ARRAY_AGG(h.count_by_size))\n    INTO v_produced_by_size\n    FROM public.hourly_counts h\n    WHERE h.factory_id = p_factory_id\n      AND h.order_id = p_order_id\n      AND h.colorway_id IS NOT DISTINCT FROM p_colorway_id\n      AND h.department_id = p_department_id\n      AND h.count_by_size <> ''{}''::jsonb;\n    IF v_produced_by_size = ''{}''::jsonb OR v_produced_by_size IS NULL THEN\n      SELECT COALESCE(SUM(h.count), 0)::integer INTO v_hourly_total\n      FROM public.hourly_counts h\n      WHERE h.factory_id = p_factory_id\n        AND h.order_id = p_order_id\n        AND h.colorway_id IS NOT DISTINCT FROM p_colorway_id\n        AND h.department_id = p_department_id;\n      v_produced_by_size := public.proportional_qty_by_size(v_hourly_total, v_planned);\n    END IF;'
  );

  EXECUTE def;
END $$;
