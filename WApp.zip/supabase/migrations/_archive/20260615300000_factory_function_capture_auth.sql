-- Shipment + rejection capture: factory-function auth via profiles.assigned_apps (not department.apps).

CREATE OR REPLACE FUNCTION public.profile_has_capture_app(
  p_user_id uuid,
  p_factory_id uuid,
  p_app text
)
RETURNS boolean
LANGUAGE sql
STABLE
AS $$
  SELECT CASE
    WHEN p_app IN ('shipment_log', 'final_rejection_log') THEN
      EXISTS (
        SELECT 1
        FROM public.profiles p
        WHERE p.id = p_user_id
          AND p.factory_id = p_factory_id
          AND p.status = 'Active'
          AND (
            COALESCE(p.assigned_apps, '[]'::jsonb) @> jsonb_build_array(p_app)
            OR p.user_role IN ('admin', 'superadmin')
            OR (p_app = 'final_rejection_log' AND p.user_role = 'quality_manager')
          )
      )
    ELSE
      public.profile_dept_has_app(p_user_id, p_factory_id, p_app)
  END;
$$;

COMMENT ON FUNCTION public.profile_has_capture_app(uuid, uuid, text) IS
  'Capture auth: shipment_log and final_rejection_log use profiles.assigned_apps or admin/quality_manager role; other apps use department.apps.';

DO $$
DECLARE
  def text;
BEGIN
  def := pg_get_functiondef('public.floor_capture(uuid,uuid,text,jsonb)'::regprocedure);

  def := replace(def,
    'IF NOT public.profile_dept_has_app(p_user_id, p_factory_id, ''final_rejection_log'') THEN',
    'IF NOT public.profile_has_capture_app(p_user_id, p_factory_id, ''final_rejection_log'') THEN'
  );

  def := replace(def,
    'IF NOT public.profile_dept_has_app(p_user_id, p_factory_id, ''shipment_log'') THEN',
    'IF NOT public.profile_has_capture_app(p_user_id, p_factory_id, ''shipment_log'') THEN'
  );

  EXECUTE def;
END $$;
