-- Phase 9c: Size-aware v_cut_to_ship_dept_journey + real wip_qty_by_size on v_cut_to_ship.

CREATE OR REPLACE FUNCTION public.jsonb_subtract_maps_nonneg(p_a jsonb, p_b jsonb)
RETURNS jsonb
LANGUAGE sql
IMMUTABLE
AS $$
  SELECT COALESCE(
    (
      SELECT jsonb_object_agg(
        k,
        GREATEST(
          COALESCE((COALESCE(p_a, '{}'::jsonb) ->> k)::integer, 0)
          - COALESCE((COALESCE(p_b, '{}'::jsonb) ->> k)::integer, 0),
          0
        )
      )
      FROM (
        SELECT key AS k FROM jsonb_each_text(COALESCE(p_a, '{}'::jsonb))
        UNION
        SELECT key AS k FROM jsonb_each_text(COALESCE(p_b, '{}'::jsonb))
      ) keys
    ),
    '{}'::jsonb
  );
$$;

COMMENT ON FUNCTION public.jsonb_subtract_maps_nonneg(jsonb, jsonb) IS
  'Per-size GREATEST(a - b, 0). Used for dept WIP-by-size (received or produced minus sent).';

DROP VIEW IF EXISTS public.v_cut_to_ship CASCADE;
DROP VIEW IF EXISTS public.v_cut_to_ship_dept_journey CASCADE;

CREATE VIEW public.v_cut_to_ship_dept_journey AS
WITH order_colorways AS (
  SELECT so.factory_id, so.id AS order_id, so.process_flow_id, cw.id AS colorway_id
  FROM public.style_orders so
  LEFT JOIN public.colorways cw ON cw.order_id = so.id
),
dept_grid AS (
  SELECT
    oc.factory_id,
    oc.order_id,
    oc.colorway_id,
    oc.process_flow_id,
    d.id AS dept_id,
    d.name AS dept_name,
    d.is_production,
    d.apps,
    pfs.flow_step,
    (pfs.department_id IS NOT NULL) AS is_in_flow,
    (d.id = public.get_cutting_department_id(oc.factory_id)) AS is_cutting,
    (d.name ILIKE 'shipment' OR COALESCE(d.apps, '[]'::jsonb) @> '["shipment_log"]'::jsonb) AS is_shipment,
    (d.name ILIKE 'quality audit') AS is_quality_audit
  FROM order_colorways oc
  JOIN public.departments d ON d.factory_id = oc.factory_id
  LEFT JOIN public.process_flow_steps pfs
    ON pfs.flow_id = oc.process_flow_id AND pfs.department_id = d.id
),
handover_received AS (
  SELECT
    hs.factory_id, hs.order_id, hs.colorway_id, hs.to_department_id AS dept_id,
    SUM(COALESCE(NULLIF(hs.received_qty, 0), hs.sent_qty))::integer AS qty_received
  FROM public.handover_slips hs
  GROUP BY hs.factory_id, hs.order_id, hs.colorway_id, hs.to_department_id
),
handover_received_by_size AS (
  SELECT
    hs.factory_id, hs.order_id, hs.colorway_id, hs.to_department_id AS dept_id,
    public.jsonb_merge_sum_maps(ARRAY_AGG(
      CASE
        WHEN COALESCE(hs.received_qty_by_size, '{}'::jsonb) <> '{}'::jsonb THEN hs.received_qty_by_size
        WHEN COALESCE(hs.qty_by_size, '{}'::jsonb) <> '{}'::jsonb THEN hs.qty_by_size
        ELSE public.proportional_qty_by_size(
          COALESCE(NULLIF(hs.received_qty, 0), hs.sent_qty),
          public.colorway_planned_by_size(hs.colorway_id)
        )
      END
    )) AS qty_received_by_size
  FROM public.handover_slips hs
  GROUP BY hs.factory_id, hs.order_id, hs.colorway_id, hs.to_department_id
),
handover_sent AS (
  SELECT
    hs.factory_id, hs.order_id, hs.colorway_id, hs.from_department_id AS dept_id,
    SUM(hs.sent_qty)::integer AS qty_sent
  FROM public.handover_slips hs
  GROUP BY hs.factory_id, hs.order_id, hs.colorway_id, hs.from_department_id
),
handover_sent_by_size AS (
  SELECT
    hs.factory_id, hs.order_id, hs.colorway_id, hs.from_department_id AS dept_id,
    public.jsonb_merge_sum_maps(ARRAY_AGG(
      CASE
        WHEN COALESCE(hs.qty_by_size, '{}'::jsonb) <> '{}'::jsonb THEN hs.qty_by_size
        ELSE public.proportional_qty_by_size(
          hs.sent_qty,
          public.colorway_planned_by_size(hs.colorway_id)
        )
      END
    )) AS qty_sent_by_size
  FROM public.handover_slips hs
  GROUP BY hs.factory_id, hs.order_id, hs.colorway_id, hs.from_department_id
),
hourly_produced AS (
  SELECT
    h.factory_id, h.order_id, h.colorway_id, h.department_id AS dept_id,
    SUM(h.count)::integer AS qty_produced
  FROM public.hourly_counts h
  JOIN public.departments d ON d.id = h.department_id
  WHERE COALESCE(d.apps, '[]'::jsonb) @> '["hourly"]'::jsonb
  GROUP BY h.factory_id, h.order_id, h.colorway_id, h.department_id
),
hourly_produced_by_size AS (
  SELECT
    h.factory_id, h.order_id, h.colorway_id, h.department_id AS dept_id,
    public.proportional_qty_by_size(
      SUM(h.count)::integer,
      public.colorway_planned_by_size(h.colorway_id)
    ) AS qty_produced_by_size
  FROM public.hourly_counts h
  JOIN public.departments d ON d.id = h.department_id
  WHERE COALESCE(d.apps, '[]'::jsonb) @> '["hourly"]'::jsonb
  GROUP BY h.factory_id, h.order_id, h.colorway_id, h.department_id,
    public.colorway_planned_by_size(h.colorway_id)
),
qc_produced AS (
  SELECT
    i.factory_id, i.order_id, i.colorway_id, i.department_id AS dept_id,
    COUNT(*) FILTER (WHERE i.result IN ('pass', 'rework_pass'))::integer AS qty_produced
  FROM public.inspections i
  JOIN public.departments d ON d.id = i.department_id
  WHERE COALESCE(d.apps, '[]'::jsonb) @> '["qc_log"]'::jsonb
  GROUP BY i.factory_id, i.order_id, i.colorway_id, i.department_id
),
shipped AS (
  SELECT factory_id, order_id, colorway_id, SUM(shipped_qty)::integer AS qty_shipped
  FROM public.shipments
  GROUP BY factory_id, order_id, colorway_id
),
shipped_by_size AS (
  SELECT
    s.factory_id, s.order_id, s.colorway_id,
    public.jsonb_merge_sum_maps(ARRAY_AGG(
      CASE
        WHEN COALESCE(s.shipped_qty_by_size, '{}'::jsonb) <> '{}'::jsonb THEN s.shipped_qty_by_size
        ELSE public.proportional_qty_by_size(
          s.shipped_qty,
          public.colorway_planned_by_size(s.colorway_id)
        )
      END
    )) AS qty_shipped_by_size
  FROM public.shipments s
  GROUP BY s.factory_id, s.order_id, s.colorway_id
),
rejected_by_dept AS (
  SELECT
    r.factory_id, r.order_id, r.colorway_id,
    public.resolve_rejection_department_id(r.factory_id, r.order_id, r.stage) AS dept_id,
    SUM(r.qty)::integer AS qty_rejected
  FROM public.rejections r
  GROUP BY r.factory_id, r.order_id, r.colorway_id,
    public.resolve_rejection_department_id(r.factory_id, r.order_id, r.stage)
),
rejected_by_dept_size AS (
  SELECT
    x.factory_id, x.order_id, x.colorway_id,
    public.resolve_rejection_department_id(x.factory_id, x.order_id, x.stage) AS dept_id,
    jsonb_object_agg(x.size_key, x.dept_rej_qty) AS qty_rejected_by_size
  FROM (
    SELECT
      r.factory_id, r.order_id, r.colorway_id, r.stage,
      COALESCE(r.size, 'UNSPEC') AS size_key,
      SUM(r.qty)::integer AS dept_rej_qty
    FROM public.rejections r
    GROUP BY r.factory_id, r.order_id, r.colorway_id, r.stage, COALESCE(r.size, 'UNSPEC')
  ) x
  GROUP BY x.factory_id, x.order_id, x.colorway_id,
    public.resolve_rejection_department_id(x.factory_id, x.order_id, x.stage)
),
assembled AS (
  SELECT
    g.factory_id,
    g.order_id,
    g.colorway_id,
    g.dept_id,
    g.dept_name,
    g.flow_step,
    g.is_in_flow,
    g.is_cutting,
    CASE WHEN g.is_in_flow THEN
      CASE WHEN g.is_cutting THEN NULL ELSE hr.qty_received END
    END AS qty_received,
    CASE WHEN g.is_in_flow THEN
      CASE
        WHEN g.is_cutting THEN hp.qty_produced
        WHEN COALESCE(g.apps, '[]'::jsonb) @> '["hourly"]'::jsonb THEN hp.qty_produced
        WHEN COALESCE(g.apps, '[]'::jsonb) @> '["qc_log"]'::jsonb THEN qp.qty_produced
        ELSE COALESCE(hp.qty_produced, qp.qty_produced)
      END
    END AS qty_produced,
    CASE WHEN g.is_in_flow THEN
      CASE WHEN g.is_shipment THEN sh.qty_shipped ELSE hs.qty_sent END
    END AS qty_sent,
    CASE WHEN g.is_in_flow THEN rb.qty_rejected END AS qty_rejected,
    CASE WHEN g.is_in_flow THEN
      CASE WHEN g.is_cutting THEN NULL ELSE hrb.qty_received_by_size END
    END AS qty_received_by_size,
    CASE WHEN g.is_in_flow THEN
      CASE
        WHEN g.is_cutting THEN hpb.qty_produced_by_size
        WHEN COALESCE(hsb.qty_sent_by_size, '{}'::jsonb) <> '{}'::jsonb THEN hsb.qty_sent_by_size
        WHEN COALESCE(g.apps, '[]'::jsonb) @> '["hourly"]'::jsonb THEN hpb.qty_produced_by_size
        WHEN COALESCE(g.apps, '[]'::jsonb) @> '["qc_log"]'::jsonb
          AND COALESCE(qp.qty_produced, 0) > 0
          THEN public.proportional_qty_by_size(
            qp.qty_produced,
            public.colorway_planned_by_size(g.colorway_id)
          )
        ELSE hsb.qty_sent_by_size
      END
    END AS qty_produced_by_size,
    CASE WHEN g.is_in_flow THEN
      CASE WHEN g.is_shipment THEN shb.qty_shipped_by_size ELSE hsb.qty_sent_by_size END
    END AS qty_sent_by_size,
    CASE WHEN g.is_in_flow THEN rbs.qty_rejected_by_size END AS qty_rejected_by_size
  FROM dept_grid g
  LEFT JOIN handover_received hr
    ON hr.factory_id = g.factory_id AND hr.order_id = g.order_id
   AND hr.colorway_id IS NOT DISTINCT FROM g.colorway_id AND hr.dept_id = g.dept_id
  LEFT JOIN handover_received_by_size hrb
    ON hrb.factory_id = g.factory_id AND hrb.order_id = g.order_id
   AND hrb.colorway_id IS NOT DISTINCT FROM g.colorway_id AND hrb.dept_id = g.dept_id
  LEFT JOIN handover_sent hs
    ON hs.factory_id = g.factory_id AND hs.order_id = g.order_id
   AND hs.colorway_id IS NOT DISTINCT FROM g.colorway_id AND hs.dept_id = g.dept_id
  LEFT JOIN handover_sent_by_size hsb
    ON hsb.factory_id = g.factory_id AND hsb.order_id = g.order_id
   AND hsb.colorway_id IS NOT DISTINCT FROM g.colorway_id AND hsb.dept_id = g.dept_id
  LEFT JOIN hourly_produced hp
    ON hp.factory_id = g.factory_id AND hp.order_id = g.order_id
   AND hp.colorway_id IS NOT DISTINCT FROM g.colorway_id AND hp.dept_id = g.dept_id
  LEFT JOIN hourly_produced_by_size hpb
    ON hpb.factory_id = g.factory_id AND hpb.order_id = g.order_id
   AND hpb.colorway_id IS NOT DISTINCT FROM g.colorway_id AND hpb.dept_id = g.dept_id
  LEFT JOIN qc_produced qp
    ON qp.factory_id = g.factory_id AND qp.order_id = g.order_id
   AND qp.colorway_id IS NOT DISTINCT FROM g.colorway_id AND qp.dept_id = g.dept_id
  LEFT JOIN shipped sh
    ON sh.factory_id = g.factory_id AND sh.order_id = g.order_id
   AND sh.colorway_id IS NOT DISTINCT FROM g.colorway_id AND g.is_shipment
  LEFT JOIN shipped_by_size shb
    ON shb.factory_id = g.factory_id AND shb.order_id = g.order_id
   AND shb.colorway_id IS NOT DISTINCT FROM g.colorway_id AND g.is_shipment
  LEFT JOIN rejected_by_dept rb
    ON rb.factory_id = g.factory_id AND rb.order_id = g.order_id
   AND rb.colorway_id IS NOT DISTINCT FROM g.colorway_id AND rb.dept_id = g.dept_id
  LEFT JOIN rejected_by_dept_size rbs
    ON rbs.factory_id = g.factory_id AND rbs.order_id = g.order_id
   AND rbs.colorway_id IS NOT DISTINCT FROM g.colorway_id AND rbs.dept_id = g.dept_id
)
SELECT
  a.factory_id,
  a.order_id,
  a.colorway_id,
  a.dept_id,
  a.dept_name,
  a.flow_step,
  a.is_in_flow,
  a.qty_received,
  a.qty_produced,
  a.qty_sent,
  a.qty_rejected,
  CASE WHEN NOT a.is_in_flow THEN NULL
    WHEN a.qty_received IS NULL AND a.qty_produced IS NOT NULL
      THEN GREATEST(COALESCE(a.qty_produced, 0) - COALESCE(a.qty_sent, 0), 0)
    WHEN a.qty_received IS NOT NULL
      THEN GREATEST(COALESCE(a.qty_received, 0) - COALESCE(a.qty_sent, 0), 0)
    ELSE NULL
  END::integer AS wip_qty,
  CASE WHEN NOT a.is_in_flow THEN NULL
    WHEN a.is_cutting THEN public.jsonb_subtract_maps_nonneg(a.qty_produced_by_size, a.qty_sent_by_size)
    WHEN a.qty_received_by_size IS NOT NULL
      THEN public.jsonb_subtract_maps_nonneg(a.qty_received_by_size, a.qty_sent_by_size)
    WHEN a.qty_produced_by_size IS NOT NULL
      THEN public.jsonb_subtract_maps_nonneg(a.qty_produced_by_size, a.qty_sent_by_size)
    ELSE NULL
  END AS wip_qty_by_size,
  CASE WHEN NOT a.is_in_flow THEN NULL ELSE a.qty_received_by_size END AS qty_received_by_size,
  CASE WHEN NOT a.is_in_flow THEN NULL ELSE a.qty_produced_by_size END AS qty_produced_by_size,
  CASE WHEN NOT a.is_in_flow THEN NULL ELSE a.qty_sent_by_size END AS qty_sent_by_size,
  CASE WHEN NOT a.is_in_flow THEN NULL ELSE a.qty_rejected_by_size END AS qty_rejected_by_size,
  CASE
    WHEN NOT a.is_in_flow THEN 'not_in_flow'
    WHEN a.qty_received IS NULL AND COALESCE(a.qty_produced, 0) = 0 THEN 'pending'
    WHEN a.qty_received IS NULL AND COALESCE(a.qty_sent, 0) = 0 AND COALESCE(a.qty_produced, 0) > 0 THEN 'in_progress'
    WHEN a.qty_received IS NULL AND COALESCE(a.qty_sent, 0) >= COALESCE(a.qty_produced, 0)
      AND COALESCE(a.qty_sent, 0) > 0 THEN 'completed'
    WHEN COALESCE(a.qty_received, 0) = 0 THEN 'pending'
    WHEN COALESCE(a.qty_received, 0) > COALESCE(a.qty_sent, 0) THEN 'in_progress'
    WHEN COALESCE(a.qty_sent, 0) >= COALESCE(a.qty_received, 0) AND COALESCE(a.qty_sent, 0) > 0 THEN 'completed'
    ELSE 'pending'
  END AS status
FROM assembled a;

COMMENT ON VIEW public.v_cut_to_ship_dept_journey IS
  'Per order/colorway department journey with size-wise qty columns. Cutting: produced proportional from hourly; others: produced from outgoing handover qty_by_size with hourly fallback. WIP-by-size = received (or produced at Cutting) minus sent per size. Out-of-flow depts: NULL size maps, status not_in_flow.';

-- Backfill v_cut_to_ship.wip_qty_by_size from in-flow dept journey WIP maps.
CREATE VIEW public.v_cut_to_ship AS
WITH rej_by_size AS (
  SELECT factory_id, order_id, colorway_id,
    jsonb_object_agg(size, rejected_qty) AS rejected_qty_by_size
  FROM public.v_order_rejected_qty_by_size
  GROUP BY factory_id, order_id, colorway_id
),
ship_by_size AS (
  SELECT factory_id, order_id, colorway_id,
    public.jsonb_merge_sum_maps(ARRAY_AGG(shipped_qty_by_size)) AS shipped_qty_by_size
  FROM public.shipments
  WHERE shipped_qty_by_size <> '{}'::jsonb
  GROUP BY factory_id, order_id, colorway_id
),
cut_by_size AS (
  SELECT h.factory_id, h.order_id, h.colorway_id,
    public.proportional_qty_by_size(
      SUM(h.count)::integer,
      public.colorway_planned_by_size(h.colorway_id)
    ) AS cut_qty_by_size
  FROM public.hourly_counts h
  WHERE h.department_id = public.get_cutting_department_id(h.factory_id)
  GROUP BY h.factory_id, h.order_id, h.colorway_id,
    public.colorway_planned_by_size(h.colorway_id)
),
SELECT
  so.factory_id,
  so.id AS order_id,
  cw.id AS colorway_id,
  so.style_name,
  so.buyer_name,
  so.po_number,
  COALESCE(so.adj_qty, so.order_qty, 0)::integer AS order_qty,
  COALESCE(cq.cut_qty, 0)::integer AS cut_qty,
  COALESCE(cq.cut_qty_source, 'planned') AS cut_qty_source,
  COALESCE(sq.shipped_qty, 0)::integer AS shipped_qty,
  COALESCE(rq.rejected_qty, 0)::integer AS rejected_qty,
  COALESCE(wt.wip_qty, 0)::integer AS wip_qty,
  (COALESCE(cq.cut_qty, 0)
    - (COALESCE(sq.shipped_qty, 0) + COALESCE(rq.rejected_qty, 0) + COALESCE(wt.wip_qty, 0)))::integer
    AS reconciliation_gap,
  COALESCE(rq.rejected_by_reason, '{}'::jsonb) AS rejected_by_reason,
  COALESCE(rq.rejected_by_stage, '{}'::jsonb) AS rejected_by_stage,
  (COALESCE(cq.cut_qty, 0)
    = COALESCE(sq.shipped_qty, 0) + COALESCE(rq.rejected_qty, 0) + COALESCE(wt.wip_qty, 0)) AS is_balanced,
  ROUND(100.0 * COALESCE(sq.shipped_qty, 0) / NULLIF(COALESCE(so.adj_qty, so.order_qty, 0), 0), 2) AS completion_pct,
  so.status AS order_status,
  sq.last_shipment_date,
  COALESCE(cbs.cut_qty_by_size, '{}'::jsonb) AS cut_qty_by_size,
  COALESCE(sbs.shipped_qty_by_size, '{}'::jsonb) AS shipped_qty_by_size,
  COALESCE(rbs.rejected_qty_by_size, '{}'::jsonb) AS rejected_qty_by_size,
  CASE
    WHEN COALESCE(wt.wip_qty, 0) > 0 AND COALESCE(cbs.cut_qty_by_size, '{}'::jsonb) <> '{}'::jsonb THEN
      public.proportional_qty_by_size(wt.wip_qty, cbs.cut_qty_by_size)
    WHEN COALESCE(wt.wip_qty, 0) > 0 THEN
      public.proportional_qty_by_size(wt.wip_qty, public.colorway_planned_by_size(cw.id))
    ELSE '{}'::jsonb
  END AS wip_qty_by_size
FROM public.style_orders so
LEFT JOIN public.colorways cw ON cw.order_id = so.id
LEFT JOIN public.v_order_cut_qty cq
  ON cq.factory_id = so.factory_id AND cq.order_id = so.id
 AND cq.colorway_id IS NOT DISTINCT FROM cw.id
LEFT JOIN public.v_order_shipped_qty sq
  ON sq.factory_id = so.factory_id AND sq.order_id = so.id
 AND sq.colorway_id IS NOT DISTINCT FROM cw.id
LEFT JOIN public.v_order_rejected_qty rq
  ON rq.factory_id = so.factory_id AND rq.order_id = so.id
 AND rq.colorway_id IS NOT DISTINCT FROM cw.id
LEFT JOIN public.v_order_wip_total wt
  ON wt.factory_id = so.factory_id AND wt.order_id = so.id
 AND wt.colorway_id IS NOT DISTINCT FROM cw.id
LEFT JOIN cut_by_size cbs
  ON cbs.factory_id = so.factory_id AND cbs.order_id = so.id
 AND cbs.colorway_id IS NOT DISTINCT FROM cw.id
LEFT JOIN ship_by_size sbs
  ON sbs.factory_id = so.factory_id AND sbs.order_id = so.id
 AND sbs.colorway_id IS NOT DISTINCT FROM cw.id
LEFT JOIN rej_by_size rbs
  ON rbs.factory_id = so.factory_id AND rbs.order_id = so.id
 AND rbs.colorway_id IS NOT DISTINCT FROM cw.id
;

COMMENT ON VIEW public.v_cut_to_ship IS
  'Cut-to-ship per colorway. wip_qty_by_size = proportional split of scalar wip_qty across cut size mix.';

CREATE OR REPLACE FUNCTION public.get_cut_to_ship_journey(
  p_factory_id uuid,
  p_order_id uuid
)
RETURNS SETOF public.v_cut_to_ship_dept_journey
LANGUAGE sql
STABLE
SECURITY INVOKER
SET search_path = public
AS $$
  SELECT *
  FROM public.v_cut_to_ship_dept_journey
  WHERE factory_id = p_factory_id AND order_id = p_order_id
  ORDER BY colorway_id NULLS LAST, flow_step NULLS LAST, dept_name;
$$;

COMMENT ON FUNCTION public.get_cut_to_ship_journey(uuid, uuid) IS
  'Department journey rows for one order including size-wise qty columns.';

CREATE OR REPLACE FUNCTION public.get_cut_to_ship_detail(
  p_factory_id uuid,
  p_order_id uuid
)
RETURNS jsonb
LANGUAGE sql
STABLE
SECURITY INVOKER
SET search_path = public
AS $$
  SELECT jsonb_build_object(
    'reconciliation',
      COALESCE((
        SELECT jsonb_agg(to_jsonb(c) ORDER BY c.colorway_id NULLS LAST)
        FROM public.v_cut_to_ship c
        WHERE c.factory_id = p_factory_id AND c.order_id = p_order_id
      ), '[]'::jsonb),
    'shipments',
      COALESCE((
        SELECT jsonb_agg(to_jsonb(s) ORDER BY s.shipment_date DESC, s.logged_at DESC)
        FROM public.shipments s
        WHERE s.factory_id = p_factory_id AND s.order_id = p_order_id
      ), '[]'::jsonb),
    'rejections',
      COALESCE((
        SELECT jsonb_agg(to_jsonb(r) ORDER BY r.rejected_date DESC, r.logged_at DESC)
        FROM public.rejections r
        WHERE r.factory_id = p_factory_id AND r.order_id = p_order_id
      ), '[]'::jsonb),
    'wip_by_dept',
      COALESCE((
        SELECT jsonb_agg(to_jsonb(w) ORDER BY w.flow_step, w.colorway_id NULLS LAST, w.department_id)
        FROM public.get_order_wip(p_factory_id, p_order_id) w
      ), '[]'::jsonb),
    'journey',
      COALESCE((
        SELECT jsonb_agg(to_jsonb(j) ORDER BY j.colorway_id NULLS LAST, j.flow_step NULLS LAST, j.dept_name)
        FROM public.get_cut_to_ship_journey(p_factory_id, p_order_id) j
      ), '[]'::jsonb)
  );
$$;

COMMENT ON FUNCTION public.get_cut_to_ship_detail(uuid, uuid) IS
  'Order cut-to-ship drill-down: reconciliation, shipments, rejections, wip_by_dept, size-aware journey.';

REVOKE ALL ON FUNCTION public.get_cut_to_ship_journey(uuid, uuid) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.get_cut_to_ship_journey(uuid, uuid) TO authenticated;
REVOKE EXECUTE ON FUNCTION public.get_cut_to_ship_journey(uuid, uuid) FROM anon;

CREATE OR REPLACE FUNCTION public.get_cut_to_ship_report(
  p_factory_id uuid,
  p_date_from date DEFAULT NULL,
  p_date_to date DEFAULT NULL,
  p_buyer_id uuid DEFAULT NULL,
  p_balanced_only boolean DEFAULT NULL
)
RETURNS SETOF public.v_cut_to_ship
LANGUAGE sql
STABLE
SECURITY INVOKER
SET search_path = public
AS $$
  SELECT c.*
  FROM public.v_cut_to_ship c
  JOIN public.style_orders so
    ON so.id = c.order_id AND so.factory_id = c.factory_id
  WHERE c.factory_id = p_factory_id
    AND (
      p_date_from IS NULL
      OR COALESCE(so.delivery_date, so.order_date) >= p_date_from
    )
    AND (
      p_date_to IS NULL
      OR COALESCE(so.delivery_date, so.order_date) <= p_date_to
    )
    AND (p_buyer_id IS NULL OR so.buyer_id = p_buyer_id)
    AND (p_balanced_only IS NULL OR c.is_balanced = p_balanced_only)
  ORDER BY so.style_name, c.colorway_id NULLS LAST;
$$;

COMMENT ON FUNCTION public.get_cut_to_ship_report(uuid, date, date, uuid, boolean) IS
  'Cut-to-ship list with optional delivery_date/order_date range, buyer, balanced filter. Wraps v_cut_to_ship.';

REVOKE ALL ON FUNCTION public.get_cut_to_ship_report(uuid, date, date, uuid, boolean) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.get_cut_to_ship_report(uuid, date, date, uuid, boolean) TO authenticated;
REVOKE EXECUTE ON FUNCTION public.get_cut_to_ship_report(uuid, date, date, uuid, boolean) FROM anon;
