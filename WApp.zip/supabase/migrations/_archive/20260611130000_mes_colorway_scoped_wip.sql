-- Phase 3.5 correction: WIP at colorway grain.
-- hourly_counts already has colorway_id; extend inspections + handover_slips.

ALTER TABLE public.inspections
  ADD COLUMN IF NOT EXISTS colorway_id uuid REFERENCES public.colorways(id);

ALTER TABLE public.handover_slips
  ADD COLUMN IF NOT EXISTS colorway_id uuid REFERENCES public.colorways(id);

CREATE INDEX IF NOT EXISTS idx_inspections_factory_order_colorway
  ON public.inspections (factory_id, order_id, colorway_id);

CREATE INDEX IF NOT EXISTS idx_handover_slips_factory_order_colorway
  ON public.handover_slips (factory_id, order_id, colorway_id);

COMMENT ON COLUMN public.inspections.colorway_id IS
  'Nullable for legacy rows. New floor captures should set colorwayId.';

COMMENT ON COLUMN public.handover_slips.colorway_id IS
  'Nullable for legacy rows. New floor captures should set colorwayId.';

-- v_daily_output column order changes require drop + recreate dependents.
DROP VIEW IF EXISTS public.v_daily_output CASCADE;

-- -----------------------------------------------------------------------------
-- v_daily_output: add colorway_id grain (KPI views SUM across colorways)
-- -----------------------------------------------------------------------------
CREATE VIEW public.v_daily_output AS
WITH hourly AS (
  SELECT
    h.factory_id,
    h.order_id,
    h.colorway_id,
    h.department_id,
    h.log_date,
    public.get_shift_for_hour_slot(h.factory_id, h.hour_slot) AS shift_id,
    SUM(h.count)::integer AS output_qty
  FROM public.hourly_counts h
  JOIN public.departments d ON d.id = h.department_id AND d.is_production = true
  GROUP BY
    h.factory_id, h.order_id, h.colorway_id, h.department_id, h.log_date,
    public.get_shift_for_hour_slot(h.factory_id, h.hour_slot)
),
inspection_rows AS (
  SELECT
    i.factory_id,
    i.order_id,
    i.colorway_id,
    i.department_id,
    i.logged_at::date AS log_date,
    public.infer_shift_id_for_inspection(i.factory_id, i.logged_at) AS shift_id,
    i.result
  FROM public.inspections i
  JOIN public.departments d ON d.id = i.department_id AND d.is_production = true
),
inspection AS (
  SELECT
    factory_id, order_id, colorway_id, department_id, log_date, shift_id,
    COUNT(*) FILTER (WHERE result IN ('pass', 'rework_pass'))::integer AS output_qty
  FROM inspection_rows
  GROUP BY factory_id, order_id, colorway_id, department_id, log_date, shift_id
),
keys AS (
  SELECT DISTINCT factory_id, order_id, colorway_id, department_id, log_date FROM hourly
  UNION
  SELECT DISTINCT factory_id, order_id, colorway_id, department_id, log_date FROM inspection
),
mode_pick AS (
  SELECT
    k.factory_id, k.order_id, k.colorway_id, k.department_id, k.log_date,
    CASE
      WHEN EXISTS (
        SELECT 1 FROM public.hourly_counts h
        JOIN public.departments d ON d.id = h.department_id AND d.is_production = true
        WHERE h.factory_id = k.factory_id AND h.order_id = k.order_id
          AND h.department_id = k.department_id AND h.log_date = k.log_date
      ) THEN 'hourly'
      WHEN EXISTS (
        SELECT 1 FROM public.inspections i
        JOIN public.departments d ON d.id = i.department_id AND d.is_production = true
        WHERE i.factory_id = k.factory_id AND i.order_id = k.order_id
          AND i.department_id = k.department_id AND i.logged_at::date = k.log_date
      ) THEN 'qc'
      ELSE 'none'
    END AS capture_mode
  FROM keys k
)
SELECT
  m.factory_id, m.order_id, m.colorway_id, m.department_id, m.log_date,
  o.shift_id, o.output_qty, m.capture_mode, (o.shift_id IS NULL) AS is_unallocated
FROM mode_pick m
JOIN LATERAL (
  SELECT h.shift_id, h.output_qty FROM hourly h
  WHERE m.capture_mode = 'hourly'
    AND h.factory_id = m.factory_id AND h.order_id = m.order_id
    AND h.colorway_id IS NOT DISTINCT FROM m.colorway_id
    AND h.department_id = m.department_id AND h.log_date = m.log_date
  UNION ALL
  SELECT i.shift_id, i.output_qty FROM inspection i
  WHERE m.capture_mode = 'qc'
    AND i.factory_id = m.factory_id AND i.order_id = m.order_id
    AND i.colorway_id IS NOT DISTINCT FROM m.colorway_id
    AND i.department_id = m.department_id AND i.log_date = m.log_date
) o ON true;

COMMENT ON VIEW public.v_daily_output IS
  'Production dept output at colorway grain. Legacy rows with NULL colorway_id bucket separately. KPI views SUM across colorways.';

-- Restore KPI views (production-filtered; SUM across colorways)
CREATE VIEW public.v_daily_kpis_by_shift AS
WITH output_shift AS (
  SELECT factory_id, order_id, department_id, log_date, shift_id,
    SUM(output_qty)::integer AS shift_output
  FROM public.v_daily_output WHERE shift_id IS NOT NULL
  GROUP BY factory_id, order_id, department_id, log_date, shift_id
),
workforce AS (SELECT * FROM public.v_daily_workforce),
shift_keys AS (
  SELECT factory_id, department_id, log_date, shift_id FROM workforce
  UNION
  SELECT h.factory_id, h.department_id, h.log_date,
    public.get_shift_for_hour_slot(h.factory_id, h.hour_slot) AS shift_id
  FROM public.hourly_counts h
  JOIN public.departments d ON d.id = h.department_id AND d.is_production = true
  WHERE public.get_shift_for_hour_slot(h.factory_id, h.hour_slot) IS NOT NULL
  UNION
  SELECT i.factory_id, i.department_id, i.logged_at::date AS log_date, inf.shift_id
  FROM public.inspections i
  JOIN public.departments d ON d.id = i.department_id AND d.is_production = true
  CROSS JOIN LATERAL (
    SELECT public.infer_shift_id_for_inspection(i.factory_id, i.logged_at) AS shift_id
  ) inf
  WHERE inf.shift_id IS NOT NULL
),
order_keys AS (
  SELECT DISTINCT factory_id, order_id, department_id, log_date FROM public.v_daily_output
  UNION
  SELECT DISTINCT t.factory_id, t.order_id, t.department_id, t.log_date
  FROM public.v_daily_target t
  JOIN public.departments d ON d.id = t.department_id AND d.is_production = true
),
base AS (
  SELECT ok.factory_id, ok.order_id, ok.department_id, ok.log_date, sk.shift_id
  FROM order_keys ok
  JOIN shift_keys sk ON sk.factory_id = ok.factory_id
   AND sk.department_id = ok.department_id AND sk.log_date = ok.log_date
),
enriched AS (
  SELECT b.factory_id, b.order_id, b.department_id, b.log_date, b.shift_id,
    sm.shift_name, sm.productive_mins,
    COALESCE(os.shift_output, 0) AS shift_output,
    COALESCE(wf.headcount, 0) AS shift_headcount,
    COALESCE(wf.available_mins, 0) AS shift_available_mins,
    (wf.shift_id IS NOT NULL) AS has_workforce,
    (COALESCE(os.shift_output, 0) > 0) AS has_output
  FROM base b
  JOIN public.v_shift_minutes sm ON sm.shift_id = b.shift_id
  LEFT JOIN output_shift os ON os.factory_id = b.factory_id AND os.order_id = b.order_id
   AND os.department_id = b.department_id AND os.log_date = b.log_date AND os.shift_id = b.shift_id
  LEFT JOIN workforce wf ON wf.factory_id = b.factory_id AND wf.department_id = b.department_id
   AND wf.log_date = b.log_date AND wf.shift_id = b.shift_id
),
with_flags AS (
  SELECT e.*,
    CASE
      WHEN NOT e.has_workforce AND NOT e.has_output THEN 'none'
      WHEN e.has_workforce AND e.has_output THEN 'complete'
      WHEN e.has_workforce THEN 'workforce_only'
      ELSE 'output_only'
    END AS data_completeness
  FROM enriched e
),
prorated AS (
  SELECT wf.*, t.daily_target,
    SUM(wf.productive_mins) OVER (
      PARTITION BY wf.factory_id, wf.order_id, wf.department_id, wf.log_date
    ) AS active_productive_mins
  FROM with_flags wf
  LEFT JOIN public.v_daily_target t ON t.factory_id = wf.factory_id AND t.order_id = wf.order_id
   AND t.department_id = wf.department_id AND t.log_date = wf.log_date
)
SELECT p.factory_id, p.order_id, p.department_id, p.log_date, p.shift_id, p.shift_name,
  p.shift_output, p.shift_headcount, p.shift_available_mins, p.has_workforce, p.has_output,
  p.data_completeness,
  CASE WHEN p.data_completeness = 'complete' AND COALESCE(p.daily_target, 0) > 0
    THEN ROUND(100.0 * p.shift_output / NULLIF(
      p.daily_target * (p.productive_mins / NULLIF(p.active_productive_mins, 0)), 0))::numeric
    ELSE NULL END AS shift_efficiency_pct,
  CASE WHEN p.data_completeness = 'complete' AND p.shift_headcount > 0
    THEN ROUND(p.shift_output::numeric / p.shift_headcount, 2) ELSE NULL END AS shift_productivity
FROM prorated p;

COMMENT ON VIEW public.v_daily_kpis_by_shift IS
  'Production dept shift KPIs only. Excludes Shipment and Quality Audit pseudo-depts.';

CREATE VIEW public.v_daily_kpis AS
WITH shift_rows AS (
  SELECT * FROM public.v_daily_kpis_by_shift
),
unalloc AS (
  SELECT factory_id, order_id, department_id, log_date, unallocated_output
  FROM (
    SELECT factory_id, order_id, department_id, log_date,
      SUM(output_qty)::integer AS unallocated_output
    FROM public.v_daily_output
    WHERE shift_id IS NULL
    GROUP BY factory_id, order_id, department_id, log_date
  ) u
),
daily AS (
  SELECT
    sr.factory_id, sr.order_id, sr.department_id, sr.log_date,
    COALESCE(t.daily_target, 0) AS daily_target,
    COALESCE(SUM(sr.shift_output), 0) + COALESCE(MAX(u.unallocated_output), 0) AS daily_output,
    COALESCE(SUM(sr.shift_available_mins) FILTER (
      WHERE sr.data_completeness IN ('complete', 'workforce_only')
    ), 0) AS daily_available_mins,
    COALESCE(SUM(sr.shift_output) FILTER (WHERE sr.data_completeness = 'complete'), 0) AS complete_output,
    COALESCE(SUM(sr.shift_headcount) FILTER (WHERE sr.data_completeness = 'complete'), 0) AS complete_headcount,
    BOOL_OR(sr.data_completeness = 'complete') AS any_complete,
    BOOL_OR(sr.data_completeness = 'output_only') AS any_output_only,
    BOOL_OR(sr.data_completeness = 'workforce_only') AS any_workforce_only,
    BOOL_OR(sr.data_completeness <> 'none') AS any_active
  FROM shift_rows sr
  LEFT JOIN public.v_daily_target t
    ON t.factory_id = sr.factory_id AND t.order_id = sr.order_id
   AND t.department_id = sr.department_id AND t.log_date = sr.log_date
  LEFT JOIN unalloc u
    ON u.factory_id = sr.factory_id AND u.order_id = sr.order_id
   AND u.department_id = sr.department_id AND u.log_date = sr.log_date
  GROUP BY sr.factory_id, sr.order_id, sr.department_id, sr.log_date, t.daily_target
)
SELECT
  d.factory_id, d.order_id, d.department_id, d.log_date, d.daily_target, d.daily_output,
  d.daily_available_mins,
  CASE WHEN d.daily_target > 0 AND d.complete_output > 0
    THEN ROUND(100.0 * d.complete_output / d.daily_target)::numeric ELSE NULL END AS daily_efficiency_pct,
  CASE WHEN d.complete_headcount > 0
    THEN ROUND(d.complete_output::numeric / d.complete_headcount, 2) ELSE NULL END AS daily_productivity,
  CASE
    WHEN NOT d.any_active THEN 'none'
    WHEN d.any_complete AND NOT d.any_output_only AND NOT d.any_workforce_only THEN 'complete'
    WHEN d.any_complete THEN 'partial'
    WHEN d.any_output_only AND NOT d.any_workforce_only THEN 'output_only'
    WHEN d.any_workforce_only AND NOT d.any_output_only THEN 'workforce_only'
    ELSE 'none'
  END AS day_completeness,
  (
    SELECT COALESCE(jsonb_agg(jsonb_build_object(
      'shift_id', s.shift_id, 'shift_name', s.shift_name, 'shift_output', s.shift_output,
      'shift_headcount', s.shift_headcount, 'data_completeness', s.data_completeness
    ) ORDER BY s.shift_name), '[]'::jsonb)
    FROM public.v_daily_kpis_by_shift s
    WHERE s.factory_id = d.factory_id AND s.order_id = d.order_id
      AND s.department_id = d.department_id AND s.log_date = d.log_date
  ) AS shift_breakdown
FROM daily d;

COMMENT ON VIEW public.v_daily_kpis IS
  'Daily KPI rollup from shift rows. Aggregates output across colorways.';

-- -----------------------------------------------------------------------------
-- WIP views at colorway grain
-- -----------------------------------------------------------------------------
CREATE VIEW public.v_wip_dept AS
WITH daily_prod AS (
  SELECT factory_id, order_id, colorway_id, department_id, log_date,
    SUM(output_qty)::integer AS produced
  FROM public.v_daily_output
  GROUP BY factory_id, order_id, colorway_id, department_id, log_date
),
daily_sent AS (
  SELECT
    hs.factory_id, hs.order_id, hs.colorway_id, hs.from_department_id AS department_id,
    hs.sent_at::date AS log_date, SUM(hs.sent_qty)::integer AS sent_qty
  FROM public.handover_slips hs
  JOIN public.departments d ON d.id = hs.from_department_id AND d.is_production = true
  GROUP BY hs.factory_id, hs.order_id, hs.colorway_id, hs.from_department_id, hs.sent_at::date
),
prod_cum AS (
  SELECT factory_id, order_id, colorway_id, department_id, log_date,
    SUM(produced) OVER (
      PARTITION BY factory_id, order_id, colorway_id, department_id ORDER BY log_date
      ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
    )::integer AS cumulative_produced
  FROM daily_prod
),
sent_cum AS (
  SELECT factory_id, order_id, colorway_id, department_id, log_date,
    SUM(sent_qty) OVER (
      PARTITION BY factory_id, order_id, colorway_id, department_id ORDER BY log_date
      ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
    )::integer AS cumulative_sent
  FROM daily_sent
),
dates AS (
  SELECT DISTINCT factory_id, order_id, colorway_id, department_id, log_date FROM daily_prod
  UNION
  SELECT DISTINCT factory_id, order_id, colorway_id, department_id, log_date FROM daily_sent
)
SELECT
  d.factory_id, d.order_id, d.colorway_id, d.department_id, d.log_date,
  COALESCE(pc.cumulative_produced, 0) AS cumulative_produced,
  COALESCE(sc.cumulative_sent, 0) AS cumulative_sent,
  GREATEST(COALESCE(pc.cumulative_produced, 0) - COALESCE(sc.cumulative_sent, 0), 0)::integer AS wip_qty
FROM dates d
LEFT JOIN prod_cum pc ON pc.factory_id = d.factory_id AND pc.order_id = d.order_id
  AND pc.colorway_id IS NOT DISTINCT FROM d.colorway_id
  AND pc.department_id = d.department_id AND pc.log_date = d.log_date
LEFT JOIN sent_cum sc ON sc.factory_id = d.factory_id AND sc.order_id = d.order_id
  AND sc.colorway_id IS NOT DISTINCT FROM d.colorway_id
  AND sc.department_id = d.department_id AND sc.log_date = d.log_date;

COMMENT ON VIEW public.v_wip_dept IS
  'Production dept WIP at colorway grain. produced from v_daily_output; sent from handover_slips. wip_qty = cumulative produced − cumulative sent. Legacy capture rows with NULL colorway_id are bucketed under colorway_id = NULL — surface separately for data cleanup.';

CREATE VIEW public.v_wip_order AS
WITH order_flow AS (
  SELECT so.id AS order_id, so.factory_id, so.process_flow_id, pfs.flow_step, pfs.department_id
  FROM public.style_orders so
  JOIN public.process_flow_steps pfs ON pfs.flow_id = so.process_flow_id
  JOIN public.departments d ON d.id = pfs.department_id AND d.is_production = true
  WHERE so.process_flow_id IS NOT NULL
),
order_colorways AS (
  SELECT so.factory_id, so.id AS order_id, cw.id AS colorway_id
  FROM public.style_orders so
  LEFT JOIN public.colorways cw ON cw.order_id = so.id
),
wip AS (SELECT * FROM public.v_wip_dept)
SELECT
  of.factory_id, of.order_id, oc.colorway_id, w.log_date, of.flow_step, of.department_id,
  COALESCE(w.wip_qty, 0) AS wip_qty
FROM order_flow of
JOIN order_colorways oc ON oc.order_id = of.order_id AND oc.factory_id = of.factory_id
LEFT JOIN wip w ON w.order_id = of.order_id AND w.department_id = of.department_id
  AND w.colorway_id IS NOT DISTINCT FROM oc.colorway_id;

COMMENT ON VIEW public.v_wip_order IS
  'Production dept WIP along process flow at colorway grain.';

CREATE VIEW public.v_order_wip_total AS
WITH latest_per_dept AS (
  SELECT
    w.factory_id, w.order_id, w.colorway_id, w.department_id, w.wip_qty,
    ROW_NUMBER() OVER (
      PARTITION BY w.factory_id, w.order_id, w.colorway_id, w.department_id
      ORDER BY w.log_date DESC NULLS LAST
    ) AS rn
  FROM public.v_wip_order w
)
SELECT
  factory_id,
  order_id,
  colorway_id,
  SUM(wip_qty)::integer AS wip_qty
FROM latest_per_dept
WHERE rn = 1
GROUP BY factory_id, order_id, colorway_id;

COMMENT ON VIEW public.v_order_wip_total IS
  'Colorway-level WIP: SUM of latest wip_qty per production dept. Order-level WIP = SUM of colorway rows.';

CREATE VIEW public.v_cut_to_ship AS
SELECT
  so.factory_id,
  so.id AS order_id,
  cw.id AS colorway_id,
  so.style_name,
  so.buyer_name,
  so.po_number,
  COALESCE(so.adj_qty, so.order_qty, 0)::integer AS order_qty,
  COALESCE(cq.cut_qty, 0)::integer AS cut_qty,
  COALESCE(cq.cut_qty_source, 'planned') AS cut_qty_source,
  COALESCE(sq.shipped_qty, 0)::integer AS shipped_qty,
  COALESCE(rq.rejected_qty, 0)::integer AS rejected_qty,
  COALESCE(wt.wip_qty, 0)::integer AS wip_qty,
  (COALESCE(cq.cut_qty, 0)
    - (COALESCE(sq.shipped_qty, 0) + COALESCE(rq.rejected_qty, 0) + COALESCE(wt.wip_qty, 0)))::integer
    AS reconciliation_gap,
  COALESCE(rq.rejected_by_reason, '{}'::jsonb) AS rejected_by_reason,
  COALESCE(rq.rejected_by_stage, '{}'::jsonb) AS rejected_by_stage,
  (COALESCE(cq.cut_qty, 0)
    = COALESCE(sq.shipped_qty, 0) + COALESCE(rq.rejected_qty, 0) + COALESCE(wt.wip_qty, 0)) AS is_balanced,
  ROUND(100.0 * COALESCE(sq.shipped_qty, 0) / NULLIF(COALESCE(so.adj_qty, so.order_qty, 0), 0), 2) AS completion_pct,
  so.status AS order_status,
  sq.last_shipment_date
FROM public.style_orders so
LEFT JOIN public.colorways cw ON cw.order_id = so.id
LEFT JOIN public.v_order_cut_qty cq
  ON cq.factory_id = so.factory_id AND cq.order_id = so.id
 AND cq.colorway_id IS NOT DISTINCT FROM cw.id
LEFT JOIN public.v_order_shipped_qty sq
  ON sq.factory_id = so.factory_id AND sq.order_id = so.id
 AND sq.colorway_id IS NOT DISTINCT FROM cw.id
LEFT JOIN public.v_order_rejected_qty rq
  ON rq.factory_id = so.factory_id AND rq.order_id = so.id
 AND rq.colorway_id IS NOT DISTINCT FROM cw.id
LEFT JOIN public.v_order_wip_total wt
  ON wt.factory_id = so.factory_id AND wt.order_id = so.id
 AND wt.colorway_id IS NOT DISTINCT FROM cw.id;

COMMENT ON VIEW public.v_cut_to_ship IS
  'Cut-to-ship reconciliation per factory/order/colorway. IDENTITY: CUT QTY = SHIPPED + REJECTED + WIP (colorway-scoped). reconciliation_gap != 0 means pieces unaccounted for.';
