-- Hour-slot shift attribution: hourly_counts resolved via shifts.hours JSONB, not stored shift_id or logged_at.

CREATE OR REPLACE FUNCTION public.normalize_hour_slot_start(p_hour_slot text)
RETURNS time
LANGUAGE sql
IMMUTABLE
AS $$
  SELECT split_part(trim(p_hour_slot), '-', 1)::time;
$$;

COMMENT ON FUNCTION public.normalize_hour_slot_start(text) IS
  'Canonical hour_slot anchor: start of slot (e.g. "10:00" from "10:00" or "10:00-11:00").';

CREATE OR REPLACE FUNCTION public.get_shift_for_hour_slot(p_factory_id uuid, p_hour_slot text)
RETURNS uuid
LANGUAGE sql
STABLE
AS $$
  SELECT s.id
  FROM public.shifts s
  WHERE s.factory_id = p_factory_id
    AND EXISTS (
      SELECT 1
      FROM jsonb_array_elements(COALESCE(s.hours, '[]'::jsonb)) slot
      WHERE slot->>'type' = 'active'
        AND (slot->>'start')::time = public.normalize_hour_slot_start(p_hour_slot)
    )
  ORDER BY s.id
  LIMIT 1;
$$;

COMMENT ON FUNCTION public.get_shift_for_hour_slot(uuid, text) IS
  'Maps hourly_counts.hour_slot to shift_id by matching slot start to shifts.hours active slots. Always re-resolved in views (ignores stored hourly_counts.shift_id). NULL if unallocated.';

CREATE OR REPLACE VIEW public.v_daily_output AS
WITH hourly AS (
  SELECT
    h.factory_id,
    h.order_id,
    h.department_id,
    h.log_date,
    public.get_shift_for_hour_slot(h.factory_id, h.hour_slot) AS shift_id,
    SUM(h.count)::integer AS output_qty
  FROM public.hourly_counts h
  GROUP BY
    h.factory_id,
    h.order_id,
    h.department_id,
    h.log_date,
    public.get_shift_for_hour_slot(h.factory_id, h.hour_slot)
),
inspection_rows AS (
  SELECT
    i.factory_id,
    i.order_id,
    i.department_id,
    i.logged_at::date AS log_date,
    public.infer_shift_id_for_inspection(i.factory_id, i.logged_at) AS shift_id,
    i.result
  FROM public.inspections i
),
inspection AS (
  SELECT
    factory_id,
    order_id,
    department_id,
    log_date,
    shift_id,
    COUNT(*) FILTER (WHERE result IN ('pass', 'rework_pass'))::integer AS output_qty
  FROM inspection_rows
  GROUP BY factory_id, order_id, department_id, log_date, shift_id
),
keys AS (
  SELECT DISTINCT factory_id, order_id, department_id, log_date FROM hourly
  UNION
  SELECT DISTINCT factory_id, order_id, department_id, log_date FROM inspection
),
mode_pick AS (
  SELECT
    k.factory_id,
    k.order_id,
    k.department_id,
    k.log_date,
    CASE
      WHEN EXISTS (
        SELECT 1 FROM public.hourly_counts h
        WHERE h.factory_id = k.factory_id AND h.order_id = k.order_id
          AND h.department_id = k.department_id AND h.log_date = k.log_date
      ) THEN 'hourly'
      WHEN EXISTS (
        SELECT 1 FROM public.inspections i
        WHERE i.factory_id = k.factory_id AND i.order_id = k.order_id
          AND i.department_id = k.department_id AND i.logged_at::date = k.log_date
      ) THEN 'qc'
      ELSE 'none'
    END AS capture_mode
  FROM keys k
)
SELECT
  m.factory_id,
  m.order_id,
  m.department_id,
  m.log_date,
  o.shift_id,
  o.output_qty,
  m.capture_mode,
  (o.shift_id IS NULL) AS is_unallocated
FROM mode_pick m
JOIN LATERAL (
  SELECT h.shift_id, h.output_qty
  FROM hourly h
  WHERE m.capture_mode = 'hourly'
    AND h.factory_id = m.factory_id AND h.order_id = m.order_id
    AND h.department_id = m.department_id AND h.log_date = m.log_date
  UNION ALL
  SELECT i.shift_id, i.output_qty
  FROM inspection i
  WHERE m.capture_mode = 'qc'
    AND i.factory_id = m.factory_id AND i.order_id = m.order_id
    AND i.department_id = m.department_id AND i.log_date = m.log_date
) o ON true;

COMMENT ON VIEW public.v_daily_output IS
  'Output per factory/order/dept/date/shift. Hourly: shift from get_shift_for_hour_slot(hour_slot → shifts.hours active start), never stored shift_id or logged_at. QC: infer_shift_id_for_inspection(logged_at). Unallocated rows have shift_id NULL.';

CREATE OR REPLACE VIEW public.v_daily_kpis_by_shift AS
WITH output_shift AS (
  SELECT
    factory_id,
    order_id,
    department_id,
    log_date,
    shift_id,
    SUM(output_qty)::integer AS shift_output
  FROM public.v_daily_output
  WHERE shift_id IS NOT NULL
  GROUP BY factory_id, order_id, department_id, log_date, shift_id
),
output_unalloc AS (
  SELECT
    factory_id,
    order_id,
    department_id,
    log_date,
    SUM(output_qty)::integer AS unallocated_output
  FROM public.v_daily_output
  WHERE shift_id IS NULL
  GROUP BY factory_id, order_id, department_id, log_date
),
workforce AS (
  SELECT * FROM public.v_daily_workforce
),
shift_keys AS (
  SELECT factory_id, department_id, log_date, shift_id FROM workforce
  UNION
  SELECT
    h.factory_id,
    h.department_id,
    h.log_date,
    public.get_shift_for_hour_slot(h.factory_id, h.hour_slot) AS shift_id
  FROM public.hourly_counts h
  WHERE public.get_shift_for_hour_slot(h.factory_id, h.hour_slot) IS NOT NULL
  UNION
  SELECT i.factory_id, i.department_id, i.logged_at::date AS log_date, inf.shift_id
  FROM public.inspections i
  CROSS JOIN LATERAL (
    SELECT public.infer_shift_id_for_inspection(i.factory_id, i.logged_at) AS shift_id
  ) inf
  WHERE inf.shift_id IS NOT NULL
),
order_keys AS (
  SELECT DISTINCT factory_id, order_id, department_id, log_date FROM public.v_daily_output
  UNION
  SELECT DISTINCT factory_id, order_id, department_id, log_date FROM public.v_daily_target
),
base AS (
  SELECT
    ok.factory_id,
    ok.order_id,
    ok.department_id,
    ok.log_date,
    sk.shift_id
  FROM order_keys ok
  JOIN shift_keys sk
    ON sk.factory_id = ok.factory_id
   AND sk.department_id = ok.department_id
   AND sk.log_date = ok.log_date
),
enriched AS (
  SELECT
    b.factory_id,
    b.order_id,
    b.department_id,
    b.log_date,
    b.shift_id,
    sm.shift_name,
    sm.productive_mins,
    COALESCE(os.shift_output, 0) AS shift_output,
    COALESCE(wf.headcount, 0) AS shift_headcount,
    COALESCE(wf.available_mins, 0) AS shift_available_mins,
    (wf.shift_id IS NOT NULL) AS has_workforce,
    (COALESCE(os.shift_output, 0) > 0) AS has_output
  FROM base b
  JOIN public.v_shift_minutes sm ON sm.shift_id = b.shift_id
  LEFT JOIN output_shift os
    ON os.factory_id = b.factory_id AND os.order_id = b.order_id
   AND os.department_id = b.department_id AND os.log_date = b.log_date
   AND os.shift_id = b.shift_id
  LEFT JOIN workforce wf
    ON wf.factory_id = b.factory_id AND wf.department_id = b.department_id
   AND wf.log_date = b.log_date AND wf.shift_id = b.shift_id
),
with_flags AS (
  SELECT
    e.*,
    CASE
      WHEN NOT e.has_workforce AND NOT e.has_output THEN 'none'
      WHEN e.has_workforce AND e.has_output THEN 'complete'
      WHEN e.has_workforce THEN 'workforce_only'
      ELSE 'output_only'
    END AS data_completeness
  FROM enriched e
),
prorated AS (
  SELECT
    wf.*,
    t.daily_target,
    SUM(wf.productive_mins) OVER (
      PARTITION BY wf.factory_id, wf.order_id, wf.department_id, wf.log_date
    ) AS active_productive_mins
  FROM with_flags wf
  LEFT JOIN public.v_daily_target t
    ON t.factory_id = wf.factory_id AND t.order_id = wf.order_id
   AND t.department_id = wf.department_id AND t.log_date = wf.log_date
)
SELECT
  p.factory_id,
  p.order_id,
  p.department_id,
  p.log_date,
  p.shift_id,
  p.shift_name,
  p.shift_output,
  p.shift_headcount,
  p.shift_available_mins,
  p.has_workforce,
  p.has_output,
  p.data_completeness,
  CASE
    WHEN p.data_completeness = 'complete' AND COALESCE(p.daily_target, 0) > 0
      THEN ROUND(100.0 * p.shift_output / NULLIF(
        p.daily_target * (p.productive_mins / NULLIF(p.active_productive_mins, 0)), 0))::numeric
    ELSE NULL
  END AS shift_efficiency_pct,
  CASE
    WHEN p.data_completeness = 'complete' AND p.shift_headcount > 0
      THEN ROUND(p.shift_output::numeric / p.shift_headcount, 2)
    ELSE NULL
  END AS shift_productivity
FROM prorated p;

COMMENT ON VIEW public.v_daily_kpis_by_shift IS
  'Shift-level KPIs. Workforce: one row per factory/dept/date/shift_id (source of truth for shift activation). Hourly output shift from hour_slot→hours JSONB; QC from logged_at inference. output_only on OT may mean pending back-fill OR data entry mistake. BACK-FILL SAFE: re-query always reads current tables.';
