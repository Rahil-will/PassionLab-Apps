-- Phase 9.5: Size-wise shipment capture.

ALTER TABLE public.shipments
  ADD COLUMN IF NOT EXISTS shipped_qty_by_size jsonb NOT NULL DEFAULT '{}'::jsonb;

COMMENT ON COLUMN public.shipments.shipped_qty_by_size IS
  'Size breakdown for shipment row. Sum of values should equal shipped_qty (validated in floor_capture).';
