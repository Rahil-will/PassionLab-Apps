-- Phase 9.5: floor_capture v3 — size-aware handover_send/receive and shipment_log.

CREATE OR REPLACE FUNCTION public.floor_capture_fail(
  p_reason text,
  p_code text,
  p_details jsonb DEFAULT '{}'::jsonb
)
RETURNS jsonb
LANGUAGE sql
IMMUTABLE
AS $$
  SELECT jsonb_build_object(
    'error', p_reason,
    'code', p_code,
    'details', COALESCE(p_details, '{}'::jsonb)
  );
$$;

COMMENT ON FUNCTION public.floor_capture_fail(text, text, jsonb) IS
  'Standard floor_capture error payload: { error, code, details }.';

CREATE OR REPLACE FUNCTION public.floor_capture(
  p_factory_id uuid,
  p_user_id uuid,
  p_type text,
  p_payload jsonb
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_id uuid;
  v_existing uuid;
  v_challan text;
  v_po text;
  v_colorway_id uuid;
  v_profile_department_id uuid;
  v_user_role text;
  v_dept_apps jsonb;
  v_log_date date;
  v_shift_id uuid;
  v_shift_type text;
  v_count integer;
  v_sent_qty integer;
  v_available_wip integer;
  v_slip public.handover_slips%ROWTYPE;
  v_to_dept_production boolean;
  v_to_dept_apps jsonb;
  v_payload_dept uuid;
  v_qty_by_size jsonb;
  v_recv_by_size jsonb;
  v_ship_by_size jsonb;
  v_size_sum integer;
  v_bad_key text;
BEGIN
  IF p_factory_id IS NULL OR p_user_id IS NULL THEN
    RETURN public.floor_capture_fail('Invalid session', 'INVALID_SESSION');
  END IF;

  SELECT p.department_id, p.user_role, d.apps
  INTO v_profile_department_id, v_user_role, v_dept_apps
  FROM public.profiles p
  LEFT JOIN public.departments d ON d.id = p.department_id
  WHERE p.id = p_user_id
    AND p.factory_id = p_factory_id
    AND p.status = 'Active';

  IF NOT FOUND THEN
    RETURN public.floor_capture_fail('User profile not found in factory', 'INVALID_SESSION');
  END IF;

  IF p_type = 'hourly_upsert' THEN
    IF NOT public.profile_dept_has_app(p_user_id, p_factory_id, 'hourly') THEN
      RETURN public.floor_capture_fail(
        'Department not authorized for hourly capture',
        'REQUIRE_APP_HOURLY'
      );
    END IF;

    IF COALESCE(v_dept_apps, '[]'::jsonb) @> '["qc_log"]'::jsonb THEN
      RETURN public.floor_capture_fail(
        'Department uses QC capture; hourly not allowed',
        'XOR_VIOLATION'
      );
    END IF;

    IF p_payload->>'orderId' IS NULL OR p_payload->>'orderId' !~* '^[0-9a-f-]{36}$' THEN
      RETURN public.floor_capture_fail('orderId must be a valid UUID', 'INVALID_ORDER');
    END IF;

    IF NOT EXISTS (
      SELECT 1 FROM public.style_orders
      WHERE id = (p_payload->>'orderId')::uuid AND factory_id = p_factory_id
    ) THEN
      RETURN public.floor_capture_fail('Order not found in factory', 'INVALID_ORDER');
    END IF;

    v_payload_dept := (p_payload->>'departmentId')::uuid;
    IF v_profile_department_id IS NULL OR v_payload_dept IS DISTINCT FROM v_profile_department_id THEN
      RETURN public.floor_capture_fail(
        'departmentId must match user department',
        'DEPT_MISMATCH',
        jsonb_build_object('expectedDepartmentId', v_profile_department_id)
      );
    END IF;

    IF p_payload->>'hourSlot' IS NULL OR btrim(p_payload->>'hourSlot') = '' THEN
      RETURN public.floor_capture_fail('hourSlot is required', 'MISSING_HOUR_SLOT');
    END IF;

    BEGIN
      v_shift_id := public.get_shift_for_hour_slot(p_factory_id, p_payload->>'hourSlot');
    EXCEPTION WHEN OTHERS THEN
      v_shift_id := NULL;
    END;
    IF v_shift_id IS NULL THEN
      RETURN public.floor_capture_fail(
        'hourSlot does not match any active shift slot',
        'INVALID_HOUR_SLOT',
        jsonb_build_object('hourSlot', p_payload->>'hourSlot')
      );
    END IF;

    BEGIN
      v_count := (p_payload->>'count')::integer;
    EXCEPTION WHEN OTHERS THEN
      RETURN public.floor_capture_fail('count must be an integer', 'INVALID_COUNT');
    END;

    IF v_count IS NULL OR v_count < 0 THEN
      RETURN public.floor_capture_fail('count must be a non-negative integer', 'INVALID_COUNT');
    END IF;

    v_log_date := COALESCE((p_payload->>'logDate')::date, CURRENT_DATE);
    IF v_log_date < CURRENT_DATE - 7 THEN
      RETURN public.floor_capture_fail(
        'logDate cannot be more than 7 days in the past',
        'BACKFILL_TOO_OLD',
        jsonb_build_object('logDate', v_log_date)
      );
    END IF;

    SELECT s.type INTO v_shift_type
    FROM public.shifts s
    WHERE s.id = v_shift_id;

    IF upper(COALESCE(v_shift_type, '')) = 'OT' AND NOT EXISTS (
      SELECT 1 FROM public.workforce_logs wl
      WHERE wl.factory_id = p_factory_id
        AND wl.department_id = v_profile_department_id
        AND wl.log_date = v_log_date
        AND wl.shift_id = v_shift_id
        AND (wl.operators + wl.helpers + wl.supervisors + wl.trainees) > 0
    ) THEN
      RETURN public.floor_capture_fail(
        'OT hourly output requires OT workforce logged for this date',
        'OT_OUTPUT_WITHOUT_WORKFORCE',
        jsonb_build_object('logDate', v_log_date, 'shiftId', v_shift_id)
      );
    END IF;

    v_colorway_id := NULLIF(p_payload->>'colorwayId', '')::uuid;

    SELECT id INTO v_existing
    FROM public.hourly_counts
    WHERE factory_id = p_factory_id
      AND order_id = (p_payload->>'orderId')::uuid
      AND department_id = v_payload_dept
      AND COALESCE(colorway_id, '00000000-0000-0000-0000-000000000000'::uuid)
        = COALESCE(v_colorway_id, '00000000-0000-0000-0000-000000000000'::uuid)
      AND hour_slot = p_payload->>'hourSlot'
      AND log_date = v_log_date
    LIMIT 1;

    IF v_existing IS NOT NULL THEN
      UPDATE public.hourly_counts
      SET count = v_count,
          logged_at = COALESCE((p_payload->>'loggedAt')::timestamptz, now()),
          shift_id = NULLIF(p_payload->>'shiftId', '')::uuid,
          resource_id = NULLIF(p_payload->>'resourceId', '')::uuid,
          logged_by = p_user_id
      WHERE id = v_existing;
      RETURN jsonb_build_object('id', v_existing);
    END IF;

    INSERT INTO public.hourly_counts (
      factory_id, order_id, colorway_id, department_id, resource_id, shift_id,
      hour_slot, log_date, count, logged_by, logged_at
    ) VALUES (
      p_factory_id,
      (p_payload->>'orderId')::uuid,
      v_colorway_id,
      v_payload_dept,
      NULLIF(p_payload->>'resourceId', '')::uuid,
      NULLIF(p_payload->>'shiftId', '')::uuid,
      p_payload->>'hourSlot',
      v_log_date,
      v_count,
      p_user_id,
      COALESCE((p_payload->>'loggedAt')::timestamptz, now())
    )
    RETURNING id INTO v_id;

    RETURN jsonb_build_object('id', v_id);
  END IF;

  IF p_type = 'inspection' THEN
    IF NOT public.profile_dept_has_app(p_user_id, p_factory_id, 'qc_log') THEN
      RETURN public.floor_capture_fail(
        'Department not authorized for QC capture',
        'REQUIRE_APP_QC'
      );
    END IF;

    IF COALESCE(v_dept_apps, '[]'::jsonb) @> '["hourly"]'::jsonb THEN
      RETURN public.floor_capture_fail(
        'Department uses hourly capture; QC not allowed',
        'XOR_VIOLATION'
      );
    END IF;

    IF p_payload->>'orderId' IS NULL OR p_payload->>'orderId' !~* '^[0-9a-f-]{36}$' THEN
      RETURN public.floor_capture_fail('orderId must be a valid UUID', 'INVALID_ORDER');
    END IF;

    IF NOT EXISTS (
      SELECT 1 FROM public.style_orders
      WHERE id = (p_payload->>'orderId')::uuid AND factory_id = p_factory_id
    ) THEN
      RETURN public.floor_capture_fail('Order not found in factory', 'INVALID_ORDER');
    END IF;

    v_payload_dept := (p_payload->>'departmentId')::uuid;
    IF v_profile_department_id IS NULL OR v_payload_dept IS DISTINCT FROM v_profile_department_id THEN
      RETURN public.floor_capture_fail(
        'departmentId must match user department',
        'DEPT_MISMATCH',
        jsonb_build_object('expectedDepartmentId', v_profile_department_id)
      );
    END IF;

    IF p_payload->>'result' IS NULL OR p_payload->>'result' NOT IN (
      'pass', 'fail', 'rework', 'rework_pass'
    ) THEN
      RETURN public.floor_capture_fail('Invalid inspection result', 'INVALID_RESULT');
    END IF;

    IF p_payload->>'result' IN ('fail', 'rework')
       AND COALESCE(jsonb_array_length(COALESCE(p_payload->'defects', '[]'::jsonb)), 0) = 0 THEN
      RAISE NOTICE 'Inspection % without defects JSON', p_payload->>'result';
    END IF;

    INSERT INTO public.inspections (
      factory_id, order_id, colorway_id, department_id, piece_ref, result, defects, logged_by, logged_at
    ) VALUES (
      p_factory_id,
      (p_payload->>'orderId')::uuid,
      NULLIF(p_payload->>'colorwayId', '')::uuid,
      v_payload_dept,
      NULLIF(p_payload->>'pieceRef', ''),
      p_payload->>'result',
      COALESCE(p_payload->'defects', '[]'::jsonb),
      p_user_id,
      COALESCE((p_payload->>'loggedAt')::timestamptz, now())
    )
    RETURNING id INTO v_id;
    RETURN jsonb_build_object('id', v_id);
  END IF;

  IF p_type = 'workforce_upsert' THEN
    IF NOT (
      public.profile_dept_has_app(p_user_id, p_factory_id, 'workforce_log')
      OR v_user_role IN ('supervisor', 'admin', 'superadmin', 'quality_manager')
    ) THEN
      RETURN public.floor_capture_fail(
        'Department not authorized for workforce log',
        'REQUIRE_APP_WORKFORCE'
      );
    END IF;

    v_payload_dept := (p_payload->>'departmentId')::uuid;
    IF v_profile_department_id IS NULL OR v_payload_dept IS DISTINCT FROM v_profile_department_id THEN
      RETURN public.floor_capture_fail(
        'departmentId must match user department',
        'DEPT_MISMATCH',
        jsonb_build_object('expectedDepartmentId', v_profile_department_id)
      );
    END IF;

    IF NULLIF(p_payload->>'shiftId', '') IS NULL THEN
      RETURN public.floor_capture_fail('shiftId is required', 'MISSING_SHIFT');
    END IF;

    v_log_date := (p_payload->>'logDate')::date;
    IF v_log_date IS NULL THEN
      RETURN public.floor_capture_fail('logDate is required', 'BACKFILL_TOO_OLD');
    END IF;

    IF v_log_date < CURRENT_DATE - 7 THEN
      RETURN public.floor_capture_fail(
        'logDate cannot be more than 7 days in the past',
        'BACKFILL_TOO_OLD',
        jsonb_build_object('logDate', v_log_date)
      );
    END IF;

    IF COALESCE((p_payload->>'operators')::integer, 0)
       + COALESCE((p_payload->>'helpers')::integer, 0)
       + COALESCE((p_payload->>'supervisors')::integer, 0)
       + COALESCE((p_payload->>'trainees')::integer, 0) <= 0 THEN
      RETURN public.floor_capture_fail('At least one headcount field must be > 0', 'EMPTY_HEADCOUNT');
    END IF;

    SELECT id INTO v_existing
    FROM public.workforce_logs
    WHERE factory_id = p_factory_id
      AND department_id = v_payload_dept
      AND log_date = v_log_date
      AND shift_id IS NOT DISTINCT FROM NULLIF(p_payload->>'shiftId', '')::uuid
    LIMIT 1;

    IF v_existing IS NOT NULL THEN
      UPDATE public.workforce_logs SET
        order_id = NULLIF(p_payload->>'orderId', '')::uuid,
        operators = COALESCE((p_payload->>'operators')::integer, 0),
        helpers = COALESCE((p_payload->>'helpers')::integer, 0),
        supervisors = COALESCE((p_payload->>'supervisors')::integer, 0),
        trainees = COALESCE((p_payload->>'trainees')::integer, 0),
        logged_by = p_user_id,
        logged_at = COALESCE((p_payload->>'loggedAt')::timestamptz, now())
      WHERE id = v_existing;
      RETURN jsonb_build_object('id', v_existing);
    END IF;

    INSERT INTO public.workforce_logs (
      factory_id, order_id, department_id, shift_id, log_date,
      operators, helpers, supervisors, trainees, logged_by, logged_at
    ) VALUES (
      p_factory_id,
      NULLIF(p_payload->>'orderId', '')::uuid,
      v_payload_dept,
      NULLIF(p_payload->>'shiftId', '')::uuid,
      v_log_date,
      COALESCE((p_payload->>'operators')::integer, 0),
      COALESCE((p_payload->>'helpers')::integer, 0),
      COALESCE((p_payload->>'supervisors')::integer, 0),
      COALESCE((p_payload->>'trainees')::integer, 0),
      p_user_id,
      COALESCE((p_payload->>'loggedAt')::timestamptz, now())
    )
    RETURNING id INTO v_id;
    RETURN jsonb_build_object('id', v_id);
  END IF;

  IF p_type = 'handover_send' THEN
    IF NOT public.profile_dept_has_app(p_user_id, p_factory_id, 'transaction') THEN
      RETURN public.floor_capture_fail(
        'Department not authorized for handover',
        'REQUIRE_APP_TRANSACTION'
      );
    END IF;

    IF p_payload->>'orderId' IS NULL OR p_payload->>'orderId' !~* '^[0-9a-f-]{36}$' THEN
      RETURN public.floor_capture_fail('orderId must be a valid UUID', 'INVALID_ORDER');
    END IF;

    IF NOT EXISTS (
      SELECT 1 FROM public.style_orders
      WHERE id = (p_payload->>'orderId')::uuid AND factory_id = p_factory_id
    ) THEN
      RETURN public.floor_capture_fail('Order not found in factory', 'INVALID_ORDER');
    END IF;

    IF v_profile_department_id IS NULL
       OR (p_payload->>'fromDepartmentId')::uuid IS DISTINCT FROM v_profile_department_id THEN
      RETURN public.floor_capture_fail(
        'fromDepartmentId must match user department',
        'CANT_SEND_FROM_OTHER_DEPT',
        jsonb_build_object('expectedDepartmentId', v_profile_department_id)
      );
    END IF;

    SELECT d.is_production, d.apps
    INTO v_to_dept_production, v_to_dept_apps
    FROM public.departments d
    WHERE d.id = (p_payload->>'toDepartmentId')::uuid
      AND d.factory_id = p_factory_id;

    IF NOT FOUND OR NOT (
      COALESCE(v_to_dept_production, false)
      OR COALESCE(v_to_dept_apps, '[]'::jsonb) @> '["shipment_log"]'::jsonb
    ) THEN
      RETURN public.floor_capture_fail(
        'Destination must be a production department or Shipment',
        'INVALID_DESTINATION'
      );
    END IF;

    v_sent_qty := COALESCE((p_payload->>'sentQty')::integer, 0);
    IF v_sent_qty <= 0 THEN
      RETURN public.floor_capture_fail('sentQty must be a positive integer', 'INVALID_QTY');
    END IF;

    v_colorway_id := NULLIF(p_payload->>'colorwayId', '')::uuid;

    SELECT COALESCE(w.wip_qty, 0) INTO v_available_wip
    FROM public.v_wip_dept w
    WHERE w.factory_id = p_factory_id
      AND w.order_id = (p_payload->>'orderId')::uuid
      AND w.colorway_id IS NOT DISTINCT FROM v_colorway_id
      AND w.department_id = v_profile_department_id
    ORDER BY w.log_date DESC NULLS LAST
    LIMIT 1;

    IF COALESCE(v_available_wip, 0) < v_sent_qty THEN
      RETURN public.floor_capture_fail(
        'sentQty exceeds available WIP at sending department',
        'OVERSENT',
        jsonb_build_object('availableWip', COALESCE(v_available_wip, 0), 'sentQty', v_sent_qty)
      );
    END IF;

    v_qty_by_size := COALESCE(p_payload->'qtyBySize', '{}'::jsonb);
    IF v_qty_by_size <> '{}'::jsonb THEN
      v_size_sum := public.jsonb_sum_int_values(v_qty_by_size);
      IF v_size_sum <> v_sent_qty THEN
        RETURN public.floor_capture_fail(
          'qtyBySize sum must equal sentQty',
          'SIZE_TOTAL_MISMATCH',
          jsonb_build_object('sentQty', v_sent_qty, 'sizeSum', v_size_sum)
        );
      END IF;
    END IF;

    v_challan := 'CH-' || to_char(now(), 'YYYY') || '-' || upper(substr(md5(random()::text), 1, 5));
    INSERT INTO public.handover_slips (
      factory_id, order_id, colorway_id, from_department_id, to_department_id,
      sent_qty, received_qty, qty_by_size, sent_by, sent_at, notes, status, challan_number
    ) VALUES (
      p_factory_id,
      (p_payload->>'orderId')::uuid,
      v_colorway_id,
      v_profile_department_id,
      (p_payload->>'toDepartmentId')::uuid,
      v_sent_qty,
      NULL,
      v_qty_by_size,
      p_user_id,
      COALESCE((p_payload->>'sentAt')::timestamptz, now()),
      NULLIF(p_payload->>'notes', ''),
      'pending',
      v_challan
    )
    RETURNING id INTO v_id;
    RETURN jsonb_build_object('id', v_id, 'challanNumber', v_challan);
  END IF;

  IF p_type = 'handover_receive' THEN
    SELECT * INTO v_slip
    FROM public.handover_slips
    WHERE id = (p_payload->>'slipId')::uuid
      AND factory_id = p_factory_id;

    IF NOT FOUND THEN
      RETURN public.floor_capture_fail('Handover slip not found', 'SLIP_NOT_FOUND');
    END IF;

    IF v_slip.status IS DISTINCT FROM 'pending' THEN
      RETURN public.floor_capture_fail('Handover slip is not pending', 'SLIP_NOT_PENDING');
    END IF;

    IF v_profile_department_id IS NULL OR v_slip.to_department_id IS DISTINCT FROM v_profile_department_id THEN
      RETURN public.floor_capture_fail(
        'Receiving department must match user department',
        'CANT_RECEIVE_ELSEWHERE',
        jsonb_build_object('expectedDepartmentId', v_profile_department_id)
      );
    END IF;

    IF COALESCE((p_payload->>'receivedQty')::integer, 0) <= 0 THEN
      RETURN public.floor_capture_fail('receivedQty must be a positive integer', 'INVALID_QTY');
    END IF;

    v_recv_by_size := COALESCE(p_payload->'receivedQtyBySize', '{}'::jsonb);
    IF v_recv_by_size <> '{}'::jsonb THEN
      v_size_sum := public.jsonb_sum_int_values(v_recv_by_size);
      IF v_size_sum <> (p_payload->>'receivedQty')::integer THEN
        RETURN public.floor_capture_fail(
          'receivedQtyBySize sum must equal receivedQty',
          'SIZE_TOTAL_MISMATCH',
          jsonb_build_object('receivedQty', (p_payload->>'receivedQty')::integer, 'sizeSum', v_size_sum)
        );
      END IF;
      IF COALESCE(v_slip.qty_by_size, '{}'::jsonb) <> '{}'::jsonb THEN
        FOR v_bad_key IN SELECT key FROM jsonb_each_text(v_recv_by_size) LOOP
          IF NOT (COALESCE(v_slip.qty_by_size, '{}'::jsonb) ? v_bad_key) THEN
            RETURN public.floor_capture_fail(
              'Receive size not defined on send slip',
              'NO_SIZE_DEFINED',
              jsonb_build_object('size', v_bad_key)
            );
          END IF;
        END LOOP;
      END IF;
    END IF;

    UPDATE public.handover_slips
    SET received_qty = (p_payload->>'receivedQty')::integer,
        received_qty_by_size = v_recv_by_size,
        received_by = p_user_id,
        received_at = now(),
        status = 'received'
    WHERE id = v_slip.id;
    RETURN jsonb_build_object('ok', true);
  END IF;

  IF p_type = 'attendance_upsert' THEN
    IF NOT public.profile_dept_has_app(p_user_id, p_factory_id, 'attendance') THEN
      RETURN public.floor_capture_fail(
        'Department not authorized for attendance',
        'REQUIRE_APP_ATTENDANCE'
      );
    END IF;

    IF NULLIF(p_payload->>'shiftId', '') IS NULL THEN
      RETURN public.floor_capture_fail('shiftId is required', 'MISSING_SHIFT');
    END IF;

    IF p_payload->>'status' IS NULL OR replace(p_payload->>'status', 'half-day', 'half_day') NOT IN (
      'present', 'absent', 'half_day', 'late'
    ) THEN
      RETURN public.floor_capture_fail('Invalid attendance status', 'INVALID_STATUS');
    END IF;

    IF NOT EXISTS (
      SELECT 1 FROM public.workers w
      WHERE w.id = (p_payload->>'workerId')::uuid
        AND w.factory_id = p_factory_id
        AND w.department_id = v_profile_department_id
        AND w.is_active = true
    ) THEN
      RETURN public.floor_capture_fail('Worker not found in department', 'INVALID_WORKER');
    END IF;

    SELECT id INTO v_existing
    FROM public.attendance_records
    WHERE worker_id = (p_payload->>'workerId')::uuid
      AND record_date = (p_payload->>'recordDate')::date
      AND shift_id IS NOT DISTINCT FROM NULLIF(p_payload->>'shiftId', '')::uuid
    LIMIT 1;

    IF v_existing IS NOT NULL THEN
      UPDATE public.attendance_records
      SET status = replace(p_payload->>'status', 'half-day', 'half_day'),
          logged_by = p_user_id,
          logged_at = now()
      WHERE id = v_existing;
      RETURN jsonb_build_object('id', v_existing);
    END IF;

    INSERT INTO public.attendance_records (
      factory_id, worker_id, department_id, shift_id, record_date, status, logged_by, logged_at
    ) VALUES (
      p_factory_id,
      (p_payload->>'workerId')::uuid,
      v_profile_department_id,
      NULLIF(p_payload->>'shiftId', '')::uuid,
      (p_payload->>'recordDate')::date,
      replace(p_payload->>'status', 'half-day', 'half_day'),
      p_user_id,
      now()
    )
    RETURNING id INTO v_id;
    RETURN jsonb_build_object('id', v_id);
  END IF;

  IF p_type = 'audit_session' THEN
    IF NOT (
      public.profile_dept_has_app(p_user_id, p_factory_id, 'audit')
      OR v_user_role IN ('auditor', 'admin', 'superadmin', 'quality_manager')
    ) THEN
      RETURN public.floor_capture_fail(
        'Department not authorized for audit',
        'REQUIRE_APP_AUDIT'
      );
    END IF;

    IF COALESCE((p_payload->>'lotSize')::integer, 0) <= 0
       OR COALESCE((p_payload->>'sampleSize')::integer, 0) <= 0
       OR COALESCE((p_payload->>'sampleSize')::integer, 0) > COALESCE((p_payload->>'lotSize')::integer, 0) THEN
      RETURN public.floor_capture_fail('Invalid lot or sample size', 'INVALID_LOT');
    END IF;

    IF COALESCE((p_payload->>'passed')::integer, 0) + COALESCE((p_payload->>'failed')::integer, 0)
       > COALESCE((p_payload->>'sampleSize')::integer, 0) THEN
      RETURN public.floor_capture_fail('passed + failed cannot exceed sampleSize', 'INVALID_COUNT');
    END IF;

    INSERT INTO public.audit_sessions (
      factory_id, order_id, department_id, lot_size, sample_size, aql_level,
      passed, failed, result, logged_by, logged_at
    ) VALUES (
      p_factory_id,
      (p_payload->>'orderId')::uuid,
      (p_payload->>'departmentId')::uuid,
      COALESCE((p_payload->>'lotSize')::integer, 0),
      COALESCE((p_payload->>'sampleSize')::integer, 0),
      NULLIF(p_payload->>'aqlLevel', ''),
      COALESCE((p_payload->>'passed')::integer, 0),
      COALESCE((p_payload->>'failed')::integer, 0),
      NULLIF(p_payload->>'result', ''),
      p_user_id,
      COALESCE((p_payload->>'loggedAt')::timestamptz, now())
    )
    RETURNING id INTO v_id;
    RETURN jsonb_build_object('id', v_id);
  END IF;

  IF p_type = 'rejection_log' THEN
    IF NOT public.profile_dept_has_app(p_user_id, p_factory_id, 'final_rejection_log') THEN
      RETURN public.floor_capture_fail(
        'Department not authorized for rejection log',
        'APP_NOT_ALLOWED'
      );
    END IF;

    IF NOT EXISTS (
      SELECT 1 FROM public.style_orders
      WHERE id = (p_payload->>'orderId')::uuid AND factory_id = p_factory_id
    ) THEN
      RETURN public.floor_capture_fail('Order not found in factory', 'ORDER_NOT_FOUND');
    END IF;

    IF COALESCE((p_payload->>'qty')::integer, 0) <= 0 THEN
      RETURN public.floor_capture_fail('qty must be a positive integer', 'INVALID_QTY');
    END IF;

    IF p_payload->>'stage' IS NULL OR p_payload->>'stage' NOT IN (
      'inline', 'end_line', 'final_audit', 'pre_pack', 'post_pack', 'customer_return'
    ) THEN
      RETURN public.floor_capture_fail('Invalid rejection stage', 'INVALID_STAGE');
    END IF;

    INSERT INTO public.rejections (
      factory_id, order_id, colorway_id, size, qty, reason_code, reason_detail,
      stage, rejected_date, notes, logged_by, logged_at
    ) VALUES (
      p_factory_id,
      (p_payload->>'orderId')::uuid,
      NULLIF(p_payload->>'colorwayId', '')::uuid,
      NULLIF(p_payload->>'size', ''),
      (p_payload->>'qty')::integer,
      COALESCE(NULLIF(p_payload->>'reasonCode', ''), 'Other'),
      NULLIF(p_payload->>'reasonDetail', ''),
      p_payload->>'stage',
      COALESCE((p_payload->>'rejectedDate')::date, CURRENT_DATE),
      NULLIF(p_payload->>'notes', ''),
      p_user_id,
      COALESCE((p_payload->>'loggedAt')::timestamptz, now())
    )
    RETURNING id INTO v_id;

    RETURN jsonb_build_object('id', v_id);
  END IF;

  IF p_type = 'shipment_log' THEN
    IF NOT public.profile_dept_has_app(p_user_id, p_factory_id, 'shipment_log') THEN
      RETURN public.floor_capture_fail(
        'Department not authorized for shipment log',
        'APP_NOT_ALLOWED'
      );
    END IF;

    IF NOT EXISTS (
      SELECT 1 FROM public.style_orders
      WHERE id = (p_payload->>'orderId')::uuid AND factory_id = p_factory_id
    ) THEN
      RETURN public.floor_capture_fail('Order not found in factory', 'ORDER_NOT_FOUND');
    END IF;

    IF COALESCE((p_payload->>'shippedQty')::integer, 0) <= 0 THEN
      RETURN public.floor_capture_fail('shippedQty must be a positive integer', 'INVALID_QTY');
    END IF;

    IF p_payload->>'shipmentType' IS NULL OR p_payload->>'shipmentType' NOT IN (
      'main', 'partial', 'replacement', 'sample', 'rejection_return'
    ) THEN
      RETURN public.floor_capture_fail('Invalid shipment type', 'INVALID_SHIPMENT_TYPE');
    END IF;

    v_ship_by_size := COALESCE(p_payload->'shippedQtyBySize', '{}'::jsonb);
    IF v_ship_by_size <> '{}'::jsonb THEN
      v_size_sum := public.jsonb_sum_int_values(v_ship_by_size);
      IF v_size_sum <> (p_payload->>'shippedQty')::integer THEN
        RETURN public.floor_capture_fail(
          'shippedQtyBySize sum must equal shippedQty',
          'SIZE_TOTAL_MISMATCH',
          jsonb_build_object('shippedQty', (p_payload->>'shippedQty')::integer, 'sizeSum', v_size_sum)
        );
      END IF;
    END IF;

    SELECT po_number INTO v_po
    FROM public.style_orders
    WHERE id = (p_payload->>'orderId')::uuid AND factory_id = p_factory_id;

    INSERT INTO public.shipments (
      factory_id, order_id, colorway_id, po_number, shipped_qty, shipped_qty_by_size,
      shipment_date, invoice_number, awb_number, destination, shipment_type, notes, logged_by, logged_at
    ) VALUES (
      p_factory_id,
      (p_payload->>'orderId')::uuid,
      NULLIF(p_payload->>'colorwayId', '')::uuid,
      v_po,
      (p_payload->>'shippedQty')::integer,
      v_ship_by_size,
      COALESCE((p_payload->>'shipmentDate')::date, CURRENT_DATE),
      NULLIF(p_payload->>'invoiceNumber', ''),
      NULLIF(p_payload->>'awbNumber', ''),
      NULLIF(p_payload->>'destination', ''),
      p_payload->>'shipmentType',
      NULLIF(p_payload->>'notes', ''),
      p_user_id,
      COALESCE((p_payload->>'loggedAt')::timestamptz, now())
    )
    RETURNING id INTO v_id;

    RETURN jsonb_build_object('id', v_id);
  END IF;

  RETURN public.floor_capture_fail('Unknown capture type', 'UNKNOWN_CAPTURE_TYPE');
END;
$$;

REVOKE ALL ON FUNCTION public.floor_capture(uuid, uuid, text, jsonb) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.floor_capture(uuid, uuid, text, jsonb) TO anon, authenticated;

REVOKE ALL ON FUNCTION public.floor_capture_fail(text, text, jsonb) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.floor_capture_fail(text, text, jsonb) TO authenticated;
