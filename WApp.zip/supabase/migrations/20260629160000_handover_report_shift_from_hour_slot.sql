-- Attribute handover shifts via hour_slot → get_shift_for_hour_slot (same as production reports).

CREATE OR REPLACE FUNCTION public.get_handover_report(
  p_factory_id uuid,
  p_date_from date DEFAULT NULL,
  p_date_to date DEFAULT NULL,
  p_from_department_id uuid DEFAULT NULL,
  p_to_department_id uuid DEFAULT NULL,
  p_status text DEFAULT NULL,
  p_order_id uuid DEFAULT NULL,
  p_colorway_id uuid DEFAULT NULL,
  p_search text DEFAULT NULL
)
RETURNS TABLE (
  id uuid,
  order_id uuid,
  colorway_id uuid,
  from_department_id uuid,
  to_department_id uuid,
  sent_qty integer,
  received_qty integer,
  qty_by_size jsonb,
  received_qty_by_size jsonb,
  sent_at timestamptz,
  received_at timestamptz,
  status text,
  challan_number text,
  notes text,
  received_notes text,
  sent_by uuid,
  received_by uuid,
  style_name text,
  po_number text,
  colorway_name text,
  color_code text,
  from_department_name text,
  to_department_name text,
  sent_by_name text,
  received_by_name text,
  log_date date,
  shift_id uuid,
  shift_name text,
  hour_slot text
)
LANGUAGE sql
STABLE
SECURITY INVOKER
SET search_path = public
AS $$
  WITH base AS (
    SELECT
      hs.*,
      so.style_name,
      so.po_number,
      cw.name AS colorway_name,
      cw.color_code,
      fd.name AS from_department_name,
      td.name AS to_department_name,
      sp.full_name AS sent_by_name,
      rp.full_name AS received_by_name,
      hs.sent_at::date AS log_date,
      public.infer_hour_slot_for_timestamp(p_factory_id, hs.sent_at) AS hour_slot
    FROM public.handover_slips hs
    JOIN public.style_orders so ON so.id = hs.order_id
    LEFT JOIN public.colorways cw ON cw.id = hs.colorway_id
    JOIN public.departments fd ON fd.id = hs.from_department_id
    JOIN public.departments td ON td.id = hs.to_department_id
    LEFT JOIN public.profiles sp ON sp.id = hs.sent_by
    LEFT JOIN public.profiles rp ON rp.id = hs.received_by
    WHERE hs.factory_id = p_factory_id
      AND hs.sent_at::date >= COALESCE(p_date_from, CURRENT_DATE - 30)
      AND hs.sent_at::date <= COALESCE(p_date_to, CURRENT_DATE)
      AND (p_from_department_id IS NULL OR hs.from_department_id = p_from_department_id)
      AND (p_to_department_id IS NULL OR hs.to_department_id = p_to_department_id)
      AND (p_status IS NULL OR hs.status = p_status)
      AND (p_order_id IS NULL OR hs.order_id = p_order_id)
      AND (p_colorway_id IS NULL OR hs.colorway_id IS NOT DISTINCT FROM p_colorway_id)
      AND (
        p_search IS NULL
        OR trim(p_search) = ''
        OR so.style_name ILIKE '%' || trim(p_search) || '%'
        OR so.po_number ILIKE '%' || trim(p_search) || '%'
        OR hs.challan_number ILIKE '%' || trim(p_search) || '%'
        OR fd.name ILIKE '%' || trim(p_search) || '%'
        OR td.name ILIKE '%' || trim(p_search) || '%'
      )
  ),
  attributed AS (
    SELECT
      b.*,
      COALESCE(
        public.get_shift_for_hour_slot(p_factory_id, b.hour_slot),
        public.infer_shift_id_for_inspection(p_factory_id, b.sent_at)
      ) AS resolved_shift_id
    FROM base b
  )
  SELECT
    a.id,
    a.order_id,
    a.colorway_id,
    a.from_department_id,
    a.to_department_id,
    a.sent_qty,
    a.received_qty,
    COALESCE(a.qty_by_size, '{}'::jsonb),
    COALESCE(a.received_qty_by_size, '{}'::jsonb),
    a.sent_at,
    a.received_at,
    a.status,
    a.challan_number,
    a.notes,
    a.received_notes,
    a.sent_by,
    a.received_by,
    a.style_name,
    a.po_number,
    a.colorway_name,
    a.color_code,
    a.from_department_name,
    a.to_department_name,
    a.sent_by_name,
    a.received_by_name,
    a.log_date,
    a.resolved_shift_id AS shift_id,
    sh.name AS shift_name,
    a.hour_slot
  FROM attributed a
  LEFT JOIN public.shifts sh ON sh.id = a.resolved_shift_id
  ORDER BY a.sent_at DESC
  LIMIT 2000;
$$;

COMMENT ON FUNCTION public.get_handover_report IS
  'Handover ledger for Transaction Report. Shift from hour_slot → get_shift_for_hour_slot; fallback infer_shift_id_for_inspection.';
