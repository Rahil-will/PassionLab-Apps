-- =============================================================================
-- Phase 9.5 catch-up: bring xtfljldeceonqyzgkoyp from mid-Phase-3 to Phase 9.5+9c.
-- Idempotent: IF NOT EXISTS, CREATE OR REPLACE, ON CONFLICT DO NOTHING.
-- Single transaction — rolls back entirely on failure.
-- =============================================================================

BEGIN;

-- Pre-flight: reject departments with both hourly and qc_log before XOR trigger
DO $$
DECLARE
  v_bad jsonb;
BEGIN
  SELECT COALESCE(jsonb_agg(jsonb_build_object('id', d.id, 'name', d.name, 'apps', d.apps)), '[]'::jsonb)
  INTO v_bad
  FROM public.departments d
  WHERE COALESCE(d.apps, '[]'::jsonb) @> '["hourly"]'::jsonb
    AND COALESCE(d.apps, '[]'::jsonb) @> '["qc_log"]'::jsonb;

  IF jsonb_array_length(v_bad) > 0 THEN
    RAISE EXCEPTION 'Cannot enable XOR trigger: departments have both hourly and qc_log: %', v_bad;
  END IF;
END $$;

-- =============================================================================
-- A. Schema additions
-- =============================================================================
ALTER TABLE public.departments
  ADD COLUMN IF NOT EXISTS is_production boolean NOT NULL DEFAULT true;

COMMENT ON COLUMN public.departments.is_production IS
  'false for support functions like Shipment and Quality Audit — excluded from production KPI calcs.';

ALTER TABLE public.inspections
  ADD COLUMN IF NOT EXISTS colorway_id uuid REFERENCES public.colorways(id) ON DELETE SET NULL;

ALTER TABLE public.handover_slips
  ADD COLUMN IF NOT EXISTS colorway_id uuid REFERENCES public.colorways(id) ON DELETE SET NULL;

ALTER TABLE public.handover_slips
  ADD COLUMN IF NOT EXISTS qty_by_size jsonb NOT NULL DEFAULT '{}'::jsonb;

ALTER TABLE public.handover_slips
  ADD COLUMN IF NOT EXISTS received_qty_by_size jsonb NOT NULL DEFAULT '{}'::jsonb;

ALTER TABLE public.hourly_counts
  ADD COLUMN IF NOT EXISTS count_by_size jsonb NOT NULL DEFAULT '{}'::jsonb;

COMMENT ON COLUMN public.hourly_counts.count_by_size IS
  'Hourly output by size label. count column stores the total (sum of values).';

ALTER TABLE public.workforce_logs
  ADD COLUMN IF NOT EXISTS headcount_by_category jsonb NOT NULL DEFAULT '{}'::jsonb;

COMMENT ON COLUMN public.workforce_logs.headcount_by_category IS
  'Headcount by category label (from departments.worker_roles). Keys are labels, values are counts.';

-- Unique department names per factory (for seed ON CONFLICT)
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint
    WHERE conname = 'departments_factory_id_name_key'
      AND conrelid = 'public.departments'::regclass
  ) THEN
    ALTER TABLE public.departments
      ADD CONSTRAINT departments_factory_id_name_key UNIQUE (factory_id, name);
  END IF;
END $$;



-- >>> 20260611100000_mes_cut_to_ship_schema.sql
-- Phase 3.5: Cut-to-Ship schema — pseudo-departments, rejections, shipments.
-- Purpose: model Shipment + Quality Audit as non-production departments; capture rejections/shipments.
-- Inputs: existing factories, departments, style_orders.
-- Outputs: is_production flag, rejections + shipments tables with RLS, seeded pseudo-depts + rejection reasons.

ALTER TABLE public.departments
  ADD COLUMN IF NOT EXISTS is_production boolean NOT NULL DEFAULT true;

COMMENT ON COLUMN public.departments.is_production IS
  'false for support functions like Shipment and Quality Audit — captured data but excluded from production KPI calcs.';

-- -----------------------------------------------------------------------------
-- rejections: post-production rejection log (Quality Audit desk)
-- Output shape: one row per rejection entry (factory, order, colorway, qty, reason, stage, date)
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.rejections (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  factory_id      uuid NOT NULL REFERENCES public.factories(id) ON DELETE CASCADE,
  order_id        uuid NOT NULL REFERENCES public.style_orders(id) ON DELETE CASCADE,
  colorway_id     uuid REFERENCES public.colorways(id) ON DELETE SET NULL,
  size            text,
  qty             integer NOT NULL CHECK (qty > 0),
  reason_code     text NOT NULL,
  reason_detail   text,
  stage           text NOT NULL CHECK (stage IN (
    'inline', 'end_line', 'final_audit', 'pre_pack', 'post_pack', 'customer_return'
  )),
  rejected_date   date NOT NULL DEFAULT CURRENT_DATE,
  notes           text,
  logged_by       uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  logged_at       timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS rejections_factory_order_idx
  ON public.rejections(factory_id, order_id);
CREATE INDEX IF NOT EXISTS rejections_factory_date_idx
  ON public.rejections(factory_id, rejected_date);
CREATE INDEX IF NOT EXISTS rejections_factory_reason_idx
  ON public.rejections(factory_id, reason_code);

COMMENT ON TABLE public.rejections IS
  'Post-production rejection entries from Quality Audit. Used in cut-to-ship reconciliation (rejected_qty).';

-- -----------------------------------------------------------------------------
-- shipments: PO-level dispatch log (Shipment desk)
-- Output shape: one row per shipment event
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.shipments (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  factory_id      uuid NOT NULL REFERENCES public.factories(id) ON DELETE CASCADE,
  order_id        uuid NOT NULL REFERENCES public.style_orders(id) ON DELETE CASCADE,
  colorway_id     uuid REFERENCES public.colorways(id) ON DELETE SET NULL,
  po_number       text,
  shipped_qty     integer NOT NULL CHECK (shipped_qty > 0),
  shipment_date   date NOT NULL DEFAULT CURRENT_DATE,
  invoice_number  text,
  awb_number      text,
  destination     text,
  shipment_type   text NOT NULL CHECK (shipment_type IN (
    'main', 'partial', 'replacement', 'sample', 'rejection_return'
  )),
  notes           text,
  logged_by       uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  logged_at       timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS shipments_factory_order_idx
  ON public.shipments(factory_id, order_id);
CREATE INDEX IF NOT EXISTS shipments_factory_date_idx
  ON public.shipments(factory_id, shipment_date);

COMMENT ON TABLE public.shipments IS
  'Dispatch/shipment log from Shipment desk. Used in cut-to-ship reconciliation (shipped_qty).';

ALTER TABLE public.rejections ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.shipments ENABLE ROW LEVEL SECURITY;

DO $$
DECLARE
  t text;
  tables text[] := ARRAY['rejections', 'shipments'];
BEGIN
  FOREACH t IN ARRAY tables LOOP
    EXECUTE format('DROP POLICY IF EXISTS %I ON public.%I', t || '_select', t);
    EXECUTE format('DROP POLICY IF EXISTS %I ON public.%I', t || '_insert', t);
    EXECUTE format('DROP POLICY IF EXISTS %I ON public.%I', t || '_update', t);
    EXECUTE format('DROP POLICY IF EXISTS %I ON public.%I', t || '_delete', t);
    EXECUTE format(
      'CREATE POLICY %I ON public.%I FOR SELECT TO authenticated USING (factory_id = public.current_factory_id())',
      t || '_select', t
    );
    EXECUTE format(
      'CREATE POLICY %I ON public.%I FOR INSERT TO authenticated WITH CHECK (factory_id = public.current_factory_id())',
      t || '_insert', t
    );
    EXECUTE format(
      'CREATE POLICY %I ON public.%I FOR UPDATE TO authenticated USING (factory_id = public.current_factory_id()) WITH CHECK (factory_id = public.current_factory_id())',
      t || '_update', t
    );
    EXECUTE format(
      'CREATE POLICY %I ON public.%I FOR DELETE TO authenticated USING (factory_id = public.current_factory_id())',
      t || '_delete', t
    );
  END LOOP;
END $$;

GRANT SELECT, INSERT, UPDATE, DELETE ON public.rejections TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.shipments TO authenticated;

-- -----------------------------------------------------------------------------
-- Seed pseudo-departments + rejection_reasons dropdown (per factory, idempotent)
-- -----------------------------------------------------------------------------
INSERT INTO public.departments (factory_id, name, sequence, is_production, apps)
SELECT f.id, 'Quality Audit', 98, false, '["transaction","final_rejection_log"]'::jsonb
FROM public.factories f
ON CONFLICT (factory_id, name) DO NOTHING;

INSERT INTO public.departments (factory_id, name, sequence, is_production, apps)
SELECT f.id, 'Shipment', 99, false, '["transaction","shipment_log"]'::jsonb
FROM public.factories f
ON CONFLICT (factory_id, name) DO NOTHING;

INSERT INTO public.support_dropdowns (factory_id, category, values)
SELECT f.id, 'rejection_reasons',
  '["Stained","Damaged","Wrong measurement","Color mismatch","Construction defect","Buyer audit fail","Pattern issue","Print/Embroidery defect","Other"]'::jsonb
FROM public.factories f
ON CONFLICT (factory_id, category) DO NOTHING;



-- >>> 20260610110000_mes_schema_polish.sql
-- mes_schema_polish (Phase 2b)
-- productive_mins, order_department_mode, reporting indexes, dept XOR trigger, core MES RLS.

-- -----------------------------------------------------------------------------
-- productive_mins: sum active slots from shifts.hours JSONB (not start_time/end_time)
-- -----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.shift_productive_mins_from_hours(p_hours jsonb)
RETURNS numeric
LANGUAGE sql
IMMUTABLE
AS $$
  SELECT COALESCE(SUM(
    CASE
      WHEN slot->>'type' = 'active' THEN
        EXTRACT(EPOCH FROM (
          (slot->>'end')::time - (slot->>'start')::time
          + CASE
              WHEN (slot->>'end')::time < (slot->>'start')::time THEN interval '24 hours'
              ELSE interval '0'
            END
        )) / 60.0
      ELSE 0
    END
  ), 0)
  FROM jsonb_array_elements(COALESCE(p_hours, '[]'::jsonb)) AS slot;
$$;

COMMENT ON FUNCTION public.shift_productive_mins_from_hours(jsonb) IS
  'Derives productive minutes from shifts.hours JSONB by summing slots where type=active.';

ALTER TABLE public.shifts
  ADD COLUMN IF NOT EXISTS productive_mins numeric;

UPDATE public.shifts
SET productive_mins = public.shift_productive_mins_from_hours(hours)
WHERE productive_mins IS NULL;

ALTER TABLE public.shifts
  ALTER COLUMN productive_mins SET DEFAULT 0;

UPDATE public.shifts SET productive_mins = 0 WHERE productive_mins IS NULL;

ALTER TABLE public.shifts
  ALTER COLUMN productive_mins SET NOT NULL;

COMMENT ON COLUMN public.shifts.productive_mins IS
  'Productive minutes per shift day, derived from hours JSONB active slots (not start_time/end_time).';

-- -----------------------------------------------------------------------------
-- order_department_mode: lock capture mode per order x department
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.order_department_mode (
  order_id       uuid NOT NULL REFERENCES public.style_orders(id) ON DELETE CASCADE,
  department_id  uuid NOT NULL REFERENCES public.departments(id) ON DELETE CASCADE,
  mode           text NOT NULL CHECK (mode IN ('hourly', 'qc', 'none')),
  PRIMARY KEY (order_id, department_id)
);

COMMENT ON TABLE public.order_department_mode IS
  'Locks capture mode per style_order x department. hourly = hourly_counts only; qc = inspections only; none = no capture.';

ALTER TABLE public.order_department_mode ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS order_department_mode_select ON public.order_department_mode;
DROP POLICY IF EXISTS order_department_mode_insert ON public.order_department_mode;
DROP POLICY IF EXISTS order_department_mode_update ON public.order_department_mode;
DROP POLICY IF EXISTS order_department_mode_delete ON public.order_department_mode;

CREATE POLICY order_department_mode_select ON public.order_department_mode
  FOR SELECT TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.style_orders o
      WHERE o.id = order_department_mode.order_id
        AND o.factory_id = public.current_factory_id()
    )
  );

CREATE POLICY order_department_mode_insert ON public.order_department_mode
  FOR INSERT TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.style_orders o
      WHERE o.id = order_department_mode.order_id
        AND o.factory_id = public.current_factory_id()
    )
  );

CREATE POLICY order_department_mode_update ON public.order_department_mode
  FOR UPDATE TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.style_orders o
      WHERE o.id = order_department_mode.order_id
        AND o.factory_id = public.current_factory_id()
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.style_orders o
      WHERE o.id = order_department_mode.order_id
        AND o.factory_id = public.current_factory_id()
    )
  );

CREATE POLICY order_department_mode_delete ON public.order_department_mode
  FOR DELETE TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.style_orders o
      WHERE o.id = order_department_mode.order_id
        AND o.factory_id = public.current_factory_id()
    )
  );

-- -----------------------------------------------------------------------------
-- Reporting indexes on capture tables
-- -----------------------------------------------------------------------------
CREATE INDEX IF NOT EXISTS hourly_counts_factory_log_date_idx
  ON public.hourly_counts(factory_id, log_date);

CREATE INDEX IF NOT EXISTS inspections_factory_dept_logged_at_idx
  ON public.inspections(factory_id, department_id, logged_at);

CREATE INDEX IF NOT EXISTS handover_slips_factory_order_idx
  ON public.handover_slips(factory_id, order_id);

CREATE INDEX IF NOT EXISTS workforce_logs_factory_log_date_idx
  ON public.workforce_logs(factory_id, log_date);

CREATE INDEX IF NOT EXISTS audit_sessions_factory_dept_logged_at_idx
  ON public.audit_sessions(factory_id, department_id, logged_at);

-- -----------------------------------------------------------------------------
-- departments.apps XOR: reject hourly + qc_log on same department
-- -----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.reject_dept_hourly_qc_both()
RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
  IF COALESCE(NEW.apps, '[]'::jsonb) @> '["hourly"]'::jsonb
     AND COALESCE(NEW.apps, '[]'::jsonb) @> '["qc_log"]'::jsonb THEN
    RAISE EXCEPTION 'Department apps cannot include both hourly and qc_log';
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS departments_reject_hourly_qc_both ON public.departments;
CREATE TRIGGER departments_reject_hourly_qc_both
  BEFORE INSERT OR UPDATE OF apps ON public.departments
  FOR EACH ROW
  EXECUTE FUNCTION public.reject_dept_hourly_qc_both();

-- -----------------------------------------------------------------------------
-- Factory-scoped RLS on core MES master tables
-- -----------------------------------------------------------------------------
ALTER TABLE public.buyers ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.departments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.shifts ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.workers ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.assigned_resources ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.style_orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.line_allocations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.colorways ENABLE ROW LEVEL SECURITY;

DO $$
DECLARE
  t text;
  tables text[] := ARRAY[
    'buyers', 'departments', 'shifts', 'workers', 'assigned_resources',
    'style_orders', 'line_allocations'
  ];
BEGIN
  FOREACH t IN ARRAY tables LOOP
    EXECUTE format('DROP POLICY IF EXISTS %I ON public.%I', t || '_select', t);
    EXECUTE format('DROP POLICY IF EXISTS %I ON public.%I', t || '_insert', t);
    EXECUTE format('DROP POLICY IF EXISTS %I ON public.%I', t || '_update', t);
    EXECUTE format('DROP POLICY IF EXISTS %I ON public.%I', t || '_delete', t);
    EXECUTE format(
      'CREATE POLICY %I ON public.%I FOR SELECT TO authenticated USING (factory_id = public.current_factory_id())',
      t || '_select', t
    );
    EXECUTE format(
      'CREATE POLICY %I ON public.%I FOR INSERT TO authenticated WITH CHECK (factory_id = public.current_factory_id())',
      t || '_insert', t
    );
    EXECUTE format(
      'CREATE POLICY %I ON public.%I FOR UPDATE TO authenticated USING (factory_id = public.current_factory_id()) WITH CHECK (factory_id = public.current_factory_id())',
      t || '_update', t
    );
    EXECUTE format(
      'CREATE POLICY %I ON public.%I FOR DELETE TO authenticated USING (factory_id = public.current_factory_id())',
      t || '_delete', t
    );
  END LOOP;
END $$;

DROP POLICY IF EXISTS colorways_select ON public.colorways;
DROP POLICY IF EXISTS colorways_insert ON public.colorways;
DROP POLICY IF EXISTS colorways_update ON public.colorways;
DROP POLICY IF EXISTS colorways_delete ON public.colorways;

CREATE POLICY colorways_select ON public.colorways
  FOR SELECT TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.style_orders o
      WHERE o.id = colorways.order_id AND o.factory_id = public.current_factory_id()
    )
  );

CREATE POLICY colorways_insert ON public.colorways
  FOR INSERT TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.style_orders o
      WHERE o.id = colorways.order_id AND o.factory_id = public.current_factory_id()
    )
  );

CREATE POLICY colorways_update ON public.colorways
  FOR UPDATE TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.style_orders o
      WHERE o.id = colorways.order_id AND o.factory_id = public.current_factory_id()
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.style_orders o
      WHERE o.id = colorways.order_id AND o.factory_id = public.current_factory_id()
    )
  );

CREATE POLICY colorways_delete ON public.colorways
  FOR DELETE TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.style_orders o
      WHERE o.id = colorways.order_id AND o.factory_id = public.current_factory_id()
    )
  );



-- >>> 20260611180000_department_worker_roles.sql
-- Phase 6A: department worker_roles for workforce capture categories.

ALTER TABLE public.departments
  ADD COLUMN IF NOT EXISTS worker_roles jsonb NOT NULL DEFAULT '["Operators", "Helpers", "Supervisors", "Trainees"]'::jsonb;

COMMENT ON COLUMN public.departments.worker_roles IS
  'Display labels for workforce_log headcount categories (max 4 map to operators/helpers/supervisors/trainees).';



-- >>> 20260613100000_handover_slips_size_breakdown.sql
-- Phase 9.5: Size-wise handover capture on handover_slips.

ALTER TABLE public.handover_slips
  ADD COLUMN IF NOT EXISTS qty_by_size jsonb NOT NULL DEFAULT '{}'::jsonb,
  ADD COLUMN IF NOT EXISTS received_qty_by_size jsonb NOT NULL DEFAULT '{}'::jsonb;

COMMENT ON COLUMN public.handover_slips.qty_by_size IS
  'Size breakdown sent on handover. Sum of values should equal sent_qty (validated in floor_capture). Example: {"S":50,"M":100}.';

COMMENT ON COLUMN public.handover_slips.received_qty_by_size IS
  'Size breakdown confirmed on receive. Sum should equal received_qty; keys must be subset of qty_by_size keys when send had size split.';



-- >>> 20260613101000_shipments_size_breakdown.sql
-- Phase 9.5: Size-wise shipment capture.

ALTER TABLE public.shipments
  ADD COLUMN IF NOT EXISTS shipped_qty_by_size jsonb NOT NULL DEFAULT '{}'::jsonb;

COMMENT ON COLUMN public.shipments.shipped_qty_by_size IS
  'Size breakdown for shipment row. Sum of values should equal shipped_qty (validated in floor_capture).';



-- >>> 20260613101500_size_json_helpers.sql
-- Phase 9.5: JSONB size-map helpers for floor_capture and reporting.

CREATE OR REPLACE FUNCTION public.jsonb_sum_int_values(p_obj jsonb)
RETURNS integer
LANGUAGE sql
IMMUTABLE
AS $$
  SELECT COALESCE(SUM((value)::integer), 0)
  FROM jsonb_each_text(COALESCE(p_obj, '{}'::jsonb));
$$;

COMMENT ON FUNCTION public.jsonb_sum_int_values(jsonb) IS
  'Sum integer values in a JSONB object like {"S":10,"M":20}.';

CREATE OR REPLACE FUNCTION public.colorway_planned_by_size(p_colorway_id uuid)
RETURNS jsonb
LANGUAGE sql
STABLE
SET search_path = public
AS $$
  SELECT COALESCE(
    (
      SELECT jsonb_object_agg(
        elem->>'size',
        COALESCE(
          NULLIF(elem->>'plannedQty', '')::integer,
          NULLIF(elem->>'adj_qty', '')::integer,
          NULLIF(elem->>'qty', '')::integer,
          0
        )
      )
      FROM public.colorways cw
      CROSS JOIN LATERAL jsonb_array_elements(COALESCE(cw.sizes, '[]'::jsonb)) AS elem
      WHERE cw.id = p_colorway_id
    ),
    '{}'::jsonb
  );
$$;

COMMENT ON FUNCTION public.colorway_planned_by_size(uuid) IS
  'Extract planned qty per size from colorways.sizes JSONB array.';

CREATE OR REPLACE FUNCTION public.proportional_qty_by_size(p_total integer, p_planned jsonb)
RETURNS jsonb
LANGUAGE plpgsql
IMMUTABLE
AS $$
DECLARE
  v_plan_total integer;
  v_result jsonb := '{}'::jsonb;
  v_key text;
  v_val integer;
  v_allocated integer := 0;
  v_last_key text;
  v_share integer;
BEGIN
  IF p_total IS NULL OR p_total <= 0 OR COALESCE(p_planned, '{}'::jsonb) = '{}'::jsonb THEN
    RETURN '{}'::jsonb;
  END IF;
  v_plan_total := public.jsonb_sum_int_values(p_planned);
  IF v_plan_total <= 0 THEN
    RETURN '{}'::jsonb;
  END IF;
  FOR v_key, v_val IN SELECT key, value::integer FROM jsonb_each_text(p_planned) LOOP
    v_last_key := v_key;
    v_share := ROUND(p_total::numeric * v_val / v_plan_total)::integer;
    v_result := v_result || jsonb_build_object(v_key, v_share);
    v_allocated := v_allocated + v_share;
  END LOOP;
  IF v_last_key IS NOT NULL AND v_allocated <> p_total THEN
    v_result := jsonb_set(
      v_result,
      ARRAY[v_last_key],
      to_jsonb(GREATEST(0, COALESCE((v_result->>v_last_key)::integer, 0) + (p_total - v_allocated)))
    );
  END IF;
  RETURN v_result;
END;
$$;

COMMENT ON FUNCTION public.proportional_qty_by_size(integer, jsonb) IS
  'Split p_total across size keys proportionally to planned qty map. Used for Cutting hourly until per-size capture exists.';

CREATE OR REPLACE FUNCTION public.jsonb_merge_sum_maps(p_maps jsonb[])
RETURNS jsonb
LANGUAGE sql
IMMUTABLE
AS $$
  SELECT COALESCE(
    (
      SELECT jsonb_object_agg(key, sum_val)
      FROM (
        SELECT key, SUM(value::integer) AS sum_val
        FROM unnest(COALESCE(p_maps, ARRAY[]::jsonb[])) AS m
        CROSS JOIN LATERAL jsonb_each_text(COALESCE(m, '{}'::jsonb))
        GROUP BY key
      ) s
    ),
    '{}'::jsonb
  );
$$;

COMMENT ON FUNCTION public.jsonb_merge_sum_maps(jsonb[]) IS
  'Merge multiple size→qty JSONB maps by summing values per key.';



-- >>> 20260610120000_mes_reporting_views.sql
-- Phase 3: MES reporting views (shift-aware, back-fill safe — always reads current table state)

-- -----------------------------------------------------------------------------
-- Helpers: shift window + inspection shift inference
-- -----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.time_in_shift_bounds(p_t time, p_start time, p_end time)
RETURNS boolean
LANGUAGE sql
IMMUTABLE
AS $$
  SELECT CASE
    WHEN p_start IS NULL OR p_end IS NULL THEN false
    WHEN p_start <= p_end THEN p_t >= p_start AND p_t < p_end
    ELSE p_t >= p_start OR p_t < p_end
  END;
$$;

COMMENT ON FUNCTION public.time_in_shift_bounds(time, time, time) IS
  'True when p_t falls in [start, end), including overnight shifts when end < start.';

CREATE OR REPLACE FUNCTION public.inspection_time_in_active_slot(p_hours jsonb, p_t time)
RETURNS boolean
LANGUAGE sql
IMMUTABLE
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM jsonb_array_elements(COALESCE(p_hours, '[]'::jsonb)) slot
    WHERE slot->>'type' = 'active'
      AND (
        ((slot->>'start')::time <= (slot->>'end')::time
          AND p_t >= (slot->>'start')::time AND p_t < (slot->>'end')::time)
        OR
        ((slot->>'start')::time > (slot->>'end')::time
          AND (p_t >= (slot->>'start')::time OR p_t < (slot->>'end')::time))
      )
  );
$$;

COMMENT ON FUNCTION public.inspection_time_in_active_slot(jsonb, time) IS
  'True when p_t falls inside any active slot in shifts.hours JSONB.';

CREATE OR REPLACE FUNCTION public.infer_shift_id_for_inspection(p_factory_id uuid, p_logged_at timestamptz)
RETURNS uuid
LANGUAGE sql
STABLE
AS $$
  WITH slot_match AS (
    SELECT s.id, s.name
    FROM public.shifts s
    WHERE s.factory_id = p_factory_id
      AND public.inspection_time_in_active_slot(s.hours, p_logged_at::time)
  ),
  bounds_match AS (
    SELECT s.id, s.name
    FROM public.shifts s
    WHERE s.factory_id = p_factory_id
      AND public.time_in_shift_bounds(p_logged_at::time, s.start_time, s.end_time)
  ),
  chosen AS (
    SELECT id FROM slot_match
    UNION ALL
    SELECT id FROM bounds_match
    WHERE NOT EXISTS (SELECT 1 FROM slot_match)
  )
  SELECT id
  FROM chosen
  ORDER BY id
  LIMIT 1;
$$;

COMMENT ON FUNCTION public.infer_shift_id_for_inspection(uuid, timestamptz) IS
  'Maps inspection.logged_at to a shift: prefers hours JSONB active slots, else start_time/end_time. NULL if unallocated.';

CREATE OR REPLACE FUNCTION public.normalize_hour_slot_start(p_hour_slot text)
RETURNS time
LANGUAGE sql
IMMUTABLE
AS $$
  SELECT split_part(trim(p_hour_slot), '-', 1)::time;
$$;

COMMENT ON FUNCTION public.normalize_hour_slot_start(text) IS
  'Canonical hour_slot anchor: start of slot (e.g. "10:00" from "10:00" or "10:00-11:00").';

CREATE OR REPLACE FUNCTION public.get_shift_for_hour_slot(p_factory_id uuid, p_hour_slot text)
RETURNS uuid
LANGUAGE sql
STABLE
AS $$
  SELECT s.id
  FROM public.shifts s
  WHERE s.factory_id = p_factory_id
    AND EXISTS (
      SELECT 1
      FROM jsonb_array_elements(COALESCE(s.hours, '[]'::jsonb)) slot
      WHERE slot->>'type' = 'active'
        AND (slot->>'start')::time = public.normalize_hour_slot_start(p_hour_slot)
    )
  ORDER BY s.id
  LIMIT 1;
$$;

COMMENT ON FUNCTION public.get_shift_for_hour_slot(uuid, text) IS
  'Maps hourly_counts.hour_slot to shift_id by matching slot start to shifts.hours active slots. Views always re-resolve (ignore stored hourly_counts.shift_id). NULL if unallocated.';

-- -----------------------------------------------------------------------------
-- v_shift_minutes: shift_id -> productive_mins (from shifts.productive_mins column)
-- Formula: productive_mins = sum of active slots in shifts.hours JSONB (stored column).
-- Output: shift_id, factory_id, shift_name, shift_type, productive_mins
-- -----------------------------------------------------------------------------
CREATE OR REPLACE VIEW public.v_shift_minutes AS
SELECT
  s.id AS shift_id,
  s.factory_id,
  s.name AS shift_name,
  s.type AS shift_type,
  s.productive_mins
FROM public.shifts s;

COMMENT ON VIEW public.v_shift_minutes IS
  'Shift productive minutes per shift row. Source: shifts.productive_mins (derived from hours JSONB active slots).';

-- -----------------------------------------------------------------------------
-- v_daily_target: daily plan target from line_allocations
-- line_allocations.order_id = colorway id; resolve to style_orders via colorways.
-- Output: factory_id, order_id, department_id, log_date, daily_target
-- -----------------------------------------------------------------------------
CREATE OR REPLACE VIEW public.v_daily_target AS
SELECT
  la.factory_id,
  COALESCE(cw.order_id, la.order_id) AS order_id,
  la.department_id,
  d.log_date,
  SUM(la.daily_target)::integer AS daily_target
FROM public.line_allocations la
LEFT JOIN public.colorways cw ON cw.id = la.order_id
CROSS JOIN LATERAL (
  SELECT generate_series(la.start_date, la.end_date, interval '1 day')::date AS log_date
) d
WHERE la.start_date IS NOT NULL
  AND la.end_date IS NOT NULL
  AND la.department_id IS NOT NULL
GROUP BY la.factory_id, COALESCE(cw.order_id, la.order_id), la.department_id, d.log_date;

COMMENT ON VIEW public.v_daily_target IS
  'Daily plan target per factory/order/department/date from line_allocations.daily_target on each day in [start_date,end_date].';

-- -----------------------------------------------------------------------------
-- v_daily_output: output attributed to shifts (back-fill safe — reads raw capture tables)
-- hourly_counts: get_shift_for_hour_slot(hour_slot). inspections: infer_shift_id_for_inspection().
-- Unallocated inspections (shift_id NULL) still count toward daily output.
-- capture_mode per factory/order/dept/date: hourly if any hourly_counts else qc if inspections.
-- Output: factory_id, order_id, department_id, log_date, shift_id, output_qty, capture_mode, is_unallocated
-- -----------------------------------------------------------------------------
CREATE OR REPLACE VIEW public.v_daily_output AS
WITH hourly AS (
  SELECT
    h.factory_id,
    h.order_id,
    h.department_id,
    h.log_date,
    public.get_shift_for_hour_slot(h.factory_id, h.hour_slot) AS shift_id,
    SUM(h.count)::integer AS output_qty
  FROM public.hourly_counts h
  GROUP BY
    h.factory_id,
    h.order_id,
    h.department_id,
    h.log_date,
    public.get_shift_for_hour_slot(h.factory_id, h.hour_slot)
),
inspection_rows AS (
  SELECT
    i.factory_id,
    i.order_id,
    i.department_id,
    i.logged_at::date AS log_date,
    public.infer_shift_id_for_inspection(i.factory_id, i.logged_at) AS shift_id,
    i.result
  FROM public.inspections i
),
inspection AS (
  SELECT
    factory_id,
    order_id,
    department_id,
    log_date,
    shift_id,
    COUNT(*) FILTER (WHERE result IN ('pass', 'rework_pass'))::integer AS output_qty
  FROM inspection_rows
  GROUP BY factory_id, order_id, department_id, log_date, shift_id
),
keys AS (
  SELECT DISTINCT factory_id, order_id, department_id, log_date FROM hourly
  UNION
  SELECT DISTINCT factory_id, order_id, department_id, log_date FROM inspection
),
mode_pick AS (
  SELECT
    k.factory_id,
    k.order_id,
    k.department_id,
    k.log_date,
    CASE
      WHEN EXISTS (
        SELECT 1 FROM public.hourly_counts h
        WHERE h.factory_id = k.factory_id AND h.order_id = k.order_id
          AND h.department_id = k.department_id AND h.log_date = k.log_date
      ) THEN 'hourly'
      WHEN EXISTS (
        SELECT 1 FROM public.inspections i
        WHERE i.factory_id = k.factory_id AND i.order_id = k.order_id
          AND i.department_id = k.department_id AND i.logged_at::date = k.log_date
      ) THEN 'qc'
      ELSE 'none'
    END AS capture_mode
  FROM keys k
)
SELECT
  m.factory_id,
  m.order_id,
  m.department_id,
  m.log_date,
  o.shift_id,
  o.output_qty,
  m.capture_mode,
  (o.shift_id IS NULL) AS is_unallocated
FROM mode_pick m
JOIN LATERAL (
  SELECT h.shift_id, h.output_qty
  FROM hourly h
  WHERE m.capture_mode = 'hourly'
    AND h.factory_id = m.factory_id AND h.order_id = m.order_id
    AND h.department_id = m.department_id AND h.log_date = m.log_date
  UNION ALL
  SELECT i.shift_id, i.output_qty
  FROM inspection i
  WHERE m.capture_mode = 'qc'
    AND i.factory_id = m.factory_id AND i.order_id = m.order_id
    AND i.department_id = m.department_id AND i.log_date = m.log_date
) o ON true;

COMMENT ON VIEW public.v_daily_output IS
  'Output per factory/order/dept/date/shift. Hourly: get_shift_for_hour_slot(hour_slot → hours JSONB active start), not stored shift_id or logged_at. QC: infer_shift_id_for_inspection(logged_at). Unallocated rows have shift_id NULL. No cached state.';

-- -----------------------------------------------------------------------------
-- v_daily_workforce: headcount + available_mins per factory/dept/date/shift (NOT pre-aggregated)
-- Formula: headcount = sum(headcount_by_category); available_mins = headcount * productive_mins
-- log_date may be back-dated — views always read current workforce_logs rows.
-- -----------------------------------------------------------------------------
CREATE OR REPLACE VIEW public.v_daily_workforce AS
SELECT
  wl.factory_id,
  wl.department_id,
  wl.log_date,
  wl.shift_id,
  sm.shift_name,
  sm.productive_mins,
  public.jsonb_sum_int_values(COALESCE(wl.headcount_by_category, '{}'::jsonb))::integer AS headcount,
  (public.jsonb_sum_int_values(COALESCE(wl.headcount_by_category, '{}'::jsonb)) * sm.productive_mins)::numeric AS available_mins
FROM public.workforce_logs wl
JOIN public.v_shift_minutes sm ON sm.shift_id = wl.shift_id;

COMMENT ON VIEW public.v_daily_workforce IS
  'One row per factory/department/log_date/shift_id. Headcount from workforce_logs; available_mins = headcount * productive_mins. Supports back-dated log_date — re-query anytime to pick up late workforce entries.';

-- -----------------------------------------------------------------------------
-- v_daily_quality: quality KPIs per factory/order/dept/date (department-level QC)
-- inspected = pass+fail+rework_pass; DHU% = fail/inspected*100; defective% = (fail+rework)/inspected*100
-- -----------------------------------------------------------------------------
CREATE OR REPLACE VIEW public.v_daily_quality AS
SELECT
  i.factory_id,
  i.order_id,
  i.department_id,
  i.logged_at::date AS log_date,
  COUNT(*) FILTER (WHERE i.result IN ('pass', 'fail', 'rework_pass'))::integer AS inspected,
  COUNT(*) FILTER (WHERE i.result = 'pass')::integer AS passed,
  COUNT(*) FILTER (WHERE i.result = 'fail')::integer AS failed,
  COUNT(*) FILTER (WHERE i.result = 'rework')::integer AS rework,
  COUNT(*) FILTER (WHERE i.result = 'rework_pass')::integer AS rework_pass,
  CASE
    WHEN COUNT(*) FILTER (WHERE i.result IN ('pass', 'fail', 'rework_pass')) = 0 THEN NULL
    ELSE ROUND(
      100.0 * COUNT(*) FILTER (WHERE i.result = 'fail')
      / NULLIF(COUNT(*) FILTER (WHERE i.result IN ('pass', 'fail', 'rework_pass')), 0)
    )::numeric
  END AS dhu_pct,
  CASE
    WHEN COUNT(*) FILTER (WHERE i.result IN ('pass', 'fail', 'rework_pass')) = 0 THEN NULL
    ELSE ROUND(
      100.0 * COUNT(*) FILTER (WHERE i.result IN ('fail', 'rework'))
      / NULLIF(COUNT(*) FILTER (WHERE i.result IN ('pass', 'fail', 'rework_pass')), 0)
    )::numeric
  END AS defective_pct
FROM public.inspections i
GROUP BY i.factory_id, i.order_id, i.department_id, i.logged_at::date;

COMMENT ON VIEW public.v_daily_quality IS
  'Daily QC metrics from inspections. DHU% = fail/inspected*100. defective% = (fail+rework)/inspected*100.';

-- -----------------------------------------------------------------------------
-- v_wip_dept: cumulative produced - sent per factory/order/dept through log_date
-- produced: hourly sum or QC inspected count (same mode rule as output)
-- -----------------------------------------------------------------------------
CREATE OR REPLACE VIEW public.v_wip_dept AS
WITH daily_prod AS (
  SELECT factory_id, order_id, department_id, log_date, SUM(output_qty)::integer AS produced
  FROM public.v_daily_output
  GROUP BY factory_id, order_id, department_id, log_date
),
daily_sent AS (
  SELECT
    hs.factory_id,
    hs.order_id,
    hs.from_department_id AS department_id,
    hs.sent_at::date AS log_date,
    SUM(hs.sent_qty)::integer AS sent_qty
  FROM public.handover_slips hs
  GROUP BY hs.factory_id, hs.order_id, hs.from_department_id, hs.sent_at::date
),
prod_cum AS (
  SELECT
    factory_id,
    order_id,
    department_id,
    log_date,
    SUM(produced) OVER (
      PARTITION BY factory_id, order_id, department_id
      ORDER BY log_date
      ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
    )::integer AS cumulative_produced
  FROM daily_prod
),
sent_cum AS (
  SELECT
    factory_id,
    order_id,
    department_id,
    log_date,
    SUM(sent_qty) OVER (
      PARTITION BY factory_id, order_id, department_id
      ORDER BY log_date
      ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
    )::integer AS cumulative_sent
  FROM daily_sent
),
dates AS (
  SELECT DISTINCT factory_id, order_id, department_id, log_date FROM daily_prod
  UNION
  SELECT DISTINCT factory_id, order_id, department_id, log_date FROM daily_sent
)
SELECT
  d.factory_id,
  d.order_id,
  d.department_id,
  d.log_date,
  COALESCE(pc.cumulative_produced, 0) AS cumulative_produced,
  COALESCE(sc.cumulative_sent, 0) AS cumulative_sent,
  GREATEST(COALESCE(pc.cumulative_produced, 0) - COALESCE(sc.cumulative_sent, 0), 0)::integer AS wip_qty
FROM dates d
LEFT JOIN prod_cum pc
  ON pc.factory_id = d.factory_id AND pc.order_id = d.order_id
 AND pc.department_id = d.department_id AND pc.log_date = d.log_date
LEFT JOIN sent_cum sc
  ON sc.factory_id = d.factory_id AND sc.order_id = d.order_id
 AND sc.department_id = d.department_id AND sc.log_date = d.log_date;

COMMENT ON VIEW public.v_wip_dept IS
  'Running WIP per factory/order/dept/date: cumulative produced minus cumulative sent (handover_slips). Produced from v_daily_output.';

-- -----------------------------------------------------------------------------
-- v_wip_order: cross-department WIP along process flow
-- For each order/date: WIP at each dept in flow sequence
-- -----------------------------------------------------------------------------
CREATE OR REPLACE VIEW public.v_wip_order AS
WITH order_flow AS (
  SELECT
    so.id AS order_id,
    so.factory_id,
    so.process_flow_id,
    pfs.flow_step,
    pfs.department_id
  FROM public.style_orders so
  JOIN public.process_flow_steps pfs ON pfs.flow_id = so.process_flow_id
  WHERE so.process_flow_id IS NOT NULL
),
wip AS (
  SELECT * FROM public.v_wip_dept
)
SELECT
  of.factory_id,
  of.order_id,
  w.log_date,
  of.flow_step,
  of.department_id,
  COALESCE(w.wip_qty, 0) AS wip_qty
FROM order_flow of
LEFT JOIN wip w
  ON w.order_id = of.order_id AND w.department_id = of.department_id;

COMMENT ON VIEW public.v_wip_order IS
  'Per order/date/dept in process flow: WIP qty from v_wip_dept aligned to process_flow_steps sequence.';

-- -----------------------------------------------------------------------------
-- v_audit_summary: AQL audit aggregates
-- -----------------------------------------------------------------------------
CREATE OR REPLACE VIEW public.v_audit_summary AS
SELECT
  a.factory_id,
  a.order_id,
  a.department_id,
  a.logged_at::date AS log_date,
  COUNT(*)::integer AS lots,
  SUM(a.sample_size)::integer AS total_samples,
  SUM(a.passed)::integer AS total_passed,
  SUM(a.failed)::integer AS total_failed,
  CASE
    WHEN SUM(a.sample_size) = 0 THEN NULL
    ELSE ROUND(100.0 * SUM(a.passed) / NULLIF(SUM(a.sample_size), 0))::numeric
  END AS aql_pass_pct
FROM public.audit_sessions a
GROUP BY a.factory_id, a.order_id, a.department_id, a.logged_at::date;

COMMENT ON VIEW public.v_audit_summary IS
  'Daily audit summary: lots, samples, pass rate from audit_sessions.';

-- -----------------------------------------------------------------------------
-- v_daily_kpis_by_shift: shift-level KPI building block
-- Shift active if workforce OR output exists for factory/dept/date/shift.
-- Efficiency/productivity NULL unless BOTH workforce AND output exist for shift.
-- data_completeness: complete | workforce_only | output_only | none
-- BACK-FILL: never caches absence — always reads workforce_logs + capture tables as-of query time.
-- -----------------------------------------------------------------------------
CREATE OR REPLACE VIEW public.v_daily_kpis_by_shift AS
WITH output_shift AS (
  SELECT
    factory_id,
    order_id,
    department_id,
    log_date,
    shift_id,
    SUM(output_qty)::integer AS shift_output
  FROM public.v_daily_output
  WHERE shift_id IS NOT NULL
  GROUP BY factory_id, order_id, department_id, log_date, shift_id
),
output_unalloc AS (
  SELECT
    factory_id,
    order_id,
    department_id,
    log_date,
    SUM(output_qty)::integer AS unallocated_output
  FROM public.v_daily_output
  WHERE shift_id IS NULL
  GROUP BY factory_id, order_id, department_id, log_date
),
workforce AS (
  SELECT * FROM public.v_daily_workforce
),
shift_keys AS (
  SELECT factory_id, department_id, log_date, shift_id FROM workforce
  UNION
  SELECT
    h.factory_id,
    h.department_id,
    h.log_date,
    public.get_shift_for_hour_slot(h.factory_id, h.hour_slot) AS shift_id
  FROM public.hourly_counts h
  WHERE public.get_shift_for_hour_slot(h.factory_id, h.hour_slot) IS NOT NULL
  UNION
  SELECT i.factory_id, i.department_id, i.logged_at::date AS log_date, inf.shift_id
  FROM public.inspections i
  CROSS JOIN LATERAL (
    SELECT public.infer_shift_id_for_inspection(i.factory_id, i.logged_at) AS shift_id
  ) inf
  WHERE inf.shift_id IS NOT NULL
),
order_keys AS (
  SELECT DISTINCT factory_id, order_id, department_id, log_date FROM public.v_daily_output
  UNION
  SELECT DISTINCT factory_id, order_id, department_id, log_date FROM public.v_daily_target
),
base AS (
  SELECT
    ok.factory_id,
    ok.order_id,
    ok.department_id,
    ok.log_date,
    sk.shift_id
  FROM order_keys ok
  JOIN shift_keys sk
    ON sk.factory_id = ok.factory_id
   AND sk.department_id = ok.department_id
   AND sk.log_date = ok.log_date
),
enriched AS (
  SELECT
    b.factory_id,
    b.order_id,
    b.department_id,
    b.log_date,
    b.shift_id,
    sm.shift_name,
    sm.productive_mins,
    COALESCE(os.shift_output, 0) AS shift_output,
    COALESCE(wf.headcount, 0) AS shift_headcount,
    COALESCE(wf.available_mins, 0) AS shift_available_mins,
    (wf.shift_id IS NOT NULL) AS has_workforce,
    (COALESCE(os.shift_output, 0) > 0) AS has_output
  FROM base b
  JOIN public.v_shift_minutes sm ON sm.shift_id = b.shift_id
  LEFT JOIN output_shift os
    ON os.factory_id = b.factory_id AND os.order_id = b.order_id
   AND os.department_id = b.department_id AND os.log_date = b.log_date
   AND os.shift_id = b.shift_id
  LEFT JOIN workforce wf
    ON wf.factory_id = b.factory_id AND wf.department_id = b.department_id
   AND wf.log_date = b.log_date AND wf.shift_id = b.shift_id
),
with_flags AS (
  SELECT
    e.*,
    CASE
      WHEN NOT e.has_workforce AND NOT e.has_output THEN 'none'
      WHEN e.has_workforce AND e.has_output THEN 'complete'
      WHEN e.has_workforce THEN 'workforce_only'
      ELSE 'output_only'
    END AS data_completeness
  FROM enriched e
),
prorated AS (
  SELECT
    wf.*,
    t.daily_target,
    SUM(wf.productive_mins) OVER (
      PARTITION BY wf.factory_id, wf.order_id, wf.department_id, wf.log_date
    ) AS active_productive_mins
  FROM with_flags wf
  LEFT JOIN public.v_daily_target t
    ON t.factory_id = wf.factory_id AND t.order_id = wf.order_id
   AND t.department_id = wf.department_id AND t.log_date = wf.log_date
)
SELECT
  p.factory_id,
  p.order_id,
  p.department_id,
  p.log_date,
  p.shift_id,
  p.shift_name,
  p.shift_output,
  p.shift_headcount,
  p.shift_available_mins,
  p.has_workforce,
  p.has_output,
  p.data_completeness,
  CASE
    WHEN p.data_completeness = 'complete' AND COALESCE(p.daily_target, 0) > 0
      THEN ROUND(100.0 * p.shift_output / NULLIF(
        p.daily_target * (p.productive_mins / NULLIF(p.active_productive_mins, 0)), 0))::numeric
    ELSE NULL
  END AS shift_efficiency_pct,
  CASE
    WHEN p.data_completeness = 'complete' AND p.shift_headcount > 0
      THEN ROUND(p.shift_output::numeric / p.shift_headcount, 2)
    ELSE NULL
  END AS shift_productivity
FROM prorated p;

COMMENT ON VIEW public.v_daily_kpis_by_shift IS
  'Shift-level KPIs. Workforce one row per factory/dept/date/shift (activation source of truth). Hourly output shift from hour_slot→hours JSONB; QC from logged_at. output_only on OT: pending back-fill or data mistake. Efficiency only when BOTH workforce and output. BACK-FILL SAFE.';

-- -----------------------------------------------------------------------------
-- v_daily_kpis: master daily KPI row per factory/order/dept/date with rollups + day_completeness
-- daily_output = SUM shift output (incl. unallocated) where output exists
-- daily_available_mins = SUM available_mins for shifts with workforce
-- daily_efficiency = SUM(complete shift output) / daily_target * 100
-- daily_productivity = SUM(complete shift output) / SUM(complete shift headcount)
-- day_completeness: complete | partial | output_only | workforce_only | none
-- -----------------------------------------------------------------------------
CREATE OR REPLACE VIEW public.v_daily_kpis AS
WITH shift_rows AS (
  SELECT * FROM public.v_daily_kpis_by_shift
),
unalloc AS (
  SELECT factory_id, order_id, department_id, log_date, unallocated_output
  FROM (
    SELECT
      factory_id,
      order_id,
      department_id,
      log_date,
      SUM(output_qty)::integer AS unallocated_output
    FROM public.v_daily_output
    WHERE shift_id IS NULL
    GROUP BY factory_id, order_id, department_id, log_date
  ) u
),
daily AS (
  SELECT
    sr.factory_id,
    sr.order_id,
    sr.department_id,
    sr.log_date,
    COALESCE(t.daily_target, 0) AS daily_target,
    COALESCE(SUM(sr.shift_output), 0)
      + COALESCE(MAX(u.unallocated_output), 0) AS daily_output,
    COALESCE(SUM(sr.shift_available_mins) FILTER (
      WHERE sr.data_completeness IN ('complete', 'workforce_only')
    ), 0) AS daily_available_mins,
    COALESCE(SUM(sr.shift_output) FILTER (WHERE sr.data_completeness = 'complete'), 0) AS complete_output,
    COALESCE(SUM(sr.shift_headcount) FILTER (WHERE sr.data_completeness = 'complete'), 0) AS complete_headcount,
    BOOL_OR(sr.data_completeness = 'complete') AS any_complete,
    BOOL_OR(sr.data_completeness = 'output_only') AS any_output_only,
    BOOL_OR(sr.data_completeness = 'workforce_only') AS any_workforce_only,
    BOOL_OR(sr.data_completeness <> 'none') AS any_active
  FROM shift_rows sr
  LEFT JOIN public.v_daily_target t
    ON t.factory_id = sr.factory_id AND t.order_id = sr.order_id
   AND t.department_id = sr.department_id AND t.log_date = sr.log_date
  LEFT JOIN unalloc u
    ON u.factory_id = sr.factory_id AND u.order_id = sr.order_id
   AND u.department_id = sr.department_id AND u.log_date = sr.log_date
  GROUP BY sr.factory_id, sr.order_id, sr.department_id, sr.log_date, t.daily_target
)
SELECT
  d.factory_id,
  d.order_id,
  d.department_id,
  d.log_date,
  d.daily_target,
  d.daily_output,
  d.daily_available_mins,
  CASE
    WHEN d.daily_target > 0 AND d.complete_output > 0
      THEN ROUND(100.0 * d.complete_output / d.daily_target)::numeric
    ELSE NULL
  END AS daily_efficiency_pct,
  CASE
    WHEN d.complete_headcount > 0
      THEN ROUND(d.complete_output::numeric / d.complete_headcount, 2)
    ELSE NULL
  END AS daily_productivity,
  CASE
    WHEN NOT d.any_active THEN 'none'
    WHEN d.any_complete AND NOT d.any_output_only AND NOT d.any_workforce_only THEN 'complete'
    WHEN d.any_complete THEN 'partial'
    WHEN d.any_output_only AND NOT d.any_workforce_only THEN 'output_only'
    WHEN d.any_workforce_only AND NOT d.any_output_only THEN 'workforce_only'
    ELSE 'none'
  END AS day_completeness,
  (
    SELECT COALESCE(jsonb_agg(jsonb_build_object(
      'shift_id', s.shift_id,
      'shift_name', s.shift_name,
      'shift_output', s.shift_output,
      'shift_headcount', s.shift_headcount,
      'shift_available_mins', s.shift_available_mins,
      'data_completeness', s.data_completeness,
      'shift_efficiency_pct', s.shift_efficiency_pct,
      'shift_productivity', s.shift_productivity
    ) ORDER BY s.shift_name), '[]'::jsonb)
    FROM public.v_daily_kpis_by_shift s
    WHERE s.factory_id = d.factory_id AND s.order_id = d.order_id
      AND s.department_id = d.department_id AND s.log_date = d.log_date
  ) AS shifts
FROM daily d;

COMMENT ON VIEW public.v_daily_kpis IS
  'Master daily KPI per factory/order/dept/date. BACK-FILL BEHAVIOR: efficiency and completeness are NEVER frozen — they recompute from workforce_logs and capture tables on every SELECT. Example: Monday evening OT output exists but workforce missing → OT efficiency NULL (output_only). Tuesday morning workforce back-filled with log_date=Monday → re-query shows complete and efficiency computes. daily_output counts all captured output; daily_efficiency uses only shifts where BOTH workforce and output exist (partial days flagged via day_completeness=partial). shifts JSON array exposes per-shift data_completeness for UI messaging.';



-- >>> 20260610130000_mes_hour_slot_shift_attribution.sql
-- Hour-slot shift attribution: hourly_counts resolved via shifts.hours JSONB, not stored shift_id or logged_at.

CREATE OR REPLACE FUNCTION public.normalize_hour_slot_start(p_hour_slot text)
RETURNS time
LANGUAGE sql
IMMUTABLE
AS $$
  SELECT split_part(trim(p_hour_slot), '-', 1)::time;
$$;

COMMENT ON FUNCTION public.normalize_hour_slot_start(text) IS
  'Canonical hour_slot anchor: start of slot (e.g. "10:00" from "10:00" or "10:00-11:00").';

CREATE OR REPLACE FUNCTION public.get_shift_for_hour_slot(p_factory_id uuid, p_hour_slot text)
RETURNS uuid
LANGUAGE sql
STABLE
AS $$
  SELECT s.id
  FROM public.shifts s
  WHERE s.factory_id = p_factory_id
    AND EXISTS (
      SELECT 1
      FROM jsonb_array_elements(COALESCE(s.hours, '[]'::jsonb)) slot
      WHERE slot->>'type' = 'active'
        AND (slot->>'start')::time = public.normalize_hour_slot_start(p_hour_slot)
    )
  ORDER BY s.id
  LIMIT 1;
$$;

COMMENT ON FUNCTION public.get_shift_for_hour_slot(uuid, text) IS
  'Maps hourly_counts.hour_slot to shift_id by matching slot start to shifts.hours active slots. Always re-resolved in views (ignores stored hourly_counts.shift_id). NULL if unallocated.';

CREATE OR REPLACE VIEW public.v_daily_output AS
WITH hourly AS (
  SELECT
    h.factory_id,
    h.order_id,
    h.department_id,
    h.log_date,
    public.get_shift_for_hour_slot(h.factory_id, h.hour_slot) AS shift_id,
    SUM(h.count)::integer AS output_qty
  FROM public.hourly_counts h
  GROUP BY
    h.factory_id,
    h.order_id,
    h.department_id,
    h.log_date,
    public.get_shift_for_hour_slot(h.factory_id, h.hour_slot)
),
inspection_rows AS (
  SELECT
    i.factory_id,
    i.order_id,
    i.department_id,
    i.logged_at::date AS log_date,
    public.infer_shift_id_for_inspection(i.factory_id, i.logged_at) AS shift_id,
    i.result
  FROM public.inspections i
),
inspection AS (
  SELECT
    factory_id,
    order_id,
    department_id,
    log_date,
    shift_id,
    COUNT(*) FILTER (WHERE result IN ('pass', 'rework_pass'))::integer AS output_qty
  FROM inspection_rows
  GROUP BY factory_id, order_id, department_id, log_date, shift_id
),
keys AS (
  SELECT DISTINCT factory_id, order_id, department_id, log_date FROM hourly
  UNION
  SELECT DISTINCT factory_id, order_id, department_id, log_date FROM inspection
),
mode_pick AS (
  SELECT
    k.factory_id,
    k.order_id,
    k.department_id,
    k.log_date,
    CASE
      WHEN EXISTS (
        SELECT 1 FROM public.hourly_counts h
        WHERE h.factory_id = k.factory_id AND h.order_id = k.order_id
          AND h.department_id = k.department_id AND h.log_date = k.log_date
      ) THEN 'hourly'
      WHEN EXISTS (
        SELECT 1 FROM public.inspections i
        WHERE i.factory_id = k.factory_id AND i.order_id = k.order_id
          AND i.department_id = k.department_id AND i.logged_at::date = k.log_date
      ) THEN 'qc'
      ELSE 'none'
    END AS capture_mode
  FROM keys k
)
SELECT
  m.factory_id,
  m.order_id,
  m.department_id,
  m.log_date,
  o.shift_id,
  o.output_qty,
  m.capture_mode,
  (o.shift_id IS NULL) AS is_unallocated
FROM mode_pick m
JOIN LATERAL (
  SELECT h.shift_id, h.output_qty
  FROM hourly h
  WHERE m.capture_mode = 'hourly'
    AND h.factory_id = m.factory_id AND h.order_id = m.order_id
    AND h.department_id = m.department_id AND h.log_date = m.log_date
  UNION ALL
  SELECT i.shift_id, i.output_qty
  FROM inspection i
  WHERE m.capture_mode = 'qc'
    AND i.factory_id = m.factory_id AND i.order_id = m.order_id
    AND i.department_id = m.department_id AND i.log_date = m.log_date
) o ON true;

COMMENT ON VIEW public.v_daily_output IS
  'Output per factory/order/dept/date/shift. Hourly: shift from get_shift_for_hour_slot(hour_slot → shifts.hours active start), never stored shift_id or logged_at. QC: infer_shift_id_for_inspection(logged_at). Unallocated rows have shift_id NULL.';

CREATE OR REPLACE VIEW public.v_daily_kpis_by_shift AS
WITH output_shift AS (
  SELECT
    factory_id,
    order_id,
    department_id,
    log_date,
    shift_id,
    SUM(output_qty)::integer AS shift_output
  FROM public.v_daily_output
  WHERE shift_id IS NOT NULL
  GROUP BY factory_id, order_id, department_id, log_date, shift_id
),
output_unalloc AS (
  SELECT
    factory_id,
    order_id,
    department_id,
    log_date,
    SUM(output_qty)::integer AS unallocated_output
  FROM public.v_daily_output
  WHERE shift_id IS NULL
  GROUP BY factory_id, order_id, department_id, log_date
),
workforce AS (
  SELECT * FROM public.v_daily_workforce
),
shift_keys AS (
  SELECT factory_id, department_id, log_date, shift_id FROM workforce
  UNION
  SELECT
    h.factory_id,
    h.department_id,
    h.log_date,
    public.get_shift_for_hour_slot(h.factory_id, h.hour_slot) AS shift_id
  FROM public.hourly_counts h
  WHERE public.get_shift_for_hour_slot(h.factory_id, h.hour_slot) IS NOT NULL
  UNION
  SELECT i.factory_id, i.department_id, i.logged_at::date AS log_date, inf.shift_id
  FROM public.inspections i
  CROSS JOIN LATERAL (
    SELECT public.infer_shift_id_for_inspection(i.factory_id, i.logged_at) AS shift_id
  ) inf
  WHERE inf.shift_id IS NOT NULL
),
order_keys AS (
  SELECT DISTINCT factory_id, order_id, department_id, log_date FROM public.v_daily_output
  UNION
  SELECT DISTINCT factory_id, order_id, department_id, log_date FROM public.v_daily_target
),
base AS (
  SELECT
    ok.factory_id,
    ok.order_id,
    ok.department_id,
    ok.log_date,
    sk.shift_id
  FROM order_keys ok
  JOIN shift_keys sk
    ON sk.factory_id = ok.factory_id
   AND sk.department_id = ok.department_id
   AND sk.log_date = ok.log_date
),
enriched AS (
  SELECT
    b.factory_id,
    b.order_id,
    b.department_id,
    b.log_date,
    b.shift_id,
    sm.shift_name,
    sm.productive_mins,
    COALESCE(os.shift_output, 0) AS shift_output,
    COALESCE(wf.headcount, 0) AS shift_headcount,
    COALESCE(wf.available_mins, 0) AS shift_available_mins,
    (wf.shift_id IS NOT NULL) AS has_workforce,
    (COALESCE(os.shift_output, 0) > 0) AS has_output
  FROM base b
  JOIN public.v_shift_minutes sm ON sm.shift_id = b.shift_id
  LEFT JOIN output_shift os
    ON os.factory_id = b.factory_id AND os.order_id = b.order_id
   AND os.department_id = b.department_id AND os.log_date = b.log_date
   AND os.shift_id = b.shift_id
  LEFT JOIN workforce wf
    ON wf.factory_id = b.factory_id AND wf.department_id = b.department_id
   AND wf.log_date = b.log_date AND wf.shift_id = b.shift_id
),
with_flags AS (
  SELECT
    e.*,
    CASE
      WHEN NOT e.has_workforce AND NOT e.has_output THEN 'none'
      WHEN e.has_workforce AND e.has_output THEN 'complete'
      WHEN e.has_workforce THEN 'workforce_only'
      ELSE 'output_only'
    END AS data_completeness
  FROM enriched e
),
prorated AS (
  SELECT
    wf.*,
    t.daily_target,
    SUM(wf.productive_mins) OVER (
      PARTITION BY wf.factory_id, wf.order_id, wf.department_id, wf.log_date
    ) AS active_productive_mins
  FROM with_flags wf
  LEFT JOIN public.v_daily_target t
    ON t.factory_id = wf.factory_id AND t.order_id = wf.order_id
   AND t.department_id = wf.department_id AND t.log_date = wf.log_date
)
SELECT
  p.factory_id,
  p.order_id,
  p.department_id,
  p.log_date,
  p.shift_id,
  p.shift_name,
  p.shift_output,
  p.shift_headcount,
  p.shift_available_mins,
  p.has_workforce,
  p.has_output,
  p.data_completeness,
  CASE
    WHEN p.data_completeness = 'complete' AND COALESCE(p.daily_target, 0) > 0
      THEN ROUND(100.0 * p.shift_output / NULLIF(
        p.daily_target * (p.productive_mins / NULLIF(p.active_productive_mins, 0)), 0))::numeric
    ELSE NULL
  END AS shift_efficiency_pct,
  CASE
    WHEN p.data_completeness = 'complete' AND p.shift_headcount > 0
      THEN ROUND(p.shift_output::numeric / p.shift_headcount, 2)
    ELSE NULL
  END AS shift_productivity
FROM prorated p;

COMMENT ON VIEW public.v_daily_kpis_by_shift IS
  'Shift-level KPIs. Workforce: one row per factory/dept/date/shift_id (source of truth for shift activation). Hourly output shift from hour_slot→hours JSONB; QC from logged_at inference. output_only on OT may mean pending back-fill OR data entry mistake. BACK-FILL SAFE: re-query always reads current tables.';



-- >>> 20260611120000_mes_views_production_and_cut_to_ship.sql
-- Phase 3.5: Filter production KPI views + Cut-to-Ship reconciliation views.
-- Production views exclude departments.is_production = false (Shipment, Quality Audit).
-- Cut-to-ship identity: CUT QTY = SHIPPED + REJECTED + WIP (reconciliation_gap = remainder).

CREATE OR REPLACE FUNCTION public.get_cutting_department_id(p_factory_id uuid)
RETURNS uuid
LANGUAGE sql
STABLE
AS $$
  SELECT COALESCE(
    (
      SELECT d.id
      FROM public.departments d
      JOIN public.process_flow_steps pfs ON pfs.department_id = d.id
      WHERE d.factory_id = p_factory_id AND pfs.flow_step = 1
      ORDER BY d.id
      LIMIT 1
    ),
    (
      SELECT d.id
      FROM public.departments d
      WHERE d.factory_id = p_factory_id AND d.name ILIKE 'cutting'
      ORDER BY d.id
      LIMIT 1
    )
  );
$$;

COMMENT ON FUNCTION public.get_cutting_department_id(uuid) IS
  'Resolves Cutting department: process_flow_steps.flow_step=1 first, else name ILIKE cutting.';

-- -----------------------------------------------------------------------------
-- v_daily_output: production departments only
-- -----------------------------------------------------------------------------
CREATE OR REPLACE VIEW public.v_daily_output AS
WITH hourly AS (
  SELECT
    h.factory_id,
    h.order_id,
    h.department_id,
    h.log_date,
    public.get_shift_for_hour_slot(h.factory_id, h.hour_slot) AS shift_id,
    SUM(h.count)::integer AS output_qty
  FROM public.hourly_counts h
  JOIN public.departments d ON d.id = h.department_id AND d.is_production = true
  GROUP BY
    h.factory_id, h.order_id, h.department_id, h.log_date,
    public.get_shift_for_hour_slot(h.factory_id, h.hour_slot)
),
inspection_rows AS (
  SELECT
    i.factory_id,
    i.order_id,
    i.department_id,
    i.logged_at::date AS log_date,
    public.infer_shift_id_for_inspection(i.factory_id, i.logged_at) AS shift_id,
    i.result
  FROM public.inspections i
  JOIN public.departments d ON d.id = i.department_id AND d.is_production = true
),
inspection AS (
  SELECT
    factory_id, order_id, department_id, log_date, shift_id,
    COUNT(*) FILTER (WHERE result IN ('pass', 'rework_pass'))::integer AS output_qty
  FROM inspection_rows
  GROUP BY factory_id, order_id, department_id, log_date, shift_id
),
keys AS (
  SELECT DISTINCT factory_id, order_id, department_id, log_date FROM hourly
  UNION
  SELECT DISTINCT factory_id, order_id, department_id, log_date FROM inspection
),
mode_pick AS (
  SELECT
    k.factory_id, k.order_id, k.department_id, k.log_date,
    CASE
      WHEN EXISTS (
        SELECT 1 FROM public.hourly_counts h
        JOIN public.departments d ON d.id = h.department_id AND d.is_production = true
        WHERE h.factory_id = k.factory_id AND h.order_id = k.order_id
          AND h.department_id = k.department_id AND h.log_date = k.log_date
      ) THEN 'hourly'
      WHEN EXISTS (
        SELECT 1 FROM public.inspections i
        JOIN public.departments d ON d.id = i.department_id AND d.is_production = true
        WHERE i.factory_id = k.factory_id AND i.order_id = k.order_id
          AND i.department_id = k.department_id AND i.logged_at::date = k.log_date
      ) THEN 'qc'
      ELSE 'none'
    END AS capture_mode
  FROM keys k
)
SELECT
  m.factory_id, m.order_id, m.department_id, m.log_date,
  o.shift_id, o.output_qty, m.capture_mode, (o.shift_id IS NULL) AS is_unallocated
FROM mode_pick m
JOIN LATERAL (
  SELECT h.shift_id, h.output_qty FROM hourly h
  WHERE m.capture_mode = 'hourly'
    AND h.factory_id = m.factory_id AND h.order_id = m.order_id
    AND h.department_id = m.department_id AND h.log_date = m.log_date
  UNION ALL
  SELECT i.shift_id, i.output_qty FROM inspection i
  WHERE m.capture_mode = 'qc'
    AND i.factory_id = m.factory_id AND i.order_id = m.order_id
    AND i.department_id = m.department_id AND i.log_date = m.log_date
) o ON true;

COMMENT ON VIEW public.v_daily_output IS
  'Production dept output only (is_production=true). Hourly: hour_slot→shift; QC: logged_at inference.';

CREATE OR REPLACE VIEW public.v_daily_workforce AS
SELECT
  wl.factory_id, wl.department_id, wl.log_date, wl.shift_id,
  sm.shift_name, sm.productive_mins,
  public.jsonb_sum_int_values(COALESCE(wl.headcount_by_category, '{}'::jsonb))::integer AS headcount,
  (public.jsonb_sum_int_values(COALESCE(wl.headcount_by_category, '{}'::jsonb)) * sm.productive_mins)::numeric AS available_mins
FROM public.workforce_logs wl
JOIN public.departments d ON d.id = wl.department_id AND d.is_production = true
JOIN public.v_shift_minutes sm ON sm.shift_id = wl.shift_id;

COMMENT ON VIEW public.v_daily_workforce IS
  'Production dept workforce only. One row per factory/dept/date/shift_id.';

CREATE OR REPLACE VIEW public.v_daily_quality AS
SELECT
  i.factory_id, i.order_id, i.department_id, i.logged_at::date AS log_date,
  COUNT(*) FILTER (WHERE i.result IN ('pass', 'fail', 'rework_pass'))::integer AS inspected,
  COUNT(*) FILTER (WHERE i.result = 'pass')::integer AS passed,
  COUNT(*) FILTER (WHERE i.result = 'fail')::integer AS failed,
  COUNT(*) FILTER (WHERE i.result = 'rework')::integer AS rework,
  COUNT(*) FILTER (WHERE i.result = 'rework_pass')::integer AS rework_pass,
  CASE
    WHEN COUNT(*) FILTER (WHERE i.result IN ('pass', 'fail', 'rework_pass')) = 0 THEN NULL
    ELSE ROUND(100.0 * COUNT(*) FILTER (WHERE i.result = 'fail')
      / NULLIF(COUNT(*) FILTER (WHERE i.result IN ('pass', 'fail', 'rework_pass')), 0))::numeric
  END AS dhu_pct,
  CASE
    WHEN COUNT(*) FILTER (WHERE i.result IN ('pass', 'fail', 'rework_pass')) = 0 THEN NULL
    ELSE ROUND(100.0 * COUNT(*) FILTER (WHERE i.result IN ('fail', 'rework'))
      / NULLIF(COUNT(*) FILTER (WHERE i.result IN ('pass', 'fail', 'rework_pass')), 0))::numeric
  END AS defective_pct
FROM public.inspections i
JOIN public.departments d ON d.id = i.department_id AND d.is_production = true
GROUP BY i.factory_id, i.order_id, i.department_id, i.logged_at::date;

COMMENT ON VIEW public.v_daily_quality IS
  'Production dept QC metrics only (is_production=true).';

CREATE OR REPLACE VIEW public.v_wip_dept AS
WITH daily_prod AS (
  SELECT factory_id, order_id, department_id, log_date, SUM(output_qty)::integer AS produced
  FROM public.v_daily_output
  GROUP BY factory_id, order_id, department_id, log_date
),
daily_sent AS (
  SELECT
    hs.factory_id, hs.order_id, hs.from_department_id AS department_id,
    hs.sent_at::date AS log_date, SUM(hs.sent_qty)::integer AS sent_qty
  FROM public.handover_slips hs
  JOIN public.departments d ON d.id = hs.from_department_id AND d.is_production = true
  GROUP BY hs.factory_id, hs.order_id, hs.from_department_id, hs.sent_at::date
),
prod_cum AS (
  SELECT factory_id, order_id, department_id, log_date,
    SUM(produced) OVER (PARTITION BY factory_id, order_id, department_id ORDER BY log_date
      ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW)::integer AS cumulative_produced
  FROM daily_prod
),
sent_cum AS (
  SELECT factory_id, order_id, department_id, log_date,
    SUM(sent_qty) OVER (PARTITION BY factory_id, order_id, department_id ORDER BY log_date
      ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW)::integer AS cumulative_sent
  FROM daily_sent
),
dates AS (
  SELECT DISTINCT factory_id, order_id, department_id, log_date FROM daily_prod
  UNION
  SELECT DISTINCT factory_id, order_id, department_id, log_date FROM daily_sent
)
SELECT
  d.factory_id, d.order_id, d.department_id, d.log_date,
  COALESCE(pc.cumulative_produced, 0) AS cumulative_produced,
  COALESCE(sc.cumulative_sent, 0) AS cumulative_sent,
  GREATEST(COALESCE(pc.cumulative_produced, 0) - COALESCE(sc.cumulative_sent, 0), 0)::integer AS wip_qty
FROM dates d
LEFT JOIN prod_cum pc ON pc.factory_id = d.factory_id AND pc.order_id = d.order_id
  AND pc.department_id = d.department_id AND pc.log_date = d.log_date
LEFT JOIN sent_cum sc ON sc.factory_id = d.factory_id AND sc.order_id = d.order_id
  AND sc.department_id = d.department_id AND sc.log_date = d.log_date;

COMMENT ON VIEW public.v_wip_dept IS
  'Production dept WIP only. cumulative produced minus sent from v_daily_output + handover_slips.';

CREATE OR REPLACE VIEW public.v_wip_order AS
WITH order_flow AS (
  SELECT so.id AS order_id, so.factory_id, so.process_flow_id, pfs.flow_step, pfs.department_id
  FROM public.style_orders so
  JOIN public.process_flow_steps pfs ON pfs.flow_id = so.process_flow_id
  JOIN public.departments d ON d.id = pfs.department_id AND d.is_production = true
  WHERE so.process_flow_id IS NOT NULL
),
wip AS (SELECT * FROM public.v_wip_dept)
SELECT
  of.factory_id, of.order_id, w.log_date, of.flow_step, of.department_id,
  COALESCE(w.wip_qty, 0) AS wip_qty
FROM order_flow of
LEFT JOIN wip w ON w.order_id = of.order_id AND w.department_id = of.department_id;

COMMENT ON VIEW public.v_wip_order IS
  'Production dept WIP along process flow (is_production=true steps only).';

CREATE OR REPLACE VIEW public.v_daily_kpis_by_shift AS
WITH output_shift AS (
  SELECT factory_id, order_id, department_id, log_date, shift_id,
    SUM(output_qty)::integer AS shift_output
  FROM public.v_daily_output WHERE shift_id IS NOT NULL
  GROUP BY factory_id, order_id, department_id, log_date, shift_id
),
workforce AS (SELECT * FROM public.v_daily_workforce),
shift_keys AS (
  SELECT factory_id, department_id, log_date, shift_id FROM workforce
  UNION
  SELECT h.factory_id, h.department_id, h.log_date,
    public.get_shift_for_hour_slot(h.factory_id, h.hour_slot) AS shift_id
  FROM public.hourly_counts h
  JOIN public.departments d ON d.id = h.department_id AND d.is_production = true
  WHERE public.get_shift_for_hour_slot(h.factory_id, h.hour_slot) IS NOT NULL
  UNION
  SELECT i.factory_id, i.department_id, i.logged_at::date AS log_date, inf.shift_id
  FROM public.inspections i
  JOIN public.departments d ON d.id = i.department_id AND d.is_production = true
  CROSS JOIN LATERAL (
    SELECT public.infer_shift_id_for_inspection(i.factory_id, i.logged_at) AS shift_id
  ) inf
  WHERE inf.shift_id IS NOT NULL
),
order_keys AS (
  SELECT DISTINCT factory_id, order_id, department_id, log_date FROM public.v_daily_output
  UNION
  SELECT DISTINCT t.factory_id, t.order_id, t.department_id, t.log_date
  FROM public.v_daily_target t
  JOIN public.departments d ON d.id = t.department_id AND d.is_production = true
),
base AS (
  SELECT ok.factory_id, ok.order_id, ok.department_id, ok.log_date, sk.shift_id
  FROM order_keys ok
  JOIN shift_keys sk ON sk.factory_id = ok.factory_id
   AND sk.department_id = ok.department_id AND sk.log_date = ok.log_date
),
enriched AS (
  SELECT b.factory_id, b.order_id, b.department_id, b.log_date, b.shift_id,
    sm.shift_name, sm.productive_mins,
    COALESCE(os.shift_output, 0) AS shift_output,
    COALESCE(wf.headcount, 0) AS shift_headcount,
    COALESCE(wf.available_mins, 0) AS shift_available_mins,
    (wf.shift_id IS NOT NULL) AS has_workforce,
    (COALESCE(os.shift_output, 0) > 0) AS has_output
  FROM base b
  JOIN public.v_shift_minutes sm ON sm.shift_id = b.shift_id
  LEFT JOIN output_shift os ON os.factory_id = b.factory_id AND os.order_id = b.order_id
   AND os.department_id = b.department_id AND os.log_date = b.log_date AND os.shift_id = b.shift_id
  LEFT JOIN workforce wf ON wf.factory_id = b.factory_id AND wf.department_id = b.department_id
   AND wf.log_date = b.log_date AND wf.shift_id = b.shift_id
),
with_flags AS (
  SELECT e.*,
    CASE
      WHEN NOT e.has_workforce AND NOT e.has_output THEN 'none'
      WHEN e.has_workforce AND e.has_output THEN 'complete'
      WHEN e.has_workforce THEN 'workforce_only'
      ELSE 'output_only'
    END AS data_completeness
  FROM enriched e
),
prorated AS (
  SELECT wf.*, t.daily_target,
    SUM(wf.productive_mins) OVER (
      PARTITION BY wf.factory_id, wf.order_id, wf.department_id, wf.log_date
    ) AS active_productive_mins
  FROM with_flags wf
  LEFT JOIN public.v_daily_target t ON t.factory_id = wf.factory_id AND t.order_id = wf.order_id
   AND t.department_id = wf.department_id AND t.log_date = wf.log_date
)
SELECT p.factory_id, p.order_id, p.department_id, p.log_date, p.shift_id, p.shift_name,
  p.shift_output, p.shift_headcount, p.shift_available_mins, p.has_workforce, p.has_output,
  p.data_completeness,
  CASE WHEN p.data_completeness = 'complete' AND COALESCE(p.daily_target, 0) > 0
    THEN ROUND(100.0 * p.shift_output / NULLIF(
      p.daily_target * (p.productive_mins / NULLIF(p.active_productive_mins, 0)), 0))::numeric
    ELSE NULL END AS shift_efficiency_pct,
  CASE WHEN p.data_completeness = 'complete' AND p.shift_headcount > 0
    THEN ROUND(p.shift_output::numeric / p.shift_headcount, 2) ELSE NULL END AS shift_productivity
FROM prorated p;

COMMENT ON VIEW public.v_daily_kpis_by_shift IS
  'Production dept shift KPIs only. Excludes Shipment and Quality Audit pseudo-depts.';

-- v_daily_kpis unchanged structure — inherits production filter via v_daily_kpis_by_shift

-- -----------------------------------------------------------------------------
-- Cut-to-ship building blocks
-- -----------------------------------------------------------------------------

CREATE OR REPLACE VIEW public.v_order_cut_qty AS
WITH captured AS (
  SELECT
    h.factory_id,
    h.order_id,
    h.colorway_id,
    SUM(h.count)::integer AS captured_cut,
    true AS has_capture
  FROM public.hourly_counts h
  WHERE h.department_id = public.get_cutting_department_id(h.factory_id)
  GROUP BY h.factory_id, h.order_id, h.colorway_id
),
order_rows AS (
  SELECT so.factory_id, so.id AS order_id, cw.id AS colorway_id, so.adj_qty
  FROM public.style_orders so
  LEFT JOIN public.colorways cw ON cw.order_id = so.id
)
SELECT
  o.factory_id,
  o.order_id,
  o.colorway_id,
  CASE
    WHEN COALESCE(c.has_capture, false) THEN COALESCE(c.captured_cut, 0)
    ELSE COALESCE(o.adj_qty, 0)
  END::integer AS cut_qty,
  CASE WHEN COALESCE(c.has_capture, false) THEN 'captured' ELSE 'planned' END AS cut_qty_source,
  COALESCE(o.adj_qty, 0)::integer AS cut_qty_fallback
FROM order_rows o
LEFT JOIN captured c ON c.factory_id = o.factory_id AND c.order_id = o.order_id
  AND c.colorway_id IS NOT DISTINCT FROM o.colorway_id;

COMMENT ON VIEW public.v_order_cut_qty IS
  'Cut qty per factory/order/colorway. Primary: SUM hourly_counts in Cutting dept (flow_step=1, else name ILIKE cutting). cut_qty_source=captured when any cutting hourly exists for order/colorway; else planned uses adj_qty fallback.';

CREATE OR REPLACE VIEW public.v_order_shipped_qty AS
SELECT
  s.factory_id,
  s.order_id,
  s.colorway_id,
  SUM(s.shipped_qty)::integer AS shipped_qty,
  MAX(s.shipment_date) AS last_shipment_date,
  COUNT(*)::integer AS shipment_count
FROM public.shipments s
GROUP BY s.factory_id, s.order_id, s.colorway_id;

COMMENT ON VIEW public.v_order_shipped_qty IS
  'Shipped qty aggregates per factory/order/colorway from shipments table.';

CREATE OR REPLACE VIEW public.v_order_rejected_qty AS
WITH base AS (
  SELECT factory_id, order_id, colorway_id, SUM(qty)::integer AS rejected_qty
  FROM public.rejections
  GROUP BY factory_id, order_id, colorway_id
),
reason_agg AS (
  SELECT factory_id, order_id, colorway_id,
    jsonb_object_agg(reason_code, qty_sum) AS rejected_by_reason
  FROM (
    SELECT factory_id, order_id, colorway_id, reason_code, SUM(qty)::integer AS qty_sum
    FROM public.rejections
    GROUP BY factory_id, order_id, colorway_id, reason_code
  ) r
  GROUP BY factory_id, order_id, colorway_id
),
stage_agg AS (
  SELECT factory_id, order_id, colorway_id,
    jsonb_object_agg(stage, qty_sum) AS rejected_by_stage
  FROM (
    SELECT factory_id, order_id, colorway_id, stage, SUM(qty)::integer AS qty_sum
    FROM public.rejections
    GROUP BY factory_id, order_id, colorway_id, stage
  ) s
  GROUP BY factory_id, order_id, colorway_id
)
SELECT
  b.factory_id, b.order_id, b.colorway_id, b.rejected_qty,
  COALESCE(ra.rejected_by_reason, '{}'::jsonb) AS rejected_by_reason,
  COALESCE(sa.rejected_by_stage, '{}'::jsonb) AS rejected_by_stage
FROM base b
LEFT JOIN reason_agg ra ON ra.factory_id = b.factory_id AND ra.order_id = b.order_id
  AND ra.colorway_id IS NOT DISTINCT FROM b.colorway_id
LEFT JOIN stage_agg sa ON sa.factory_id = b.factory_id AND sa.order_id = b.order_id
  AND sa.colorway_id IS NOT DISTINCT FROM b.colorway_id;

COMMENT ON VIEW public.v_order_rejected_qty IS
  'Rejected qty per factory/order/colorway with reason and stage breakdown JSONB.';

CREATE OR REPLACE VIEW public.v_order_wip_total AS
WITH latest_per_dept AS (
  SELECT
    w.factory_id, w.order_id, w.department_id, w.wip_qty,
    ROW_NUMBER() OVER (
      PARTITION BY w.factory_id, w.order_id, w.department_id
      ORDER BY w.log_date DESC NULLS LAST
    ) AS rn
  FROM public.v_wip_order w
)
SELECT
  factory_id,
  order_id,
  NULL::uuid AS colorway_id,
  SUM(wip_qty)::integer AS wip_qty
FROM latest_per_dept
WHERE rn = 1
GROUP BY factory_id, order_id;

COMMENT ON VIEW public.v_order_wip_total IS
  'Order-level WIP: SUM of latest wip_qty per production dept (colorway_id NULL — WIP is order-scoped).';

CREATE OR REPLACE VIEW public.v_cut_to_ship AS
SELECT
  so.factory_id,
  so.id AS order_id,
  cw.id AS colorway_id,
  so.style_name,
  so.buyer_name,
  so.po_number,
  COALESCE(so.adj_qty, so.order_qty, 0)::integer AS order_qty,
  COALESCE(cq.cut_qty, 0)::integer AS cut_qty,
  COALESCE(cq.cut_qty_source, 'planned') AS cut_qty_source,
  COALESCE(sq.shipped_qty, 0)::integer AS shipped_qty,
  COALESCE(rq.rejected_qty, 0)::integer AS rejected_qty,
  COALESCE(wt.wip_qty, 0)::integer AS wip_qty,
  (COALESCE(cq.cut_qty, 0)
    - (COALESCE(sq.shipped_qty, 0) + COALESCE(rq.rejected_qty, 0) + COALESCE(wt.wip_qty, 0)))::integer
    AS reconciliation_gap,
  COALESCE(rq.rejected_by_reason, '{}'::jsonb) AS rejected_by_reason,
  COALESCE(rq.rejected_by_stage, '{}'::jsonb) AS rejected_by_stage,
  (COALESCE(cq.cut_qty, 0)
    = COALESCE(sq.shipped_qty, 0) + COALESCE(rq.rejected_qty, 0) + COALESCE(wt.wip_qty, 0)) AS is_balanced,
  ROUND(100.0 * COALESCE(sq.shipped_qty, 0) / NULLIF(COALESCE(so.adj_qty, so.order_qty, 0), 0), 2) AS completion_pct,
  so.status AS order_status,
  sq.last_shipment_date
FROM public.style_orders so
LEFT JOIN public.colorways cw ON cw.order_id = so.id
LEFT JOIN public.v_order_cut_qty cq
  ON cq.factory_id = so.factory_id AND cq.order_id = so.id
 AND cq.colorway_id IS NOT DISTINCT FROM cw.id
LEFT JOIN public.v_order_shipped_qty sq
  ON sq.factory_id = so.factory_id AND sq.order_id = so.id
 AND sq.colorway_id IS NOT DISTINCT FROM cw.id
LEFT JOIN public.v_order_rejected_qty rq
  ON rq.factory_id = so.factory_id AND rq.order_id = so.id
 AND rq.colorway_id IS NOT DISTINCT FROM cw.id
LEFT JOIN public.v_order_wip_total wt
  ON wt.factory_id = so.factory_id AND wt.order_id = so.id;

COMMENT ON VIEW public.v_cut_to_ship IS
  'Cut-to-ship reconciliation per factory/order/colorway. IDENTITY: CUT QTY = SHIPPED + REJECTED + WIP. reconciliation_gap != 0 means pieces unaccounted for (operational signal). cut_qty_source: captured = SUM cutting hourly_counts; planned = style_orders.adj_qty fallback when no cutting capture. completion_pct = shipped / order_qty * 100.';



-- >>> 20260611130000_mes_colorway_scoped_wip.sql
-- Phase 3.5 correction: WIP at colorway grain.
-- hourly_counts already has colorway_id; extend inspections + handover_slips.

ALTER TABLE public.inspections
  ADD COLUMN IF NOT EXISTS colorway_id uuid REFERENCES public.colorways(id);

ALTER TABLE public.handover_slips
  ADD COLUMN IF NOT EXISTS colorway_id uuid REFERENCES public.colorways(id);

CREATE INDEX IF NOT EXISTS idx_inspections_factory_order_colorway
  ON public.inspections (factory_id, order_id, colorway_id);

CREATE INDEX IF NOT EXISTS idx_handover_slips_factory_order_colorway
  ON public.handover_slips (factory_id, order_id, colorway_id);

COMMENT ON COLUMN public.inspections.colorway_id IS
  'Nullable for legacy rows. New floor captures should set colorwayId.';

COMMENT ON COLUMN public.handover_slips.colorway_id IS
  'Nullable for legacy rows. New floor captures should set colorwayId.';

-- v_daily_output column order changes require drop + recreate dependents.
DROP VIEW IF EXISTS public.v_daily_output CASCADE;

-- -----------------------------------------------------------------------------
-- v_daily_output: add colorway_id grain (KPI views SUM across colorways)
-- -----------------------------------------------------------------------------
CREATE VIEW public.v_daily_output AS
WITH hourly AS (
  SELECT
    h.factory_id,
    h.order_id,
    h.colorway_id,
    h.department_id,
    h.log_date,
    public.get_shift_for_hour_slot(h.factory_id, h.hour_slot) AS shift_id,
    SUM(h.count)::integer AS output_qty
  FROM public.hourly_counts h
  JOIN public.departments d ON d.id = h.department_id AND d.is_production = true
  GROUP BY
    h.factory_id, h.order_id, h.colorway_id, h.department_id, h.log_date,
    public.get_shift_for_hour_slot(h.factory_id, h.hour_slot)
),
inspection_rows AS (
  SELECT
    i.factory_id,
    i.order_id,
    i.colorway_id,
    i.department_id,
    i.logged_at::date AS log_date,
    public.infer_shift_id_for_inspection(i.factory_id, i.logged_at) AS shift_id,
    i.result
  FROM public.inspections i
  JOIN public.departments d ON d.id = i.department_id AND d.is_production = true
),
inspection AS (
  SELECT
    factory_id, order_id, colorway_id, department_id, log_date, shift_id,
    COUNT(*) FILTER (WHERE result IN ('pass', 'rework_pass'))::integer AS output_qty
  FROM inspection_rows
  GROUP BY factory_id, order_id, colorway_id, department_id, log_date, shift_id
),
keys AS (
  SELECT DISTINCT factory_id, order_id, colorway_id, department_id, log_date FROM hourly
  UNION
  SELECT DISTINCT factory_id, order_id, colorway_id, department_id, log_date FROM inspection
),
mode_pick AS (
  SELECT
    k.factory_id, k.order_id, k.colorway_id, k.department_id, k.log_date,
    CASE
      WHEN EXISTS (
        SELECT 1 FROM public.hourly_counts h
        JOIN public.departments d ON d.id = h.department_id AND d.is_production = true
        WHERE h.factory_id = k.factory_id AND h.order_id = k.order_id
          AND h.department_id = k.department_id AND h.log_date = k.log_date
      ) THEN 'hourly'
      WHEN EXISTS (
        SELECT 1 FROM public.inspections i
        JOIN public.departments d ON d.id = i.department_id AND d.is_production = true
        WHERE i.factory_id = k.factory_id AND i.order_id = k.order_id
          AND i.department_id = k.department_id AND i.logged_at::date = k.log_date
      ) THEN 'qc'
      ELSE 'none'
    END AS capture_mode
  FROM keys k
)
SELECT
  m.factory_id, m.order_id, m.colorway_id, m.department_id, m.log_date,
  o.shift_id, o.output_qty, m.capture_mode, (o.shift_id IS NULL) AS is_unallocated
FROM mode_pick m
JOIN LATERAL (
  SELECT h.shift_id, h.output_qty FROM hourly h
  WHERE m.capture_mode = 'hourly'
    AND h.factory_id = m.factory_id AND h.order_id = m.order_id
    AND h.colorway_id IS NOT DISTINCT FROM m.colorway_id
    AND h.department_id = m.department_id AND h.log_date = m.log_date
  UNION ALL
  SELECT i.shift_id, i.output_qty FROM inspection i
  WHERE m.capture_mode = 'qc'
    AND i.factory_id = m.factory_id AND i.order_id = m.order_id
    AND i.colorway_id IS NOT DISTINCT FROM m.colorway_id
    AND i.department_id = m.department_id AND i.log_date = m.log_date
) o ON true;

COMMENT ON VIEW public.v_daily_output IS
  'Production dept output at colorway grain. Legacy rows with NULL colorway_id bucket separately. KPI views SUM across colorways.';

-- Restore KPI views (production-filtered; SUM across colorways)
CREATE VIEW public.v_daily_kpis_by_shift AS
WITH output_shift AS (
  SELECT factory_id, order_id, department_id, log_date, shift_id,
    SUM(output_qty)::integer AS shift_output
  FROM public.v_daily_output WHERE shift_id IS NOT NULL
  GROUP BY factory_id, order_id, department_id, log_date, shift_id
),
workforce AS (SELECT * FROM public.v_daily_workforce),
shift_keys AS (
  SELECT factory_id, department_id, log_date, shift_id FROM workforce
  UNION
  SELECT h.factory_id, h.department_id, h.log_date,
    public.get_shift_for_hour_slot(h.factory_id, h.hour_slot) AS shift_id
  FROM public.hourly_counts h
  JOIN public.departments d ON d.id = h.department_id AND d.is_production = true
  WHERE public.get_shift_for_hour_slot(h.factory_id, h.hour_slot) IS NOT NULL
  UNION
  SELECT i.factory_id, i.department_id, i.logged_at::date AS log_date, inf.shift_id
  FROM public.inspections i
  JOIN public.departments d ON d.id = i.department_id AND d.is_production = true
  CROSS JOIN LATERAL (
    SELECT public.infer_shift_id_for_inspection(i.factory_id, i.logged_at) AS shift_id
  ) inf
  WHERE inf.shift_id IS NOT NULL
),
order_keys AS (
  SELECT DISTINCT factory_id, order_id, department_id, log_date FROM public.v_daily_output
  UNION
  SELECT DISTINCT t.factory_id, t.order_id, t.department_id, t.log_date
  FROM public.v_daily_target t
  JOIN public.departments d ON d.id = t.department_id AND d.is_production = true
),
base AS (
  SELECT ok.factory_id, ok.order_id, ok.department_id, ok.log_date, sk.shift_id
  FROM order_keys ok
  JOIN shift_keys sk ON sk.factory_id = ok.factory_id
   AND sk.department_id = ok.department_id AND sk.log_date = ok.log_date
),
enriched AS (
  SELECT b.factory_id, b.order_id, b.department_id, b.log_date, b.shift_id,
    sm.shift_name, sm.productive_mins,
    COALESCE(os.shift_output, 0) AS shift_output,
    COALESCE(wf.headcount, 0) AS shift_headcount,
    COALESCE(wf.available_mins, 0) AS shift_available_mins,
    (wf.shift_id IS NOT NULL) AS has_workforce,
    (COALESCE(os.shift_output, 0) > 0) AS has_output
  FROM base b
  JOIN public.v_shift_minutes sm ON sm.shift_id = b.shift_id
  LEFT JOIN output_shift os ON os.factory_id = b.factory_id AND os.order_id = b.order_id
   AND os.department_id = b.department_id AND os.log_date = b.log_date AND os.shift_id = b.shift_id
  LEFT JOIN workforce wf ON wf.factory_id = b.factory_id AND wf.department_id = b.department_id
   AND wf.log_date = b.log_date AND wf.shift_id = b.shift_id
),
with_flags AS (
  SELECT e.*,
    CASE
      WHEN NOT e.has_workforce AND NOT e.has_output THEN 'none'
      WHEN e.has_workforce AND e.has_output THEN 'complete'
      WHEN e.has_workforce THEN 'workforce_only'
      ELSE 'output_only'
    END AS data_completeness
  FROM enriched e
),
prorated AS (
  SELECT wf.*, t.daily_target,
    SUM(wf.productive_mins) OVER (
      PARTITION BY wf.factory_id, wf.order_id, wf.department_id, wf.log_date
    ) AS active_productive_mins
  FROM with_flags wf
  LEFT JOIN public.v_daily_target t ON t.factory_id = wf.factory_id AND t.order_id = wf.order_id
   AND t.department_id = wf.department_id AND t.log_date = wf.log_date
)
SELECT p.factory_id, p.order_id, p.department_id, p.log_date, p.shift_id, p.shift_name,
  p.shift_output, p.shift_headcount, p.shift_available_mins, p.has_workforce, p.has_output,
  p.data_completeness,
  CASE WHEN p.data_completeness = 'complete' AND COALESCE(p.daily_target, 0) > 0
    THEN ROUND(100.0 * p.shift_output / NULLIF(
      p.daily_target * (p.productive_mins / NULLIF(p.active_productive_mins, 0)), 0))::numeric
    ELSE NULL END AS shift_efficiency_pct,
  CASE WHEN p.data_completeness = 'complete' AND p.shift_headcount > 0
    THEN ROUND(p.shift_output::numeric / p.shift_headcount, 2) ELSE NULL END AS shift_productivity
FROM prorated p;

COMMENT ON VIEW public.v_daily_kpis_by_shift IS
  'Production dept shift KPIs only. Excludes Shipment and Quality Audit pseudo-depts.';

CREATE VIEW public.v_daily_kpis AS
WITH shift_rows AS (
  SELECT * FROM public.v_daily_kpis_by_shift
),
unalloc AS (
  SELECT factory_id, order_id, department_id, log_date, unallocated_output
  FROM (
    SELECT factory_id, order_id, department_id, log_date,
      SUM(output_qty)::integer AS unallocated_output
    FROM public.v_daily_output
    WHERE shift_id IS NULL
    GROUP BY factory_id, order_id, department_id, log_date
  ) u
),
daily AS (
  SELECT
    sr.factory_id, sr.order_id, sr.department_id, sr.log_date,
    COALESCE(t.daily_target, 0) AS daily_target,
    COALESCE(SUM(sr.shift_output), 0) + COALESCE(MAX(u.unallocated_output), 0) AS daily_output,
    COALESCE(SUM(sr.shift_available_mins) FILTER (
      WHERE sr.data_completeness IN ('complete', 'workforce_only')
    ), 0) AS daily_available_mins,
    COALESCE(SUM(sr.shift_output) FILTER (WHERE sr.data_completeness = 'complete'), 0) AS complete_output,
    COALESCE(SUM(sr.shift_headcount) FILTER (WHERE sr.data_completeness = 'complete'), 0) AS complete_headcount,
    BOOL_OR(sr.data_completeness = 'complete') AS any_complete,
    BOOL_OR(sr.data_completeness = 'output_only') AS any_output_only,
    BOOL_OR(sr.data_completeness = 'workforce_only') AS any_workforce_only,
    BOOL_OR(sr.data_completeness <> 'none') AS any_active
  FROM shift_rows sr
  LEFT JOIN public.v_daily_target t
    ON t.factory_id = sr.factory_id AND t.order_id = sr.order_id
   AND t.department_id = sr.department_id AND t.log_date = sr.log_date
  LEFT JOIN unalloc u
    ON u.factory_id = sr.factory_id AND u.order_id = sr.order_id
   AND u.department_id = sr.department_id AND u.log_date = sr.log_date
  GROUP BY sr.factory_id, sr.order_id, sr.department_id, sr.log_date, t.daily_target
)
SELECT
  d.factory_id, d.order_id, d.department_id, d.log_date, d.daily_target, d.daily_output,
  d.daily_available_mins,
  CASE WHEN d.daily_target > 0 AND d.complete_output > 0
    THEN ROUND(100.0 * d.complete_output / d.daily_target)::numeric ELSE NULL END AS daily_efficiency_pct,
  CASE WHEN d.complete_headcount > 0
    THEN ROUND(d.complete_output::numeric / d.complete_headcount, 2) ELSE NULL END AS daily_productivity,
  CASE
    WHEN NOT d.any_active THEN 'none'
    WHEN d.any_complete AND NOT d.any_output_only AND NOT d.any_workforce_only THEN 'complete'
    WHEN d.any_complete THEN 'partial'
    WHEN d.any_output_only AND NOT d.any_workforce_only THEN 'output_only'
    WHEN d.any_workforce_only AND NOT d.any_output_only THEN 'workforce_only'
    ELSE 'none'
  END AS day_completeness,
  (
    SELECT COALESCE(jsonb_agg(jsonb_build_object(
      'shift_id', s.shift_id, 'shift_name', s.shift_name, 'shift_output', s.shift_output,
      'shift_headcount', s.shift_headcount, 'data_completeness', s.data_completeness
    ) ORDER BY s.shift_name), '[]'::jsonb)
    FROM public.v_daily_kpis_by_shift s
    WHERE s.factory_id = d.factory_id AND s.order_id = d.order_id
      AND s.department_id = d.department_id AND s.log_date = d.log_date
  ) AS shift_breakdown
FROM daily d;

COMMENT ON VIEW public.v_daily_kpis IS
  'Daily KPI rollup from shift rows. Aggregates output across colorways.';

-- -----------------------------------------------------------------------------
-- WIP views at colorway grain
-- -----------------------------------------------------------------------------
CREATE VIEW public.v_wip_dept AS
WITH daily_prod AS (
  SELECT factory_id, order_id, colorway_id, department_id, log_date,
    SUM(output_qty)::integer AS produced
  FROM public.v_daily_output
  GROUP BY factory_id, order_id, colorway_id, department_id, log_date
),
daily_sent AS (
  SELECT
    hs.factory_id, hs.order_id, hs.colorway_id, hs.from_department_id AS department_id,
    hs.sent_at::date AS log_date, SUM(hs.sent_qty)::integer AS sent_qty
  FROM public.handover_slips hs
  JOIN public.departments d ON d.id = hs.from_department_id AND d.is_production = true
  GROUP BY hs.factory_id, hs.order_id, hs.colorway_id, hs.from_department_id, hs.sent_at::date
),
prod_cum AS (
  SELECT factory_id, order_id, colorway_id, department_id, log_date,
    SUM(produced) OVER (
      PARTITION BY factory_id, order_id, colorway_id, department_id ORDER BY log_date
      ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
    )::integer AS cumulative_produced
  FROM daily_prod
),
sent_cum AS (
  SELECT factory_id, order_id, colorway_id, department_id, log_date,
    SUM(sent_qty) OVER (
      PARTITION BY factory_id, order_id, colorway_id, department_id ORDER BY log_date
      ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
    )::integer AS cumulative_sent
  FROM daily_sent
),
dates AS (
  SELECT DISTINCT factory_id, order_id, colorway_id, department_id, log_date FROM daily_prod
  UNION
  SELECT DISTINCT factory_id, order_id, colorway_id, department_id, log_date FROM daily_sent
)
SELECT
  d.factory_id, d.order_id, d.colorway_id, d.department_id, d.log_date,
  COALESCE(pc.cumulative_produced, 0) AS cumulative_produced,
  COALESCE(sc.cumulative_sent, 0) AS cumulative_sent,
  GREATEST(COALESCE(pc.cumulative_produced, 0) - COALESCE(sc.cumulative_sent, 0), 0)::integer AS wip_qty
FROM dates d
LEFT JOIN prod_cum pc ON pc.factory_id = d.factory_id AND pc.order_id = d.order_id
  AND pc.colorway_id IS NOT DISTINCT FROM d.colorway_id
  AND pc.department_id = d.department_id AND pc.log_date = d.log_date
LEFT JOIN sent_cum sc ON sc.factory_id = d.factory_id AND sc.order_id = d.order_id
  AND sc.colorway_id IS NOT DISTINCT FROM d.colorway_id
  AND sc.department_id = d.department_id AND sc.log_date = d.log_date;

COMMENT ON VIEW public.v_wip_dept IS
  'Production dept WIP at colorway grain. produced from v_daily_output; sent from handover_slips. wip_qty = cumulative produced − cumulative sent. Legacy capture rows with NULL colorway_id are bucketed under colorway_id = NULL — surface separately for data cleanup.';

CREATE VIEW public.v_wip_order AS
WITH order_flow AS (
  SELECT so.id AS order_id, so.factory_id, so.process_flow_id, pfs.flow_step, pfs.department_id
  FROM public.style_orders so
  JOIN public.process_flow_steps pfs ON pfs.flow_id = so.process_flow_id
  JOIN public.departments d ON d.id = pfs.department_id AND d.is_production = true
  WHERE so.process_flow_id IS NOT NULL
),
order_colorways AS (
  SELECT so.factory_id, so.id AS order_id, cw.id AS colorway_id
  FROM public.style_orders so
  LEFT JOIN public.colorways cw ON cw.order_id = so.id
),
wip AS (SELECT * FROM public.v_wip_dept)
SELECT
  of.factory_id, of.order_id, oc.colorway_id, w.log_date, of.flow_step, of.department_id,
  COALESCE(w.wip_qty, 0) AS wip_qty
FROM order_flow of
JOIN order_colorways oc ON oc.order_id = of.order_id AND oc.factory_id = of.factory_id
LEFT JOIN wip w ON w.order_id = of.order_id AND w.department_id = of.department_id
  AND w.colorway_id IS NOT DISTINCT FROM oc.colorway_id;

COMMENT ON VIEW public.v_wip_order IS
  'Production dept WIP along process flow at colorway grain.';

CREATE VIEW public.v_order_wip_total AS
WITH latest_per_dept AS (
  SELECT
    w.factory_id, w.order_id, w.colorway_id, w.department_id, w.wip_qty,
    ROW_NUMBER() OVER (
      PARTITION BY w.factory_id, w.order_id, w.colorway_id, w.department_id
      ORDER BY w.log_date DESC NULLS LAST
    ) AS rn
  FROM public.v_wip_order w
)
SELECT
  factory_id,
  order_id,
  colorway_id,
  SUM(wip_qty)::integer AS wip_qty
FROM latest_per_dept
WHERE rn = 1
GROUP BY factory_id, order_id, colorway_id;

COMMENT ON VIEW public.v_order_wip_total IS
  'Colorway-level WIP: SUM of latest wip_qty per production dept. Order-level WIP = SUM of colorway rows.';

CREATE VIEW public.v_cut_to_ship AS
SELECT
  so.factory_id,
  so.id AS order_id,
  cw.id AS colorway_id,
  so.style_name,
  so.buyer_name,
  so.po_number,
  COALESCE(so.adj_qty, so.order_qty, 0)::integer AS order_qty,
  COALESCE(cq.cut_qty, 0)::integer AS cut_qty,
  COALESCE(cq.cut_qty_source, 'planned') AS cut_qty_source,
  COALESCE(sq.shipped_qty, 0)::integer AS shipped_qty,
  COALESCE(rq.rejected_qty, 0)::integer AS rejected_qty,
  COALESCE(wt.wip_qty, 0)::integer AS wip_qty,
  (COALESCE(cq.cut_qty, 0)
    - (COALESCE(sq.shipped_qty, 0) + COALESCE(rq.rejected_qty, 0) + COALESCE(wt.wip_qty, 0)))::integer
    AS reconciliation_gap,
  COALESCE(rq.rejected_by_reason, '{}'::jsonb) AS rejected_by_reason,
  COALESCE(rq.rejected_by_stage, '{}'::jsonb) AS rejected_by_stage,
  (COALESCE(cq.cut_qty, 0)
    = COALESCE(sq.shipped_qty, 0) + COALESCE(rq.rejected_qty, 0) + COALESCE(wt.wip_qty, 0)) AS is_balanced,
  ROUND(100.0 * COALESCE(sq.shipped_qty, 0) / NULLIF(COALESCE(so.adj_qty, so.order_qty, 0), 0), 2) AS completion_pct,
  so.status AS order_status,
  sq.last_shipment_date
FROM public.style_orders so
LEFT JOIN public.colorways cw ON cw.order_id = so.id
LEFT JOIN public.v_order_cut_qty cq
  ON cq.factory_id = so.factory_id AND cq.order_id = so.id
 AND cq.colorway_id IS NOT DISTINCT FROM cw.id
LEFT JOIN public.v_order_shipped_qty sq
  ON sq.factory_id = so.factory_id AND sq.order_id = so.id
 AND sq.colorway_id IS NOT DISTINCT FROM cw.id
LEFT JOIN public.v_order_rejected_qty rq
  ON rq.factory_id = so.factory_id AND rq.order_id = so.id
 AND rq.colorway_id IS NOT DISTINCT FROM cw.id
LEFT JOIN public.v_order_wip_total wt
  ON wt.factory_id = so.factory_id AND wt.order_id = so.id
 AND wt.colorway_id IS NOT DISTINCT FROM cw.id;

COMMENT ON VIEW public.v_cut_to_ship IS
  'Cut-to-ship reconciliation per factory/order/colorway. IDENTITY: CUT QTY = SHIPPED + REJECTED + WIP (colorway-scoped). reconciliation_gap != 0 means pieces unaccounted for.';



-- >>> 20260611140000_mes_cut_to_ship_views_v2.sql
-- Phase 3.5 correction: deterministic per-order Cutting dept identification.

CREATE OR REPLACE FUNCTION public.get_cutting_department_id_for_order(p_order_id uuid)
RETURNS uuid
LANGUAGE sql
STABLE
AS $$
  SELECT COALESCE(
    (
      SELECT pfs.department_id
      FROM public.style_orders so
      JOIN public.process_flow_steps pfs
        ON pfs.flow_id = so.process_flow_id AND pfs.flow_step = 1
      WHERE so.id = p_order_id
      LIMIT 1
    ),
    (
      SELECT d.id
      FROM public.style_orders so
      JOIN public.departments d
        ON d.factory_id = so.factory_id
       AND d.name ILIKE 'cutting'
       AND d.is_production = true
      WHERE so.id = p_order_id
      ORDER BY d.id
      LIMIT 1
    )
  );
$$;

COMMENT ON FUNCTION public.get_cutting_department_id_for_order(uuid) IS
  'Per-order Cutting dept resolution (priority order):
   1) process_flow_steps.flow_step = 1 for the order''s process_flow_id (authoritative first step).
   2) Else departments.name ILIKE ''cutting'' AND is_production = true for the order''s factory.
   3) Returns NULL when neither applies — caller should set cut_qty = 0, cut_qty_source = ''no_cutting_dept''.';

CREATE OR REPLACE VIEW public.v_order_cut_qty AS
WITH order_cutting AS (
  SELECT
    so.factory_id,
    so.id AS order_id,
    public.get_cutting_department_id_for_order(so.id) AS cutting_department_id
  FROM public.style_orders so
),
captured AS (
  SELECT
    h.factory_id,
    h.order_id,
    h.colorway_id,
    SUM(h.count)::integer AS captured_cut,
    true AS has_capture
  FROM public.hourly_counts h
  JOIN order_cutting oc ON oc.order_id = h.order_id AND oc.factory_id = h.factory_id
  WHERE oc.cutting_department_id IS NOT NULL
    AND h.department_id = oc.cutting_department_id
  GROUP BY h.factory_id, h.order_id, h.colorway_id
),
order_rows AS (
  SELECT so.factory_id, so.id AS order_id, cw.id AS colorway_id, so.adj_qty,
    oc.cutting_department_id
  FROM public.style_orders so
  LEFT JOIN public.colorways cw ON cw.order_id = so.id
  LEFT JOIN order_cutting oc ON oc.order_id = so.id
)
SELECT
  o.factory_id,
  o.order_id,
  o.colorway_id,
  CASE
    WHEN o.cutting_department_id IS NULL THEN 0
    WHEN COALESCE(c.has_capture, false) THEN COALESCE(c.captured_cut, 0)
    ELSE COALESCE(o.adj_qty, 0)
  END::integer AS cut_qty,
  CASE
    WHEN o.cutting_department_id IS NULL THEN 'no_cutting_dept'
    WHEN COALESCE(c.has_capture, false) THEN 'captured'
    ELSE 'planned'
  END AS cut_qty_source,
  COALESCE(o.adj_qty, 0)::integer AS cut_qty_fallback
FROM order_rows o
LEFT JOIN captured c ON c.factory_id = o.factory_id AND c.order_id = o.order_id
  AND c.colorway_id IS NOT DISTINCT FROM o.colorway_id;

COMMENT ON VIEW public.v_order_cut_qty IS
  'Cut qty per factory/order/colorway. CUTTING DEPT RULE (deterministic, per order):
   1) process_flow_steps.flow_step = 1 for this order''s process_flow_id — authoritative first step.
   2) If no flow_step = 1 on that flow, fall back to departments WHERE name ILIKE ''cutting''
      AND is_production = true AND factory_id matches the order.
   3) If neither finds a dept: cut_qty = 0, cut_qty_source = ''no_cutting_dept'' (setup incomplete).
   When a cutting dept exists: cut_qty_source = captured when hourly_counts exist for that dept/colorway;
   else planned uses style_orders.adj_qty fallback.';

CREATE OR REPLACE VIEW public.v_factories_missing_flow_step_one AS
SELECT
  pf.factory_id,
  pf.id AS process_flow_id,
  pf.name AS process_flow_name,
  pf.is_current
FROM public.process_flows pf
WHERE NOT EXISTS (
  SELECT 1
  FROM public.process_flow_steps pfs
  WHERE pfs.flow_id = pf.id AND pfs.flow_step = 1
);

COMMENT ON VIEW public.v_factories_missing_flow_step_one IS
  'Setup health check: process flows with no flow_step = 1. Orders on these flows cannot resolve Cutting via rule 1.';



-- >>> 20260611150000_hourly_counts_slot_unique_with_colorway.sql
-- PRE-FIX 1: Include colorway_id in hourly_counts slot uniqueness.
-- Diagnostic (2026-06-08): hourly_counts had 0 rows — no conflicts on index rebuild.

DROP INDEX IF EXISTS public.hourly_counts_slot_unique;

CREATE UNIQUE INDEX hourly_counts_slot_unique
  ON public.hourly_counts (
    factory_id,
    order_id,
    department_id,
    COALESCE(colorway_id, '00000000-0000-0000-0000-000000000000'::uuid),
    hour_slot,
    log_date
  );

COMMENT ON INDEX public.hourly_counts_slot_unique IS
  'One hourly capture per factory/order/dept/colorway/slot/date. NULL colorway_id uses sentinel UUID for uniqueness.';

-- floor_capture hourly_upsert: match lookup key to the unique index (include colorwayId).


-- >>> 20260612115000_mes_quality_dhu_semantics_fix.sql
-- Phase 9b correction: DHU and defective % semantics for QC capture only.
-- DHU = round(100 * total_defects_found / inspected_pieces) — displayed as a number, not %.
-- defective_pct = round(100 * defective_pieces / inspected_pieces) where defective = fail + rework.
-- Only departments with qc_log app; hourly-only depts get NULL.

DROP FUNCTION IF EXISTS public.get_live_dept_kpi(uuid, uuid);
DROP FUNCTION IF EXISTS public.get_factory_kpis(uuid, date, date);
DROP FUNCTION IF EXISTS public.get_department_kpis(uuid, uuid, date, date);
DROP FUNCTION IF EXISTS public.get_style_kpis(uuid, uuid);
DROP FUNCTION IF EXISTS public.get_department_kpis_by_shift(uuid, uuid, date, date);
DROP FUNCTION IF EXISTS public.get_dept_quality_for_date(uuid, uuid, date);

DROP VIEW IF EXISTS public.v_daily_kpis;
DROP VIEW IF EXISTS public.v_daily_kpis_by_shift;
DROP VIEW IF EXISTS public.v_daily_quality;

CREATE VIEW public.v_daily_quality AS
SELECT
  i.factory_id,
  i.order_id,
  i.department_id,
  i.logged_at::date AS log_date,
  COUNT(*) FILTER (WHERE i.result IN ('pass', 'fail', 'rework_pass'))::integer AS inspected,
  COUNT(*) FILTER (WHERE i.result = 'pass')::integer AS passed,
  COUNT(*) FILTER (WHERE i.result = 'fail')::integer AS failed,
  COUNT(*) FILTER (WHERE i.result = 'rework')::integer AS rework,
  COUNT(*) FILTER (WHERE i.result = 'rework_pass')::integer AS rework_pass,
  CASE
    WHEN COUNT(*) FILTER (WHERE i.result IN ('pass', 'fail', 'rework_pass')) = 0 THEN NULL
    ELSE ROUND(
      100.0 * SUM(COALESCE(jsonb_array_length(i.defects), 0))
      / NULLIF(COUNT(*) FILTER (WHERE i.result IN ('pass', 'fail', 'rework_pass')), 0)
    )::numeric
  END AS dhu,
  CASE
    WHEN COUNT(*) FILTER (WHERE i.result IN ('pass', 'fail', 'rework_pass')) = 0 THEN NULL
    ELSE ROUND(
      100.0 * COUNT(*) FILTER (WHERE i.result IN ('fail', 'rework'))
      / NULLIF(COUNT(*) FILTER (WHERE i.result IN ('pass', 'fail', 'rework_pass')), 0)
    )::numeric
  END AS defective_pct
FROM public.inspections i
JOIN public.departments d ON d.id = i.department_id
  AND COALESCE(d.apps, '[]'::jsonb) @> '["qc_log"]'::jsonb
GROUP BY i.factory_id, i.order_id, i.department_id, i.logged_at::date;

COMMENT ON VIEW public.v_daily_quality IS
  'QC dept metrics from inspections (qc_log app only). inspected = pass+fail+rework_pass. dhu = defects per hundred units (number). defective_pct = % of pieces that were fail or rework.';

CREATE VIEW public.v_daily_kpis_by_shift AS
WITH output_shift AS (
  SELECT factory_id, order_id, department_id, log_date, shift_id,
    SUM(output_qty)::integer AS shift_output
  FROM public.v_daily_output WHERE shift_id IS NOT NULL
  GROUP BY factory_id, order_id, department_id, log_date, shift_id
),
workforce AS (SELECT * FROM public.v_daily_workforce),
shift_quality AS (
  SELECT
    i.factory_id,
    i.order_id,
    i.department_id,
    i.logged_at::date AS log_date,
    inf.shift_id,
    COUNT(*) FILTER (WHERE i.result IN ('pass', 'fail', 'rework_pass'))::integer AS inspected,
    SUM(COALESCE(jsonb_array_length(i.defects), 0))::integer AS total_defects,
    COUNT(*) FILTER (WHERE i.result IN ('fail', 'rework'))::integer AS defective_pieces
  FROM public.inspections i
  JOIN public.departments d ON d.id = i.department_id
    AND COALESCE(d.apps, '[]'::jsonb) @> '["qc_log"]'::jsonb
  CROSS JOIN LATERAL (
    SELECT public.infer_shift_id_for_inspection(i.factory_id, i.logged_at) AS shift_id
  ) inf
  WHERE inf.shift_id IS NOT NULL
  GROUP BY i.factory_id, i.order_id, i.department_id, i.logged_at::date, inf.shift_id
),
shift_keys AS (
  SELECT factory_id, department_id, log_date, shift_id FROM workforce
  UNION
  SELECT h.factory_id, h.department_id, h.log_date,
    public.get_shift_for_hour_slot(h.factory_id, h.hour_slot) AS shift_id
  FROM public.hourly_counts h
  JOIN public.departments d ON d.id = h.department_id AND d.is_production = true
  WHERE public.get_shift_for_hour_slot(h.factory_id, h.hour_slot) IS NOT NULL
  UNION
  SELECT i.factory_id, i.department_id, i.logged_at::date AS log_date, inf.shift_id
  FROM public.inspections i
  JOIN public.departments d ON d.id = i.department_id AND d.is_production = true
  CROSS JOIN LATERAL (
    SELECT public.infer_shift_id_for_inspection(i.factory_id, i.logged_at) AS shift_id
  ) inf
  WHERE inf.shift_id IS NOT NULL
),
order_keys AS (
  SELECT DISTINCT factory_id, order_id, department_id, log_date FROM public.v_daily_output
  UNION
  SELECT DISTINCT t.factory_id, t.order_id, t.department_id, t.log_date
  FROM public.v_daily_target t
  JOIN public.departments d ON d.id = t.department_id AND d.is_production = true
),
base AS (
  SELECT ok.factory_id, ok.order_id, ok.department_id, ok.log_date, sk.shift_id
  FROM order_keys ok
  JOIN shift_keys sk ON sk.factory_id = ok.factory_id
   AND sk.department_id = ok.department_id AND sk.log_date = ok.log_date
),
enriched AS (
  SELECT b.factory_id, b.order_id, b.department_id, b.log_date, b.shift_id,
    sm.shift_name, sm.productive_mins,
    COALESCE(os.shift_output, 0) AS shift_output,
    COALESCE(wf.headcount, 0) AS shift_headcount,
    COALESCE(wf.available_mins, 0) AS shift_available_mins,
    (wf.shift_id IS NOT NULL) AS has_workforce,
    (COALESCE(os.shift_output, 0) > 0) AS has_output
  FROM base b
  JOIN public.v_shift_minutes sm ON sm.shift_id = b.shift_id
  LEFT JOIN output_shift os ON os.factory_id = b.factory_id AND os.order_id = b.order_id
   AND os.department_id = b.department_id AND os.log_date = b.log_date AND os.shift_id = b.shift_id
  LEFT JOIN workforce wf ON wf.factory_id = b.factory_id AND wf.department_id = b.department_id
   AND wf.log_date = b.log_date AND wf.shift_id = b.shift_id
),
with_flags AS (
  SELECT e.*,
    CASE
      WHEN NOT e.has_workforce AND NOT e.has_output THEN 'none'
      WHEN e.has_workforce AND e.has_output THEN 'complete'
      WHEN e.has_workforce THEN 'workforce_only'
      ELSE 'output_only'
    END AS data_completeness
  FROM enriched e
),
prorated AS (
  SELECT wf.*, t.daily_target,
    SUM(wf.productive_mins) OVER (
      PARTITION BY wf.factory_id, wf.order_id, wf.department_id, wf.log_date
    ) AS active_productive_mins
  FROM with_flags wf
  LEFT JOIN public.v_daily_target t ON t.factory_id = wf.factory_id AND t.order_id = wf.order_id
   AND t.department_id = wf.department_id AND t.log_date = wf.log_date
)
SELECT
  p.factory_id, p.order_id, p.department_id, p.log_date, p.shift_id, p.shift_name,
  p.shift_output, p.shift_headcount, p.shift_available_mins, p.has_workforce, p.has_output,
  p.data_completeness,
  CASE WHEN p.data_completeness = 'complete' AND COALESCE(p.daily_target, 0) > 0
    THEN ROUND(100.0 * p.shift_output / NULLIF(
      p.daily_target * (p.productive_mins / NULLIF(p.active_productive_mins, 0)), 0))::numeric
    ELSE NULL END AS shift_efficiency_pct,
  CASE WHEN p.data_completeness = 'complete' AND p.shift_headcount > 0
    THEN ROUND(p.shift_output::numeric / p.shift_headcount, 2) ELSE NULL END AS shift_productivity,
  CASE WHEN COALESCE(sq.inspected, 0) > 0
    THEN ROUND(100.0 * sq.total_defects / sq.inspected)::numeric ELSE NULL END AS dhu,
  CASE WHEN COALESCE(sq.inspected, 0) > 0
    THEN ROUND(100.0 * sq.defective_pieces / sq.inspected)::numeric ELSE NULL END AS defective_pct
FROM prorated p
LEFT JOIN shift_quality sq
  ON sq.factory_id = p.factory_id AND sq.order_id = p.order_id
 AND sq.department_id = p.department_id AND sq.log_date = p.log_date
 AND sq.shift_id = p.shift_id;

COMMENT ON VIEW public.v_daily_kpis_by_shift IS
  'Production dept shift KPIs. dhu/defective_pct from QC inspections only (qc_log depts). No shift WIP.';

CREATE VIEW public.v_daily_kpis AS
WITH shift_rows AS (
  SELECT * FROM public.v_daily_kpis_by_shift
),
unalloc AS (
  SELECT factory_id, order_id, department_id, log_date, unallocated_output
  FROM (
    SELECT factory_id, order_id, department_id, log_date,
      SUM(output_qty)::integer AS unallocated_output
    FROM public.v_daily_output
    WHERE shift_id IS NULL
    GROUP BY factory_id, order_id, department_id, log_date
  ) u
),
wip_daily AS (
  SELECT factory_id, order_id, department_id, log_date,
    SUM(wip_qty)::integer AS wip_qty
  FROM public.v_wip_dept
  GROUP BY factory_id, order_id, department_id, log_date
),
daily AS (
  SELECT
    sr.factory_id, sr.order_id, sr.department_id, sr.log_date,
    COALESCE(t.daily_target, 0) AS daily_target,
    COALESCE(SUM(sr.shift_output), 0) + COALESCE(MAX(u.unallocated_output), 0) AS daily_output,
    COALESCE(SUM(sr.shift_available_mins) FILTER (
      WHERE sr.data_completeness IN ('complete', 'workforce_only')
    ), 0) AS daily_available_mins,
    COALESCE(SUM(sr.shift_output) FILTER (WHERE sr.data_completeness = 'complete'), 0) AS complete_output,
    COALESCE(SUM(sr.shift_headcount) FILTER (WHERE sr.data_completeness = 'complete'), 0) AS complete_headcount,
    BOOL_OR(sr.data_completeness = 'complete') AS any_complete,
    BOOL_OR(sr.data_completeness = 'output_only') AS any_output_only,
    BOOL_OR(sr.data_completeness = 'workforce_only') AS any_workforce_only,
    BOOL_OR(sr.data_completeness <> 'none') AS any_active
  FROM shift_rows sr
  LEFT JOIN public.v_daily_target t
    ON t.factory_id = sr.factory_id AND t.order_id = sr.order_id
   AND t.department_id = sr.department_id AND t.log_date = sr.log_date
  LEFT JOIN unalloc u
    ON u.factory_id = sr.factory_id AND u.order_id = sr.order_id
   AND u.department_id = sr.department_id AND u.log_date = sr.log_date
  GROUP BY sr.factory_id, sr.order_id, sr.department_id, sr.log_date, t.daily_target
)
SELECT
  d.factory_id, d.order_id, d.department_id, d.log_date, d.daily_target, d.daily_output,
  d.daily_available_mins,
  CASE WHEN d.daily_target > 0 AND d.complete_output > 0
    THEN ROUND(100.0 * d.complete_output / d.daily_target)::numeric ELSE NULL END AS daily_efficiency_pct,
  CASE WHEN d.complete_headcount > 0
    THEN ROUND(d.complete_output::numeric / d.complete_headcount, 2) ELSE NULL END AS daily_productivity,
  CASE
    WHEN NOT d.any_active THEN 'none'
    WHEN d.any_complete AND NOT d.any_output_only AND NOT d.any_workforce_only THEN 'complete'
    WHEN d.any_complete THEN 'partial'
    WHEN d.any_output_only AND NOT d.any_workforce_only THEN 'output_only'
    WHEN d.any_workforce_only AND NOT d.any_output_only THEN 'workforce_only'
    ELSE 'none'
  END AS day_completeness,
  q.dhu,
  q.defective_pct,
  COALESCE(w.wip_qty, 0) AS wip_qty,
  (
    SELECT COALESCE(jsonb_agg(jsonb_build_object(
      'shift_id', s.shift_id, 'shift_name', s.shift_name, 'shift_output', s.shift_output,
      'shift_headcount', s.shift_headcount, 'data_completeness', s.data_completeness
    ) ORDER BY s.shift_name), '[]'::jsonb)
    FROM public.v_daily_kpis_by_shift s
    WHERE s.factory_id = d.factory_id AND s.order_id = d.order_id
      AND s.department_id = d.department_id AND s.log_date = d.log_date
  ) AS shift_breakdown
FROM daily d
LEFT JOIN public.v_daily_quality q
  ON q.factory_id = d.factory_id AND q.order_id = d.order_id
 AND q.department_id = d.department_id AND q.log_date = d.log_date
LEFT JOIN wip_daily w
  ON w.factory_id = d.factory_id AND w.order_id = d.order_id
 AND w.department_id = d.department_id AND w.log_date = d.log_date;

COMMENT ON VIEW public.v_daily_kpis IS
  'Daily KPI rollup. dhu from v_daily_quality (QC only, defect-count based). defective_pct = % defective pieces. wip_qty = end-of-day WIP summed across colorways.';

CREATE OR REPLACE FUNCTION public.get_factory_kpis(
  p_factory_id uuid, p_date_from date, p_date_to date
)
RETURNS SETOF public.v_daily_kpis
LANGUAGE sql STABLE SECURITY INVOKER SET search_path = public
AS $$
  SELECT * FROM public.v_daily_kpis
  WHERE factory_id = p_factory_id AND log_date >= p_date_from AND log_date <= p_date_to
  ORDER BY log_date, department_id, order_id;
$$;

CREATE OR REPLACE FUNCTION public.get_department_kpis(
  p_factory_id uuid, p_department_id uuid, p_date_from date, p_date_to date
)
RETURNS SETOF public.v_daily_kpis
LANGUAGE sql STABLE SECURITY INVOKER SET search_path = public
AS $$
  SELECT * FROM public.v_daily_kpis
  WHERE factory_id = p_factory_id AND department_id = p_department_id
    AND log_date >= p_date_from AND log_date <= p_date_to
  ORDER BY log_date, order_id;
$$;

CREATE OR REPLACE FUNCTION public.get_department_kpis_by_shift(
  p_factory_id uuid, p_department_id uuid, p_date_from date, p_date_to date
)
RETURNS SETOF public.v_daily_kpis_by_shift
LANGUAGE sql STABLE SECURITY INVOKER SET search_path = public
AS $$
  SELECT * FROM public.v_daily_kpis_by_shift
  WHERE factory_id = p_factory_id AND department_id = p_department_id
    AND log_date >= p_date_from AND log_date <= p_date_to
  ORDER BY log_date, shift_name, order_id;
$$;

CREATE OR REPLACE FUNCTION public.get_style_kpis(p_factory_id uuid, p_order_id uuid)
RETURNS SETOF public.v_daily_kpis
LANGUAGE sql STABLE SECURITY INVOKER SET search_path = public
AS $$
  SELECT k.*
  FROM public.v_daily_kpis k
  JOIN public.style_orders so ON so.id = k.order_id AND so.factory_id = k.factory_id
  WHERE k.factory_id = p_factory_id AND k.order_id = p_order_id
    AND (
      so.process_flow_id IS NULL
      OR k.department_id IN (
        SELECT pfs.department_id FROM public.process_flow_steps pfs
        WHERE pfs.flow_id = so.process_flow_id
      )
    )
  ORDER BY k.log_date, k.department_id;
$$;

CREATE OR REPLACE FUNCTION public.get_live_dept_kpi(p_factory_id uuid, p_department_id uuid)
RETURNS SETOF public.v_daily_kpis
LANGUAGE sql STABLE SECURITY INVOKER SET search_path = public
AS $$
  SELECT * FROM public.v_daily_kpis
  WHERE factory_id = p_factory_id AND department_id = p_department_id
    AND log_date = CURRENT_DATE
  ORDER BY order_id;
$$;

COMMENT ON FUNCTION public.get_factory_kpis(uuid, date, date) IS
  'Factory daily KPIs. Includes dhu (QC defect count per hundred), defective_pct, wip_qty.';
COMMENT ON FUNCTION public.get_department_kpis(uuid, uuid, date, date) IS
  'Department daily KPIs. Includes dhu, defective_pct, wip_qty.';
COMMENT ON FUNCTION public.get_department_kpis_by_shift(uuid, uuid, date, date) IS
  'Department shift KPIs. Includes shift-level dhu and defective_pct (QC only).';
COMMENT ON FUNCTION public.get_style_kpis(uuid, uuid) IS
  'Order KPIs for process-flow departments. Includes dhu, defective_pct, wip_qty.';
COMMENT ON FUNCTION public.get_live_dept_kpi(uuid, uuid) IS
  'Today department KPI rows for floor display. Includes dhu, defective_pct, wip_qty.';

REVOKE ALL ON FUNCTION public.get_factory_kpis(uuid, date, date) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.get_department_kpis(uuid, uuid, date, date) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.get_department_kpis_by_shift(uuid, uuid, date, date) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.get_style_kpis(uuid, uuid) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.get_live_dept_kpi(uuid, uuid) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.get_factory_kpis(uuid, date, date) TO authenticated;
GRANT EXECUTE ON FUNCTION public.get_department_kpis(uuid, uuid, date, date) TO authenticated;
GRANT EXECUTE ON FUNCTION public.get_department_kpis_by_shift(uuid, uuid, date, date) TO authenticated;
GRANT EXECUTE ON FUNCTION public.get_style_kpis(uuid, uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.get_live_dept_kpi(uuid, uuid) TO authenticated;
REVOKE EXECUTE ON FUNCTION public.get_factory_kpis(uuid, date, date) FROM anon;
REVOKE EXECUTE ON FUNCTION public.get_department_kpis(uuid, uuid, date, date) FROM anon;
REVOKE EXECUTE ON FUNCTION public.get_department_kpis_by_shift(uuid, uuid, date, date) FROM anon;
REVOKE EXECUTE ON FUNCTION public.get_style_kpis(uuid, uuid) FROM anon;
REVOKE EXECUTE ON FUNCTION public.get_live_dept_kpi(uuid, uuid) FROM anon;

CREATE OR REPLACE FUNCTION public.get_dept_quality_for_date(
  p_factory_id uuid,
  p_department_id uuid,
  p_log_date date
)
RETURNS SETOF public.v_daily_quality
LANGUAGE sql
STABLE
SECURITY INVOKER
SET search_path = public
AS $$
  SELECT *
  FROM public.v_daily_quality
  WHERE factory_id = p_factory_id
    AND department_id = p_department_id
    AND log_date = p_log_date
  ORDER BY order_id;
$$;

COMMENT ON FUNCTION public.get_dept_quality_for_date(uuid, uuid, date) IS
  'Department QC KPI rows for a date. dhu = defect count per hundred (number); defective_pct = % defective pieces.';

REVOKE ALL ON FUNCTION public.get_dept_quality_for_date(uuid, uuid, date) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.get_dept_quality_for_date(uuid, uuid, date) TO authenticated;
REVOKE EXECUTE ON FUNCTION public.get_dept_quality_for_date(uuid, uuid, date) FROM anon;



-- >>> 20260612110000_mes_reporting_rpcs_v2_kpi_columns.sql (skipped — superseded by 12115000 dhu semantics fix)

-- Early define get_order_wip (required by journey/detail RPCs below)
CREATE OR REPLACE FUNCTION public.get_order_wip(
  p_factory_id uuid,
  p_order_id uuid
)
RETURNS SETOF public.v_wip_order
LANGUAGE sql
STABLE
SECURITY INVOKER
SET search_path = public
AS $$
  WITH ranked AS (
    SELECT
      w.*,
      ROW_NUMBER() OVER (
        PARTITION BY w.colorway_id, w.department_id
        ORDER BY w.log_date DESC NULLS LAST
      ) AS rn
    FROM public.v_wip_order w
    WHERE w.factory_id = p_factory_id
      AND w.order_id = p_order_id
  )
  SELECT
    factory_id, order_id, colorway_id, log_date, flow_step, department_id, wip_qty
  FROM ranked
  WHERE rn = 1
  ORDER BY flow_step, colorway_id NULLS LAST, department_id;
$$;

COMMENT ON FUNCTION public.get_order_wip(uuid, uuid) IS
  'Latest colorway-grained WIP per process-flow department for an order. Wraps v_wip_order.';

-- >>> 20260612120000_mes_cut_to_ship_journey_view.sql
-- Phase 9c: Cut-to-Ship department journey view + RPC + detail JSON extension.
-- One row per (factory, order, colorway, department). Cross-joins all factory depts;
-- depts not in the order process flow get status = not_in_flow with NULL qtys.

CREATE OR REPLACE FUNCTION public.resolve_rejection_department_id(
  p_factory_id uuid,
  p_order_id uuid,
  p_stage text
)
RETURNS uuid
LANGUAGE sql
STABLE
SET search_path = public
AS $$
  SELECT CASE p_stage
    WHEN 'end_line' THEN (
      SELECT d.id FROM public.departments d
      WHERE d.factory_id = p_factory_id AND d.name ILIKE 'sewing'
      ORDER BY d.id LIMIT 1
    )
    WHEN 'final_audit' THEN (
      SELECT d.id FROM public.departments d
      WHERE d.factory_id = p_factory_id AND d.name ILIKE 'quality audit'
      ORDER BY d.id LIMIT 1
    )
    WHEN 'pre_pack' THEN (
      SELECT d.id FROM public.departments d
      WHERE d.factory_id = p_factory_id
        AND (d.name ILIKE 'finishing' OR d.name ILIKE 'packing')
      ORDER BY CASE WHEN d.name ILIKE 'finishing' THEN 0 ELSE 1 END, d.id
      LIMIT 1
    )
    WHEN 'post_pack' THEN (
      SELECT d.id FROM public.departments d
      WHERE d.factory_id = p_factory_id
        AND (d.name ILIKE 'packing' OR d.name ILIKE 'finishing')
      ORDER BY CASE WHEN d.name ILIKE 'packing' THEN 0 ELSE 1 END, d.id
      LIMIT 1
    )
    WHEN 'customer_return' THEN (
      SELECT d.id FROM public.departments d
      WHERE d.factory_id = p_factory_id AND d.name ILIKE 'shipment'
      ORDER BY d.id LIMIT 1
    )
    WHEN 'inline' THEN (
      SELECT pfs.department_id
      FROM public.style_orders so
      JOIN public.process_flow_steps pfs ON pfs.flow_id = so.process_flow_id
      JOIN public.departments d ON d.id = pfs.department_id AND d.is_production = true
      WHERE so.id = p_order_id AND so.factory_id = p_factory_id
      ORDER BY CASE WHEN d.name ILIKE 'sewing' THEN 0 ELSE 1 END, pfs.flow_step DESC
      LIMIT 1
    )
    ELSE (
      SELECT pfs.department_id
      FROM public.style_orders so
      JOIN public.process_flow_steps pfs ON pfs.flow_id = so.process_flow_id
      WHERE so.id = p_order_id AND so.factory_id = p_factory_id
      ORDER BY pfs.flow_step DESC
      LIMIT 1
    )
  END;
$$;

COMMENT ON FUNCTION public.resolve_rejection_department_id(uuid, uuid, text) IS
  'Maps rejection.stage to a department for journey qty_rejected. inline → Sewing if in flow; final_audit → Quality Audit; customer_return → Shipment; ambiguous → max flow_step dept.';

CREATE OR REPLACE VIEW public.v_cut_to_ship_dept_journey AS
WITH order_colorways AS (
  SELECT so.factory_id, so.id AS order_id, so.process_flow_id, cw.id AS colorway_id
  FROM public.style_orders so
  LEFT JOIN public.colorways cw ON cw.order_id = so.id
),
dept_grid AS (
  SELECT
    oc.factory_id,
    oc.order_id,
    oc.colorway_id,
    oc.process_flow_id,
    d.id AS dept_id,
    d.name AS dept_name,
    d.is_production,
    d.apps,
    pfs.flow_step,
    (pfs.department_id IS NOT NULL) AS is_in_flow,
    (d.id = public.get_cutting_department_id(oc.factory_id)) AS is_cutting,
    (d.name ILIKE 'shipment' OR COALESCE(d.apps, '[]'::jsonb) @> '["shipment_log"]'::jsonb) AS is_shipment,
    (d.name ILIKE 'quality audit') AS is_quality_audit
  FROM order_colorways oc
  JOIN public.departments d ON d.factory_id = oc.factory_id
  LEFT JOIN public.process_flow_steps pfs
    ON pfs.flow_id = oc.process_flow_id AND pfs.department_id = d.id
),
handover_received AS (
  SELECT
    hs.factory_id, hs.order_id, hs.colorway_id, hs.to_department_id AS dept_id,
    SUM(COALESCE(NULLIF(hs.received_qty, 0), hs.sent_qty))::integer AS qty_received
  FROM public.handover_slips hs
  GROUP BY hs.factory_id, hs.order_id, hs.colorway_id, hs.to_department_id
),
handover_sent AS (
  SELECT
    hs.factory_id, hs.order_id, hs.colorway_id, hs.from_department_id AS dept_id,
    SUM(hs.sent_qty)::integer AS qty_sent
  FROM public.handover_slips hs
  GROUP BY hs.factory_id, hs.order_id, hs.colorway_id, hs.from_department_id
),
hourly_produced AS (
  SELECT
    h.factory_id, h.order_id, h.colorway_id, h.department_id AS dept_id,
    SUM(h.count)::integer AS qty_produced
  FROM public.hourly_counts h
  JOIN public.departments d ON d.id = h.department_id
  WHERE COALESCE(d.apps, '[]'::jsonb) @> '["hourly"]'::jsonb
  GROUP BY h.factory_id, h.order_id, h.colorway_id, h.department_id
),
qc_produced AS (
  SELECT
    i.factory_id, i.order_id, i.colorway_id, i.department_id AS dept_id,
    COUNT(*) FILTER (WHERE i.result IN ('pass', 'rework_pass'))::integer AS qty_produced
  FROM public.inspections i
  JOIN public.departments d ON d.id = i.department_id
  WHERE COALESCE(d.apps, '[]'::jsonb) @> '["qc_log"]'::jsonb
  GROUP BY i.factory_id, i.order_id, i.colorway_id, i.department_id
),
shipped AS (
  SELECT factory_id, order_id, colorway_id, SUM(shipped_qty)::integer AS qty_shipped
  FROM public.shipments
  GROUP BY factory_id, order_id, colorway_id
),
rejected_by_dept AS (
  SELECT
    r.factory_id, r.order_id, r.colorway_id,
    public.resolve_rejection_department_id(r.factory_id, r.order_id, r.stage) AS dept_id,
    SUM(r.qty)::integer AS qty_rejected
  FROM public.rejections r
  GROUP BY r.factory_id, r.order_id, r.colorway_id,
    public.resolve_rejection_department_id(r.factory_id, r.order_id, r.stage)
),
assembled AS (
  SELECT
    g.factory_id,
    g.order_id,
    g.colorway_id,
    g.dept_id,
    g.dept_name,
    g.flow_step,
    g.is_in_flow,
    CASE WHEN g.is_in_flow THEN
      CASE WHEN g.is_cutting THEN NULL ELSE hr.qty_received END
    END AS qty_received,
    CASE WHEN g.is_in_flow THEN
      CASE
        WHEN g.is_cutting THEN hp.qty_produced
        WHEN COALESCE(g.apps, '[]'::jsonb) @> '["hourly"]'::jsonb THEN hp.qty_produced
        WHEN COALESCE(g.apps, '[]'::jsonb) @> '["qc_log"]'::jsonb THEN qp.qty_produced
        ELSE COALESCE(hp.qty_produced, qp.qty_produced)
      END
    END AS qty_produced,
    CASE WHEN g.is_in_flow THEN
      CASE WHEN g.is_shipment THEN sh.qty_shipped ELSE hs.qty_sent END
    END AS qty_sent,
    CASE WHEN g.is_in_flow THEN rb.qty_rejected END AS qty_rejected
  FROM dept_grid g
  LEFT JOIN handover_received hr
    ON hr.factory_id = g.factory_id AND hr.order_id = g.order_id
   AND hr.colorway_id IS NOT DISTINCT FROM g.colorway_id AND hr.dept_id = g.dept_id
  LEFT JOIN handover_sent hs
    ON hs.factory_id = g.factory_id AND hs.order_id = g.order_id
   AND hs.colorway_id IS NOT DISTINCT FROM g.colorway_id AND hs.dept_id = g.dept_id
  LEFT JOIN hourly_produced hp
    ON hp.factory_id = g.factory_id AND hp.order_id = g.order_id
   AND hp.colorway_id IS NOT DISTINCT FROM g.colorway_id AND hp.dept_id = g.dept_id
  LEFT JOIN qc_produced qp
    ON qp.factory_id = g.factory_id AND qp.order_id = g.order_id
   AND qp.colorway_id IS NOT DISTINCT FROM g.colorway_id AND qp.dept_id = g.dept_id
  LEFT JOIN shipped sh
    ON sh.factory_id = g.factory_id AND sh.order_id = g.order_id
   AND sh.colorway_id IS NOT DISTINCT FROM g.colorway_id AND g.is_shipment
  LEFT JOIN rejected_by_dept rb
    ON rb.factory_id = g.factory_id AND rb.order_id = g.order_id
   AND rb.colorway_id IS NOT DISTINCT FROM g.colorway_id AND rb.dept_id = g.dept_id
)
SELECT
  a.factory_id,
  a.order_id,
  a.colorway_id,
  a.dept_id,
  a.dept_name,
  a.flow_step,
  a.is_in_flow,
  a.qty_received,
  a.qty_produced,
  a.qty_sent,
  a.qty_rejected,
  CASE WHEN NOT a.is_in_flow THEN NULL
    WHEN a.qty_received IS NULL AND a.qty_produced IS NOT NULL
      THEN GREATEST(COALESCE(a.qty_produced, 0) - COALESCE(a.qty_sent, 0), 0)
    WHEN a.qty_received IS NOT NULL
      THEN GREATEST(COALESCE(a.qty_received, 0) - COALESCE(a.qty_sent, 0), 0)
    ELSE NULL
  END::integer AS wip_qty,
  CASE
    WHEN NOT a.is_in_flow THEN 'not_in_flow'
    WHEN a.qty_received IS NULL AND COALESCE(a.qty_produced, 0) = 0 THEN 'pending'
    WHEN a.qty_received IS NULL AND COALESCE(a.qty_sent, 0) = 0 AND COALESCE(a.qty_produced, 0) > 0 THEN 'in_progress'
    WHEN a.qty_received IS NULL AND COALESCE(a.qty_sent, 0) >= COALESCE(a.qty_produced, 0)
      AND COALESCE(a.qty_sent, 0) > 0 THEN 'completed'
    WHEN COALESCE(a.qty_received, 0) = 0 THEN 'pending'
    WHEN COALESCE(a.qty_received, 0) > COALESCE(a.qty_sent, 0) THEN 'in_progress'
    WHEN COALESCE(a.qty_sent, 0) >= COALESCE(a.qty_received, 0) AND COALESCE(a.qty_sent, 0) > 0 THEN 'completed'
    ELSE 'pending'
  END AS status
FROM assembled a;

COMMENT ON VIEW public.v_cut_to_ship_dept_journey IS
  'Per order/colorway department journey for Cut-to-Ship drill-down. Cross-joins all factory depts; not-in-flow depts get NULL qtys. Cutting: qty_received NULL, produced from hourly. Shipment: qty_sent = shipped_qty. Rejection stage mapping via resolve_rejection_department_id.';

CREATE OR REPLACE FUNCTION public.get_cut_to_ship_journey(
  p_factory_id uuid,
  p_order_id uuid
)
RETURNS SETOF public.v_cut_to_ship_dept_journey
LANGUAGE sql
STABLE
SECURITY INVOKER
SET search_path = public
AS $$
  SELECT *
  FROM public.v_cut_to_ship_dept_journey
  WHERE factory_id = p_factory_id AND order_id = p_order_id
  ORDER BY colorway_id NULLS LAST, flow_step NULLS LAST, dept_name;
$$;

COMMENT ON FUNCTION public.get_cut_to_ship_journey(uuid, uuid) IS
  'Department journey rows for one order. One row per colorway × dept. Ordered by colorway, flow_step, dept_name.';

-- get_cut_to_ship_detail deferred until get_order_wip exists (see 11160000 / 14100000)

-- >>> 20260613103000_get_order_dept_progress_and_size_views.sql
-- Phase 9.5: get_order_dept_progress RPC + size-wise cut-to-ship views.

CREATE OR REPLACE VIEW public.v_order_rejected_qty_by_size AS
SELECT
  r.factory_id,
  r.order_id,
  r.colorway_id,
  COALESCE(r.size, 'UNSPEC') AS size,
  SUM(r.qty)::integer AS rejected_qty
FROM public.rejections r
GROUP BY r.factory_id, r.order_id, r.colorway_id, COALESCE(r.size, 'UNSPEC');

COMMENT ON VIEW public.v_order_rejected_qty_by_size IS
  'Rejected qty per size from rejections.size column. UNSPEC when size is null.';

CREATE OR REPLACE FUNCTION public.get_order_dept_progress(
  p_factory_id uuid,
  p_order_id uuid,
  p_colorway_id uuid,
  p_department_id uuid,
  p_date date DEFAULT CURRENT_DATE
)
RETURNS jsonb
LANGUAGE plpgsql
STABLE
SECURITY INVOKER
SET search_path = public
AS $$
DECLARE
  v_planned jsonb;
  v_planned_total integer;
  v_cutting_id uuid;
  v_is_cutting boolean;
  v_cum_produced integer := 0;
  v_today_produced integer := 0;
  v_cum_sent integer := 0;
  v_today_sent integer := 0;
  v_produced_by_size jsonb := '{}'::jsonb;
  v_sent_by_size jsonb := '{}'::jsonb;
  v_hourly_total integer := 0;
  v_today_target integer := 0;
  v_remaining integer;
BEGIN
  v_planned := public.colorway_planned_by_size(p_colorway_id);
  v_planned_total := public.jsonb_sum_int_values(v_planned);
  v_cutting_id := public.get_cutting_department_id(p_factory_id);
  v_is_cutting := (p_department_id = v_cutting_id);

  SELECT COALESCE(SUM(daily_target), 0)::integer INTO v_today_target
  FROM public.v_daily_target t
  WHERE t.factory_id = p_factory_id
    AND t.order_id = p_order_id
    AND t.department_id = p_department_id
    AND t.log_date = p_date;

  SELECT COALESCE(SUM(o.output_qty), 0)::integer INTO v_cum_produced
  FROM public.v_daily_output o
  WHERE o.factory_id = p_factory_id
    AND o.order_id = p_order_id
    AND o.colorway_id IS NOT DISTINCT FROM p_colorway_id
    AND o.department_id = p_department_id;

  SELECT COALESCE(SUM(o.output_qty), 0)::integer INTO v_today_produced
  FROM public.v_daily_output o
  WHERE o.factory_id = p_factory_id
    AND o.order_id = p_order_id
    AND o.colorway_id IS NOT DISTINCT FROM p_colorway_id
    AND o.department_id = p_department_id
    AND o.log_date = p_date;

  SELECT COALESCE(SUM(hs.sent_qty), 0)::integer INTO v_cum_sent
  FROM public.handover_slips hs
  WHERE hs.factory_id = p_factory_id
    AND hs.order_id = p_order_id
    AND hs.colorway_id IS NOT DISTINCT FROM p_colorway_id
    AND hs.from_department_id = p_department_id;

  SELECT COALESCE(SUM(hs.sent_qty), 0)::integer INTO v_today_sent
  FROM public.handover_slips hs
  WHERE hs.factory_id = p_factory_id
    AND hs.order_id = p_order_id
    AND hs.colorway_id IS NOT DISTINCT FROM p_colorway_id
    AND hs.from_department_id = p_department_id
    AND hs.sent_at::date = p_date;

  SELECT public.jsonb_merge_sum_maps(ARRAY_AGG(hs.qty_by_size))
  INTO v_sent_by_size
  FROM public.handover_slips hs
  WHERE hs.factory_id = p_factory_id
    AND hs.order_id = p_order_id
    AND hs.colorway_id IS NOT DISTINCT FROM p_colorway_id
    AND hs.from_department_id = p_department_id
    AND hs.qty_by_size <> '{}'::jsonb;

  IF v_is_cutting THEN
    SELECT public.jsonb_merge_sum_maps(ARRAY_AGG(h.count_by_size))
    INTO v_produced_by_size
    FROM public.hourly_counts h
    WHERE h.factory_id = p_factory_id
      AND h.order_id = p_order_id
      AND h.colorway_id IS NOT DISTINCT FROM p_colorway_id
      AND h.department_id = p_department_id
      AND h.count_by_size <> '{}'::jsonb;
    IF v_produced_by_size = '{}'::jsonb OR v_produced_by_size IS NULL THEN
      SELECT COALESCE(SUM(h.count), 0)::integer INTO v_hourly_total
      FROM public.hourly_counts h
      WHERE h.factory_id = p_factory_id
        AND h.order_id = p_order_id
        AND h.colorway_id IS NOT DISTINCT FROM p_colorway_id
        AND h.department_id = p_department_id;
      v_produced_by_size := public.proportional_qty_by_size(v_hourly_total, v_planned);
    END IF;
  ELSE
    SELECT public.jsonb_merge_sum_maps(ARRAY_AGG(hs.qty_by_size))
    INTO v_produced_by_size
    FROM public.handover_slips hs
    WHERE hs.factory_id = p_factory_id
      AND hs.order_id = p_order_id
      AND hs.colorway_id IS NOT DISTINCT FROM p_colorway_id
      AND hs.from_department_id = p_department_id
      AND hs.qty_by_size <> '{}'::jsonb;
    IF v_produced_by_size = '{}'::jsonb AND v_cum_produced > 0 THEN
      v_produced_by_size := public.proportional_qty_by_size(v_cum_produced, v_planned);
    END IF;
  END IF;

  v_remaining := GREATEST(v_planned_total - GREATEST(v_cum_produced, v_cum_sent), 0);

  RETURN jsonb_build_object(
    'cumulative_produced', v_cum_produced,
    'today_produced', v_today_produced,
    'today_target', v_today_target,
    'cumulative_sent', v_cum_sent,
    'today_sent', v_today_sent,
    'available_to_send', GREATEST(v_cum_produced - v_cum_sent, 0),
    'planned_qty_by_size', v_planned,
    'produced_qty_by_size', COALESCE(v_produced_by_size, '{}'::jsonb),
    'sent_qty_by_size', COALESCE(v_sent_by_size, '{}'::jsonb),
    'remaining_qty', v_remaining
  );
END;
$$;

COMMENT ON FUNCTION public.get_order_dept_progress(uuid, uuid, uuid, uuid, date) IS
  'Dept progress for order/colorway: produced, sent, targets, size maps. Cutting uses proportional hourly split; other depts use handover qty_by_size.';

CREATE OR REPLACE FUNCTION public.get_pseudo_dept_daily_summary(
  p_factory_id uuid,
  p_department_id uuid,
  p_date date DEFAULT CURRENT_DATE
)
RETURNS jsonb
LANGUAGE sql
STABLE
SECURITY INVOKER
SET search_path = public
AS $$
  SELECT CASE
    WHEN EXISTS (
      SELECT 1 FROM public.departments d
      WHERE d.id = p_department_id AND d.factory_id = p_factory_id
        AND (d.name ILIKE 'shipment' OR COALESCE(d.apps, '[]'::jsonb) @> '["shipment_log"]'::jsonb)
    ) THEN jsonb_build_object(
      'kind', 'shipment',
      'shipment_count', (SELECT COUNT(*)::integer FROM public.shipments s WHERE s.factory_id = p_factory_id AND s.shipment_date = p_date),
      'shipped_qty', (SELECT COALESCE(SUM(shipped_qty), 0)::integer FROM public.shipments s WHERE s.factory_id = p_factory_id AND s.shipment_date = p_date)
    )
    WHEN EXISTS (
      SELECT 1 FROM public.departments d
      WHERE d.id = p_department_id AND d.factory_id = p_factory_id
        AND d.name ILIKE 'quality audit'
    ) THEN jsonb_build_object(
      'kind', 'rejection',
      'rejection_count', (SELECT COUNT(*)::integer FROM public.rejections r WHERE r.factory_id = p_factory_id AND r.rejected_date = p_date),
      'rejected_qty', (SELECT COALESCE(SUM(qty), 0)::integer FROM public.rejections r WHERE r.factory_id = p_factory_id AND r.rejected_date = p_date)
    )
    ELSE jsonb_build_object('kind', 'production')
  END;
$$;

COMMENT ON FUNCTION public.get_pseudo_dept_daily_summary(uuid, uuid, date) IS
  'Today summary for Shipment or Quality Audit pseudo-depts on floor home tiles.';

REVOKE ALL ON FUNCTION public.get_order_dept_progress(uuid, uuid, uuid, uuid, date) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.get_order_dept_progress(uuid, uuid, uuid, uuid, date) TO authenticated;
REVOKE EXECUTE ON FUNCTION public.get_order_dept_progress(uuid, uuid, uuid, uuid, date) FROM anon;

REVOKE ALL ON FUNCTION public.get_pseudo_dept_daily_summary(uuid, uuid, date) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.get_pseudo_dept_daily_summary(uuid, uuid, date) TO authenticated;
REVOKE EXECUTE ON FUNCTION public.get_pseudo_dept_daily_summary(uuid, uuid, date) FROM anon;

-- Extend v_cut_to_ship with size-wise reconciliation columns.
CREATE OR REPLACE VIEW public.v_cut_to_ship AS
WITH rej_by_size AS (
  SELECT factory_id, order_id, colorway_id,
    jsonb_object_agg(size, rejected_qty) AS rejected_qty_by_size
  FROM public.v_order_rejected_qty_by_size
  GROUP BY factory_id, order_id, colorway_id
),
ship_by_size AS (
  SELECT factory_id, order_id, colorway_id,
    public.jsonb_merge_sum_maps(ARRAY_AGG(shipped_qty_by_size)) AS shipped_qty_by_size
  FROM public.shipments
  WHERE shipped_qty_by_size <> '{}'::jsonb
  GROUP BY factory_id, order_id, colorway_id
),
cut_by_size AS (
  SELECT h.factory_id, h.order_id, h.colorway_id,
    public.proportional_qty_by_size(SUM(h.count)::integer, public.colorway_planned_by_size(h.colorway_id)) AS cut_qty_by_size
  FROM public.hourly_counts h
  WHERE h.department_id = public.get_cutting_department_id(h.factory_id)
  GROUP BY h.factory_id, h.order_id, h.colorway_id, public.colorway_planned_by_size(h.colorway_id)
)
SELECT
  so.factory_id,
  so.id AS order_id,
  cw.id AS colorway_id,
  so.style_name,
  so.buyer_name,
  so.po_number,
  COALESCE(so.adj_qty, so.order_qty, 0)::integer AS order_qty,
  COALESCE(cq.cut_qty, 0)::integer AS cut_qty,
  COALESCE(cq.cut_qty_source, 'planned') AS cut_qty_source,
  COALESCE(sq.shipped_qty, 0)::integer AS shipped_qty,
  COALESCE(rq.rejected_qty, 0)::integer AS rejected_qty,
  COALESCE(wt.wip_qty, 0)::integer AS wip_qty,
  (COALESCE(cq.cut_qty, 0)
    - (COALESCE(sq.shipped_qty, 0) + COALESCE(rq.rejected_qty, 0) + COALESCE(wt.wip_qty, 0)))::integer
    AS reconciliation_gap,
  COALESCE(rq.rejected_by_reason, '{}'::jsonb) AS rejected_by_reason,
  COALESCE(rq.rejected_by_stage, '{}'::jsonb) AS rejected_by_stage,
  (COALESCE(cq.cut_qty, 0)
    = COALESCE(sq.shipped_qty, 0) + COALESCE(rq.rejected_qty, 0) + COALESCE(wt.wip_qty, 0)) AS is_balanced,
  ROUND(100.0 * COALESCE(sq.shipped_qty, 0) / NULLIF(COALESCE(so.adj_qty, so.order_qty, 0), 0), 2) AS completion_pct,
  so.status AS order_status,
  sq.last_shipment_date,
  COALESCE(cbs.cut_qty_by_size, '{}'::jsonb) AS cut_qty_by_size,
  COALESCE(sbs.shipped_qty_by_size, '{}'::jsonb) AS shipped_qty_by_size,
  COALESCE(rbs.rejected_qty_by_size, '{}'::jsonb) AS rejected_qty_by_size,
  '{}'::jsonb AS wip_qty_by_size
FROM public.style_orders so
LEFT JOIN public.colorways cw ON cw.order_id = so.id
LEFT JOIN public.v_order_cut_qty cq
  ON cq.factory_id = so.factory_id AND cq.order_id = so.id
 AND cq.colorway_id IS NOT DISTINCT FROM cw.id
LEFT JOIN public.v_order_shipped_qty sq
  ON sq.factory_id = so.factory_id AND sq.order_id = so.id
 AND sq.colorway_id IS NOT DISTINCT FROM cw.id
LEFT JOIN public.v_order_rejected_qty rq
  ON rq.factory_id = so.factory_id AND rq.order_id = so.id
 AND rq.colorway_id IS NOT DISTINCT FROM cw.id
LEFT JOIN public.v_order_wip_total wt
  ON wt.factory_id = so.factory_id AND wt.order_id = so.id
 AND wt.colorway_id IS NOT DISTINCT FROM cw.id
LEFT JOIN cut_by_size cbs
  ON cbs.factory_id = so.factory_id AND cbs.order_id = so.id
 AND cbs.colorway_id IS NOT DISTINCT FROM cw.id
LEFT JOIN ship_by_size sbs
  ON sbs.factory_id = so.factory_id AND sbs.order_id = so.id
 AND sbs.colorway_id IS NOT DISTINCT FROM cw.id
LEFT JOIN rej_by_size rbs
  ON rbs.factory_id = so.factory_id AND rbs.order_id = so.id
 AND rbs.colorway_id IS NOT DISTINCT FROM cw.id;

COMMENT ON VIEW public.v_cut_to_ship IS
  'Cut-to-ship per colorway with size-wise columns. cut_qty_by_size from proportional hourly; shipped/rejected from size JSONB aggregates.';



-- >>> 20260614100000_mes_journey_size_aware.sql
-- Phase 9c: Size-aware v_cut_to_ship_dept_journey + real wip_qty_by_size on v_cut_to_ship.

CREATE OR REPLACE FUNCTION public.jsonb_subtract_maps_nonneg(p_a jsonb, p_b jsonb)
RETURNS jsonb
LANGUAGE sql
IMMUTABLE
AS $$
  SELECT COALESCE(
    (
      SELECT jsonb_object_agg(
        k,
        GREATEST(
          COALESCE((COALESCE(p_a, '{}'::jsonb) ->> k)::integer, 0)
          - COALESCE((COALESCE(p_b, '{}'::jsonb) ->> k)::integer, 0),
          0
        )
      )
      FROM (
        SELECT key AS k FROM jsonb_each_text(COALESCE(p_a, '{}'::jsonb))
        UNION
        SELECT key AS k FROM jsonb_each_text(COALESCE(p_b, '{}'::jsonb))
      ) keys
    ),
    '{}'::jsonb
  );
$$;

COMMENT ON FUNCTION public.jsonb_subtract_maps_nonneg(jsonb, jsonb) IS
  'Per-size GREATEST(a - b, 0). Used for dept WIP-by-size (received or produced minus sent).';

DROP VIEW IF EXISTS public.v_cut_to_ship CASCADE;
DROP VIEW IF EXISTS public.v_cut_to_ship_dept_journey CASCADE;

CREATE VIEW public.v_cut_to_ship_dept_journey AS
WITH order_colorways AS (
  SELECT so.factory_id, so.id AS order_id, so.process_flow_id, cw.id AS colorway_id
  FROM public.style_orders so
  LEFT JOIN public.colorways cw ON cw.order_id = so.id
),
dept_grid AS (
  SELECT
    oc.factory_id,
    oc.order_id,
    oc.colorway_id,
    oc.process_flow_id,
    d.id AS dept_id,
    d.name AS dept_name,
    d.is_production,
    d.apps,
    pfs.flow_step,
    (pfs.department_id IS NOT NULL) AS is_in_flow,
    (d.id = public.get_cutting_department_id(oc.factory_id)) AS is_cutting,
    (d.name ILIKE 'shipment' OR COALESCE(d.apps, '[]'::jsonb) @> '["shipment_log"]'::jsonb) AS is_shipment,
    (d.name ILIKE 'quality audit') AS is_quality_audit
  FROM order_colorways oc
  JOIN public.departments d ON d.factory_id = oc.factory_id
  LEFT JOIN public.process_flow_steps pfs
    ON pfs.flow_id = oc.process_flow_id AND pfs.department_id = d.id
),
handover_received AS (
  SELECT
    hs.factory_id, hs.order_id, hs.colorway_id, hs.to_department_id AS dept_id,
    SUM(COALESCE(NULLIF(hs.received_qty, 0), hs.sent_qty))::integer AS qty_received
  FROM public.handover_slips hs
  GROUP BY hs.factory_id, hs.order_id, hs.colorway_id, hs.to_department_id
),
handover_received_by_size AS (
  SELECT
    hs.factory_id, hs.order_id, hs.colorway_id, hs.to_department_id AS dept_id,
    public.jsonb_merge_sum_maps(ARRAY_AGG(
      CASE
        WHEN COALESCE(hs.received_qty_by_size, '{}'::jsonb) <> '{}'::jsonb THEN hs.received_qty_by_size
        WHEN COALESCE(hs.qty_by_size, '{}'::jsonb) <> '{}'::jsonb THEN hs.qty_by_size
        ELSE public.proportional_qty_by_size(
          COALESCE(NULLIF(hs.received_qty, 0), hs.sent_qty),
          public.colorway_planned_by_size(hs.colorway_id)
        )
      END
    )) AS qty_received_by_size
  FROM public.handover_slips hs
  GROUP BY hs.factory_id, hs.order_id, hs.colorway_id, hs.to_department_id
),
handover_sent AS (
  SELECT
    hs.factory_id, hs.order_id, hs.colorway_id, hs.from_department_id AS dept_id,
    SUM(hs.sent_qty)::integer AS qty_sent
  FROM public.handover_slips hs
  GROUP BY hs.factory_id, hs.order_id, hs.colorway_id, hs.from_department_id
),
handover_sent_by_size AS (
  SELECT
    hs.factory_id, hs.order_id, hs.colorway_id, hs.from_department_id AS dept_id,
    public.jsonb_merge_sum_maps(ARRAY_AGG(
      CASE
        WHEN COALESCE(hs.qty_by_size, '{}'::jsonb) <> '{}'::jsonb THEN hs.qty_by_size
        ELSE public.proportional_qty_by_size(
          hs.sent_qty,
          public.colorway_planned_by_size(hs.colorway_id)
        )
      END
    )) AS qty_sent_by_size
  FROM public.handover_slips hs
  GROUP BY hs.factory_id, hs.order_id, hs.colorway_id, hs.from_department_id
),
hourly_produced AS (
  SELECT
    h.factory_id, h.order_id, h.colorway_id, h.department_id AS dept_id,
    SUM(h.count)::integer AS qty_produced
  FROM public.hourly_counts h
  JOIN public.departments d ON d.id = h.department_id
  WHERE COALESCE(d.apps, '[]'::jsonb) @> '["hourly"]'::jsonb
  GROUP BY h.factory_id, h.order_id, h.colorway_id, h.department_id
),
hourly_produced_by_size AS (
  SELECT
    h.factory_id, h.order_id, h.colorway_id, h.department_id AS dept_id,
    public.proportional_qty_by_size(
      SUM(h.count)::integer,
      public.colorway_planned_by_size(h.colorway_id)
    ) AS qty_produced_by_size
  FROM public.hourly_counts h
  JOIN public.departments d ON d.id = h.department_id
  WHERE COALESCE(d.apps, '[]'::jsonb) @> '["hourly"]'::jsonb
  GROUP BY h.factory_id, h.order_id, h.colorway_id, h.department_id,
    public.colorway_planned_by_size(h.colorway_id)
),
qc_produced AS (
  SELECT
    i.factory_id, i.order_id, i.colorway_id, i.department_id AS dept_id,
    COUNT(*) FILTER (WHERE i.result IN ('pass', 'rework_pass'))::integer AS qty_produced
  FROM public.inspections i
  JOIN public.departments d ON d.id = i.department_id
  WHERE COALESCE(d.apps, '[]'::jsonb) @> '["qc_log"]'::jsonb
  GROUP BY i.factory_id, i.order_id, i.colorway_id, i.department_id
),
shipped AS (
  SELECT factory_id, order_id, colorway_id, SUM(shipped_qty)::integer AS qty_shipped
  FROM public.shipments
  GROUP BY factory_id, order_id, colorway_id
),
shipped_by_size AS (
  SELECT
    s.factory_id, s.order_id, s.colorway_id,
    public.jsonb_merge_sum_maps(ARRAY_AGG(
      CASE
        WHEN COALESCE(s.shipped_qty_by_size, '{}'::jsonb) <> '{}'::jsonb THEN s.shipped_qty_by_size
        ELSE public.proportional_qty_by_size(
          s.shipped_qty,
          public.colorway_planned_by_size(s.colorway_id)
        )
      END
    )) AS qty_shipped_by_size
  FROM public.shipments s
  GROUP BY s.factory_id, s.order_id, s.colorway_id
),
rejected_by_dept AS (
  SELECT
    r.factory_id, r.order_id, r.colorway_id,
    public.resolve_rejection_department_id(r.factory_id, r.order_id, r.stage) AS dept_id,
    SUM(r.qty)::integer AS qty_rejected
  FROM public.rejections r
  GROUP BY r.factory_id, r.order_id, r.colorway_id,
    public.resolve_rejection_department_id(r.factory_id, r.order_id, r.stage)
),
rejected_by_dept_size AS (
  SELECT
    x.factory_id, x.order_id, x.colorway_id,
    public.resolve_rejection_department_id(x.factory_id, x.order_id, x.stage) AS dept_id,
    jsonb_object_agg(x.size_key, x.dept_rej_qty) AS qty_rejected_by_size
  FROM (
    SELECT
      r.factory_id, r.order_id, r.colorway_id, r.stage,
      COALESCE(r.size, 'UNSPEC') AS size_key,
      SUM(r.qty)::integer AS dept_rej_qty
    FROM public.rejections r
    GROUP BY r.factory_id, r.order_id, r.colorway_id, r.stage, COALESCE(r.size, 'UNSPEC')
  ) x
  GROUP BY x.factory_id, x.order_id, x.colorway_id,
    public.resolve_rejection_department_id(x.factory_id, x.order_id, x.stage)
),
assembled AS (
  SELECT
    g.factory_id,
    g.order_id,
    g.colorway_id,
    g.dept_id,
    g.dept_name,
    g.flow_step,
    g.is_in_flow,
    g.is_cutting,
    CASE WHEN g.is_in_flow THEN
      CASE WHEN g.is_cutting THEN NULL ELSE hr.qty_received END
    END AS qty_received,
    CASE WHEN g.is_in_flow THEN
      CASE
        WHEN g.is_cutting THEN hp.qty_produced
        WHEN COALESCE(g.apps, '[]'::jsonb) @> '["hourly"]'::jsonb THEN hp.qty_produced
        WHEN COALESCE(g.apps, '[]'::jsonb) @> '["qc_log"]'::jsonb THEN qp.qty_produced
        ELSE COALESCE(hp.qty_produced, qp.qty_produced)
      END
    END AS qty_produced,
    CASE WHEN g.is_in_flow THEN
      CASE WHEN g.is_shipment THEN sh.qty_shipped ELSE hs.qty_sent END
    END AS qty_sent,
    CASE WHEN g.is_in_flow THEN rb.qty_rejected END AS qty_rejected,
    CASE WHEN g.is_in_flow THEN
      CASE WHEN g.is_cutting THEN NULL ELSE hrb.qty_received_by_size END
    END AS qty_received_by_size,
    CASE WHEN g.is_in_flow THEN
      CASE
        WHEN g.is_cutting THEN hpb.qty_produced_by_size
        WHEN COALESCE(hsb.qty_sent_by_size, '{}'::jsonb) <> '{}'::jsonb THEN hsb.qty_sent_by_size
        WHEN COALESCE(g.apps, '[]'::jsonb) @> '["hourly"]'::jsonb THEN hpb.qty_produced_by_size
        WHEN COALESCE(g.apps, '[]'::jsonb) @> '["qc_log"]'::jsonb
          AND COALESCE(qp.qty_produced, 0) > 0
          THEN public.proportional_qty_by_size(
            qp.qty_produced,
            public.colorway_planned_by_size(g.colorway_id)
          )
        ELSE hsb.qty_sent_by_size
      END
    END AS qty_produced_by_size,
    CASE WHEN g.is_in_flow THEN
      CASE WHEN g.is_shipment THEN shb.qty_shipped_by_size ELSE hsb.qty_sent_by_size END
    END AS qty_sent_by_size,
    CASE WHEN g.is_in_flow THEN rbs.qty_rejected_by_size END AS qty_rejected_by_size
  FROM dept_grid g
  LEFT JOIN handover_received hr
    ON hr.factory_id = g.factory_id AND hr.order_id = g.order_id
   AND hr.colorway_id IS NOT DISTINCT FROM g.colorway_id AND hr.dept_id = g.dept_id
  LEFT JOIN handover_received_by_size hrb
    ON hrb.factory_id = g.factory_id AND hrb.order_id = g.order_id
   AND hrb.colorway_id IS NOT DISTINCT FROM g.colorway_id AND hrb.dept_id = g.dept_id
  LEFT JOIN handover_sent hs
    ON hs.factory_id = g.factory_id AND hs.order_id = g.order_id
   AND hs.colorway_id IS NOT DISTINCT FROM g.colorway_id AND hs.dept_id = g.dept_id
  LEFT JOIN handover_sent_by_size hsb
    ON hsb.factory_id = g.factory_id AND hsb.order_id = g.order_id
   AND hsb.colorway_id IS NOT DISTINCT FROM g.colorway_id AND hsb.dept_id = g.dept_id
  LEFT JOIN hourly_produced hp
    ON hp.factory_id = g.factory_id AND hp.order_id = g.order_id
   AND hp.colorway_id IS NOT DISTINCT FROM g.colorway_id AND hp.dept_id = g.dept_id
  LEFT JOIN hourly_produced_by_size hpb
    ON hpb.factory_id = g.factory_id AND hpb.order_id = g.order_id
   AND hpb.colorway_id IS NOT DISTINCT FROM g.colorway_id AND hpb.dept_id = g.dept_id
  LEFT JOIN qc_produced qp
    ON qp.factory_id = g.factory_id AND qp.order_id = g.order_id
   AND qp.colorway_id IS NOT DISTINCT FROM g.colorway_id AND qp.dept_id = g.dept_id
  LEFT JOIN shipped sh
    ON sh.factory_id = g.factory_id AND sh.order_id = g.order_id
   AND sh.colorway_id IS NOT DISTINCT FROM g.colorway_id AND g.is_shipment
  LEFT JOIN shipped_by_size shb
    ON shb.factory_id = g.factory_id AND shb.order_id = g.order_id
   AND shb.colorway_id IS NOT DISTINCT FROM g.colorway_id AND g.is_shipment
  LEFT JOIN rejected_by_dept rb
    ON rb.factory_id = g.factory_id AND rb.order_id = g.order_id
   AND rb.colorway_id IS NOT DISTINCT FROM g.colorway_id AND rb.dept_id = g.dept_id
  LEFT JOIN rejected_by_dept_size rbs
    ON rbs.factory_id = g.factory_id AND rbs.order_id = g.order_id
   AND rbs.colorway_id IS NOT DISTINCT FROM g.colorway_id AND rbs.dept_id = g.dept_id
)
SELECT
  a.factory_id,
  a.order_id,
  a.colorway_id,
  a.dept_id,
  a.dept_name,
  a.flow_step,
  a.is_in_flow,
  a.qty_received,
  a.qty_produced,
  a.qty_sent,
  a.qty_rejected,
  CASE WHEN NOT a.is_in_flow THEN NULL
    WHEN a.qty_received IS NULL AND a.qty_produced IS NOT NULL
      THEN GREATEST(COALESCE(a.qty_produced, 0) - COALESCE(a.qty_sent, 0), 0)
    WHEN a.qty_received IS NOT NULL
      THEN GREATEST(COALESCE(a.qty_received, 0) - COALESCE(a.qty_sent, 0), 0)
    ELSE NULL
  END::integer AS wip_qty,
  CASE WHEN NOT a.is_in_flow THEN NULL
    WHEN a.is_cutting THEN public.jsonb_subtract_maps_nonneg(a.qty_produced_by_size, a.qty_sent_by_size)
    WHEN a.qty_received_by_size IS NOT NULL
      THEN public.jsonb_subtract_maps_nonneg(a.qty_received_by_size, a.qty_sent_by_size)
    WHEN a.qty_produced_by_size IS NOT NULL
      THEN public.jsonb_subtract_maps_nonneg(a.qty_produced_by_size, a.qty_sent_by_size)
    ELSE NULL
  END AS wip_qty_by_size,
  CASE WHEN NOT a.is_in_flow THEN NULL ELSE a.qty_received_by_size END AS qty_received_by_size,
  CASE WHEN NOT a.is_in_flow THEN NULL ELSE a.qty_produced_by_size END AS qty_produced_by_size,
  CASE WHEN NOT a.is_in_flow THEN NULL ELSE a.qty_sent_by_size END AS qty_sent_by_size,
  CASE WHEN NOT a.is_in_flow THEN NULL ELSE a.qty_rejected_by_size END AS qty_rejected_by_size,
  CASE
    WHEN NOT a.is_in_flow THEN 'not_in_flow'
    WHEN a.qty_received IS NULL AND COALESCE(a.qty_produced, 0) = 0 THEN 'pending'
    WHEN a.qty_received IS NULL AND COALESCE(a.qty_sent, 0) = 0 AND COALESCE(a.qty_produced, 0) > 0 THEN 'in_progress'
    WHEN a.qty_received IS NULL AND COALESCE(a.qty_sent, 0) >= COALESCE(a.qty_produced, 0)
      AND COALESCE(a.qty_sent, 0) > 0 THEN 'completed'
    WHEN COALESCE(a.qty_received, 0) = 0 THEN 'pending'
    WHEN COALESCE(a.qty_received, 0) > COALESCE(a.qty_sent, 0) THEN 'in_progress'
    WHEN COALESCE(a.qty_sent, 0) >= COALESCE(a.qty_received, 0) AND COALESCE(a.qty_sent, 0) > 0 THEN 'completed'
    ELSE 'pending'
  END AS status
FROM assembled a;

COMMENT ON VIEW public.v_cut_to_ship_dept_journey IS
  'Per order/colorway department journey with size-wise qty columns. Cutting: produced proportional from hourly; others: produced from outgoing handover qty_by_size with hourly fallback. WIP-by-size = received (or produced at Cutting) minus sent per size. Out-of-flow depts: NULL size maps, status not_in_flow.';

-- Backfill v_cut_to_ship.wip_qty_by_size from in-flow dept journey WIP maps.
CREATE VIEW public.v_cut_to_ship AS
WITH rej_by_size AS (
  SELECT factory_id, order_id, colorway_id,
    jsonb_object_agg(size, rejected_qty) AS rejected_qty_by_size
  FROM public.v_order_rejected_qty_by_size
  GROUP BY factory_id, order_id, colorway_id
),
ship_by_size AS (
  SELECT factory_id, order_id, colorway_id,
    public.jsonb_merge_sum_maps(ARRAY_AGG(shipped_qty_by_size)) AS shipped_qty_by_size
  FROM public.shipments
  WHERE shipped_qty_by_size <> '{}'::jsonb
  GROUP BY factory_id, order_id, colorway_id
),
cut_by_size AS (
  SELECT h.factory_id, h.order_id, h.colorway_id,
    public.proportional_qty_by_size(
      SUM(h.count)::integer,
      public.colorway_planned_by_size(h.colorway_id)
    ) AS cut_qty_by_size
  FROM public.hourly_counts h
  WHERE h.department_id = public.get_cutting_department_id(h.factory_id)
  GROUP BY h.factory_id, h.order_id, h.colorway_id,
    public.colorway_planned_by_size(h.colorway_id)
)
SELECT
  so.factory_id,
  so.id AS order_id,
  cw.id AS colorway_id,
  so.style_name,
  so.buyer_name,
  so.po_number,
  COALESCE(so.adj_qty, so.order_qty, 0)::integer AS order_qty,
  COALESCE(cq.cut_qty, 0)::integer AS cut_qty,
  COALESCE(cq.cut_qty_source, 'planned') AS cut_qty_source,
  COALESCE(sq.shipped_qty, 0)::integer AS shipped_qty,
  COALESCE(rq.rejected_qty, 0)::integer AS rejected_qty,
  COALESCE(wt.wip_qty, 0)::integer AS wip_qty,
  (COALESCE(cq.cut_qty, 0)
    - (COALESCE(sq.shipped_qty, 0) + COALESCE(rq.rejected_qty, 0) + COALESCE(wt.wip_qty, 0)))::integer
    AS reconciliation_gap,
  COALESCE(rq.rejected_by_reason, '{}'::jsonb) AS rejected_by_reason,
  COALESCE(rq.rejected_by_stage, '{}'::jsonb) AS rejected_by_stage,
  (COALESCE(cq.cut_qty, 0)
    = COALESCE(sq.shipped_qty, 0) + COALESCE(rq.rejected_qty, 0) + COALESCE(wt.wip_qty, 0)) AS is_balanced,
  ROUND(100.0 * COALESCE(sq.shipped_qty, 0) / NULLIF(COALESCE(so.adj_qty, so.order_qty, 0), 0), 2) AS completion_pct,
  so.status AS order_status,
  sq.last_shipment_date,
  COALESCE(cbs.cut_qty_by_size, '{}'::jsonb) AS cut_qty_by_size,
  COALESCE(sbs.shipped_qty_by_size, '{}'::jsonb) AS shipped_qty_by_size,
  COALESCE(rbs.rejected_qty_by_size, '{}'::jsonb) AS rejected_qty_by_size,
  CASE
    WHEN COALESCE(wt.wip_qty, 0) > 0 AND COALESCE(cbs.cut_qty_by_size, '{}'::jsonb) <> '{}'::jsonb THEN
      public.proportional_qty_by_size(wt.wip_qty, cbs.cut_qty_by_size)
    WHEN COALESCE(wt.wip_qty, 0) > 0 THEN
      public.proportional_qty_by_size(wt.wip_qty, public.colorway_planned_by_size(cw.id))
    ELSE '{}'::jsonb
  END AS wip_qty_by_size
FROM public.style_orders so
LEFT JOIN public.colorways cw ON cw.order_id = so.id
LEFT JOIN public.v_order_cut_qty cq
  ON cq.factory_id = so.factory_id AND cq.order_id = so.id
 AND cq.colorway_id IS NOT DISTINCT FROM cw.id
LEFT JOIN public.v_order_shipped_qty sq
  ON sq.factory_id = so.factory_id AND sq.order_id = so.id
 AND sq.colorway_id IS NOT DISTINCT FROM cw.id
LEFT JOIN public.v_order_rejected_qty rq
  ON rq.factory_id = so.factory_id AND rq.order_id = so.id
 AND rq.colorway_id IS NOT DISTINCT FROM cw.id
LEFT JOIN public.v_order_wip_total wt
  ON wt.factory_id = so.factory_id AND wt.order_id = so.id
 AND wt.colorway_id IS NOT DISTINCT FROM cw.id
LEFT JOIN cut_by_size cbs
  ON cbs.factory_id = so.factory_id AND cbs.order_id = so.id
 AND cbs.colorway_id IS NOT DISTINCT FROM cw.id
LEFT JOIN ship_by_size sbs
  ON sbs.factory_id = so.factory_id AND sbs.order_id = so.id
 AND sbs.colorway_id IS NOT DISTINCT FROM cw.id
LEFT JOIN rej_by_size rbs
  ON rbs.factory_id = so.factory_id AND rbs.order_id = so.id
 AND rbs.colorway_id IS NOT DISTINCT FROM cw.id
;

COMMENT ON VIEW public.v_cut_to_ship IS
  'Cut-to-ship per colorway. wip_qty_by_size = proportional split of scalar wip_qty across cut size mix.';

CREATE OR REPLACE FUNCTION public.get_cut_to_ship_journey(
  p_factory_id uuid,
  p_order_id uuid
)
RETURNS SETOF public.v_cut_to_ship_dept_journey
LANGUAGE sql
STABLE
SECURITY INVOKER
SET search_path = public
AS $$
  SELECT *
  FROM public.v_cut_to_ship_dept_journey
  WHERE factory_id = p_factory_id AND order_id = p_order_id
  ORDER BY colorway_id NULLS LAST, flow_step NULLS LAST, dept_name;
$$;

COMMENT ON FUNCTION public.get_cut_to_ship_journey(uuid, uuid) IS
  'Department journey rows for one order including size-wise qty columns.';

CREATE OR REPLACE FUNCTION public.get_cut_to_ship_detail(
  p_factory_id uuid,
  p_order_id uuid
)
RETURNS jsonb
LANGUAGE sql
STABLE
SECURITY INVOKER
SET search_path = public
AS $$
  SELECT jsonb_build_object(
    'reconciliation',
      COALESCE((
        SELECT jsonb_agg(to_jsonb(c) ORDER BY c.colorway_id NULLS LAST)
        FROM public.v_cut_to_ship c
        WHERE c.factory_id = p_factory_id AND c.order_id = p_order_id
      ), '[]'::jsonb),
    'shipments',
      COALESCE((
        SELECT jsonb_agg(to_jsonb(s) ORDER BY s.shipment_date DESC, s.logged_at DESC)
        FROM public.shipments s
        WHERE s.factory_id = p_factory_id AND s.order_id = p_order_id
      ), '[]'::jsonb),
    'rejections',
      COALESCE((
        SELECT jsonb_agg(to_jsonb(r) ORDER BY r.rejected_date DESC, r.logged_at DESC)
        FROM public.rejections r
        WHERE r.factory_id = p_factory_id AND r.order_id = p_order_id
      ), '[]'::jsonb),
    'wip_by_dept',
      COALESCE((
        SELECT jsonb_agg(to_jsonb(w) ORDER BY w.flow_step, w.colorway_id NULLS LAST, w.department_id)
        FROM public.get_order_wip(p_factory_id, p_order_id) w
      ), '[]'::jsonb),
    'journey',
      COALESCE((
        SELECT jsonb_agg(to_jsonb(j) ORDER BY j.colorway_id NULLS LAST, j.flow_step NULLS LAST, j.dept_name)
        FROM public.get_cut_to_ship_journey(p_factory_id, p_order_id) j
      ), '[]'::jsonb)
  );
$$;

COMMENT ON FUNCTION public.get_cut_to_ship_detail(uuid, uuid) IS
  'Order cut-to-ship drill-down: reconciliation, shipments, rejections, wip_by_dept, size-aware journey.';

REVOKE ALL ON FUNCTION public.get_cut_to_ship_journey(uuid, uuid) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.get_cut_to_ship_journey(uuid, uuid) TO authenticated;
REVOKE EXECUTE ON FUNCTION public.get_cut_to_ship_journey(uuid, uuid) FROM anon;

CREATE OR REPLACE FUNCTION public.get_cut_to_ship_report(
  p_factory_id uuid,
  p_date_from date DEFAULT NULL,
  p_date_to date DEFAULT NULL,
  p_buyer_id uuid DEFAULT NULL,
  p_balanced_only boolean DEFAULT NULL
)
RETURNS SETOF public.v_cut_to_ship
LANGUAGE sql
STABLE
SECURITY INVOKER
SET search_path = public
AS $$
  SELECT c.*
  FROM public.v_cut_to_ship c
  JOIN public.style_orders so
    ON so.id = c.order_id AND so.factory_id = c.factory_id
  WHERE c.factory_id = p_factory_id
    AND (
      p_date_from IS NULL
      OR COALESCE(so.delivery_date, so.order_date) >= p_date_from
    )
    AND (
      p_date_to IS NULL
      OR COALESCE(so.delivery_date, so.order_date) <= p_date_to
    )
    AND (p_buyer_id IS NULL OR so.buyer_id = p_buyer_id)
    AND (p_balanced_only IS NULL OR c.is_balanced = p_balanced_only)
  ORDER BY so.style_name, c.colorway_id NULLS LAST;
$$;

COMMENT ON FUNCTION public.get_cut_to_ship_report(uuid, date, date, uuid, boolean) IS
  'Cut-to-ship list with optional delivery_date/order_date range, buyer, balanced filter. Wraps v_cut_to_ship.';

REVOKE ALL ON FUNCTION public.get_cut_to_ship_report(uuid, date, date, uuid, boolean) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.get_cut_to_ship_report(uuid, date, date, uuid, boolean) TO authenticated;
REVOKE EXECUTE ON FUNCTION public.get_cut_to_ship_report(uuid, date, date, uuid, boolean) FROM anon;



-- >>> 20260614110000_mes_wip_by_size_proportional.sql
-- Phase 9c follow-up: wip_qty_by_size sums to scalar wip_qty via proportional split.

CREATE OR REPLACE VIEW public.v_cut_to_ship AS
WITH rej_by_size AS (
  SELECT factory_id, order_id, colorway_id,
    jsonb_object_agg(size, rejected_qty) AS rejected_qty_by_size
  FROM public.v_order_rejected_qty_by_size
  GROUP BY factory_id, order_id, colorway_id
),
ship_by_size AS (
  SELECT factory_id, order_id, colorway_id,
    public.jsonb_merge_sum_maps(ARRAY_AGG(shipped_qty_by_size)) AS shipped_qty_by_size
  FROM public.shipments
  WHERE shipped_qty_by_size <> '{}'::jsonb
  GROUP BY factory_id, order_id, colorway_id
),
cut_by_size AS (
  SELECT h.factory_id, h.order_id, h.colorway_id,
    public.proportional_qty_by_size(
      SUM(h.count)::integer,
      public.colorway_planned_by_size(h.colorway_id)
    ) AS cut_qty_by_size
  FROM public.hourly_counts h
  WHERE h.department_id = public.get_cutting_department_id(h.factory_id)
  GROUP BY h.factory_id, h.order_id, h.colorway_id,
    public.colorway_planned_by_size(h.colorway_id)
)
SELECT
  so.factory_id,
  so.id AS order_id,
  cw.id AS colorway_id,
  so.style_name,
  so.buyer_name,
  so.po_number,
  COALESCE(so.adj_qty, so.order_qty, 0)::integer AS order_qty,
  COALESCE(cq.cut_qty, 0)::integer AS cut_qty,
  COALESCE(cq.cut_qty_source, 'planned') AS cut_qty_source,
  COALESCE(sq.shipped_qty, 0)::integer AS shipped_qty,
  COALESCE(rq.rejected_qty, 0)::integer AS rejected_qty,
  COALESCE(wt.wip_qty, 0)::integer AS wip_qty,
  (COALESCE(cq.cut_qty, 0)
    - (COALESCE(sq.shipped_qty, 0) + COALESCE(rq.rejected_qty, 0) + COALESCE(wt.wip_qty, 0)))::integer
    AS reconciliation_gap,
  COALESCE(rq.rejected_by_reason, '{}'::jsonb) AS rejected_by_reason,
  COALESCE(rq.rejected_by_stage, '{}'::jsonb) AS rejected_by_stage,
  (COALESCE(cq.cut_qty, 0)
    = COALESCE(sq.shipped_qty, 0) + COALESCE(rq.rejected_qty, 0) + COALESCE(wt.wip_qty, 0)) AS is_balanced,
  ROUND(100.0 * COALESCE(sq.shipped_qty, 0) / NULLIF(COALESCE(so.adj_qty, so.order_qty, 0), 0), 2) AS completion_pct,
  so.status AS order_status,
  sq.last_shipment_date,
  COALESCE(cbs.cut_qty_by_size, '{}'::jsonb) AS cut_qty_by_size,
  COALESCE(sbs.shipped_qty_by_size, '{}'::jsonb) AS shipped_qty_by_size,
  COALESCE(rbs.rejected_qty_by_size, '{}'::jsonb) AS rejected_qty_by_size,
  CASE
    WHEN COALESCE(wt.wip_qty, 0) > 0 AND COALESCE(cbs.cut_qty_by_size, '{}'::jsonb) <> '{}'::jsonb THEN
      public.proportional_qty_by_size(wt.wip_qty, cbs.cut_qty_by_size)
    WHEN COALESCE(wt.wip_qty, 0) > 0 THEN
      public.proportional_qty_by_size(wt.wip_qty, public.colorway_planned_by_size(cw.id))
    ELSE '{}'::jsonb
  END AS wip_qty_by_size
FROM public.style_orders so
LEFT JOIN public.colorways cw ON cw.order_id = so.id
LEFT JOIN public.v_order_cut_qty cq
  ON cq.factory_id = so.factory_id AND cq.order_id = so.id
 AND cq.colorway_id IS NOT DISTINCT FROM cw.id
LEFT JOIN public.v_order_shipped_qty sq
  ON sq.factory_id = so.factory_id AND sq.order_id = so.id
 AND sq.colorway_id IS NOT DISTINCT FROM cw.id
LEFT JOIN public.v_order_rejected_qty rq
  ON rq.factory_id = so.factory_id AND rq.order_id = so.id
 AND rq.colorway_id IS NOT DISTINCT FROM cw.id
LEFT JOIN public.v_order_wip_total wt
  ON wt.factory_id = so.factory_id AND wt.order_id = so.id
 AND wt.colorway_id IS NOT DISTINCT FROM cw.id
LEFT JOIN cut_by_size cbs
  ON cbs.factory_id = so.factory_id AND cbs.order_id = so.id
 AND cbs.colorway_id IS NOT DISTINCT FROM cw.id
LEFT JOIN ship_by_size sbs
  ON sbs.factory_id = so.factory_id AND sbs.order_id = so.id
 AND sbs.colorway_id IS NOT DISTINCT FROM cw.id
LEFT JOIN rej_by_size rbs
  ON rbs.factory_id = so.factory_id AND rbs.order_id = so.id
 AND rbs.colorway_id IS NOT DISTINCT FROM cw.id;

COMMENT ON VIEW public.v_cut_to_ship IS
  'Cut-to-ship per colorway. wip_qty_by_size = proportional split of scalar wip_qty across cut size mix (sums match wip_qty).';



-- >>> 20260615200000_workforce_dynamic_categories.sql
-- Dynamic workforce categories: labels on departments.worker_roles, counts in workforce_logs.headcount_by_category only.

-- Backfill legacy four integer columns into headcount_by_category using department labels.
UPDATE public.workforce_logs wl
SET headcount_by_category = (
  SELECT COALESCE(NULLIF(wl.headcount_by_category, '{}'::jsonb), '{}'::jsonb)
    || jsonb_strip_nulls(jsonb_build_object(
      COALESCE(d.worker_roles->>0, 'Operators'), NULLIF(wl.operators, 0),
      COALESCE(d.worker_roles->>1, 'Helpers'), NULLIF(wl.helpers, 0),
      COALESCE(d.worker_roles->>2, 'Supervisors'), NULLIF(wl.supervisors, 0),
      COALESCE(d.worker_roles->>3, 'Trainees'), NULLIF(wl.trainees, 0)
    ))
  FROM public.departments d
  WHERE d.id = wl.department_id
)
WHERE (wl.operators + wl.helpers + wl.supervisors + wl.trainees) > 0;

ALTER TABLE public.departments
  ALTER COLUMN worker_roles SET DEFAULT '[]'::jsonb;

COMMENT ON COLUMN public.departments.worker_roles IS
  'Workforce category labels when apps includes workforce_log. Empty when not using workforce log.';

UPDATE public.departments
SET worker_roles = '[]'::jsonb
WHERE NOT (COALESCE(apps, '[]'::jsonb) @> '["workforce_log"]'::jsonb);

COMMENT ON COLUMN public.workforce_logs.headcount_by_category IS
  'Headcount by category label (from departments.worker_roles). Keys are display labels, values are counts.';

CREATE OR REPLACE FUNCTION public.workforce_log_total_headcount(p_headcount jsonb DEFAULT '{}'::jsonb)
RETURNS integer
LANGUAGE sql
IMMUTABLE
AS $$
  SELECT COALESCE(public.jsonb_sum_int_values(COALESCE(p_headcount, '{}'::jsonb)), 0)::integer;
$$;

CREATE OR REPLACE VIEW public.v_daily_workforce AS
SELECT
  wl.factory_id,
  wl.department_id,
  wl.log_date,
  wl.shift_id,
  sm.shift_name,
  sm.productive_mins,
  public.workforce_log_total_headcount(wl.headcount_by_category) AS headcount,
  (public.workforce_log_total_headcount(wl.headcount_by_category) * sm.productive_mins)::numeric AS available_mins
FROM public.workforce_logs wl
JOIN public.v_shift_minutes sm ON sm.shift_id = wl.shift_id;

COMMENT ON VIEW public.v_daily_workforce IS
  'One row per factory/department/log_date/shift_id. Headcount from workforce_logs.headcount_by_category; available_mins = headcount * productive_mins.';

-- Patch floor_capture: jsonb-only workforce upsert (before dropping legacy columns).


-- >>> 20260611160000_mes_reporting_rpcs.sql
-- Phase 4: SECURITY INVOKER reporting RPCs wrapping MES views.

-- -----------------------------------------------------------------------------
-- 1. get_factory_kpis
-- Purpose: Factory-wide daily KPI rows for a date range.
-- Inputs: factory_id, date_from, date_to (inclusive).
-- Returns: SETOF v_daily_kpis (factory_id, order_id, department_id, log_date, targets, output, efficiency, shift_breakdown).
-- Source: v_daily_kpis
-- -----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.get_factory_kpis(
  p_factory_id uuid,
  p_date_from date,
  p_date_to date
)
RETURNS SETOF public.v_daily_kpis
LANGUAGE sql
STABLE
SECURITY INVOKER
SET search_path = public
AS $$
  SELECT *
  FROM public.v_daily_kpis
  WHERE factory_id = p_factory_id
    AND log_date >= p_date_from
    AND log_date <= p_date_to
  ORDER BY log_date, department_id, order_id;
$$;

COMMENT ON FUNCTION public.get_factory_kpis(uuid, date, date) IS
  'Factory daily KPIs for date range. Wraps v_daily_kpis.';

-- -----------------------------------------------------------------------------
-- 2. get_department_kpis
-- Purpose: Daily KPI rows for one production department.
-- Returns: SETOF v_daily_kpis filtered to department_id.
-- Source: v_daily_kpis
-- -----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.get_department_kpis(
  p_factory_id uuid,
  p_department_id uuid,
  p_date_from date,
  p_date_to date
)
RETURNS SETOF public.v_daily_kpis
LANGUAGE sql
STABLE
SECURITY INVOKER
SET search_path = public
AS $$
  SELECT *
  FROM public.v_daily_kpis
  WHERE factory_id = p_factory_id
    AND department_id = p_department_id
    AND log_date >= p_date_from
    AND log_date <= p_date_to
  ORDER BY log_date, order_id;
$$;

COMMENT ON FUNCTION public.get_department_kpis(uuid, uuid, date, date) IS
  'Department daily KPIs for date range. Wraps v_daily_kpis.';

-- -----------------------------------------------------------------------------
-- 3. get_department_kpis_by_shift
-- Purpose: Shift-level drilldown for one department.
-- Returns: SETOF v_daily_kpis_by_shift.
-- Source: v_daily_kpis_by_shift
-- -----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.get_department_kpis_by_shift(
  p_factory_id uuid,
  p_department_id uuid,
  p_date_from date,
  p_date_to date
)
RETURNS SETOF public.v_daily_kpis_by_shift
LANGUAGE sql
STABLE
SECURITY INVOKER
SET search_path = public
AS $$
  SELECT *
  FROM public.v_daily_kpis_by_shift
  WHERE factory_id = p_factory_id
    AND department_id = p_department_id
    AND log_date >= p_date_from
    AND log_date <= p_date_to
  ORDER BY log_date, shift_name, order_id;
$$;

COMMENT ON FUNCTION public.get_department_kpis_by_shift(uuid, uuid, date, date) IS
  'Department shift KPIs for date range. Wraps v_daily_kpis_by_shift.';

-- -----------------------------------------------------------------------------
-- 4. get_style_kpis
-- Purpose: Order KPIs across production-flow departments for full captured duration.
-- Returns: SETOF v_daily_kpis for departments in the order process_flow.
-- Source: v_daily_kpis JOIN style_orders / process_flow_steps
-- -----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.get_style_kpis(
  p_factory_id uuid,
  p_order_id uuid
)
RETURNS SETOF public.v_daily_kpis
LANGUAGE sql
STABLE
SECURITY INVOKER
SET search_path = public
AS $$
  SELECT k.*
  FROM public.v_daily_kpis k
  JOIN public.style_orders so
    ON so.id = k.order_id AND so.factory_id = k.factory_id
  WHERE k.factory_id = p_factory_id
    AND k.order_id = p_order_id
    AND (
      so.process_flow_id IS NULL
      OR k.department_id IN (
        SELECT pfs.department_id
        FROM public.process_flow_steps pfs
        WHERE pfs.flow_id = so.process_flow_id
      )
    )
  ORDER BY k.log_date, k.department_id;
$$;

COMMENT ON FUNCTION public.get_style_kpis(uuid, uuid) IS
  'Order KPIs for all departments in the order process flow. Wraps v_daily_kpis.';

-- -----------------------------------------------------------------------------
-- 5. get_order_wip
-- Purpose: Colorway-grained WIP along process flow for an order.
-- Returns: SETOF v_wip_order ordered by flow_step, colorway_id.
-- Source: v_wip_order (latest log_date per colorway/dept only)
-- -----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.get_order_wip(
  p_factory_id uuid,
  p_order_id uuid
)
RETURNS SETOF public.v_wip_order
LANGUAGE sql
STABLE
SECURITY INVOKER
SET search_path = public
AS $$
  WITH ranked AS (
    SELECT
      w.*,
      ROW_NUMBER() OVER (
        PARTITION BY w.colorway_id, w.department_id
        ORDER BY w.log_date DESC NULLS LAST
      ) AS rn
    FROM public.v_wip_order w
    WHERE w.factory_id = p_factory_id
      AND w.order_id = p_order_id
  )
  SELECT
    factory_id, order_id, colorway_id, log_date, flow_step, department_id, wip_qty
  FROM ranked
  WHERE rn = 1
  ORDER BY flow_step, colorway_id NULLS LAST, department_id;
$$;

COMMENT ON FUNCTION public.get_order_wip(uuid, uuid) IS
  'Latest colorway-grained WIP per process-flow department for an order. Wraps v_wip_order.';

-- -----------------------------------------------------------------------------
-- 6. get_audit_report
-- Purpose: Daily audit summary for a factory date range.
-- Returns: SETOF v_audit_summary.
-- Source: v_audit_summary
-- -----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.get_audit_report(
  p_factory_id uuid,
  p_date_from date,
  p_date_to date
)
RETURNS SETOF public.v_audit_summary
LANGUAGE sql
STABLE
SECURITY INVOKER
SET search_path = public
AS $$
  SELECT *
  FROM public.v_audit_summary
  WHERE factory_id = p_factory_id
    AND log_date >= p_date_from
    AND log_date <= p_date_to
  ORDER BY log_date, department_id, order_id;
$$;

COMMENT ON FUNCTION public.get_audit_report(uuid, date, date) IS
  'Audit summary for date range. Wraps v_audit_summary.';

-- -----------------------------------------------------------------------------
-- 7. get_cut_to_ship_report
-- Purpose: Cut-to-ship reconciliation list with optional filters.
-- Date filter: COALESCE(style_orders.delivery_date, style_orders.order_date) — delivery preferred for fulfillment window.
-- p_balanced_only: NULL = all, true = balanced only, false = unbalanced only.
-- Returns: SETOF v_cut_to_ship.
-- Source: v_cut_to_ship JOIN style_orders (buyer + date filters)
-- -----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.get_cut_to_ship_report(
  p_factory_id uuid,
  p_date_from date DEFAULT NULL,
  p_date_to date DEFAULT NULL,
  p_buyer_id uuid DEFAULT NULL,
  p_balanced_only boolean DEFAULT NULL
)
RETURNS SETOF public.v_cut_to_ship
LANGUAGE sql
STABLE
SECURITY INVOKER
SET search_path = public
AS $$
  SELECT c.*
  FROM public.v_cut_to_ship c
  JOIN public.style_orders so
    ON so.id = c.order_id AND so.factory_id = c.factory_id
  WHERE c.factory_id = p_factory_id
    AND (
      p_date_from IS NULL
      OR COALESCE(so.delivery_date, so.order_date) >= p_date_from
    )
    AND (
      p_date_to IS NULL
      OR COALESCE(so.delivery_date, so.order_date) <= p_date_to
    )
    AND (p_buyer_id IS NULL OR so.buyer_id = p_buyer_id)
    AND (p_balanced_only IS NULL OR c.is_balanced = p_balanced_only)
  ORDER BY so.style_name, c.colorway_id NULLS LAST;
$$;

COMMENT ON FUNCTION public.get_cut_to_ship_report(uuid, date, date, uuid, boolean) IS
  'Cut-to-ship list with optional delivery_date/order_date range, buyer, balanced filter. Wraps v_cut_to_ship.';

-- -----------------------------------------------------------------------------
-- 8. get_cut_to_ship_detail
-- Purpose: Drill-down JSON for one order: reconciliation, shipments, rejections, wip_by_dept.
-- Returns: JSONB { reconciliation, shipments, rejections, wip_by_dept }.
-- Sources: v_cut_to_ship, shipments, rejections, get_order_wip (v_wip_order)
-- -----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.get_cut_to_ship_detail(
  p_factory_id uuid,
  p_order_id uuid
)
RETURNS jsonb
LANGUAGE sql
STABLE
SECURITY INVOKER
SET search_path = public
AS $$
  SELECT jsonb_build_object(
    'reconciliation',
      COALESCE((
        SELECT jsonb_agg(to_jsonb(c) ORDER BY c.colorway_id NULLS LAST)
        FROM public.v_cut_to_ship c
        WHERE c.factory_id = p_factory_id AND c.order_id = p_order_id
      ), '[]'::jsonb),
    'shipments',
      COALESCE((
        SELECT jsonb_agg(to_jsonb(s) ORDER BY s.shipment_date DESC, s.logged_at DESC)
        FROM public.shipments s
        WHERE s.factory_id = p_factory_id AND s.order_id = p_order_id
      ), '[]'::jsonb),
    'rejections',
      COALESCE((
        SELECT jsonb_agg(to_jsonb(r) ORDER BY r.rejected_date DESC, r.logged_at DESC)
        FROM public.rejections r
        WHERE r.factory_id = p_factory_id AND r.order_id = p_order_id
      ), '[]'::jsonb),
    'wip_by_dept',
      COALESCE((
        SELECT jsonb_agg(to_jsonb(w) ORDER BY w.flow_step, w.colorway_id NULLS LAST, w.department_id)
        FROM public.get_order_wip(p_factory_id, p_order_id) w
      ), '[]'::jsonb)
  );
$$;

COMMENT ON FUNCTION public.get_cut_to_ship_detail(uuid, uuid) IS
  'Order cut-to-ship drill-down: reconciliation per colorway, shipment/rejection rows, latest wip_by_dept.';

-- -----------------------------------------------------------------------------
-- 9. get_live_dept_kpi
-- Purpose: Today''s daily KPI rows for a department (floor tile).
-- Returns: SETOF v_daily_kpis for CURRENT_DATE.
-- Source: v_daily_kpis
-- -----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.get_live_dept_kpi(
  p_factory_id uuid,
  p_department_id uuid
)
RETURNS SETOF public.v_daily_kpis
LANGUAGE sql
STABLE
SECURITY INVOKER
SET search_path = public
AS $$
  SELECT *
  FROM public.v_daily_kpis
  WHERE factory_id = p_factory_id
    AND department_id = p_department_id
    AND log_date = CURRENT_DATE
  ORDER BY order_id;
$$;

COMMENT ON FUNCTION public.get_live_dept_kpi(uuid, uuid) IS
  'Today''s department KPI rows for floor display. Wraps v_daily_kpis.';

-- Grants: authenticated only
REVOKE ALL ON FUNCTION public.get_factory_kpis(uuid, date, date) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.get_department_kpis(uuid, uuid, date, date) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.get_department_kpis_by_shift(uuid, uuid, date, date) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.get_style_kpis(uuid, uuid) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.get_order_wip(uuid, uuid) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.get_audit_report(uuid, date, date) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.get_cut_to_ship_report(uuid, date, date, uuid, boolean) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.get_cut_to_ship_detail(uuid, uuid) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.get_live_dept_kpi(uuid, uuid) FROM PUBLIC;

GRANT EXECUTE ON FUNCTION public.get_factory_kpis(uuid, date, date) TO authenticated;
GRANT EXECUTE ON FUNCTION public.get_department_kpis(uuid, uuid, date, date) TO authenticated;
GRANT EXECUTE ON FUNCTION public.get_department_kpis_by_shift(uuid, uuid, date, date) TO authenticated;
GRANT EXECUTE ON FUNCTION public.get_style_kpis(uuid, uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.get_order_wip(uuid, uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.get_audit_report(uuid, date, date) TO authenticated;
GRANT EXECUTE ON FUNCTION public.get_cut_to_ship_report(uuid, date, date, uuid, boolean) TO authenticated;
GRANT EXECUTE ON FUNCTION public.get_cut_to_ship_detail(uuid, uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.get_live_dept_kpi(uuid, uuid) TO authenticated;



-- >>> 20260611190000_mes_floor_kpi_rpcs.sql
-- Phase 7: Floor PWA KPI RPCs — rejections running total + dept quality for date.

-- -----------------------------------------------------------------------------
-- get_today_rejections_for_order
-- Running rejection total for an order on a given date (default today).
-- -----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.get_today_rejections_for_order(
  p_factory_id uuid,
  p_order_id uuid,
  p_rejected_date date DEFAULT CURRENT_DATE
)
RETURNS jsonb
LANGUAGE sql
STABLE
SECURITY INVOKER
SET search_path = public
AS $$
  SELECT jsonb_build_object(
    'total_qty', COALESCE((
      SELECT SUM(qty)::integer
      FROM public.rejections
      WHERE factory_id = p_factory_id
        AND order_id = p_order_id
        AND rejected_date = p_rejected_date
    ), 0),
    'by_reason', COALESCE((
      SELECT jsonb_agg(jsonb_build_object('reason_code', reason_code, 'qty', qty) ORDER BY qty DESC)
      FROM (
        SELECT reason_code, SUM(qty)::integer AS qty
        FROM public.rejections
        WHERE factory_id = p_factory_id
          AND order_id = p_order_id
          AND rejected_date = p_rejected_date
        GROUP BY reason_code
      ) x
    ), '[]'::jsonb),
    'by_stage', COALESCE((
      SELECT jsonb_agg(jsonb_build_object('stage', stage, 'qty', qty) ORDER BY qty DESC)
      FROM (
        SELECT stage, SUM(qty)::integer AS qty
        FROM public.rejections
        WHERE factory_id = p_factory_id
          AND order_id = p_order_id
          AND rejected_date = p_rejected_date
        GROUP BY stage
      ) y
    ), '[]'::jsonb)
  );
$$;

COMMENT ON FUNCTION public.get_today_rejections_for_order(uuid, uuid, date) IS
  'Rejection totals for one order on a date: total_qty, by_reason, by_stage.';

-- -----------------------------------------------------------------------------
-- get_dept_quality_for_date
-- QC metrics from v_daily_quality for a department on a date.
-- -----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.get_dept_quality_for_date(
  p_factory_id uuid,
  p_department_id uuid,
  p_log_date date DEFAULT CURRENT_DATE
)
RETURNS SETOF public.v_daily_quality
LANGUAGE sql
STABLE
SECURITY INVOKER
SET search_path = public
AS $$
  SELECT *
  FROM public.v_daily_quality
  WHERE factory_id = p_factory_id
    AND department_id = p_department_id
    AND log_date = p_log_date
  ORDER BY order_id;
$$;

COMMENT ON FUNCTION public.get_dept_quality_for_date(uuid, uuid, date) IS
  'Department QC KPI rows for a date (DHU, defective_pct, inspected). Wraps v_daily_quality.';

REVOKE ALL ON FUNCTION public.get_today_rejections_for_order(uuid, uuid, date) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.get_dept_quality_for_date(uuid, uuid, date) FROM PUBLIC;

GRANT EXECUTE ON FUNCTION public.get_today_rejections_for_order(uuid, uuid, date) TO authenticated;
GRANT EXECUTE ON FUNCTION public.get_dept_quality_for_date(uuid, uuid, date) TO authenticated;



-- >>> 20260612100000_revoke_anon_reporting_rpcs.sql
-- Phase 9a: Revoke anon EXECUTE on MES reporting RPCs (defense-in-depth).
-- floor_capture intentionally retains anon — floor login uses anon before JWT session.

REVOKE EXECUTE ON FUNCTION public.get_factory_kpis(uuid, date, date) FROM anon;
REVOKE EXECUTE ON FUNCTION public.get_department_kpis(uuid, uuid, date, date) FROM anon;
REVOKE EXECUTE ON FUNCTION public.get_department_kpis_by_shift(uuid, uuid, date, date) FROM anon;
REVOKE EXECUTE ON FUNCTION public.get_style_kpis(uuid, uuid) FROM anon;
REVOKE EXECUTE ON FUNCTION public.get_order_wip(uuid, uuid) FROM anon;
REVOKE EXECUTE ON FUNCTION public.get_audit_report(uuid, date, date) FROM anon;
REVOKE EXECUTE ON FUNCTION public.get_cut_to_ship_report(uuid, date, date, uuid, boolean) FROM anon;
REVOKE EXECUTE ON FUNCTION public.get_cut_to_ship_detail(uuid, uuid) FROM anon;
REVOKE EXECUTE ON FUNCTION public.get_live_dept_kpi(uuid, uuid) FROM anon;
REVOKE EXECUTE ON FUNCTION public.get_today_rejections_for_order(uuid, uuid, date) FROM anon;
REVOKE EXECUTE ON FUNCTION public.get_dept_quality_for_date(uuid, uuid, date) FROM anon;

-- Re-affirm authenticated access (idempotent)
GRANT EXECUTE ON FUNCTION public.get_factory_kpis(uuid, date, date) TO authenticated;
GRANT EXECUTE ON FUNCTION public.get_department_kpis(uuid, uuid, date, date) TO authenticated;
GRANT EXECUTE ON FUNCTION public.get_department_kpis_by_shift(uuid, uuid, date, date) TO authenticated;
GRANT EXECUTE ON FUNCTION public.get_style_kpis(uuid, uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.get_order_wip(uuid, uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.get_audit_report(uuid, date, date) TO authenticated;
GRANT EXECUTE ON FUNCTION public.get_cut_to_ship_report(uuid, date, date, uuid, boolean) TO authenticated;
GRANT EXECUTE ON FUNCTION public.get_cut_to_ship_detail(uuid, uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.get_live_dept_kpi(uuid, uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.get_today_rejections_for_order(uuid, uuid, date) TO authenticated;
GRANT EXECUTE ON FUNCTION public.get_dept_quality_for_date(uuid, uuid, date) TO authenticated;



-- >>> profile_dept_has_app (from 20260611110000)
-- Extend floor_capture with rejection_log + shipment_log capture types.
-- Inputs: p_factory_id, p_user_id, p_type, p_payload (orderId, qty/shippedQty, stage/shipmentType, etc.)
-- Outputs: { id } on success; { error, code } on validation failure.

CREATE OR REPLACE FUNCTION public.profile_dept_has_app(
  p_user_id uuid,
  p_factory_id uuid,
  p_app text
)
RETURNS boolean
LANGUAGE sql
STABLE
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.profiles p
    JOIN public.departments d ON d.id = p.department_id
    WHERE p.id = p_user_id
      AND d.factory_id = p_factory_id
      AND d.apps @> jsonb_build_array(p_app)
  );
$$;

COMMENT ON FUNCTION public.profile_dept_has_app(uuid, uuid, text) IS
  'True when the user profile department apps JSONB includes p_app (e.g. shipment_log).';


-- =============================================================================
-- I. Hardened floor_capture — single merged definition (no pg_get_functiondef patches)
-- =============================================================================
DROP FUNCTION IF EXISTS public.floor_capture(uuid, uuid, text, jsonb) CASCADE;

CREATE OR REPLACE FUNCTION public.profile_has_capture_app(
  p_user_id uuid,
  p_factory_id uuid,
  p_app text
)
RETURNS boolean
LANGUAGE sql
STABLE
AS $$
  SELECT CASE
    WHEN p_app IN ('shipment_log', 'final_rejection_log') THEN
      EXISTS (
        SELECT 1
        FROM public.profiles p
        WHERE p.id = p_user_id
          AND p.factory_id = p_factory_id
          AND p.status = 'Active'
          AND (
            COALESCE(p.assigned_apps, '[]'::jsonb) @> jsonb_build_array(p_app)
            OR p.user_role IN ('admin', 'superadmin')
            OR (p_app = 'final_rejection_log' AND p.user_role = 'quality_manager')
          )
      )
    ELSE
      public.profile_dept_has_app(p_user_id, p_factory_id, p_app)
  END;
$$;

COMMENT ON FUNCTION public.profile_has_capture_app(uuid, uuid, text) IS
  'Capture auth: shipment_log and final_rejection_log use profiles.assigned_apps or admin/quality_manager role; other apps use department.apps.';

CREATE OR REPLACE FUNCTION public.floor_capture_fail(
  p_reason text,
  p_code text,
  p_details jsonb DEFAULT '{}'::jsonb
)
RETURNS jsonb
LANGUAGE sql
IMMUTABLE
AS $$
  SELECT jsonb_build_object(
    'error', p_reason,
    'code', p_code,
    'details', COALESCE(p_details, '{}'::jsonb)
  );
$$;

COMMENT ON FUNCTION public.floor_capture_fail(text, text, jsonb) IS
  'Standard floor_capture error payload: { error, code, details }.';

CREATE OR REPLACE FUNCTION public.floor_capture(
  p_factory_id uuid,
  p_user_id uuid,
  p_type text,
  p_payload jsonb
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_id uuid;
  v_existing uuid;
  v_challan text;
  v_po text;
  v_colorway_id uuid;
  v_profile_department_id uuid;
  v_user_role text;
  v_dept_apps jsonb;
  v_log_date date;
  v_shift_id uuid;
  v_shift_type text;
  v_count integer;
  v_sent_qty integer;
  v_available_wip integer;
  v_slip public.handover_slips%ROWTYPE;
  v_to_dept_production boolean;
  v_to_dept_apps jsonb;
  v_payload_dept uuid;
  v_qty_by_size jsonb;
  v_recv_by_size jsonb;
  v_ship_by_size jsonb;
  v_size_sum integer;
  v_bad_key text;
  v_headcount jsonb;
BEGIN
  IF p_factory_id IS NULL OR p_user_id IS NULL THEN
    RETURN public.floor_capture_fail('Invalid session', 'INVALID_SESSION');
  END IF;

  SELECT p.department_id, p.user_role, d.apps
  INTO v_profile_department_id, v_user_role, v_dept_apps
  FROM public.profiles p
  LEFT JOIN public.departments d ON d.id = p.department_id
  WHERE p.id = p_user_id
    AND p.factory_id = p_factory_id
    AND p.status = 'Active';

  IF NOT FOUND THEN
    RETURN public.floor_capture_fail('User profile not found in factory', 'INVALID_SESSION');
  END IF;

  IF p_type = 'hourly_upsert' THEN
    IF NOT public.profile_dept_has_app(p_user_id, p_factory_id, 'hourly') THEN
      RETURN public.floor_capture_fail(
        'Department not authorized for hourly capture',
        'REQUIRE_APP_HOURLY'
      );
    END IF;

    IF COALESCE(v_dept_apps, '[]'::jsonb) @> '["qc_log"]'::jsonb THEN
      RETURN public.floor_capture_fail(
        'Department uses QC capture; hourly not allowed',
        'XOR_VIOLATION'
      );
    END IF;

    IF p_payload->>'orderId' IS NULL OR p_payload->>'orderId' !~* '^[0-9a-f-]{36}$' THEN
      RETURN public.floor_capture_fail('orderId must be a valid UUID', 'INVALID_ORDER');
    END IF;

    IF NOT EXISTS (
      SELECT 1 FROM public.style_orders
      WHERE id = (p_payload->>'orderId')::uuid AND factory_id = p_factory_id
    ) THEN
      RETURN public.floor_capture_fail('Order not found in factory', 'INVALID_ORDER');
    END IF;

    v_payload_dept := (p_payload->>'departmentId')::uuid;
    IF v_profile_department_id IS NULL OR v_payload_dept IS DISTINCT FROM v_profile_department_id THEN
      RETURN public.floor_capture_fail(
        'departmentId must match user department',
        'DEPT_MISMATCH',
        jsonb_build_object('expectedDepartmentId', v_profile_department_id)
      );
    END IF;

    IF p_payload->>'hourSlot' IS NULL OR btrim(p_payload->>'hourSlot') = '' THEN
      RETURN public.floor_capture_fail('hourSlot is required', 'MISSING_HOUR_SLOT');
    END IF;

    BEGIN
      v_shift_id := public.get_shift_for_hour_slot(p_factory_id, p_payload->>'hourSlot');
    EXCEPTION WHEN OTHERS THEN
      v_shift_id := NULL;
    END;
    IF v_shift_id IS NULL THEN
      RETURN public.floor_capture_fail(
        'hourSlot does not match any active shift slot',
        'INVALID_HOUR_SLOT',
        jsonb_build_object('hourSlot', p_payload->>'hourSlot')
      );
    END IF;

    IF COALESCE(p_payload->'countBySize', '{}'::jsonb) <> '{}'::jsonb THEN
      v_count := public.jsonb_sum_int_values(p_payload->'countBySize');
    ELSE
      BEGIN
        v_count := (p_payload->>'count')::integer;
      EXCEPTION WHEN OTHERS THEN
        RETURN public.floor_capture_fail('count must be an integer', 'INVALID_COUNT');
      END;
    END IF;

    IF v_count IS NULL OR v_count < 0 THEN
      RETURN public.floor_capture_fail('count must be a non-negative integer', 'INVALID_COUNT');
    END IF;

    v_log_date := COALESCE((p_payload->>'logDate')::date, CURRENT_DATE);
    IF v_log_date < CURRENT_DATE - 7 THEN
      RETURN public.floor_capture_fail(
        'logDate cannot be more than 7 days in the past',
        'BACKFILL_TOO_OLD',
        jsonb_build_object('logDate', v_log_date)
      );
    END IF;

    SELECT s.type INTO v_shift_type
    FROM public.shifts s
    WHERE s.id = v_shift_id;

    IF upper(COALESCE(v_shift_type, '')) = 'OT' AND NOT EXISTS (
      SELECT 1 FROM public.workforce_logs wl
      WHERE wl.factory_id = p_factory_id
        AND wl.department_id = v_profile_department_id
        AND wl.log_date = v_log_date
        AND wl.shift_id = v_shift_id
        AND public.jsonb_sum_int_values(COALESCE(wl.headcount_by_category, '{}'::jsonb)) > 0
    ) THEN
      RETURN public.floor_capture_fail(
        'OT hourly output requires OT workforce logged for this date',
        'OT_OUTPUT_WITHOUT_WORKFORCE',
        jsonb_build_object('logDate', v_log_date, 'shiftId', v_shift_id)
      );
    END IF;

    v_colorway_id := NULLIF(p_payload->>'colorwayId', '')::uuid;

    SELECT id INTO v_existing
    FROM public.hourly_counts
    WHERE factory_id = p_factory_id
      AND order_id = (p_payload->>'orderId')::uuid
      AND department_id = v_payload_dept
      AND COALESCE(colorway_id, '00000000-0000-0000-0000-000000000000'::uuid)
        = COALESCE(v_colorway_id, '00000000-0000-0000-0000-000000000000'::uuid)
      AND hour_slot = p_payload->>'hourSlot'
      AND log_date = v_log_date
    LIMIT 1;

    IF v_existing IS NOT NULL THEN
      UPDATE public.hourly_counts
      SET count = v_count,
          count_by_size = COALESCE(p_payload->'countBySize', '{}'::jsonb),
          logged_at = COALESCE((p_payload->>'loggedAt')::timestamptz, now()),
          shift_id = NULLIF(p_payload->>'shiftId', '')::uuid,
          resource_id = NULLIF(p_payload->>'resourceId', '')::uuid,
          logged_by = p_user_id
      WHERE id = v_existing;
      RETURN jsonb_build_object('id', v_existing);
    END IF;

    INSERT INTO public.hourly_counts (
      factory_id, order_id, colorway_id, department_id, resource_id, shift_id,
      hour_slot, log_date, count, count_by_size, logged_by, logged_at
    ) VALUES (
      p_factory_id,
      (p_payload->>'orderId')::uuid,
      v_colorway_id,
      v_payload_dept,
      NULLIF(p_payload->>'resourceId', '')::uuid,
      NULLIF(p_payload->>'shiftId', '')::uuid,
      p_payload->>'hourSlot',
      v_log_date,
      v_count,
      COALESCE(p_payload->'countBySize', '{}'::jsonb),
      p_user_id,
      COALESCE((p_payload->>'loggedAt')::timestamptz, now())
    )
    RETURNING id INTO v_id;

    RETURN jsonb_build_object('id', v_id);
  END IF;

  IF p_type = 'inspection' THEN
    IF NOT public.profile_dept_has_app(p_user_id, p_factory_id, 'qc_log') THEN
      RETURN public.floor_capture_fail(
        'Department not authorized for QC capture',
        'REQUIRE_APP_QC'
      );
    END IF;

    IF COALESCE(v_dept_apps, '[]'::jsonb) @> '["hourly"]'::jsonb THEN
      RETURN public.floor_capture_fail(
        'Department uses hourly capture; QC not allowed',
        'XOR_VIOLATION'
      );
    END IF;

    IF p_payload->>'orderId' IS NULL OR p_payload->>'orderId' !~* '^[0-9a-f-]{36}$' THEN
      RETURN public.floor_capture_fail('orderId must be a valid UUID', 'INVALID_ORDER');
    END IF;

    IF NOT EXISTS (
      SELECT 1 FROM public.style_orders
      WHERE id = (p_payload->>'orderId')::uuid AND factory_id = p_factory_id
    ) THEN
      RETURN public.floor_capture_fail('Order not found in factory', 'INVALID_ORDER');
    END IF;

    v_payload_dept := (p_payload->>'departmentId')::uuid;
    IF v_profile_department_id IS NULL OR v_payload_dept IS DISTINCT FROM v_profile_department_id THEN
      RETURN public.floor_capture_fail(
        'departmentId must match user department',
        'DEPT_MISMATCH',
        jsonb_build_object('expectedDepartmentId', v_profile_department_id)
      );
    END IF;

    IF p_payload->>'result' IS NULL OR p_payload->>'result' NOT IN (
      'pass', 'fail', 'rework', 'rework_pass'
    ) THEN
      RETURN public.floor_capture_fail('Invalid inspection result', 'INVALID_RESULT');
    END IF;

    IF p_payload->>'result' IN ('fail', 'rework')
       AND COALESCE(jsonb_array_length(COALESCE(p_payload->'defects', '[]'::jsonb)), 0) = 0 THEN
      RAISE NOTICE 'Inspection % without defects JSON', p_payload->>'result';
    END IF;

    INSERT INTO public.inspections (
      factory_id, order_id, colorway_id, department_id, piece_ref, result, defects, logged_by, logged_at
    ) VALUES (
      p_factory_id,
      (p_payload->>'orderId')::uuid,
      NULLIF(p_payload->>'colorwayId', '')::uuid,
      v_payload_dept,
      NULLIF(p_payload->>'pieceRef', ''),
      p_payload->>'result',
      COALESCE(p_payload->'defects', '[]'::jsonb),
      p_user_id,
      COALESCE((p_payload->>'loggedAt')::timestamptz, now())
    )
    RETURNING id INTO v_id;
    RETURN jsonb_build_object('id', v_id);
  END IF;

  -- workforce_upsert: plapps sends headcountByCategory (label -> count JSONB object).
  IF p_type = 'workforce_upsert' THEN
    IF NOT (
      public.profile_dept_has_app(p_user_id, p_factory_id, 'workforce_log')
      OR v_user_role IN ('supervisor', 'admin', 'superadmin', 'quality_manager')
    ) THEN
      RETURN public.floor_capture_fail(
        'Department not authorized for workforce log',
        'REQUIRE_APP_WORKFORCE'
      );
    END IF;

    v_payload_dept := (p_payload->>'departmentId')::uuid;
    IF v_profile_department_id IS NULL OR v_payload_dept IS DISTINCT FROM v_profile_department_id THEN
      RETURN public.floor_capture_fail(
        'departmentId must match user department',
        'DEPT_MISMATCH',
        jsonb_build_object('expectedDepartmentId', v_profile_department_id)
      );
    END IF;

    IF NULLIF(p_payload->>'shiftId', '') IS NULL THEN
      RETURN public.floor_capture_fail('shiftId is required', 'MISSING_SHIFT');
    END IF;

    v_log_date := (p_payload->>'logDate')::date;
    IF v_log_date IS NULL THEN
      RETURN public.floor_capture_fail('logDate is required', 'BACKFILL_TOO_OLD');
    END IF;

    IF v_log_date < CURRENT_DATE - 7 THEN
      RETURN public.floor_capture_fail(
        'logDate cannot be more than 7 days in the past',
        'BACKFILL_TOO_OLD',
        jsonb_build_object('logDate', v_log_date)
      );
    END IF;

    v_headcount := COALESCE(p_payload->'headcountByCategory', '{}'::jsonb);
    IF public.jsonb_sum_int_values(v_headcount) <= 0 THEN
      RETURN public.floor_capture_fail('At least one headcount field must be > 0', 'EMPTY_HEADCOUNT');
    END IF;

    SELECT id INTO v_existing
    FROM public.workforce_logs
    WHERE factory_id = p_factory_id
      AND department_id = v_payload_dept
      AND log_date = v_log_date
      AND shift_id IS NOT DISTINCT FROM NULLIF(p_payload->>'shiftId', '')::uuid
    LIMIT 1;

    IF v_existing IS NOT NULL THEN
      UPDATE public.workforce_logs SET
        order_id = NULLIF(p_payload->>'orderId', '')::uuid,
        headcount_by_category = v_headcount,
        logged_by = p_user_id,
        logged_at = COALESCE((p_payload->>'loggedAt')::timestamptz, now())
      WHERE id = v_existing;
      RETURN jsonb_build_object('id', v_existing);
    END IF;

    INSERT INTO public.workforce_logs (
      factory_id, order_id, department_id, shift_id, log_date,
      headcount_by_category, logged_by, logged_at
    ) VALUES (
      p_factory_id,
      NULLIF(p_payload->>'orderId', '')::uuid,
      v_payload_dept,
      NULLIF(p_payload->>'shiftId', '')::uuid,
      v_log_date,
      v_headcount,
      p_user_id,
      COALESCE((p_payload->>'loggedAt')::timestamptz, now())
    )
    RETURNING id INTO v_id;
    RETURN jsonb_build_object('id', v_id);
  END IF;

  IF p_type = 'handover_send' THEN
    IF NOT public.profile_dept_has_app(p_user_id, p_factory_id, 'transaction') THEN
      RETURN public.floor_capture_fail(
        'Department not authorized for handover',
        'REQUIRE_APP_TRANSACTION'
      );
    END IF;

    IF p_payload->>'orderId' IS NULL OR p_payload->>'orderId' !~* '^[0-9a-f-]{36}$' THEN
      RETURN public.floor_capture_fail('orderId must be a valid UUID', 'INVALID_ORDER');
    END IF;

    IF NOT EXISTS (
      SELECT 1 FROM public.style_orders
      WHERE id = (p_payload->>'orderId')::uuid AND factory_id = p_factory_id
    ) THEN
      RETURN public.floor_capture_fail('Order not found in factory', 'INVALID_ORDER');
    END IF;

    IF v_profile_department_id IS NULL
       OR (p_payload->>'fromDepartmentId')::uuid IS DISTINCT FROM v_profile_department_id THEN
      RETURN public.floor_capture_fail(
        'fromDepartmentId must match user department',
        'CANT_SEND_FROM_OTHER_DEPT',
        jsonb_build_object('expectedDepartmentId', v_profile_department_id)
      );
    END IF;

    SELECT d.is_production, d.apps
    INTO v_to_dept_production, v_to_dept_apps
    FROM public.departments d
    WHERE d.id = (p_payload->>'toDepartmentId')::uuid
      AND d.factory_id = p_factory_id;

    IF NOT FOUND OR NOT (
      COALESCE(v_to_dept_production, false)
      OR COALESCE(v_to_dept_apps, '[]'::jsonb) @> '["shipment_log"]'::jsonb
    ) THEN
      RETURN public.floor_capture_fail(
        'Destination must be a production department or Shipment',
        'INVALID_DESTINATION'
      );
    END IF;

    v_sent_qty := COALESCE((p_payload->>'sentQty')::integer, 0);
    IF v_sent_qty <= 0 THEN
      RETURN public.floor_capture_fail('sentQty must be a positive integer', 'INVALID_QTY');
    END IF;

    v_colorway_id := NULLIF(p_payload->>'colorwayId', '')::uuid;

    SELECT COALESCE(w.wip_qty, 0) INTO v_available_wip
    FROM public.v_wip_dept w
    WHERE w.factory_id = p_factory_id
      AND w.order_id = (p_payload->>'orderId')::uuid
      AND w.colorway_id IS NOT DISTINCT FROM v_colorway_id
      AND w.department_id = v_profile_department_id
    ORDER BY w.log_date DESC NULLS LAST
    LIMIT 1;

    IF COALESCE(v_available_wip, 0) < v_sent_qty THEN
      RETURN public.floor_capture_fail(
        'sentQty exceeds available WIP at sending department',
        'OVERSENT',
        jsonb_build_object('availableWip', COALESCE(v_available_wip, 0), 'sentQty', v_sent_qty)
      );
    END IF;

    v_qty_by_size := COALESCE(p_payload->'qtyBySize', '{}'::jsonb);
    IF v_qty_by_size <> '{}'::jsonb THEN
      v_size_sum := public.jsonb_sum_int_values(v_qty_by_size);
      IF v_size_sum <> v_sent_qty THEN
        RETURN public.floor_capture_fail(
          'qtyBySize sum must equal sentQty',
          'SIZE_TOTAL_MISMATCH',
          jsonb_build_object('sentQty', v_sent_qty, 'sizeSum', v_size_sum)
        );
      END IF;
    END IF;

    v_challan := 'CH-' || to_char(now(), 'YYYY') || '-' || upper(substr(md5(random()::text), 1, 5));
    INSERT INTO public.handover_slips (
      factory_id, order_id, colorway_id, from_department_id, to_department_id,
      sent_qty, received_qty, qty_by_size, sent_by, sent_at, notes, status, challan_number
    ) VALUES (
      p_factory_id,
      (p_payload->>'orderId')::uuid,
      v_colorway_id,
      v_profile_department_id,
      (p_payload->>'toDepartmentId')::uuid,
      v_sent_qty,
      NULL,
      v_qty_by_size,
      p_user_id,
      COALESCE((p_payload->>'sentAt')::timestamptz, now()),
      NULLIF(p_payload->>'notes', ''),
      'pending',
      v_challan
    )
    RETURNING id INTO v_id;
    RETURN jsonb_build_object('id', v_id, 'challanNumber', v_challan);
  END IF;

  IF p_type = 'handover_receive' THEN
    SELECT * INTO v_slip
    FROM public.handover_slips
    WHERE id = (p_payload->>'slipId')::uuid
      AND factory_id = p_factory_id;

    IF NOT FOUND THEN
      RETURN public.floor_capture_fail('Handover slip not found', 'SLIP_NOT_FOUND');
    END IF;

    IF v_slip.status IS DISTINCT FROM 'pending' THEN
      RETURN public.floor_capture_fail('Handover slip is not pending', 'SLIP_NOT_PENDING');
    END IF;

    IF v_profile_department_id IS NULL OR v_slip.to_department_id IS DISTINCT FROM v_profile_department_id THEN
      RETURN public.floor_capture_fail(
        'Receiving department must match user department',
        'CANT_RECEIVE_ELSEWHERE',
        jsonb_build_object('expectedDepartmentId', v_profile_department_id)
      );
    END IF;

    IF COALESCE((p_payload->>'receivedQty')::integer, 0) <= 0 THEN
      RETURN public.floor_capture_fail('receivedQty must be a positive integer', 'INVALID_QTY');
    END IF;

    v_recv_by_size := COALESCE(p_payload->'receivedQtyBySize', '{}'::jsonb);
    IF v_recv_by_size <> '{}'::jsonb THEN
      v_size_sum := public.jsonb_sum_int_values(v_recv_by_size);
      IF v_size_sum <> (p_payload->>'receivedQty')::integer THEN
        RETURN public.floor_capture_fail(
          'receivedQtyBySize sum must equal receivedQty',
          'SIZE_TOTAL_MISMATCH',
          jsonb_build_object('receivedQty', (p_payload->>'receivedQty')::integer, 'sizeSum', v_size_sum)
        );
      END IF;
      IF COALESCE(v_slip.qty_by_size, '{}'::jsonb) <> '{}'::jsonb THEN
        FOR v_bad_key IN SELECT key FROM jsonb_each_text(v_recv_by_size) LOOP
          IF NOT (COALESCE(v_slip.qty_by_size, '{}'::jsonb) ? v_bad_key) THEN
            RETURN public.floor_capture_fail(
              'Receive size not defined on send slip',
              'NO_SIZE_DEFINED',
              jsonb_build_object('size', v_bad_key)
            );
          END IF;
        END LOOP;
      END IF;
    END IF;

    UPDATE public.handover_slips
    SET received_qty = (p_payload->>'receivedQty')::integer,
        received_qty_by_size = v_recv_by_size,
        received_by = p_user_id,
        received_at = now(),
        status = 'received'
    WHERE id = v_slip.id;
    RETURN jsonb_build_object('ok', true);
  END IF;

  IF p_type = 'attendance_upsert' THEN
    IF NOT public.profile_dept_has_app(p_user_id, p_factory_id, 'attendance') THEN
      RETURN public.floor_capture_fail(
        'Department not authorized for attendance',
        'REQUIRE_APP_ATTENDANCE'
      );
    END IF;

    IF NULLIF(p_payload->>'shiftId', '') IS NULL THEN
      RETURN public.floor_capture_fail('shiftId is required', 'MISSING_SHIFT');
    END IF;

    IF p_payload->>'status' IS NULL OR replace(p_payload->>'status', 'half-day', 'half_day') NOT IN (
      'present', 'absent', 'half_day', 'late'
    ) THEN
      RETURN public.floor_capture_fail('Invalid attendance status', 'INVALID_STATUS');
    END IF;

    IF NOT EXISTS (
      SELECT 1 FROM public.workers w
      WHERE w.id = (p_payload->>'workerId')::uuid
        AND w.factory_id = p_factory_id
        AND w.department_id = v_profile_department_id
        AND w.is_active = true
    ) THEN
      RETURN public.floor_capture_fail('Worker not found in department', 'INVALID_WORKER');
    END IF;

    SELECT id INTO v_existing
    FROM public.attendance_records
    WHERE worker_id = (p_payload->>'workerId')::uuid
      AND record_date = (p_payload->>'recordDate')::date
      AND shift_id IS NOT DISTINCT FROM NULLIF(p_payload->>'shiftId', '')::uuid
    LIMIT 1;

    IF v_existing IS NOT NULL THEN
      UPDATE public.attendance_records
      SET status = replace(p_payload->>'status', 'half-day', 'half_day'),
          logged_by = p_user_id,
          logged_at = now()
      WHERE id = v_existing;
      RETURN jsonb_build_object('id', v_existing);
    END IF;

    INSERT INTO public.attendance_records (
      factory_id, worker_id, department_id, shift_id, record_date, status, logged_by, logged_at
    ) VALUES (
      p_factory_id,
      (p_payload->>'workerId')::uuid,
      v_profile_department_id,
      NULLIF(p_payload->>'shiftId', '')::uuid,
      (p_payload->>'recordDate')::date,
      replace(p_payload->>'status', 'half-day', 'half_day'),
      p_user_id,
      now()
    )
    RETURNING id INTO v_id;
    RETURN jsonb_build_object('id', v_id);
  END IF;

  IF p_type = 'audit_session' THEN
    IF NOT (
      public.profile_dept_has_app(p_user_id, p_factory_id, 'audit')
      OR v_user_role IN ('auditor', 'admin', 'superadmin', 'quality_manager')
    ) THEN
      RETURN public.floor_capture_fail(
        'Department not authorized for audit',
        'REQUIRE_APP_AUDIT'
      );
    END IF;

    IF COALESCE((p_payload->>'lotSize')::integer, 0) <= 0
       OR COALESCE((p_payload->>'sampleSize')::integer, 0) <= 0
       OR COALESCE((p_payload->>'sampleSize')::integer, 0) > COALESCE((p_payload->>'lotSize')::integer, 0) THEN
      RETURN public.floor_capture_fail('Invalid lot or sample size', 'INVALID_LOT');
    END IF;

    IF COALESCE((p_payload->>'passed')::integer, 0) + COALESCE((p_payload->>'failed')::integer, 0)
       > COALESCE((p_payload->>'sampleSize')::integer, 0) THEN
      RETURN public.floor_capture_fail('passed + failed cannot exceed sampleSize', 'INVALID_COUNT');
    END IF;

    INSERT INTO public.audit_sessions (
      factory_id, order_id, department_id, lot_size, sample_size, aql_level,
      passed, failed, result, logged_by, logged_at
    ) VALUES (
      p_factory_id,
      (p_payload->>'orderId')::uuid,
      (p_payload->>'departmentId')::uuid,
      COALESCE((p_payload->>'lotSize')::integer, 0),
      COALESCE((p_payload->>'sampleSize')::integer, 0),
      NULLIF(p_payload->>'aqlLevel', ''),
      COALESCE((p_payload->>'passed')::integer, 0),
      COALESCE((p_payload->>'failed')::integer, 0),
      NULLIF(p_payload->>'result', ''),
      p_user_id,
      COALESCE((p_payload->>'loggedAt')::timestamptz, now())
    )
    RETURNING id INTO v_id;
    RETURN jsonb_build_object('id', v_id);
  END IF;

  IF p_type = 'rejection_log' THEN
    IF NOT public.profile_has_capture_app(p_user_id, p_factory_id, 'final_rejection_log') THEN
      RETURN public.floor_capture_fail(
        'Department not authorized for rejection log',
        'APP_NOT_ALLOWED'
      );
    END IF;

    IF NOT EXISTS (
      SELECT 1 FROM public.style_orders
      WHERE id = (p_payload->>'orderId')::uuid AND factory_id = p_factory_id
    ) THEN
      RETURN public.floor_capture_fail('Order not found in factory', 'ORDER_NOT_FOUND');
    END IF;

    IF COALESCE((p_payload->>'qty')::integer, 0) <= 0 THEN
      RETURN public.floor_capture_fail('qty must be a positive integer', 'INVALID_QTY');
    END IF;

    IF p_payload->>'stage' IS NULL OR p_payload->>'stage' NOT IN (
      'inline', 'end_line', 'final_audit', 'pre_pack', 'post_pack', 'customer_return'
    ) THEN
      RETURN public.floor_capture_fail('Invalid rejection stage', 'INVALID_STAGE');
    END IF;

    INSERT INTO public.rejections (
      factory_id, order_id, colorway_id, size, qty, reason_code, reason_detail,
      stage, rejected_date, notes, logged_by, logged_at
    ) VALUES (
      p_factory_id,
      (p_payload->>'orderId')::uuid,
      NULLIF(p_payload->>'colorwayId', '')::uuid,
      NULLIF(p_payload->>'size', ''),
      (p_payload->>'qty')::integer,
      COALESCE(NULLIF(p_payload->>'reasonCode', ''), 'Other'),
      NULLIF(p_payload->>'reasonDetail', ''),
      p_payload->>'stage',
      COALESCE((p_payload->>'rejectedDate')::date, CURRENT_DATE),
      NULLIF(p_payload->>'notes', ''),
      p_user_id,
      COALESCE((p_payload->>'loggedAt')::timestamptz, now())
    )
    RETURNING id INTO v_id;

    RETURN jsonb_build_object('id', v_id);
  END IF;

  IF p_type = 'shipment_log' THEN
    IF NOT public.profile_has_capture_app(p_user_id, p_factory_id, 'shipment_log') THEN
      RETURN public.floor_capture_fail(
        'Department not authorized for shipment log',
        'APP_NOT_ALLOWED'
      );
    END IF;

    IF NOT EXISTS (
      SELECT 1 FROM public.style_orders
      WHERE id = (p_payload->>'orderId')::uuid AND factory_id = p_factory_id
    ) THEN
      RETURN public.floor_capture_fail('Order not found in factory', 'ORDER_NOT_FOUND');
    END IF;

    IF COALESCE((p_payload->>'shippedQty')::integer, 0) <= 0 THEN
      RETURN public.floor_capture_fail('shippedQty must be a positive integer', 'INVALID_QTY');
    END IF;

    IF p_payload->>'shipmentType' IS NULL OR p_payload->>'shipmentType' NOT IN (
      'main', 'partial', 'replacement', 'sample', 'rejection_return'
    ) THEN
      RETURN public.floor_capture_fail('Invalid shipment type', 'INVALID_SHIPMENT_TYPE');
    END IF;

    v_ship_by_size := COALESCE(p_payload->'shippedQtyBySize', '{}'::jsonb);
    IF v_ship_by_size <> '{}'::jsonb THEN
      v_size_sum := public.jsonb_sum_int_values(v_ship_by_size);
      IF v_size_sum <> (p_payload->>'shippedQty')::integer THEN
        RETURN public.floor_capture_fail(
          'shippedQtyBySize sum must equal shippedQty',
          'SIZE_TOTAL_MISMATCH',
          jsonb_build_object('shippedQty', (p_payload->>'shippedQty')::integer, 'sizeSum', v_size_sum)
        );
      END IF;
    END IF;

    SELECT po_number INTO v_po
    FROM public.style_orders
    WHERE id = (p_payload->>'orderId')::uuid AND factory_id = p_factory_id;

    INSERT INTO public.shipments (
      factory_id, order_id, colorway_id, po_number, shipped_qty, shipped_qty_by_size,
      shipment_date, invoice_number, awb_number, destination, shipment_type, notes, logged_by, logged_at
    ) VALUES (
      p_factory_id,
      (p_payload->>'orderId')::uuid,
      NULLIF(p_payload->>'colorwayId', '')::uuid,
      v_po,
      (p_payload->>'shippedQty')::integer,
      v_ship_by_size,
      COALESCE((p_payload->>'shipmentDate')::date, CURRENT_DATE),
      NULLIF(p_payload->>'invoiceNumber', ''),
      NULLIF(p_payload->>'awbNumber', ''),
      NULLIF(p_payload->>'destination', ''),
      p_payload->>'shipmentType',
      NULLIF(p_payload->>'notes', ''),
      p_user_id,
      COALESCE((p_payload->>'loggedAt')::timestamptz, now())
    )
    RETURNING id INTO v_id;

    RETURN jsonb_build_object('id', v_id);
  END IF;

  RETURN public.floor_capture_fail('Unknown capture type', 'UNKNOWN_CAPTURE_TYPE');
END;
$$;

REVOKE ALL ON FUNCTION public.floor_capture(uuid, uuid, text, jsonb) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.floor_capture(uuid, uuid, text, jsonb) TO anon, authenticated;

REVOKE ALL ON FUNCTION public.floor_capture_fail(text, text, jsonb) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.floor_capture_fail(text, text, jsonb) TO authenticated;

ALTER TABLE public.workforce_logs DROP COLUMN IF EXISTS operators;
ALTER TABLE public.workforce_logs DROP COLUMN IF EXISTS helpers;
ALTER TABLE public.workforce_logs DROP COLUMN IF EXISTS supervisors;
ALTER TABLE public.workforce_logs DROP COLUMN IF EXISTS trainees;

-- >>> get_floor_bootstrap (enhanced with shipments/rejections)
-- Floor bootstrap for plapps when service role is not available on the API server.
-- Called with anon key after floor session cookie validates factory scope.

CREATE OR REPLACE FUNCTION public.get_floor_bootstrap(p_factory_id uuid)
RETURNS jsonb
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_result jsonb;
BEGIN
  IF p_factory_id IS NULL OR NOT EXISTS (SELECT 1 FROM public.factories f WHERE f.id = p_factory_id) THEN
    RETURN NULL;
  END IF;

  SELECT jsonb_build_object(
    'departments', COALESCE((
      SELECT jsonb_agg(to_jsonb(d) ORDER BY d.sequence)
      FROM public.departments d
      WHERE d.factory_id = p_factory_id
    ), '[]'::jsonb),
    'orders', COALESCE((
      SELECT jsonb_agg(
        to_jsonb(o) || jsonb_build_object(
          'colorways', COALESCE((
            SELECT jsonb_agg(to_jsonb(c) ORDER BY c.created_at)
            FROM public.colorways c
            WHERE c.order_id = o.id
          ), '[]'::jsonb)
        )
        ORDER BY o.created_at DESC
      )
      FROM public.style_orders o
      WHERE o.factory_id = p_factory_id
    ), '[]'::jsonb),
    'resources', COALESCE((
      SELECT jsonb_agg(to_jsonb(r) ORDER BY r.resource_name)
      FROM public.assigned_resources r
      WHERE r.factory_id = p_factory_id
    ), '[]'::jsonb),
    'shifts', COALESCE((
      SELECT jsonb_agg(to_jsonb(s) ORDER BY s.name)
      FROM public.shifts s
      WHERE s.factory_id = p_factory_id
    ), '[]'::jsonb),
    'workers', COALESCE((
      SELECT jsonb_agg(to_jsonb(w) ORDER BY w.name)
      FROM public.workers w
      WHERE w.factory_id = p_factory_id AND w.is_active = true
    ), '[]'::jsonb),
    'flows', COALESCE((
      SELECT jsonb_agg(
        to_jsonb(f) || jsonb_build_object(
          'process_flow_steps', COALESCE((
            SELECT jsonb_agg(to_jsonb(s) ORDER BY s.flow_step)
            FROM public.process_flow_steps s
            WHERE s.flow_id = f.id
          ), '[]'::jsonb)
        )
      )
      FROM public.process_flows f
      WHERE f.factory_id = p_factory_id
    ), '[]'::jsonb),
    'hourly', COALESCE((
      SELECT jsonb_agg(to_jsonb(h) ORDER BY h.logged_at DESC)
      FROM (
        SELECT * FROM public.hourly_counts
        WHERE factory_id = p_factory_id
        ORDER BY logged_at DESC
        LIMIT 500
      ) h
    ), '[]'::jsonb),
    'slips', COALESCE((
      SELECT jsonb_agg(to_jsonb(s) ORDER BY s.sent_at DESC)
      FROM (
        SELECT * FROM public.handover_slips
        WHERE factory_id = p_factory_id
        ORDER BY sent_at DESC
        LIMIT 500
      ) s
    ), '[]'::jsonb),
    'inspections', COALESCE((
      SELECT jsonb_agg(to_jsonb(i) ORDER BY i.logged_at DESC)
      FROM (
        SELECT * FROM public.inspections
        WHERE factory_id = p_factory_id
        ORDER BY logged_at DESC
        LIMIT 500
      ) i
    ), '[]'::jsonb),
    'workforce', COALESCE((
      SELECT jsonb_agg(to_jsonb(w) ORDER BY w.logged_at DESC)
      FROM (
        SELECT * FROM public.workforce_logs
        WHERE factory_id = p_factory_id
        ORDER BY logged_at DESC
        LIMIT 200
      ) w
    ), '[]'::jsonb),
    'attendance', COALESCE((
      SELECT jsonb_agg(to_jsonb(a) ORDER BY a.logged_at DESC)
      FROM (
        SELECT * FROM public.attendance_records
        WHERE factory_id = p_factory_id
        ORDER BY logged_at DESC
        LIMIT 500
      ) a
    ), '[]'::jsonb),
    'audits', COALESCE((
      SELECT jsonb_agg(to_jsonb(a) ORDER BY a.logged_at DESC)
      FROM (
        SELECT * FROM public.audit_sessions
        WHERE factory_id = p_factory_id
        ORDER BY logged_at DESC
        LIMIT 200
      ) a
    ), '[]'::jsonb),
    'allocations', COALESCE((
      SELECT jsonb_agg(to_jsonb(a))
      FROM public.line_allocations a
      WHERE a.factory_id = p_factory_id
    ), '[]'::jsonb),
    'shipments', COALESCE((
      SELECT jsonb_agg(to_jsonb(s) ORDER BY s.logged_at DESC)
      FROM (
        SELECT * FROM public.shipments
        WHERE factory_id = p_factory_id
        ORDER BY logged_at DESC
        LIMIT 200
      ) s
    ), '[]'::jsonb),
    'rejections', COALESCE((
      SELECT jsonb_agg(to_jsonb(r) ORDER BY r.logged_at DESC)
      FROM (
        SELECT * FROM public.rejections
        WHERE factory_id = p_factory_id
        ORDER BY logged_at DESC
        LIMIT 200
      ) r
    ), '[]'::jsonb)
  ) INTO v_result;

  RETURN v_result;
END;
$$;

REVOKE ALL ON FUNCTION public.get_floor_bootstrap(uuid) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.get_floor_bootstrap(uuid) TO anon, authenticated;



-- Phase 9.5 RPCs — anon revoke + authenticated grant (extends Phase 9a)
REVOKE EXECUTE ON FUNCTION public.get_order_dept_progress(uuid, uuid, uuid, uuid, date) FROM anon;
REVOKE EXECUTE ON FUNCTION public.get_pseudo_dept_daily_summary(uuid, uuid, date) FROM anon;
REVOKE EXECUTE ON FUNCTION public.get_cut_to_ship_journey(uuid, uuid) FROM anon;

GRANT EXECUTE ON FUNCTION public.get_order_dept_progress(uuid, uuid, uuid, uuid, date) TO authenticated;
GRANT EXECUTE ON FUNCTION public.get_pseudo_dept_daily_summary(uuid, uuid, date) TO authenticated;
GRANT EXECUTE ON FUNCTION public.get_cut_to_ship_journey(uuid, uuid) TO authenticated;

COMMIT;