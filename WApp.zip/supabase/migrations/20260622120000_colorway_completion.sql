-- Order Completion: per-colorway close / short-close tracking.

ALTER TABLE public.colorways
  ADD COLUMN IF NOT EXISTS completion_status text NOT NULL DEFAULT 'ongoing',
  ADD COLUMN IF NOT EXISTS closed_at timestamptz,
  ADD COLUMN IF NOT EXISTS closed_by uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS close_reason text;

ALTER TABLE public.colorways
  DROP CONSTRAINT IF EXISTS colorways_completion_status_check;

ALTER TABLE public.colorways
  ADD CONSTRAINT colorways_completion_status_check
  CHECK (completion_status IN ('ongoing', 'complete', 'short_closed'));

COMMENT ON COLUMN public.colorways.completion_status IS
  'ongoing = open for shipment; complete = shipped+rejected matches cut/adj qty; short_closed = closed early with reason.';
COMMENT ON COLUMN public.colorways.close_reason IS
  'Required when completion_status = short_closed. Optional note on complete.';
