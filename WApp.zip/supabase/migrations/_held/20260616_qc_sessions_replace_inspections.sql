-- Repoint reporting views and progress RPC from inspections → inspection_sessions,
-- then drop the legacy inspections table.

-- -----------------------------------------------------------------------------
-- v_daily_output: QC branch reads inspection_sessions (passed + rework_passed)
-- -----------------------------------------------------------------------------
CREATE OR REPLACE VIEW public.v_daily_output AS
WITH hourly AS (
  SELECT
    h.factory_id,
    h.order_id,
    h.colorway_id,
    h.department_id,
    h.log_date,
    public.get_shift_for_hour_slot(h.factory_id, h.hour_slot) AS shift_id,
    SUM(h.count)::integer AS output_qty
  FROM public.hourly_counts h
  JOIN public.departments d ON d.id = h.department_id AND d.is_production = true
  GROUP BY
    h.factory_id, h.order_id, h.colorway_id, h.department_id, h.log_date,
    public.get_shift_for_hour_slot(h.factory_id, h.hour_slot)
),
inspection AS (
  SELECT
    s.factory_id,
    s.order_id,
    s.colorway_id,
    s.department_id,
    s.log_date,
    s.shift_id,
    SUM(COALESCE(s.passed, 0) + COALESCE(s.rework_passed, 0))::integer AS output_qty
  FROM public.inspection_sessions s
  JOIN public.departments d ON d.id = s.department_id AND d.is_production = true
  GROUP BY s.factory_id, s.order_id, s.colorway_id, s.department_id, s.log_date, s.shift_id
),
keys AS (
  SELECT DISTINCT factory_id, order_id, colorway_id, department_id, log_date FROM hourly
  UNION
  SELECT DISTINCT factory_id, order_id, colorway_id, department_id, log_date FROM inspection
),
mode_pick AS (
  SELECT
    k.factory_id, k.order_id, k.colorway_id, k.department_id, k.log_date,
    CASE
      WHEN EXISTS (
        SELECT 1 FROM public.hourly_counts h
        JOIN public.departments d ON d.id = h.department_id AND d.is_production = true
        WHERE h.factory_id = k.factory_id AND h.order_id = k.order_id
          AND h.department_id = k.department_id AND h.log_date = k.log_date
      ) THEN 'hourly'
      WHEN EXISTS (
        SELECT 1 FROM public.inspection_sessions s
        JOIN public.departments d ON d.id = s.department_id AND d.is_production = true
        WHERE s.factory_id = k.factory_id AND s.order_id = k.order_id
          AND s.department_id = k.department_id AND s.log_date = k.log_date
      ) THEN 'qc'
      ELSE 'none'
    END AS capture_mode
  FROM keys k
)
SELECT
  m.factory_id, m.order_id, m.colorway_id, m.department_id, m.log_date,
  o.shift_id, o.output_qty, m.capture_mode, (o.shift_id IS NULL) AS is_unallocated
FROM mode_pick m
JOIN LATERAL (
  SELECT h.shift_id, h.output_qty FROM hourly h
  WHERE m.capture_mode = 'hourly'
    AND h.factory_id = m.factory_id AND h.order_id = m.order_id
    AND h.colorway_id IS NOT DISTINCT FROM m.colorway_id
    AND h.department_id = m.department_id AND h.log_date = m.log_date
  UNION ALL
  SELECT i.shift_id, i.output_qty FROM inspection i
  WHERE m.capture_mode = 'qc'
    AND i.factory_id = m.factory_id AND i.order_id = m.order_id
    AND i.colorway_id IS NOT DISTINCT FROM m.colorway_id
    AND i.department_id = m.department_id AND i.log_date = m.log_date
) o ON true;

COMMENT ON VIEW public.v_daily_output IS
  'Production dept output at colorway grain. QC from inspection_sessions (passed + rework_passed).';

-- -----------------------------------------------------------------------------
-- QC quality + shift KPI views (depend on inspections today)
-- -----------------------------------------------------------------------------
DROP FUNCTION IF EXISTS public.get_dept_quality_for_date(uuid, uuid, date);
DROP FUNCTION IF EXISTS public.get_live_dept_kpi(uuid, uuid);
DROP FUNCTION IF EXISTS public.get_factory_kpis(uuid, date, date);
DROP FUNCTION IF EXISTS public.get_department_kpis(uuid, uuid, date, date);
DROP FUNCTION IF EXISTS public.get_department_kpis_by_shift(uuid, uuid, date, date);
DROP FUNCTION IF EXISTS public.get_style_kpis(uuid, uuid);

DROP VIEW IF EXISTS public.v_daily_kpis;
DROP VIEW IF EXISTS public.v_daily_kpis_by_shift;
DROP VIEW IF EXISTS public.v_daily_quality;

CREATE VIEW public.v_daily_quality AS
SELECT
  s.factory_id,
  s.order_id,
  s.department_id,
  s.log_date,
  SUM(COALESCE(s.total_inspected, 0))::integer AS inspected,
  SUM(COALESCE(s.passed, 0))::integer AS passed,
  SUM(COALESCE(s.failed, 0))::integer AS failed,
  SUM(COALESCE(s.rework, 0))::integer AS rework,
  SUM(COALESCE(s.rework_passed, 0))::integer AS rework_pass,
  CASE
    WHEN SUM(COALESCE(s.total_inspected, 0)) = 0 THEN NULL
    ELSE ROUND(
      100.0 * SUM(
        (
          SELECT COALESCE(SUM(v::integer), 0)
          FROM jsonb_each_text(COALESCE(s.defect_summary, '{}'::jsonb)) AS d(k, v)
        )
      ) / NULLIF(SUM(COALESCE(s.total_inspected, 0)), 0)
    )::numeric
  END AS dhu,
  CASE
    WHEN SUM(COALESCE(s.total_inspected, 0)) = 0 THEN NULL
    ELSE ROUND(
      100.0 * SUM(COALESCE(s.failed, 0) + COALESCE(s.rework, 0))
      / NULLIF(SUM(COALESCE(s.total_inspected, 0)), 0)
    )::numeric
  END AS defective_pct
FROM public.inspection_sessions s
JOIN public.departments d ON d.id = s.department_id
  AND COALESCE(d.apps, '[]'::jsonb) @> '["qc_log"]'::jsonb
GROUP BY s.factory_id, s.order_id, s.department_id, s.log_date;

COMMENT ON VIEW public.v_daily_quality IS
  'QC dept metrics from inspection_sessions (qc_log app only).';

CREATE VIEW public.v_daily_kpis_by_shift AS
WITH output_shift AS (
  SELECT factory_id, order_id, department_id, log_date, shift_id,
    SUM(output_qty)::integer AS shift_output
  FROM public.v_daily_output
  WHERE shift_id IS NOT NULL
  GROUP BY factory_id, order_id, department_id, log_date, shift_id
),
workforce AS (
  SELECT * FROM public.v_daily_workforce
),
shift_quality AS (
  SELECT
    s.factory_id,
    s.order_id,
    s.department_id,
    s.log_date,
    s.shift_id,
    SUM(COALESCE(s.total_inspected, 0))::integer AS inspected,
    SUM(
      (
        SELECT COALESCE(SUM(v::integer), 0)
        FROM jsonb_each_text(COALESCE(s.defect_summary, '{}'::jsonb)) AS d(k, v)
      )
    )::integer AS total_defects,
    SUM(COALESCE(s.failed, 0) + COALESCE(s.rework, 0))::integer AS defective_pieces
  FROM public.inspection_sessions s
  JOIN public.departments d ON d.id = s.department_id
    AND COALESCE(d.apps, '[]'::jsonb) @> '["qc_log"]'::jsonb
  WHERE s.shift_id IS NOT NULL
  GROUP BY s.factory_id, s.order_id, s.department_id, s.log_date, s.shift_id
),
shift_keys AS (
  SELECT factory_id, department_id, log_date, shift_id FROM workforce
  UNION
  SELECT h.factory_id, h.department_id, h.log_date,
    public.get_shift_for_hour_slot(h.factory_id, h.hour_slot) AS shift_id
  FROM public.hourly_counts h
  JOIN public.departments d ON d.id = h.department_id AND d.is_production = true
  WHERE public.get_shift_for_hour_slot(h.factory_id, h.hour_slot) IS NOT NULL
  UNION
  SELECT s.factory_id, s.department_id, s.log_date, s.shift_id
  FROM public.inspection_sessions s
  JOIN public.departments d ON d.id = s.department_id AND d.is_production = true
  WHERE s.shift_id IS NOT NULL
),
order_keys AS (
  SELECT DISTINCT factory_id, order_id, department_id, log_date FROM public.v_daily_output
  UNION
  SELECT DISTINCT t.factory_id, t.order_id, t.department_id, t.log_date
  FROM public.v_daily_target t
  JOIN public.departments d ON d.id = t.department_id AND d.is_production = true
),
base AS (
  SELECT ok.factory_id, ok.order_id, ok.department_id, ok.log_date, sk.shift_id
  FROM order_keys ok
  JOIN shift_keys sk
    ON sk.factory_id = ok.factory_id
   AND sk.department_id = ok.department_id
   AND sk.log_date = ok.log_date
),
enriched AS (
  SELECT
    b.factory_id, b.order_id, b.department_id, b.log_date, b.shift_id,
    sm.shift_name, sm.productive_mins,
    COALESCE(os.shift_output, 0) AS shift_output,
    COALESCE(wf.headcount, 0) AS shift_headcount,
    COALESCE(wf.available_mins, 0) AS shift_available_mins,
    (wf.shift_id IS NOT NULL) AS has_workforce,
    (COALESCE(os.shift_output, 0) > 0) AS has_output
  FROM base b
  JOIN public.v_shift_minutes sm ON sm.shift_id = b.shift_id
  LEFT JOIN output_shift os
    ON os.factory_id = b.factory_id AND os.order_id = b.order_id
   AND os.department_id = b.department_id AND os.log_date = b.log_date
   AND os.shift_id = b.shift_id
  LEFT JOIN workforce wf
    ON wf.factory_id = b.factory_id AND wf.department_id = b.department_id
   AND wf.log_date = b.log_date AND wf.shift_id = b.shift_id
),
with_flags AS (
  SELECT e.*,
    CASE
      WHEN NOT e.has_workforce AND NOT e.has_output THEN 'none'
      WHEN e.has_workforce AND e.has_output THEN 'complete'
      WHEN e.has_workforce THEN 'workforce_only'
      ELSE 'output_only'
    END AS data_completeness
  FROM enriched e
),
prorated AS (
  SELECT wf.*, t.daily_target,
    SUM(wf.productive_mins) OVER (
      PARTITION BY wf.factory_id, wf.order_id, wf.department_id, wf.log_date
    ) AS active_productive_mins
  FROM with_flags wf
  LEFT JOIN public.v_daily_target t
    ON t.factory_id = wf.factory_id AND t.order_id = wf.order_id
   AND t.department_id = wf.department_id AND t.log_date = wf.log_date
)
SELECT
  p.factory_id, p.order_id, p.department_id, p.log_date, p.shift_id, p.shift_name,
  p.shift_output, p.shift_headcount, p.shift_available_mins, p.has_workforce, p.has_output,
  p.data_completeness,
  CASE WHEN p.data_completeness = 'complete' AND COALESCE(p.daily_target, 0) > 0
    THEN ROUND(100.0 * p.shift_output / NULLIF(
      p.daily_target * (p.productive_mins / NULLIF(p.active_productive_mins, 0)), 0))::numeric
    ELSE NULL END AS shift_efficiency_pct,
  CASE WHEN p.data_completeness = 'complete' AND p.shift_headcount > 0
    THEN ROUND(p.shift_output::numeric / p.shift_headcount, 2) ELSE NULL END AS shift_productivity,
  CASE WHEN COALESCE(sq.inspected, 0) > 0
    THEN ROUND(100.0 * sq.total_defects / sq.inspected)::numeric ELSE NULL END AS dhu,
  CASE WHEN COALESCE(sq.inspected, 0) > 0
    THEN ROUND(100.0 * sq.defective_pieces / sq.inspected)::numeric ELSE NULL END AS defective_pct
FROM prorated p
LEFT JOIN shift_quality sq
  ON sq.factory_id = p.factory_id AND sq.order_id = p.order_id
 AND sq.department_id = p.department_id AND sq.log_date = p.log_date
 AND sq.shift_id = p.shift_id;

-- v_daily_kpis: same shape as mes_factory_kpis_reporting migration
CREATE VIEW public.v_daily_kpis AS
WITH shift_rows AS (
  SELECT * FROM public.v_daily_kpis_by_shift
),
unalloc AS (
  SELECT factory_id, order_id, department_id, log_date, unallocated_output
  FROM (
    SELECT factory_id, order_id, department_id, log_date,
      SUM(output_qty)::integer AS unallocated_output
    FROM public.v_daily_output
    WHERE shift_id IS NULL
    GROUP BY factory_id, order_id, department_id, log_date
  ) u
),
wip_daily AS (
  SELECT factory_id, order_id, department_id, log_date,
    SUM(wip_qty)::integer AS wip_qty
  FROM public.v_wip_dept
  GROUP BY factory_id, order_id, department_id, log_date
),
daily AS (
  SELECT
    sr.factory_id, sr.order_id, sr.department_id, sr.log_date,
    COALESCE(t.daily_target, 0) AS daily_target,
    COALESCE(SUM(sr.shift_output), 0) + COALESCE(MAX(u.unallocated_output), 0) AS daily_output,
    COALESCE(SUM(sr.shift_available_mins) FILTER (
      WHERE sr.data_completeness IN ('complete', 'workforce_only')
    ), 0) AS daily_available_mins,
    COALESCE(SUM(sr.shift_output) FILTER (WHERE sr.data_completeness = 'complete'), 0) AS complete_output,
    COALESCE(SUM(sr.shift_headcount) FILTER (WHERE sr.data_completeness = 'complete'), 0) AS complete_headcount,
    BOOL_OR(sr.data_completeness = 'complete') AS any_complete,
    BOOL_OR(sr.data_completeness = 'output_only') AS any_output_only,
    BOOL_OR(sr.data_completeness = 'workforce_only') AS any_workforce_only,
    BOOL_OR(sr.data_completeness <> 'none') AS any_active
  FROM shift_rows sr
  LEFT JOIN public.v_daily_target t
    ON t.factory_id = sr.factory_id AND t.order_id = sr.order_id
   AND t.department_id = sr.department_id AND t.log_date = sr.log_date
  LEFT JOIN unalloc u
    ON u.factory_id = sr.factory_id AND u.order_id = sr.order_id
   AND u.department_id = sr.department_id AND u.log_date = sr.log_date
  GROUP BY sr.factory_id, sr.order_id, sr.department_id, sr.log_date, t.daily_target
)
SELECT
  d.factory_id, d.order_id, d.department_id, d.log_date,
  d.daily_target, d.daily_output, d.daily_available_mins,
  CASE WHEN d.any_complete AND d.daily_target > 0
    THEN ROUND(100.0 * d.complete_output / NULLIF(d.daily_target, 0))::numeric
    ELSE NULL END AS daily_efficiency_pct,
  CASE WHEN d.any_complete AND d.complete_headcount > 0
    THEN ROUND(d.complete_output::numeric / d.complete_headcount, 2) ELSE NULL END AS daily_productivity,
  CASE
    WHEN NOT d.any_active THEN 'none'
    WHEN d.any_complete AND NOT d.any_output_only AND NOT d.any_workforce_only THEN 'complete'
    WHEN d.any_complete THEN 'partial'
    WHEN d.any_output_only THEN 'output_only'
    WHEN d.any_workforce_only THEN 'workforce_only'
    ELSE 'none'
  END AS day_completeness,
  q.dhu, q.defective_pct,
  COALESCE(w.wip_qty, 0) AS wip_qty,
  (
    SELECT COALESCE(jsonb_agg(jsonb_build_object(
      'shift_id', s.shift_id, 'shift_name', s.shift_name,
      'output', s.shift_output, 'headcount', s.shift_headcount,
      'efficiency_pct', s.shift_efficiency_pct
    ) ORDER BY s.shift_name), '[]'::jsonb)
    FROM public.v_daily_kpis_by_shift s
    WHERE s.factory_id = d.factory_id AND s.order_id = d.order_id
      AND s.department_id = d.department_id AND s.log_date = d.log_date
  ) AS shift_breakdown
FROM daily d
LEFT JOIN public.v_daily_quality q
  ON q.factory_id = d.factory_id AND q.order_id = d.order_id
 AND q.department_id = d.department_id AND q.log_date = d.log_date
LEFT JOIN wip_daily w
  ON w.factory_id = d.factory_id AND w.order_id = d.order_id
 AND w.department_id = d.department_id AND w.log_date = d.log_date;

-- Recreate KPI RPC wrappers (minimal — match mes_factory_kpis_reporting)
CREATE OR REPLACE FUNCTION public.get_factory_kpis(
  p_factory_id uuid, p_date_from date, p_date_to date
)
RETURNS SETOF public.v_daily_kpis
LANGUAGE sql STABLE SECURITY INVOKER SET search_path = public AS $$
  SELECT * FROM public.v_daily_kpis
  WHERE factory_id = p_factory_id AND log_date BETWEEN p_date_from AND p_date_to;
$$;

CREATE OR REPLACE FUNCTION public.get_department_kpis(
  p_factory_id uuid, p_department_id uuid, p_date_from date, p_date_to date
)
RETURNS SETOF public.v_daily_kpis
LANGUAGE sql STABLE SECURITY INVOKER SET search_path = public AS $$
  SELECT * FROM public.v_daily_kpis
  WHERE factory_id = p_factory_id AND department_id = p_department_id
    AND log_date BETWEEN p_date_from AND p_date_to;
$$;

CREATE OR REPLACE FUNCTION public.get_department_kpis_by_shift(
  p_factory_id uuid, p_department_id uuid, p_date_from date, p_date_to date
)
RETURNS SETOF public.v_daily_kpis_by_shift
LANGUAGE sql STABLE SECURITY INVOKER SET search_path = public AS $$
  SELECT * FROM public.v_daily_kpis_by_shift
  WHERE factory_id = p_factory_id AND department_id = p_department_id
    AND log_date BETWEEN p_date_from AND p_date_to;
$$;

CREATE OR REPLACE FUNCTION public.get_style_kpis(p_factory_id uuid, p_order_id uuid)
RETURNS SETOF public.v_daily_kpis
LANGUAGE sql STABLE SECURITY INVOKER SET search_path = public AS $$
  SELECT * FROM public.v_daily_kpis
  WHERE factory_id = p_factory_id AND order_id = p_order_id;
$$;

CREATE OR REPLACE FUNCTION public.get_live_dept_kpi(p_factory_id uuid, p_department_id uuid)
RETURNS SETOF public.v_daily_kpis
LANGUAGE sql STABLE SECURITY INVOKER SET search_path = public AS $$
  SELECT * FROM public.v_daily_kpis
  WHERE factory_id = p_factory_id AND department_id = p_department_id
    AND log_date = CURRENT_DATE;
$$;

CREATE OR REPLACE FUNCTION public.get_dept_quality_for_date(
  p_factory_id uuid, p_department_id uuid, p_log_date date
)
RETURNS SETOF public.v_daily_quality
LANGUAGE sql STABLE SECURITY INVOKER SET search_path = public AS $$
  SELECT * FROM public.v_daily_quality
  WHERE factory_id = p_factory_id AND department_id = p_department_id
    AND log_date = p_log_date;
$$;

-- -----------------------------------------------------------------------------
-- Cut-to-ship journey: qc_produced from inspection_sessions
-- -----------------------------------------------------------------------------
CREATE OR REPLACE VIEW public.v_cut_to_ship_dept_journey AS
WITH order_colorways AS (
  SELECT so.factory_id, so.id AS order_id, so.process_flow_id, cw.id AS colorway_id
  FROM public.style_orders so
  LEFT JOIN public.colorways cw ON cw.order_id = so.id
),
dept_grid AS (
  SELECT
    oc.factory_id, oc.order_id, oc.colorway_id, oc.process_flow_id,
    d.id AS dept_id, d.name AS dept_name, d.is_production, d.apps,
    pfs.flow_step, (pfs.department_id IS NOT NULL) AS is_in_flow,
    (d.id = public.get_cutting_department_id(oc.factory_id)) AS is_cutting,
    (d.name ILIKE 'shipment' OR COALESCE(d.apps, '[]'::jsonb) @> '["shipment_log"]'::jsonb) AS is_shipment,
    (d.name ILIKE 'quality audit') AS is_quality_audit
  FROM order_colorways oc
  JOIN public.departments d ON d.factory_id = oc.factory_id
  LEFT JOIN public.process_flow_steps pfs
    ON pfs.flow_id = oc.process_flow_id AND pfs.department_id = d.id
),
handover_received AS (
  SELECT hs.factory_id, hs.order_id, hs.colorway_id, hs.to_department_id AS dept_id,
    SUM(COALESCE(NULLIF(hs.received_qty, 0), hs.sent_qty))::integer AS qty_received
  FROM public.handover_slips hs
  GROUP BY hs.factory_id, hs.order_id, hs.colorway_id, hs.to_department_id
),
handover_received_by_size AS (
  SELECT hs.factory_id, hs.order_id, hs.colorway_id, hs.to_department_id AS dept_id,
    public.jsonb_merge_sum_maps(ARRAY_AGG(
      CASE
        WHEN COALESCE(hs.received_qty_by_size, '{}'::jsonb) <> '{}'::jsonb THEN hs.received_qty_by_size
        WHEN COALESCE(hs.qty_by_size, '{}'::jsonb) <> '{}'::jsonb THEN hs.qty_by_size
        ELSE public.proportional_qty_by_size(
          COALESCE(NULLIF(hs.received_qty, 0), hs.sent_qty),
          public.colorway_planned_by_size(hs.colorway_id)
        )
      END
    )) AS qty_received_by_size
  FROM public.handover_slips hs
  GROUP BY hs.factory_id, hs.order_id, hs.colorway_id, hs.to_department_id
),
handover_sent AS (
  SELECT hs.factory_id, hs.order_id, hs.colorway_id, hs.from_department_id AS dept_id,
    SUM(hs.sent_qty)::integer AS qty_sent
  FROM public.handover_slips hs
  GROUP BY hs.factory_id, hs.order_id, hs.colorway_id, hs.from_department_id
),
handover_sent_by_size AS (
  SELECT hs.factory_id, hs.order_id, hs.colorway_id, hs.from_department_id AS dept_id,
    public.jsonb_merge_sum_maps(ARRAY_AGG(
      CASE
        WHEN COALESCE(hs.qty_by_size, '{}'::jsonb) <> '{}'::jsonb THEN hs.qty_by_size
        ELSE public.proportional_qty_by_size(hs.sent_qty, public.colorway_planned_by_size(hs.colorway_id))
      END
    )) AS qty_sent_by_size
  FROM public.handover_slips hs
  GROUP BY hs.factory_id, hs.order_id, hs.colorway_id, hs.from_department_id
),
hourly_produced AS (
  SELECT h.factory_id, h.order_id, h.colorway_id, h.department_id AS dept_id,
    SUM(h.count)::integer AS qty_produced
  FROM public.hourly_counts h
  JOIN public.departments d ON d.id = h.department_id
  WHERE COALESCE(d.apps, '[]'::jsonb) @> '["hourly"]'::jsonb
  GROUP BY h.factory_id, h.order_id, h.colorway_id, h.department_id
),
hourly_produced_by_size AS (
  SELECT h.factory_id, h.order_id, h.colorway_id, h.department_id AS dept_id,
    public.proportional_qty_by_size(
      SUM(h.count)::integer, public.colorway_planned_by_size(h.colorway_id)
    ) AS qty_produced_by_size
  FROM public.hourly_counts h
  JOIN public.departments d ON d.id = h.department_id
  WHERE COALESCE(d.apps, '[]'::jsonb) @> '["hourly"]'::jsonb
  GROUP BY h.factory_id, h.order_id, h.colorway_id, h.department_id,
    public.colorway_planned_by_size(h.colorway_id)
),
qc_produced AS (
  SELECT s.factory_id, s.order_id, s.colorway_id, s.department_id AS dept_id,
    SUM(COALESCE(s.passed, 0) + COALESCE(s.rework_passed, 0))::integer AS qty_produced
  FROM public.inspection_sessions s
  JOIN public.departments d ON d.id = s.department_id
  WHERE COALESCE(d.apps, '[]'::jsonb) @> '["qc_log"]'::jsonb
  GROUP BY s.factory_id, s.order_id, s.colorway_id, s.department_id
),
qc_produced_by_size AS (
  SELECT s.factory_id, s.order_id, s.colorway_id, s.department_id AS dept_id,
    public.jsonb_merge_sum_maps(ARRAY_AGG(COALESCE(s.passed_by_size, '{}'::jsonb))) AS qty_produced_by_size
  FROM public.inspection_sessions s
  JOIN public.departments d ON d.id = s.department_id
  WHERE COALESCE(d.apps, '[]'::jsonb) @> '["qc_log"]'::jsonb
  GROUP BY s.factory_id, s.order_id, s.colorway_id, s.department_id
),
shipped AS (
  SELECT factory_id, order_id, colorway_id, SUM(shipped_qty)::integer AS qty_shipped
  FROM public.shipments GROUP BY factory_id, order_id, colorway_id
),
shipped_by_size AS (
  SELECT s.factory_id, s.order_id, s.colorway_id,
    public.jsonb_merge_sum_maps(ARRAY_AGG(
      CASE
        WHEN COALESCE(s.shipped_qty_by_size, '{}'::jsonb) <> '{}'::jsonb THEN s.shipped_qty_by_size
        ELSE public.proportional_qty_by_size(s.shipped_qty, public.colorway_planned_by_size(s.colorway_id))
      END
    )) AS qty_shipped_by_size
  FROM public.shipments s GROUP BY s.factory_id, s.order_id, s.colorway_id
),
rejected_by_dept AS (
  SELECT r.factory_id, r.order_id, r.colorway_id,
    public.resolve_rejection_department_id(r.factory_id, r.order_id, r.stage) AS dept_id,
    SUM(r.qty)::integer AS qty_rejected
  FROM public.rejections r
  GROUP BY r.factory_id, r.order_id, r.colorway_id,
    public.resolve_rejection_department_id(r.factory_id, r.order_id, r.stage)
),
rejected_by_dept_size AS (
  SELECT x.factory_id, x.order_id, x.colorway_id,
    public.resolve_rejection_department_id(x.factory_id, x.order_id, x.stage) AS dept_id,
    jsonb_object_agg(x.size_key, x.dept_rej_qty) AS qty_rejected_by_size
  FROM (
    SELECT r.factory_id, r.order_id, r.colorway_id, r.stage,
      COALESCE(r.size, 'UNSPEC') AS size_key, SUM(r.qty)::integer AS dept_rej_qty
    FROM public.rejections r
    GROUP BY r.factory_id, r.order_id, r.colorway_id, r.stage, COALESCE(r.size, 'UNSPEC')
  ) x
  GROUP BY x.factory_id, x.order_id, x.colorway_id,
    public.resolve_rejection_department_id(x.factory_id, x.order_id, x.stage)
),
assembled AS (
  SELECT
    g.factory_id,
    g.order_id,
    g.colorway_id,
    g.dept_id,
    g.dept_name,
    g.flow_step,
    g.is_in_flow,
    g.is_cutting,
    CASE WHEN g.is_in_flow THEN
      CASE WHEN g.is_cutting THEN NULL ELSE hr.qty_received END
    END AS qty_received,
    CASE WHEN g.is_in_flow THEN
      CASE
        WHEN g.is_cutting THEN hp.qty_produced
        WHEN COALESCE(g.apps, '[]'::jsonb) @> '["hourly"]'::jsonb THEN hp.qty_produced
        WHEN COALESCE(g.apps, '[]'::jsonb) @> '["qc_log"]'::jsonb THEN qp.qty_produced
        ELSE COALESCE(hp.qty_produced, qp.qty_produced)
      END
    END AS qty_produced,
    CASE WHEN g.is_in_flow THEN
      CASE WHEN g.is_shipment THEN sh.qty_shipped ELSE hs.qty_sent END
    END AS qty_sent,
    CASE WHEN g.is_in_flow THEN rb.qty_rejected END AS qty_rejected,
    CASE WHEN g.is_in_flow THEN
      CASE WHEN g.is_cutting THEN NULL ELSE hrb.qty_received_by_size END
    END AS qty_received_by_size,
    CASE WHEN g.is_in_flow THEN
      CASE
        WHEN g.is_cutting THEN hpb.qty_produced_by_size
        WHEN COALESCE(hsb.qty_sent_by_size, '{}'::jsonb) <> '{}'::jsonb THEN hsb.qty_sent_by_size
        WHEN COALESCE(g.apps, '[]'::jsonb) @> '["hourly"]'::jsonb THEN hpb.qty_produced_by_size
        WHEN COALESCE(g.apps, '[]'::jsonb) @> '["qc_log"]'::jsonb
          AND COALESCE(qp.qty_produced, 0) > 0
          THEN COALESCE(
            qpb.qty_produced_by_size,
            public.proportional_qty_by_size(
              qp.qty_produced,
              public.colorway_planned_by_size(g.colorway_id)
            )
          )
        ELSE hsb.qty_sent_by_size
      END
    END AS qty_produced_by_size,
    CASE WHEN g.is_in_flow THEN
      CASE WHEN g.is_shipment THEN shb.qty_shipped_by_size ELSE hsb.qty_sent_by_size END
    END AS qty_sent_by_size,
    CASE WHEN g.is_in_flow THEN rbs.qty_rejected_by_size END AS qty_rejected_by_size
  FROM dept_grid g
  LEFT JOIN handover_received hr
    ON hr.factory_id = g.factory_id AND hr.order_id = g.order_id
   AND hr.colorway_id IS NOT DISTINCT FROM g.colorway_id AND hr.dept_id = g.dept_id
  LEFT JOIN handover_received_by_size hrb
    ON hrb.factory_id = g.factory_id AND hrb.order_id = g.order_id
   AND hrb.colorway_id IS NOT DISTINCT FROM g.colorway_id AND hrb.dept_id = g.dept_id
  LEFT JOIN handover_sent hs
    ON hs.factory_id = g.factory_id AND hs.order_id = g.order_id
   AND hs.colorway_id IS NOT DISTINCT FROM g.colorway_id AND hs.dept_id = g.dept_id
  LEFT JOIN handover_sent_by_size hsb
    ON hsb.factory_id = g.factory_id AND hsb.order_id = g.order_id
   AND hsb.colorway_id IS NOT DISTINCT FROM g.colorway_id AND hsb.dept_id = g.dept_id
  LEFT JOIN hourly_produced hp
    ON hp.factory_id = g.factory_id AND hp.order_id = g.order_id
   AND hp.colorway_id IS NOT DISTINCT FROM g.colorway_id AND hp.dept_id = g.dept_id
  LEFT JOIN hourly_produced_by_size hpb
    ON hpb.factory_id = g.factory_id AND hpb.order_id = g.order_id
   AND hpb.colorway_id IS NOT DISTINCT FROM g.colorway_id AND hpb.dept_id = g.dept_id
  LEFT JOIN qc_produced qp
    ON qp.factory_id = g.factory_id AND qp.order_id = g.order_id
   AND qp.colorway_id IS NOT DISTINCT FROM g.colorway_id AND qp.dept_id = g.dept_id
  LEFT JOIN qc_produced_by_size qpb
    ON qpb.factory_id = g.factory_id AND qpb.order_id = g.order_id
   AND qpb.colorway_id IS NOT DISTINCT FROM g.colorway_id AND qpb.dept_id = g.dept_id
  LEFT JOIN shipped sh
    ON sh.factory_id = g.factory_id AND sh.order_id = g.order_id
   AND sh.colorway_id IS NOT DISTINCT FROM g.colorway_id AND g.is_shipment
  LEFT JOIN shipped_by_size shb
    ON shb.factory_id = g.factory_id AND shb.order_id = g.order_id
   AND shb.colorway_id IS NOT DISTINCT FROM g.colorway_id AND g.is_shipment
  LEFT JOIN rejected_by_dept rb
    ON rb.factory_id = g.factory_id AND rb.order_id = g.order_id
   AND rb.colorway_id IS NOT DISTINCT FROM g.colorway_id AND rb.dept_id = g.dept_id
  LEFT JOIN rejected_by_dept_size rbs
    ON rbs.factory_id = g.factory_id AND rbs.order_id = g.order_id
   AND rbs.colorway_id IS NOT DISTINCT FROM g.colorway_id AND rbs.dept_id = g.dept_id
)
SELECT
  a.factory_id,
  a.order_id,
  a.colorway_id,
  a.dept_id,
  a.dept_name,
  a.flow_step,
  a.is_in_flow,
  a.qty_received,
  a.qty_produced,
  a.qty_sent,
  a.qty_rejected,
  CASE WHEN NOT a.is_in_flow THEN NULL
    WHEN a.qty_received IS NULL AND a.qty_produced IS NOT NULL
      THEN GREATEST(COALESCE(a.qty_produced, 0) - COALESCE(a.qty_sent, 0), 0)
    WHEN a.qty_received IS NOT NULL
      THEN GREATEST(COALESCE(a.qty_received, 0) - COALESCE(a.qty_sent, 0), 0)
    ELSE NULL
  END::integer AS wip_qty,
  CASE WHEN NOT a.is_in_flow THEN NULL
    WHEN a.is_cutting THEN public.jsonb_subtract_maps_nonneg(a.qty_produced_by_size, a.qty_sent_by_size)
    WHEN a.qty_received_by_size IS NOT NULL
      THEN public.jsonb_subtract_maps_nonneg(a.qty_received_by_size, a.qty_sent_by_size)
    WHEN a.qty_produced_by_size IS NOT NULL
      THEN public.jsonb_subtract_maps_nonneg(a.qty_produced_by_size, a.qty_sent_by_size)
    ELSE NULL
  END AS wip_qty_by_size,
  CASE WHEN NOT a.is_in_flow THEN NULL ELSE a.qty_received_by_size END AS qty_received_by_size,
  CASE WHEN NOT a.is_in_flow THEN NULL ELSE a.qty_produced_by_size END AS qty_produced_by_size,
  CASE WHEN NOT a.is_in_flow THEN NULL ELSE a.qty_sent_by_size END AS qty_sent_by_size,
  CASE WHEN NOT a.is_in_flow THEN NULL ELSE a.qty_rejected_by_size END AS qty_rejected_by_size,
  CASE
    WHEN NOT a.is_in_flow THEN 'not_in_flow'
    WHEN a.qty_received IS NULL AND COALESCE(a.qty_produced, 0) = 0 THEN 'pending'
    WHEN a.qty_received IS NULL AND COALESCE(a.qty_sent, 0) = 0 AND COALESCE(a.qty_produced, 0) > 0 THEN 'in_progress'
    WHEN a.qty_received IS NULL AND COALESCE(a.qty_sent, 0) >= COALESCE(a.qty_produced, 0)
      AND COALESCE(a.qty_sent, 0) > 0 THEN 'completed'
    WHEN COALESCE(a.qty_received, 0) = 0 THEN 'pending'
    WHEN COALESCE(a.qty_received, 0) > COALESCE(a.qty_sent, 0) THEN 'in_progress'
    WHEN COALESCE(a.qty_sent, 0) >= COALESCE(a.qty_received, 0) AND COALESCE(a.qty_sent, 0) > 0 THEN 'completed'
    ELSE 'pending'
  END AS status
FROM assembled a;

CREATE OR REPLACE FUNCTION public.get_cut_to_ship_journey(p_factory_id uuid, p_order_id uuid)
RETURNS SETOF public.v_cut_to_ship_dept_journey
LANGUAGE sql STABLE SECURITY INVOKER SET search_path = public AS $$
  SELECT * FROM public.v_cut_to_ship_dept_journey
  WHERE factory_id = p_factory_id AND order_id = p_order_id;
$$;

-- -----------------------------------------------------------------------------
-- get_order_dept_progress: QC produced from inspection_sessions
-- -----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.get_order_dept_progress(
  p_factory_id uuid,
  p_order_id uuid,
  p_colorway_id uuid,
  p_department_id uuid,
  p_date date DEFAULT CURRENT_DATE
)
RETURNS jsonb
LANGUAGE plpgsql
STABLE
SECURITY INVOKER
SET search_path = public
AS $$
DECLARE
  v_planned jsonb;
  v_planned_total integer;
  v_cutting_id uuid;
  v_is_cutting boolean;
  v_cum_produced integer := 0;
  v_today_produced integer := 0;
  v_cum_sent integer := 0;
  v_today_sent integer := 0;
  v_produced_by_size jsonb := '{}'::jsonb;
  v_sent_by_size jsonb := '{}'::jsonb;
  v_hourly_total integer := 0;
  v_today_target integer := 0;
  v_remaining integer;
  v_session_output integer := 0;
BEGIN
  v_planned := public.colorway_planned_by_size(p_colorway_id);
  v_planned_total := public.jsonb_sum_int_values(v_planned);
  v_cutting_id := public.get_cutting_department_id(p_factory_id);
  v_is_cutting := (p_department_id = v_cutting_id);

  SELECT COALESCE(SUM(daily_target), 0)::integer INTO v_today_target
  FROM public.v_daily_target t
  WHERE t.factory_id = p_factory_id AND t.order_id = p_order_id
    AND t.department_id = p_department_id AND t.log_date = p_date;

  SELECT COALESCE(SUM(o.output_qty), 0)::integer INTO v_cum_produced
  FROM public.v_daily_output o
  WHERE o.factory_id = p_factory_id AND o.order_id = p_order_id
    AND o.colorway_id IS NOT DISTINCT FROM p_colorway_id
    AND o.department_id = p_department_id;

  SELECT COALESCE(SUM(o.output_qty), 0)::integer INTO v_today_produced
  FROM public.v_daily_output o
  WHERE o.factory_id = p_factory_id AND o.order_id = p_order_id
    AND o.colorway_id IS NOT DISTINCT FROM p_colorway_id
    AND o.department_id = p_department_id AND o.log_date = p_date;

  SELECT COALESCE(SUM(hs.sent_qty), 0)::integer INTO v_cum_sent
  FROM public.handover_slips hs
  WHERE hs.factory_id = p_factory_id AND hs.order_id = p_order_id
    AND hs.colorway_id IS NOT DISTINCT FROM p_colorway_id
    AND hs.from_department_id = p_department_id;

  SELECT COALESCE(SUM(hs.sent_qty), 0)::integer INTO v_today_sent
  FROM public.handover_slips hs
  WHERE hs.factory_id = p_factory_id AND hs.order_id = p_order_id
    AND hs.colorway_id IS NOT DISTINCT FROM p_colorway_id
    AND hs.from_department_id = p_department_id
    AND hs.sent_at::date = p_date;

  SELECT public.jsonb_merge_sum_maps(ARRAY_AGG(hs.qty_by_size))
  INTO v_sent_by_size
  FROM public.handover_slips hs
  WHERE hs.factory_id = p_factory_id AND hs.order_id = p_order_id
    AND hs.colorway_id IS NOT DISTINCT FROM p_colorway_id
    AND hs.from_department_id = p_department_id
    AND hs.qty_by_size <> '{}'::jsonb;

  IF v_is_cutting THEN
    SELECT public.jsonb_merge_sum_maps(ARRAY_AGG(h.count_by_size))
    INTO v_produced_by_size
    FROM public.hourly_counts h
    WHERE h.factory_id = p_factory_id AND h.order_id = p_order_id
      AND h.colorway_id IS NOT DISTINCT FROM p_colorway_id
      AND h.department_id = p_department_id AND h.count_by_size <> '{}'::jsonb;
    IF v_produced_by_size = '{}'::jsonb OR v_produced_by_size IS NULL THEN
      SELECT COALESCE(SUM(h.count), 0)::integer INTO v_hourly_total
      FROM public.hourly_counts h
      WHERE h.factory_id = p_factory_id AND h.order_id = p_order_id
        AND h.colorway_id IS NOT DISTINCT FROM p_colorway_id
        AND h.department_id = p_department_id;
      v_produced_by_size := public.proportional_qty_by_size(v_hourly_total, v_planned);
    END IF;
  ELSE
    SELECT COALESCE(SUM(COALESCE(s.passed, 0) + COALESCE(s.rework_passed, 0)), 0)::integer
    INTO v_session_output
    FROM public.inspection_sessions s
    WHERE s.factory_id = p_factory_id AND s.order_id = p_order_id
      AND s.colorway_id IS NOT DISTINCT FROM p_colorway_id
      AND s.department_id = p_department_id;

    IF v_session_output > 0 THEN
      SELECT public.jsonb_merge_sum_maps(ARRAY_AGG(COALESCE(s.passed_by_size, '{}'::jsonb)))
      INTO v_produced_by_size
      FROM public.inspection_sessions s
      WHERE s.factory_id = p_factory_id AND s.order_id = p_order_id
        AND s.colorway_id IS NOT DISTINCT FROM p_colorway_id
        AND s.department_id = p_department_id;
      IF v_produced_by_size = '{}'::jsonb OR v_produced_by_size IS NULL THEN
        v_produced_by_size := public.proportional_qty_by_size(v_session_output, v_planned);
      END IF;
    ELSE
      SELECT public.jsonb_merge_sum_maps(ARRAY_AGG(hs.qty_by_size))
      INTO v_produced_by_size
      FROM public.handover_slips hs
      WHERE hs.factory_id = p_factory_id AND hs.order_id = p_order_id
        AND hs.colorway_id IS NOT DISTINCT FROM p_colorway_id
        AND hs.from_department_id = p_department_id
        AND hs.qty_by_size <> '{}'::jsonb;
      IF v_produced_by_size = '{}'::jsonb AND v_cum_produced > 0 THEN
        v_produced_by_size := public.proportional_qty_by_size(v_cum_produced, v_planned);
      END IF;
    END IF;
  END IF;

  v_remaining := GREATEST(v_planned_total - GREATEST(v_cum_produced, v_cum_sent), 0);

  RETURN jsonb_build_object(
    'cumulative_produced', v_cum_produced,
    'today_produced', v_today_produced,
    'today_target', v_today_target,
    'cumulative_sent', v_cum_sent,
    'today_sent', v_today_sent,
    'available_to_send', GREATEST(v_cum_produced - v_cum_sent, 0),
    'planned_qty_by_size', v_planned,
    'produced_qty_by_size', COALESCE(v_produced_by_size, '{}'::jsonb),
    'sent_qty_by_size', COALESCE(v_sent_by_size, '{}'::jsonb),
    'remaining_qty', v_remaining
  );
END;
$$;

-- Remove floor_capture inspection branch if present (sessions-only capture)
DO $drop_inspection_capture$
DECLARE
  v_def text;
BEGIN
  v_def := pg_get_functiondef('public.floor_capture(uuid,uuid,text,jsonb)'::regprocedure);
  IF position('p_type = ''inspection''' in v_def) > 0 THEN
    v_def := regexp_replace(
      v_def,
      E'\\s+IF p_type = ''inspection'' THEN[\\s\\S]*?END IF;\\s*',
      E'\n  ',
      'g'
    );
    EXECUTE v_def;
  END IF;
END;
$drop_inspection_capture$;

DROP TABLE IF EXISTS public.inspections;
