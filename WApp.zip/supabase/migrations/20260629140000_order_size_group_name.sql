-- Size group on orders is a display snapshot only; qty breakdown lives on colorways.sizes.

ALTER TABLE public.style_orders
  ADD COLUMN IF NOT EXISTS size_group_name text;

COMMENT ON COLUMN public.style_orders.size_group_name IS
  'Snapshot of size group name at order creation — not a FK; colorways.sizes is authoritative.';

UPDATE public.style_orders so
SET size_group_name = sg.name
FROM public.size_groups sg
WHERE so.size_group_id = sg.id
  AND (so.size_group_name IS NULL OR so.size_group_name = '');

COMMENT ON COLUMN public.style_orders.size_group_id IS
  'Deprecated — use size_group_name snapshot. Do not rely on this FK for order sizes.';
