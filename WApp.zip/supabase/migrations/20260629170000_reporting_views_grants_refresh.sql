-- Grants missing after plapps reporting stack rebuild (audited against remote 2026-06-22).
-- v_daily_output / v_cut_to_ship / KPI RPCs already granted on remote; do not recreate views here.

-- shipment_audits table exists (plapps 27600000) but authenticated SELECT was never granted.
GRANT SELECT ON public.shipment_audits TO authenticated;

-- Helper views used by RPCs / future reports — grant only when present.
DO $$
DECLARE
  obj text;
  objs text[] := ARRAY[
    'public.v_audit_summary',
    'public.v_cut_to_ship_dept_journey',
    'public.v_order_cut_qty',
    'public.v_order_rejected_qty',
    'public.v_order_rejected_qty_by_size',
    'public.v_order_shipped_qty'
  ];
BEGIN
  FOREACH obj IN ARRAY objs LOOP
    IF to_regclass(obj) IS NOT NULL
       AND NOT has_table_privilege('authenticated', obj, 'SELECT') THEN
      EXECUTE format('GRANT SELECT ON %s TO authenticated', obj);
    END IF;
  END LOOP;
END $$;

-- Optional read view (main repo 20260628120000) — create only if absent.
DO $$
BEGIN
  IF to_regclass('public.v_shipment_audits') IS NULL
     AND to_regclass('public.shipment_audits') IS NOT NULL THEN
    EXECUTE $view$
      CREATE VIEW public.v_shipment_audits AS
      SELECT
        sa.id,
        sa.factory_id,
        sa.order_id,
        sa.colorway_id,
        sa.audit_type,
        sa.audit_date,
        sa.lot_size,
        sa.sample_size,
        sa.aql_level,
        sa.passed,
        sa.failed,
        sa.major_failed,
        sa.minor_failed,
        sa.result,
        sa.pieces_json,
        sa.status,
        sa.notes,
        sa.logged_by,
        sa.logged_at,
        sa.completed_at,
        sa.reaudit_of,
        so.style_name,
        so.po_number,
        cw.name AS colorway_name,
        p.full_name AS logged_by_name
      FROM public.shipment_audits sa
      JOIN public.style_orders so ON so.id = sa.order_id
      JOIN public.colorways cw ON cw.id = sa.colorway_id
      LEFT JOIN public.profiles p ON p.id = sa.logged_by
    $view$;
    GRANT SELECT ON public.v_shipment_audits TO authenticated;
  END IF;
END $$;
