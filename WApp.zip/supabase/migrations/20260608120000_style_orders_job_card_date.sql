ALTER TABLE public.style_orders
  ADD COLUMN IF NOT EXISTS job_card_date date;

COMMENT ON COLUMN public.style_orders.job_card_date IS 'Date the job card was opened; production lead time is measured from here to delivery.';
