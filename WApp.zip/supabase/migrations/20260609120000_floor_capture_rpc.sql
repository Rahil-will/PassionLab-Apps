-- Floor capture writes for plapps when service role is not on the API server.

CREATE OR REPLACE FUNCTION public.floor_capture(
  p_factory_id uuid,
  p_user_id uuid,
  p_type text,
  p_payload jsonb
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_id uuid;
  v_existing uuid;
  v_challan text;
  v_row public.hourly_counts%ROWTYPE;
BEGIN
  IF p_factory_id IS NULL OR p_user_id IS NULL THEN
    RETURN jsonb_build_object('error', 'Invalid session');
  END IF;

  IF p_type = 'hourly_upsert' THEN
    SELECT id INTO v_existing
    FROM public.hourly_counts
    WHERE factory_id = p_factory_id
      AND order_id = (p_payload->>'orderId')::uuid
      AND department_id = (p_payload->>'departmentId')::uuid
      AND hour_slot = p_payload->>'hourSlot'
      AND log_date = COALESCE((p_payload->>'logDate')::date, CURRENT_DATE)
    LIMIT 1;

    IF v_existing IS NOT NULL THEN
      UPDATE public.hourly_counts
      SET count = (p_payload->>'count')::integer,
          logged_at = COALESCE((p_payload->>'loggedAt')::timestamptz, now()),
          shift_id = NULLIF(p_payload->>'shiftId', '')::uuid,
          resource_id = NULLIF(p_payload->>'resourceId', '')::uuid,
          logged_by = p_user_id
      WHERE id = v_existing;
      RETURN jsonb_build_object('id', v_existing);
    END IF;

    INSERT INTO public.hourly_counts (
      factory_id, order_id, colorway_id, department_id, resource_id, shift_id,
      hour_slot, log_date, count, logged_by, logged_at
    ) VALUES (
      p_factory_id,
      (p_payload->>'orderId')::uuid,
      NULLIF(p_payload->>'colorwayId', '')::uuid,
      (p_payload->>'departmentId')::uuid,
      NULLIF(p_payload->>'resourceId', '')::uuid,
      NULLIF(p_payload->>'shiftId', '')::uuid,
      p_payload->>'hourSlot',
      COALESCE((p_payload->>'logDate')::date, CURRENT_DATE),
      (p_payload->>'count')::integer,
      p_user_id,
      COALESCE((p_payload->>'loggedAt')::timestamptz, now())
    )
    RETURNING id INTO v_id;

    RETURN jsonb_build_object('id', v_id);
  END IF;

  IF p_type = 'inspection' THEN
    INSERT INTO public.inspections (
      factory_id, order_id, department_id, piece_ref, result, defects, logged_by, logged_at
    ) VALUES (
      p_factory_id,
      (p_payload->>'orderId')::uuid,
      (p_payload->>'departmentId')::uuid,
      NULLIF(p_payload->>'pieceRef', ''),
      p_payload->>'result',
      COALESCE(p_payload->'defects', '[]'::jsonb),
      p_user_id,
      COALESCE((p_payload->>'loggedAt')::timestamptz, now())
    )
    RETURNING id INTO v_id;
    RETURN jsonb_build_object('id', v_id);
  END IF;

  IF p_type = 'workforce_upsert' THEN
    SELECT id INTO v_existing
    FROM public.workforce_logs
    WHERE factory_id = p_factory_id
      AND department_id = (p_payload->>'departmentId')::uuid
      AND log_date = (p_payload->>'logDate')::date
      AND shift_id IS NOT DISTINCT FROM NULLIF(p_payload->>'shiftId', '')::uuid
    LIMIT 1;

    IF v_existing IS NOT NULL THEN
      UPDATE public.workforce_logs SET
        order_id = NULLIF(p_payload->>'orderId', '')::uuid,
        operators = COALESCE((p_payload->>'operators')::integer, 0),
        helpers = COALESCE((p_payload->>'helpers')::integer, 0),
        supervisors = COALESCE((p_payload->>'supervisors')::integer, 0),
        trainees = COALESCE((p_payload->>'trainees')::integer, 0),
        logged_by = p_user_id,
        logged_at = COALESCE((p_payload->>'loggedAt')::timestamptz, now())
      WHERE id = v_existing;
      RETURN jsonb_build_object('id', v_existing);
    END IF;

    INSERT INTO public.workforce_logs (
      factory_id, order_id, department_id, shift_id, log_date,
      operators, helpers, supervisors, trainees, logged_by, logged_at
    ) VALUES (
      p_factory_id,
      NULLIF(p_payload->>'orderId', '')::uuid,
      (p_payload->>'departmentId')::uuid,
      NULLIF(p_payload->>'shiftId', '')::uuid,
      (p_payload->>'logDate')::date,
      COALESCE((p_payload->>'operators')::integer, 0),
      COALESCE((p_payload->>'helpers')::integer, 0),
      COALESCE((p_payload->>'supervisors')::integer, 0),
      COALESCE((p_payload->>'trainees')::integer, 0),
      p_user_id,
      COALESCE((p_payload->>'loggedAt')::timestamptz, now())
    )
    RETURNING id INTO v_id;
    RETURN jsonb_build_object('id', v_id);
  END IF;

  IF p_type = 'handover_send' THEN
    v_challan := 'CH-' || to_char(now(), 'YYYY') || '-' || upper(substr(md5(random()::text), 1, 5));
    INSERT INTO public.handover_slips (
      factory_id, order_id, from_department_id, to_department_id,
      sent_qty, received_qty, sent_by, sent_at, notes, status, challan_number
    ) VALUES (
      p_factory_id,
      (p_payload->>'orderId')::uuid,
      (p_payload->>'fromDepartmentId')::uuid,
      (p_payload->>'toDepartmentId')::uuid,
      (p_payload->>'sentQty')::integer,
      NULL,
      p_user_id,
      COALESCE((p_payload->>'sentAt')::timestamptz, now()),
      NULLIF(p_payload->>'notes', ''),
      'pending',
      v_challan
    )
    RETURNING id INTO v_id;
    RETURN jsonb_build_object('id', v_id, 'challanNumber', v_challan);
  END IF;

  IF p_type = 'handover_receive' THEN
    UPDATE public.handover_slips
    SET received_qty = (p_payload->>'receivedQty')::integer,
        received_by = p_user_id,
        received_at = now(),
        status = 'received'
    WHERE id = (p_payload->>'slipId')::uuid
      AND factory_id = p_factory_id;
    RETURN jsonb_build_object('ok', true);
  END IF;

  IF p_type = 'attendance_upsert' THEN
    SELECT id INTO v_existing
    FROM public.attendance_records
    WHERE worker_id = (p_payload->>'workerId')::uuid
      AND record_date = (p_payload->>'recordDate')::date
      AND shift_id IS NOT DISTINCT FROM NULLIF(p_payload->>'shiftId', '')::uuid
    LIMIT 1;

    IF v_existing IS NOT NULL THEN
      UPDATE public.attendance_records
      SET status = replace(p_payload->>'status', 'half-day', 'half_day'),
          logged_by = p_user_id,
          logged_at = now()
      WHERE id = v_existing;
      RETURN jsonb_build_object('id', v_existing);
    END IF;

    INSERT INTO public.attendance_records (
      factory_id, worker_id, department_id, shift_id, record_date, status, logged_by, logged_at
    ) VALUES (
      p_factory_id,
      (p_payload->>'workerId')::uuid,
      (p_payload->>'departmentId')::uuid,
      NULLIF(p_payload->>'shiftId', '')::uuid,
      (p_payload->>'recordDate')::date,
      replace(p_payload->>'status', 'half-day', 'half_day'),
      p_user_id,
      now()
    )
    RETURNING id INTO v_id;
    RETURN jsonb_build_object('id', v_id);
  END IF;

  IF p_type = 'audit_session' THEN
    INSERT INTO public.audit_sessions (
      factory_id, order_id, department_id, lot_size, sample_size, aql_level,
      passed, failed, result, logged_by, logged_at
    ) VALUES (
      p_factory_id,
      (p_payload->>'orderId')::uuid,
      (p_payload->>'departmentId')::uuid,
      COALESCE((p_payload->>'lotSize')::integer, 0),
      COALESCE((p_payload->>'sampleSize')::integer, 0),
      NULLIF(p_payload->>'aqlLevel', ''),
      COALESCE((p_payload->>'passed')::integer, 0),
      COALESCE((p_payload->>'failed')::integer, 0),
      NULLIF(p_payload->>'result', ''),
      p_user_id,
      COALESCE((p_payload->>'loggedAt')::timestamptz, now())
    )
    RETURNING id INTO v_id;
    RETURN jsonb_build_object('id', v_id);
  END IF;

  RETURN jsonb_build_object('error', 'Unknown capture type');
END;
$$;

REVOKE ALL ON FUNCTION public.floor_capture(uuid, uuid, text, jsonb) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.floor_capture(uuid, uuid, text, jsonb) TO anon, authenticated;
