-- Transaction Report: handover_slips ledger with shift + hour_slot attribution.

CREATE OR REPLACE FUNCTION public.infer_hour_slot_for_timestamp(
  p_factory_id uuid,
  p_ts timestamptz
)
RETURNS text
LANGUAGE sql
STABLE
SET search_path = public
AS $$
  SELECT COALESCE(
    (
      SELECT (slot->>'start') || '-' || (slot->>'end')
      FROM public.shifts s
      CROSS JOIN LATERAL jsonb_array_elements(COALESCE(s.hours, '[]'::jsonb)) slot
      WHERE s.factory_id = p_factory_id
        AND slot->>'type' = 'active'
        AND (
          ((slot->>'start')::time <= (slot->>'end')::time
            AND p_ts::time >= (slot->>'start')::time
            AND p_ts::time < (slot->>'end')::time)
          OR
          ((slot->>'start')::time > (slot->>'end')::time
            AND (p_ts::time >= (slot->>'start')::time OR p_ts::time < (slot->>'end')::time))
        )
      ORDER BY (slot->>'start')::time
      LIMIT 1
    ),
    to_char(date_trunc('hour', p_ts), 'HH24:MI') || '-' ||
      to_char(date_trunc('hour', p_ts) + interval '1 hour', 'HH24:MI')
  );
$$;

COMMENT ON FUNCTION public.infer_hour_slot_for_timestamp(uuid, timestamptz) IS
  'Maps a timestamp to the factory shift active hour slot label (e.g. 10:00-11:00).';

CREATE OR REPLACE FUNCTION public.get_handover_report(
  p_factory_id uuid,
  p_date_from date DEFAULT NULL,
  p_date_to date DEFAULT NULL,
  p_from_department_id uuid DEFAULT NULL,
  p_to_department_id uuid DEFAULT NULL,
  p_status text DEFAULT NULL,
  p_order_id uuid DEFAULT NULL,
  p_colorway_id uuid DEFAULT NULL,
  p_search text DEFAULT NULL
)
RETURNS TABLE (
  id uuid,
  order_id uuid,
  colorway_id uuid,
  from_department_id uuid,
  to_department_id uuid,
  sent_qty integer,
  received_qty integer,
  qty_by_size jsonb,
  received_qty_by_size jsonb,
  sent_at timestamptz,
  received_at timestamptz,
  status text,
  challan_number text,
  notes text,
  received_notes text,
  sent_by uuid,
  received_by uuid,
  style_name text,
  po_number text,
  colorway_name text,
  color_code text,
  from_department_name text,
  to_department_name text,
  sent_by_name text,
  received_by_name text,
  log_date date,
  shift_id uuid,
  shift_name text,
  hour_slot text
)
LANGUAGE sql
STABLE
SECURITY INVOKER
SET search_path = public
AS $$
  SELECT
    hs.id,
    hs.order_id,
    hs.colorway_id,
    hs.from_department_id,
    hs.to_department_id,
    hs.sent_qty,
    hs.received_qty,
    COALESCE(hs.qty_by_size, '{}'::jsonb),
    COALESCE(hs.received_qty_by_size, '{}'::jsonb),
    hs.sent_at,
    hs.received_at,
    hs.status,
    hs.challan_number,
    hs.notes,
    hs.received_notes,
    hs.sent_by,
    hs.received_by,
    so.style_name,
    so.po_number,
    cw.name AS colorway_name,
    cw.color_code,
    fd.name AS from_department_name,
    td.name AS to_department_name,
    sp.full_name AS sent_by_name,
    rp.full_name AS received_by_name,
    hs.sent_at::date AS log_date,
    public.infer_shift_id_for_inspection(p_factory_id, hs.sent_at) AS shift_id,
    sh.name AS shift_name,
    public.infer_hour_slot_for_timestamp(p_factory_id, hs.sent_at) AS hour_slot
  FROM public.handover_slips hs
  JOIN public.style_orders so ON so.id = hs.order_id
  LEFT JOIN public.colorways cw ON cw.id = hs.colorway_id
  JOIN public.departments fd ON fd.id = hs.from_department_id
  JOIN public.departments td ON td.id = hs.to_department_id
  LEFT JOIN public.profiles sp ON sp.id = hs.sent_by
  LEFT JOIN public.profiles rp ON rp.id = hs.received_by
  LEFT JOIN public.shifts sh
    ON sh.id = public.infer_shift_id_for_inspection(p_factory_id, hs.sent_at)
  WHERE hs.factory_id = p_factory_id
    AND hs.sent_at::date >= COALESCE(p_date_from, CURRENT_DATE - 30)
    AND hs.sent_at::date <= COALESCE(p_date_to, CURRENT_DATE)
    AND (p_from_department_id IS NULL OR hs.from_department_id = p_from_department_id)
    AND (p_to_department_id IS NULL OR hs.to_department_id = p_to_department_id)
    AND (p_status IS NULL OR hs.status = p_status)
    AND (p_order_id IS NULL OR hs.order_id = p_order_id)
    AND (p_colorway_id IS NULL OR hs.colorway_id IS NOT DISTINCT FROM p_colorway_id)
    AND (
      p_search IS NULL
      OR trim(p_search) = ''
      OR so.style_name ILIKE '%' || trim(p_search) || '%'
      OR so.po_number ILIKE '%' || trim(p_search) || '%'
      OR hs.challan_number ILIKE '%' || trim(p_search) || '%'
      OR fd.name ILIKE '%' || trim(p_search) || '%'
      OR td.name ILIKE '%' || trim(p_search) || '%'
    )
  ORDER BY hs.sent_at DESC
  LIMIT 2000;
$$;

COMMENT ON FUNCTION public.get_handover_report IS
  'Read-only handover ledger for Transaction Report. Shift/hour_slot from sent_at via factory shifts.hours.';

REVOKE ALL ON FUNCTION public.get_handover_report FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.get_handover_report TO authenticated;
REVOKE EXECUTE ON FUNCTION public.get_handover_report FROM anon;

REVOKE ALL ON FUNCTION public.infer_hour_slot_for_timestamp FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.infer_hour_slot_for_timestamp TO authenticated;
