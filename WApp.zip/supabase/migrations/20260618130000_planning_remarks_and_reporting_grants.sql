-- Planning remarks on colorways + remaining reporting view grants.

ALTER TABLE public.colorways
  ADD COLUMN IF NOT EXISTS planning_remarks text;

COMMENT ON COLUMN public.colorways.planning_remarks IS
  'Per-colorway production planning notes (summary modal, print).';

-- KPI reporting views (idempotent if 20260618120000 already applied)
GRANT SELECT ON public.v_daily_quality TO authenticated;
GRANT SELECT ON public.v_daily_kpis_by_shift TO authenticated;
GRANT SELECT ON public.v_daily_kpis TO authenticated;
GRANT SELECT ON public.v_daily_output TO authenticated;
GRANT SELECT ON public.v_daily_target TO authenticated;
GRANT SELECT ON public.v_daily_workforce TO authenticated;
GRANT SELECT ON public.v_wip_dept TO authenticated;
GRANT SELECT ON public.v_shift_minutes TO authenticated;

-- Cut-to-ship reporting (SECURITY INVOKER RPCs)
GRANT SELECT ON public.v_cut_to_ship TO authenticated;
GRANT SELECT ON public.v_cut_to_ship_dept_journey TO authenticated;
