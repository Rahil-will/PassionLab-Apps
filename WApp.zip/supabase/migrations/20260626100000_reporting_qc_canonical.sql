-- =============================================================================
-- Reporting QC canonicalization: enforce inspection_sessions everywhere
-- =============================================================================
-- Problem:
-- - Some migrations still define KPI views using legacy public.inspections.
-- - The app expects QC to come from public.inspection_sessions.
--
-- This migration re-points reporting views/RPCs back to inspection_sessions
-- (idempotent via CREATE OR REPLACE / DROP IF EXISTS) and ensures required grants.
--
-- Safe to apply even if inspections table already dropped.
-- =============================================================================

BEGIN;

-- Guard: inspection_sessions must exist for QC-backed reporting.
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.tables
    WHERE table_schema = 'public' AND table_name = 'inspection_sessions'
  ) THEN
    RAISE EXCEPTION 'inspection_sessions table is missing; cannot canonicalize reporting QC source';
  END IF;
END $$;

-- -----------------------------------------------------------------------------
-- v_daily_output: QC branch reads inspection_sessions (passed + rework_passed)
-- -----------------------------------------------------------------------------
CREATE OR REPLACE VIEW public.v_daily_output AS
WITH hourly AS (
  SELECT
    h.factory_id,
    h.order_id,
    h.colorway_id,
    h.department_id,
    h.log_date,
    public.get_shift_for_hour_slot(h.factory_id, h.hour_slot) AS shift_id,
    SUM(h.count)::integer AS output_qty
  FROM public.hourly_counts h
  JOIN public.departments d ON d.id = h.department_id AND d.is_production = true
  GROUP BY
    h.factory_id, h.order_id, h.colorway_id, h.department_id, h.log_date,
    public.get_shift_for_hour_slot(h.factory_id, h.hour_slot)
),
inspection AS (
  SELECT
    s.factory_id,
    s.order_id,
    s.colorway_id,
    s.department_id,
    s.log_date,
    s.shift_id,
    SUM(COALESCE(s.passed, 0) + COALESCE(s.rework_passed, 0))::integer AS output_qty
  FROM public.inspection_sessions s
  JOIN public.departments d ON d.id = s.department_id AND d.is_production = true
  GROUP BY s.factory_id, s.order_id, s.colorway_id, s.department_id, s.log_date, s.shift_id
),
keys AS (
  SELECT DISTINCT factory_id, order_id, colorway_id, department_id, log_date FROM hourly
  UNION
  SELECT DISTINCT factory_id, order_id, colorway_id, department_id, log_date FROM inspection
),
mode_pick AS (
  SELECT
    k.factory_id, k.order_id, k.colorway_id, k.department_id, k.log_date,
    CASE
      WHEN EXISTS (
        SELECT 1 FROM public.hourly_counts h
        JOIN public.departments d ON d.id = h.department_id AND d.is_production = true
        WHERE h.factory_id = k.factory_id AND h.order_id = k.order_id
          AND h.department_id = k.department_id AND h.log_date = k.log_date
      ) THEN 'hourly'
      WHEN EXISTS (
        SELECT 1 FROM public.inspection_sessions s
        JOIN public.departments d ON d.id = s.department_id AND d.is_production = true
        WHERE s.factory_id = k.factory_id AND s.order_id = k.order_id
          AND s.department_id = k.department_id AND s.log_date = k.log_date
      ) THEN 'qc'
      ELSE 'none'
    END AS capture_mode
  FROM keys k
)
SELECT
  m.factory_id, m.order_id, m.colorway_id, m.department_id, m.log_date,
  o.shift_id, o.output_qty, m.capture_mode, (o.shift_id IS NULL) AS is_unallocated
FROM mode_pick m
JOIN LATERAL (
  SELECT h.shift_id, h.output_qty FROM hourly h
  WHERE m.capture_mode = 'hourly'
    AND h.factory_id = m.factory_id AND h.order_id = m.order_id
    AND h.colorway_id IS NOT DISTINCT FROM m.colorway_id
    AND h.department_id = m.department_id AND h.log_date = m.log_date
  UNION ALL
  SELECT i.shift_id, i.output_qty FROM inspection i
  WHERE m.capture_mode = 'qc'
    AND i.factory_id = m.factory_id AND i.order_id = m.order_id
    AND i.colorway_id IS NOT DISTINCT FROM m.colorway_id
    AND i.department_id = m.department_id AND i.log_date = m.log_date
) o ON true;

COMMENT ON VIEW public.v_daily_output IS
  'Production dept output at colorway grain. QC from inspection_sessions (passed + rework_passed).';

-- -----------------------------------------------------------------------------
-- v_daily_quality: QC metrics from inspection_sessions (qc_log departments only)
-- Drop dependents first (functions → views) then recreate.
-- -----------------------------------------------------------------------------
DROP FUNCTION IF EXISTS public.get_factory_kpis(uuid, date, date);
DROP FUNCTION IF EXISTS public.get_department_kpis(uuid, uuid, date, date);
DROP FUNCTION IF EXISTS public.get_department_kpis_by_shift(uuid, uuid, date, date);
DROP FUNCTION IF EXISTS public.get_style_kpis(uuid, uuid);
DROP FUNCTION IF EXISTS public.get_live_dept_kpi(uuid, uuid);
DROP FUNCTION IF EXISTS public.get_dept_quality_for_date(uuid, uuid, date);

DROP VIEW IF EXISTS public.v_daily_kpis;
DROP VIEW IF EXISTS public.v_daily_kpis_by_shift;
DROP VIEW IF EXISTS public.v_daily_quality;

CREATE VIEW public.v_daily_quality AS
SELECT
  s.factory_id,
  s.order_id,
  s.department_id,
  s.log_date,
  SUM(COALESCE(s.total_inspected, 0))::integer AS inspected,
  SUM(COALESCE(s.passed, 0))::integer AS passed,
  SUM(COALESCE(s.failed, 0))::integer AS failed,
  SUM(COALESCE(s.rework, 0))::integer AS rework,
  SUM(COALESCE(s.rework_passed, 0))::integer AS rework_pass,
  CASE
    WHEN SUM(COALESCE(s.total_inspected, 0)) = 0 THEN NULL
    ELSE ROUND(
      100.0 * SUM(
        (
          SELECT COALESCE(SUM(v::integer), 0)
          FROM jsonb_each_text(COALESCE(s.defect_summary, '{}'::jsonb)) AS d(k, v)
        )
      ) / NULLIF(SUM(COALESCE(s.total_inspected, 0)), 0)
    )::numeric
  END AS dhu,
  CASE
    WHEN SUM(COALESCE(s.total_inspected, 0)) = 0 THEN NULL
    ELSE ROUND(
      100.0 * SUM(COALESCE(s.failed, 0) + COALESCE(s.rework, 0))
      / NULLIF(SUM(COALESCE(s.total_inspected, 0)), 0)
    )::numeric
  END AS defective_pct
FROM public.inspection_sessions s
JOIN public.departments d ON d.id = s.department_id
  AND COALESCE(d.apps, '[]'::jsonb) @> '["qc_log"]'::jsonb
GROUP BY s.factory_id, s.order_id, s.department_id, s.log_date;

COMMENT ON VIEW public.v_daily_quality IS
  'QC dept metrics from inspection_sessions (qc_log app only).';

-- -----------------------------------------------------------------------------
-- KPI views: by-shift and daily
-- -----------------------------------------------------------------------------
CREATE VIEW public.v_daily_kpis_by_shift AS
WITH output_shift AS (
  SELECT factory_id, order_id, department_id, log_date, shift_id,
    SUM(output_qty)::integer AS shift_output
  FROM public.v_daily_output
  WHERE shift_id IS NOT NULL
  GROUP BY factory_id, order_id, department_id, log_date, shift_id
),
workforce AS (
  SELECT * FROM public.v_daily_workforce
),
shift_quality AS (
  SELECT
    s.factory_id,
    s.order_id,
    s.department_id,
    s.log_date,
    s.shift_id,
    SUM(COALESCE(s.total_inspected, 0))::integer AS inspected,
    SUM(
      (
        SELECT COALESCE(SUM(v::integer), 0)
        FROM jsonb_each_text(COALESCE(s.defect_summary, '{}'::jsonb)) AS d(k, v)
      )
    )::integer AS total_defects,
    SUM(COALESCE(s.failed, 0) + COALESCE(s.rework, 0))::integer AS defective_pieces
  FROM public.inspection_sessions s
  JOIN public.departments d ON d.id = s.department_id
    AND COALESCE(d.apps, '[]'::jsonb) @> '["qc_log"]'::jsonb
  WHERE s.shift_id IS NOT NULL
  GROUP BY s.factory_id, s.order_id, s.department_id, s.log_date, s.shift_id
),
shift_keys AS (
  SELECT factory_id, department_id, log_date, shift_id FROM workforce
  UNION
  SELECT h.factory_id, h.department_id, h.log_date,
    public.get_shift_for_hour_slot(h.factory_id, h.hour_slot) AS shift_id
  FROM public.hourly_counts h
  JOIN public.departments d ON d.id = h.department_id AND d.is_production = true
  WHERE public.get_shift_for_hour_slot(h.factory_id, h.hour_slot) IS NOT NULL
  UNION
  SELECT s.factory_id, s.department_id, s.log_date, s.shift_id
  FROM public.inspection_sessions s
  JOIN public.departments d ON d.id = s.department_id AND d.is_production = true
  WHERE s.shift_id IS NOT NULL
),
order_keys AS (
  SELECT DISTINCT factory_id, order_id, department_id, log_date FROM public.v_daily_output
  UNION
  SELECT DISTINCT t.factory_id, t.order_id, t.department_id, t.log_date
  FROM public.v_daily_target t
  JOIN public.departments d ON d.id = t.department_id AND d.is_production = true
),
base AS (
  SELECT ok.factory_id, ok.order_id, ok.department_id, ok.log_date, sk.shift_id
  FROM order_keys ok
  JOIN shift_keys sk
    ON sk.factory_id = ok.factory_id
   AND sk.department_id = ok.department_id
   AND sk.log_date = ok.log_date
),
enriched AS (
  SELECT
    b.factory_id, b.order_id, b.department_id, b.log_date, b.shift_id,
    sm.shift_name, sm.productive_mins,
    COALESCE(os.shift_output, 0) AS shift_output,
    COALESCE(wf.headcount, 0) AS shift_headcount,
    COALESCE(wf.available_mins, 0) AS shift_available_mins,
    (wf.shift_id IS NOT NULL) AS has_workforce,
    (COALESCE(os.shift_output, 0) > 0) AS has_output
  FROM base b
  JOIN public.v_shift_minutes sm ON sm.shift_id = b.shift_id
  LEFT JOIN output_shift os
    ON os.factory_id = b.factory_id AND os.order_id = b.order_id
   AND os.department_id = b.department_id AND os.log_date = b.log_date
   AND os.shift_id = b.shift_id
  LEFT JOIN workforce wf
    ON wf.factory_id = b.factory_id AND wf.department_id = b.department_id
   AND wf.log_date = b.log_date AND wf.shift_id = b.shift_id
),
with_flags AS (
  SELECT e.*,
    CASE
      WHEN NOT e.has_workforce AND NOT e.has_output THEN 'none'
      WHEN e.has_workforce AND e.has_output THEN 'complete'
      WHEN e.has_workforce THEN 'workforce_only'
      ELSE 'output_only'
    END AS data_completeness
  FROM enriched e
),
prorated AS (
  SELECT wf.*, t.daily_target,
    SUM(wf.productive_mins) OVER (
      PARTITION BY wf.factory_id, wf.order_id, wf.department_id, wf.log_date
    ) AS active_productive_mins
  FROM with_flags wf
  LEFT JOIN public.v_daily_target t
    ON t.factory_id = wf.factory_id AND t.order_id = wf.order_id
   AND t.department_id = wf.department_id AND t.log_date = wf.log_date
)
SELECT
  p.factory_id, p.order_id, p.department_id, p.log_date, p.shift_id, p.shift_name,
  p.shift_output, p.shift_headcount, p.shift_available_mins, p.has_workforce, p.has_output,
  p.data_completeness,
  CASE WHEN p.data_completeness = 'complete' AND COALESCE(p.daily_target, 0) > 0
    THEN ROUND(100.0 * p.shift_output / NULLIF(
      p.daily_target * (p.productive_mins / NULLIF(p.active_productive_mins, 0)), 0))::numeric
    ELSE NULL END AS shift_efficiency_pct,
  CASE WHEN p.data_completeness = 'complete' AND p.shift_headcount > 0
    THEN ROUND(p.shift_output::numeric / p.shift_headcount, 2) ELSE NULL END AS shift_productivity,
  CASE WHEN COALESCE(sq.inspected, 0) > 0
    THEN ROUND(100.0 * sq.total_defects / sq.inspected)::numeric ELSE NULL END AS dhu,
  CASE WHEN COALESCE(sq.inspected, 0) > 0
    THEN ROUND(100.0 * sq.defective_pieces / sq.inspected)::numeric ELSE NULL END AS defective_pct
FROM prorated p
LEFT JOIN shift_quality sq
  ON sq.factory_id = p.factory_id AND sq.order_id = p.order_id
 AND sq.department_id = p.department_id AND sq.log_date = p.log_date
 AND sq.shift_id = p.shift_id;

CREATE VIEW public.v_daily_kpis AS
WITH shift_rows AS (
  SELECT * FROM public.v_daily_kpis_by_shift
),
unalloc AS (
  SELECT factory_id, order_id, department_id, log_date, unallocated_output
  FROM (
    SELECT factory_id, order_id, department_id, log_date,
      SUM(output_qty)::integer AS unallocated_output
    FROM public.v_daily_output
    WHERE shift_id IS NULL
    GROUP BY factory_id, order_id, department_id, log_date
  ) u
),
wip_daily AS (
  SELECT factory_id, order_id, department_id, log_date,
    SUM(wip_qty)::integer AS wip_qty
  FROM public.v_wip_dept
  GROUP BY factory_id, order_id, department_id, log_date
),
daily AS (
  SELECT
    sr.factory_id, sr.order_id, sr.department_id, sr.log_date,
    COALESCE(t.daily_target, 0) AS daily_target,
    COALESCE(SUM(sr.shift_output), 0) + COALESCE(MAX(u.unallocated_output), 0) AS daily_output,
    COALESCE(SUM(sr.shift_available_mins) FILTER (
      WHERE sr.data_completeness IN ('complete', 'workforce_only')
    ), 0) AS daily_available_mins,
    COALESCE(SUM(sr.shift_output) FILTER (WHERE sr.data_completeness = 'complete'), 0) AS complete_output,
    COALESCE(SUM(sr.shift_headcount) FILTER (WHERE sr.data_completeness = 'complete'), 0) AS complete_headcount,
    BOOL_OR(sr.data_completeness = 'complete') AS any_complete,
    BOOL_OR(sr.data_completeness = 'output_only') AS any_output_only,
    BOOL_OR(sr.data_completeness = 'workforce_only') AS any_workforce_only,
    BOOL_OR(sr.data_completeness <> 'none') AS any_active
  FROM shift_rows sr
  LEFT JOIN public.v_daily_target t
    ON t.factory_id = sr.factory_id AND t.order_id = sr.order_id
   AND t.department_id = sr.department_id AND t.log_date = sr.log_date
  LEFT JOIN unalloc u
    ON u.factory_id = sr.factory_id AND u.order_id = sr.order_id
   AND u.department_id = sr.department_id AND u.log_date = sr.log_date
  GROUP BY sr.factory_id, sr.order_id, sr.department_id, sr.log_date, t.daily_target
)
SELECT
  d.factory_id, d.order_id, d.department_id, d.log_date,
  d.daily_target, d.daily_output, d.daily_available_mins,
  CASE WHEN d.any_complete AND d.daily_target > 0
    THEN ROUND(100.0 * d.complete_output / NULLIF(d.daily_target, 0))::numeric
    ELSE NULL END AS daily_efficiency_pct,
  CASE WHEN d.any_complete AND d.complete_headcount > 0
    THEN ROUND(d.complete_output::numeric / d.complete_headcount, 2) ELSE NULL END AS daily_productivity,
  CASE
    WHEN NOT d.any_active THEN 'none'
    WHEN d.any_complete AND NOT d.any_output_only AND NOT d.any_workforce_only THEN 'complete'
    WHEN d.any_complete THEN 'partial'
    WHEN d.any_output_only THEN 'output_only'
    WHEN d.any_workforce_only THEN 'workforce_only'
    ELSE 'none'
  END AS day_completeness,
  q.dhu, q.defective_pct,
  COALESCE(w.wip_qty, 0) AS wip_qty,
  (
    SELECT COALESCE(jsonb_agg(jsonb_build_object(
      'shift_id', s.shift_id, 'shift_name', s.shift_name,
      'output', s.shift_output, 'headcount', s.shift_headcount,
      'efficiency_pct', s.shift_efficiency_pct
    ) ORDER BY s.shift_name), '[]'::jsonb)
    FROM public.v_daily_kpis_by_shift s
    WHERE s.factory_id = d.factory_id AND s.order_id = d.order_id
      AND s.department_id = d.department_id AND s.log_date = d.log_date
  ) AS shift_breakdown
FROM daily d
LEFT JOIN public.v_daily_quality q
  ON q.factory_id = d.factory_id AND q.order_id = d.order_id
 AND q.department_id = d.department_id AND q.log_date = d.log_date
LEFT JOIN wip_daily w
  ON w.factory_id = d.factory_id AND w.order_id = d.order_id
 AND w.department_id = d.department_id AND w.log_date = d.log_date;

-- -----------------------------------------------------------------------------
-- KPI RPC wrappers (SECURITY DEFINER + factory guard; matches 20260621100000)
-- -----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.get_factory_kpis(
  p_factory_id uuid, p_date_from date, p_date_to date
)
RETURNS SETOF public.v_daily_kpis
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT *
  FROM public.v_daily_kpis
  WHERE factory_id = p_factory_id
    AND p_factory_id = public.current_factory_id()
    AND log_date BETWEEN p_date_from AND p_date_to
  ORDER BY log_date, department_id, order_id;
$$;

CREATE OR REPLACE FUNCTION public.get_department_kpis(
  p_factory_id uuid, p_department_id uuid, p_date_from date, p_date_to date
)
RETURNS SETOF public.v_daily_kpis
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT *
  FROM public.v_daily_kpis
  WHERE factory_id = p_factory_id
    AND p_factory_id = public.current_factory_id()
    AND department_id = p_department_id
    AND log_date BETWEEN p_date_from AND p_date_to
  ORDER BY log_date, order_id;
$$;

CREATE OR REPLACE FUNCTION public.get_department_kpis_by_shift(
  p_factory_id uuid, p_department_id uuid, p_date_from date, p_date_to date
)
RETURNS SETOF public.v_daily_kpis_by_shift
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT *
  FROM public.v_daily_kpis_by_shift
  WHERE factory_id = p_factory_id
    AND p_factory_id = public.current_factory_id()
    AND department_id = p_department_id
    AND log_date BETWEEN p_date_from AND p_date_to
  ORDER BY log_date, shift_name, order_id;
$$;

CREATE OR REPLACE FUNCTION public.get_style_kpis(p_factory_id uuid, p_order_id uuid)
RETURNS SETOF public.v_daily_kpis
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT k.*
  FROM public.v_daily_kpis k
  JOIN public.style_orders so
    ON so.id = k.order_id
   AND so.factory_id = k.factory_id
  WHERE k.factory_id = p_factory_id
    AND p_factory_id = public.current_factory_id()
    AND k.order_id = p_order_id
    AND (
      so.process_flow_id IS NULL
      OR k.department_id IN (
        SELECT pfs.department_id
        FROM public.process_flow_steps pfs
        WHERE pfs.flow_id = so.process_flow_id
      )
    )
  ORDER BY k.log_date, k.department_id;
$$;

CREATE OR REPLACE FUNCTION public.get_live_dept_kpi(
  p_factory_id uuid,
  p_department_id uuid
)
RETURNS SETOF public.v_daily_kpis
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT *
  FROM public.v_daily_kpis
  WHERE factory_id = p_factory_id
    AND p_factory_id = public.current_factory_id()
    AND department_id = p_department_id
    AND log_date = CURRENT_DATE
  ORDER BY order_id;
$$;

CREATE OR REPLACE FUNCTION public.get_dept_quality_for_date(
  p_factory_id uuid,
  p_department_id uuid,
  p_log_date date
)
RETURNS SETOF public.v_daily_quality
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT *
  FROM public.v_daily_quality
  WHERE factory_id = p_factory_id
    AND p_factory_id = public.current_factory_id()
    AND department_id = p_department_id
    AND log_date = p_log_date
  ORDER BY order_id;
$$;

REVOKE ALL ON FUNCTION public.get_factory_kpis(uuid, date, date) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.get_department_kpis(uuid, uuid, date, date) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.get_department_kpis_by_shift(uuid, uuid, date, date) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.get_style_kpis(uuid, uuid) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.get_live_dept_kpi(uuid, uuid) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.get_dept_quality_for_date(uuid, uuid, date) FROM PUBLIC;

GRANT EXECUTE ON FUNCTION public.get_factory_kpis(uuid, date, date) TO authenticated;
GRANT EXECUTE ON FUNCTION public.get_department_kpis(uuid, uuid, date, date) TO authenticated;
GRANT EXECUTE ON FUNCTION public.get_department_kpis_by_shift(uuid, uuid, date, date) TO authenticated;
GRANT EXECUTE ON FUNCTION public.get_style_kpis(uuid, uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.get_live_dept_kpi(uuid, uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.get_dept_quality_for_date(uuid, uuid, date) TO authenticated;

REVOKE EXECUTE ON FUNCTION public.get_factory_kpis(uuid, date, date) FROM anon;
REVOKE EXECUTE ON FUNCTION public.get_department_kpis(uuid, uuid, date, date) FROM anon;
REVOKE EXECUTE ON FUNCTION public.get_department_kpis_by_shift(uuid, uuid, date, date) FROM anon;
REVOKE EXECUTE ON FUNCTION public.get_style_kpis(uuid, uuid) FROM anon;
REVOKE EXECUTE ON FUNCTION public.get_live_dept_kpi(uuid, uuid) FROM anon;
REVOKE EXECUTE ON FUNCTION public.get_dept_quality_for_date(uuid, uuid, date) FROM anon;

COMMENT ON FUNCTION public.get_live_dept_kpi(uuid, uuid) IS
  'Today''s KPI rows for a department (floor dashboard).';
COMMENT ON FUNCTION public.get_dept_quality_for_date(uuid, uuid, date) IS
  'Department QC KPI rows for a date (DHU, defective_pct, inspected). Wraps v_daily_quality.';

-- -----------------------------------------------------------------------------
-- Compatibility cleanup: drop legacy inspections if still present
-- -----------------------------------------------------------------------------
DROP TABLE IF EXISTS public.inspections;

-- -----------------------------------------------------------------------------
-- Grants: underlying QC table must be readable for view invoker reads
-- -----------------------------------------------------------------------------
GRANT SELECT ON public.v_daily_quality TO authenticated;
GRANT SELECT ON public.v_daily_kpis_by_shift TO authenticated;
GRANT SELECT ON public.v_daily_kpis TO authenticated;
GRANT SELECT ON public.v_daily_output TO authenticated;
GRANT SELECT ON public.inspection_sessions TO authenticated;

COMMIT;

