-- Planned hourly output per line allocation (saved from production planning).
ALTER TABLE public.line_allocations
  ADD COLUMN IF NOT EXISTS hourly_target numeric(10, 2);

COMMENT ON COLUMN public.line_allocations.hourly_target IS
  'Planned pieces per active hour for this allocation row.';
