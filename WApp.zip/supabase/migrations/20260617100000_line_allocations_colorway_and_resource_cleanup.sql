-- line_allocations: explicit colorway_id + style order on order_id
-- assigned_resources: drop unused order_id (resources belong to department only)

ALTER TABLE public.line_allocations
  ADD COLUMN IF NOT EXISTS colorway_id uuid REFERENCES public.colorways(id) ON DELETE CASCADE;

-- Backfill from legacy convention (order_id held colorway id)
UPDATE public.line_allocations la
SET colorway_id = la.order_id
WHERE la.colorway_id IS NULL
  AND EXISTS (SELECT 1 FROM public.colorways cw WHERE cw.id = la.order_id);

UPDATE public.line_allocations la
SET order_id = cw.order_id
FROM public.colorways cw
WHERE la.colorway_id = cw.id
  AND la.order_id = cw.id;

CREATE INDEX IF NOT EXISTS line_allocations_colorway_id_idx
  ON public.line_allocations(colorway_id);

COMMENT ON COLUMN public.line_allocations.colorway_id IS
  'Colorway this allocation row plans. order_id is the parent style_orders id.';

-- v_daily_target: use explicit colorway_id when present
CREATE OR REPLACE VIEW public.v_daily_target AS
SELECT
  la.factory_id,
  la.order_id,
  la.colorway_id,
  la.department_id,
  d.log_date,
  SUM(la.daily_target)::integer AS daily_target
FROM public.line_allocations la
CROSS JOIN LATERAL (
  SELECT generate_series(la.start_date, la.end_date, interval '1 day')::date AS log_date
) d
WHERE la.start_date IS NOT NULL
  AND la.end_date IS NOT NULL
  AND la.department_id IS NOT NULL
GROUP BY la.factory_id, la.order_id, la.colorway_id, la.department_id, d.log_date;

COMMENT ON VIEW public.v_daily_target IS
  'Daily plan target per factory/order/colorway/department/date from line_allocations.daily_target.';

ALTER TABLE public.assigned_resources
  DROP COLUMN IF EXISTS order_id;
