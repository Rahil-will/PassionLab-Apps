-- Order delete: cascade all floor / capture rows when a style_order is removed.
-- Fixes FK 23503 on inspection_sessions_order_id_fkey (and any other RESTRICT/NO ACTION refs).

-- 1) Ensure every FK → style_orders(id) uses ON DELETE CASCADE (except intentional SET NULL).
DO $$
DECLARE
  r RECORD;
BEGIN
  FOR r IN
    SELECT
      con.conname AS constraint_name,
      src.relname AS table_name,
      att.attname AS column_name,
      con.confdeltype AS delete_type
    FROM pg_constraint con
    JOIN pg_class src ON src.oid = con.conrelid
    JOIN pg_class tgt ON tgt.oid = con.confrelid
    JOIN pg_namespace nsp ON nsp.oid = src.relnamespace
    JOIN pg_attribute att
      ON att.attrelid = con.conrelid
     AND att.attnum = ANY (con.conkey)
     AND att.attnum > 0
     AND NOT att.attisdropped
    WHERE con.contype = 'f'
      AND nsp.nspname = 'public'
      AND tgt.relname = 'style_orders'
      AND con.confdeltype IN ('a', 'r') -- NO ACTION, RESTRICT
  LOOP
    EXECUTE format(
      'ALTER TABLE public.%I DROP CONSTRAINT %I',
      r.table_name,
      r.constraint_name
    );
    EXECUTE format(
      'ALTER TABLE public.%I ADD CONSTRAINT %I FOREIGN KEY (%I) REFERENCES public.style_orders(id) ON DELETE CASCADE',
      r.table_name,
      r.constraint_name,
      r.column_name
    );
    RAISE NOTICE 'Updated FK % on %.% to ON DELETE CASCADE', r.constraint_name, r.table_name, r.column_name;
  END LOOP;
END $$;

-- 2) Admin RPC: purge all order-scoped rows then delete the order (bypasses RLS on capture tables).
CREATE OR REPLACE FUNCTION public.delete_style_order(
  p_factory_id uuid,
  p_order_id uuid
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_colorway_ids uuid[];
BEGIN
  IF p_factory_id IS NULL OR p_order_id IS NULL THEN
    RAISE EXCEPTION 'factory_id and order_id are required';
  END IF;

  IF p_factory_id IS DISTINCT FROM public.current_factory_id() THEN
    RAISE EXCEPTION 'Factory mismatch';
  END IF;

  IF NOT public.is_factory_admin() THEN
    RAISE EXCEPTION 'Not authorized to delete orders';
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM public.style_orders
    WHERE id = p_order_id AND factory_id = p_factory_id
  ) THEN
    RAISE EXCEPTION 'Order not found';
  END IF;

  SELECT COALESCE(array_agg(c.id), '{}'::uuid[])
  INTO v_colorway_ids
  FROM public.colorways c
  WHERE c.order_id = p_order_id;

  -- Capture / floor data (explicit delete for tables without CASCADE or without client DELETE policies)
  IF to_regclass('public.inspection_sessions') IS NOT NULL THEN
    DELETE FROM public.inspection_sessions
    WHERE factory_id = p_factory_id AND order_id = p_order_id;
  END IF;

  IF to_regclass('public.hourly_counts') IS NOT NULL THEN
    DELETE FROM public.hourly_counts
    WHERE factory_id = p_factory_id AND order_id = p_order_id;
  END IF;

  IF to_regclass('public.handover_slips') IS NOT NULL THEN
    DELETE FROM public.handover_slips
    WHERE factory_id = p_factory_id AND order_id = p_order_id;
  END IF;

  IF to_regclass('public.inspections') IS NOT NULL THEN
    DELETE FROM public.inspections
    WHERE factory_id = p_factory_id AND order_id = p_order_id;
  END IF;

  IF to_regclass('public.audit_sessions') IS NOT NULL THEN
    DELETE FROM public.audit_sessions
    WHERE factory_id = p_factory_id AND order_id = p_order_id;
  END IF;

  IF to_regclass('public.rejections') IS NOT NULL THEN
    DELETE FROM public.rejections
    WHERE factory_id = p_factory_id AND order_id = p_order_id;
  END IF;

  IF to_regclass('public.shipments') IS NOT NULL THEN
    DELETE FROM public.shipments
    WHERE factory_id = p_factory_id AND order_id = p_order_id;
  END IF;

  IF to_regclass('public.order_department_mode') IS NOT NULL THEN
    DELETE FROM public.order_department_mode WHERE order_id = p_order_id;
  END IF;

  IF to_regclass('public.line_allocations') IS NOT NULL THEN
    DELETE FROM public.line_allocations
    WHERE factory_id = p_factory_id
      AND (
        order_id = p_order_id
        OR (cardinality(v_colorway_ids) > 0 AND colorway_id = ANY (v_colorway_ids))
        OR (cardinality(v_colorway_ids) > 0 AND order_id = ANY (v_colorway_ids))
      );
  END IF;

  DELETE FROM public.style_orders
  WHERE id = p_order_id AND factory_id = p_factory_id;
END;
$$;

COMMENT ON FUNCTION public.delete_style_order(uuid, uuid) IS
  'Factory admin: delete style_order and all linked capture rows (QC sessions, hourly, handovers, shipments, rejections, allocations).';

REVOKE ALL ON FUNCTION public.delete_style_order(uuid, uuid) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.delete_style_order(uuid, uuid) TO authenticated;
