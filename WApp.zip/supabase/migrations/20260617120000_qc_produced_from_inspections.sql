-- QC departments: passed inspections drive produced_qty_by_size in get_order_dept_progress

CREATE OR REPLACE FUNCTION public.get_order_dept_progress(
  p_factory_id uuid,
  p_order_id uuid,
  p_colorway_id uuid,
  p_department_id uuid,
  p_date date DEFAULT CURRENT_DATE
)
RETURNS jsonb
LANGUAGE plpgsql
STABLE
SECURITY INVOKER
SET search_path = public
AS $$
DECLARE
  v_planned jsonb;
  v_planned_total integer;
  v_cutting_id uuid;
  v_is_cutting boolean;
  v_cum_produced integer := 0;
  v_today_produced integer := 0;
  v_cum_sent integer := 0;
  v_today_sent integer := 0;
  v_produced_by_size jsonb := '{}'::jsonb;
  v_sent_by_size jsonb := '{}'::jsonb;
  v_hourly_total integer := 0;
  v_today_target integer := 0;
  v_remaining integer;
  v_inspection_count integer := 0;
BEGIN
  v_planned := public.colorway_planned_by_size(p_colorway_id);
  v_planned_total := public.jsonb_sum_int_values(v_planned);
  v_cutting_id := public.get_cutting_department_id(p_factory_id);
  v_is_cutting := (p_department_id = v_cutting_id);

  SELECT COALESCE(SUM(daily_target), 0)::integer INTO v_today_target
  FROM public.v_daily_target t
  WHERE t.factory_id = p_factory_id
    AND t.order_id = p_order_id
    AND t.department_id = p_department_id
    AND t.log_date = p_date;

  SELECT COALESCE(SUM(o.output_qty), 0)::integer INTO v_cum_produced
  FROM public.v_daily_output o
  WHERE o.factory_id = p_factory_id
    AND o.order_id = p_order_id
    AND o.colorway_id IS NOT DISTINCT FROM p_colorway_id
    AND o.department_id = p_department_id;

  SELECT COALESCE(SUM(o.output_qty), 0)::integer INTO v_today_produced
  FROM public.v_daily_output o
  WHERE o.factory_id = p_factory_id
    AND o.order_id = p_order_id
    AND o.colorway_id IS NOT DISTINCT FROM p_colorway_id
    AND o.department_id = p_department_id
    AND o.log_date = p_date;

  SELECT COALESCE(SUM(hs.sent_qty), 0)::integer INTO v_cum_sent
  FROM public.handover_slips hs
  WHERE hs.factory_id = p_factory_id
    AND hs.order_id = p_order_id
    AND hs.colorway_id IS NOT DISTINCT FROM p_colorway_id
    AND hs.from_department_id = p_department_id;

  SELECT COALESCE(SUM(hs.sent_qty), 0)::integer INTO v_today_sent
  FROM public.handover_slips hs
  WHERE hs.factory_id = p_factory_id
    AND hs.order_id = p_order_id
    AND hs.colorway_id IS NOT DISTINCT FROM p_colorway_id
    AND hs.from_department_id = p_department_id
    AND hs.sent_at::date = p_date;

  SELECT public.jsonb_merge_sum_maps(ARRAY_AGG(hs.qty_by_size))
  INTO v_sent_by_size
  FROM public.handover_slips hs
  WHERE hs.factory_id = p_factory_id
    AND hs.order_id = p_order_id
    AND hs.colorway_id IS NOT DISTINCT FROM p_colorway_id
    AND hs.from_department_id = p_department_id
    AND hs.qty_by_size <> '{}'::jsonb;

  IF v_is_cutting THEN
    SELECT public.jsonb_merge_sum_maps(ARRAY_AGG(h.count_by_size))
    INTO v_produced_by_size
    FROM public.hourly_counts h
    WHERE h.factory_id = p_factory_id
      AND h.order_id = p_order_id
      AND h.colorway_id IS NOT DISTINCT FROM p_colorway_id
      AND h.department_id = p_department_id
      AND h.count_by_size <> '{}'::jsonb;
    IF v_produced_by_size = '{}'::jsonb OR v_produced_by_size IS NULL THEN
      SELECT COALESCE(SUM(h.count), 0)::integer INTO v_hourly_total
      FROM public.hourly_counts h
      WHERE h.factory_id = p_factory_id
        AND h.order_id = p_order_id
        AND h.colorway_id IS NOT DISTINCT FROM p_colorway_id
        AND h.department_id = p_department_id;
      v_produced_by_size := public.proportional_qty_by_size(v_hourly_total, v_planned);
    END IF;
  ELSE
    SELECT COUNT(*)::integer INTO v_inspection_count
    FROM public.inspections i
    WHERE i.factory_id = p_factory_id
      AND i.order_id = p_order_id
      AND i.colorway_id IS NOT DISTINCT FROM p_colorway_id
      AND i.department_id = p_department_id
      AND i.result IN ('pass', 'rework_pass');

    IF v_inspection_count > 0 THEN
      SELECT COALESCE(
        public.jsonb_merge_sum_maps(
          ARRAY_AGG(
            CASE
              WHEN i.piece_ref IS NOT NULL AND position('-' IN i.piece_ref) > 0 THEN
                jsonb_build_object(split_part(i.piece_ref, '-', 1), 1)
              ELSE '{}'::jsonb
            END
          )
        ),
        '{}'::jsonb
      )
      INTO v_produced_by_size
      FROM public.inspections i
      WHERE i.factory_id = p_factory_id
        AND i.order_id = p_order_id
        AND i.colorway_id IS NOT DISTINCT FROM p_colorway_id
        AND i.department_id = p_department_id
        AND i.result IN ('pass', 'rework_pass');
    ELSE
      SELECT public.jsonb_merge_sum_maps(ARRAY_AGG(hs.qty_by_size))
      INTO v_produced_by_size
      FROM public.handover_slips hs
      WHERE hs.factory_id = p_factory_id
        AND hs.order_id = p_order_id
        AND hs.colorway_id IS NOT DISTINCT FROM p_colorway_id
        AND hs.from_department_id = p_department_id
        AND hs.qty_by_size <> '{}'::jsonb;
      IF v_produced_by_size = '{}'::jsonb AND v_cum_produced > 0 THEN
        v_produced_by_size := public.proportional_qty_by_size(v_cum_produced, v_planned);
      END IF;
    END IF;
  END IF;

  v_remaining := GREATEST(v_planned_total - GREATEST(v_cum_produced, v_cum_sent), 0);

  RETURN jsonb_build_object(
    'cumulative_produced', v_cum_produced,
    'today_produced', v_today_produced,
    'today_target', v_today_target,
    'cumulative_sent', v_cum_sent,
    'today_sent', v_today_sent,
    'available_to_send', GREATEST(v_cum_produced - v_cum_sent, 0),
    'planned_qty_by_size', v_planned,
    'produced_qty_by_size', COALESCE(v_produced_by_size, '{}'::jsonb),
    'sent_qty_by_size', COALESCE(v_sent_by_size, '{}'::jsonb),
    'remaining_qty', v_remaining
  );
END;
$$;

COMMENT ON FUNCTION public.get_order_dept_progress(uuid, uuid, uuid, uuid, date) IS
  'Dept progress for order/colorway. QC depts: passed inspections = produced. Cutting: hourly counts. Others: handover fallback.';
