-- Atomic save for line_allocations across one or more colorways on an order.

CREATE OR REPLACE FUNCTION public.save_line_plan(
  p_factory_id uuid,
  p_order_id uuid,
  p_colorway_plans jsonb
)
RETURNS void
LANGUAGE plpgsql
SECURITY INVOKER
SET search_path = public
AS $$
DECLARE
  v_plan jsonb;
  v_colorway_id uuid;
  v_alloc jsonb;
  v_alloc_id uuid;
  v_keep_ids uuid[] := ARRAY[]::uuid[];
BEGIN
  IF p_factory_id IS NULL OR p_order_id IS NULL THEN
    RAISE EXCEPTION 'factory_id and order_id are required';
  END IF;

  IF p_factory_id IS DISTINCT FROM public.current_factory_id() THEN
    RAISE EXCEPTION 'Factory mismatch';
  END IF;

  IF NOT public.is_factory_admin() THEN
    RAISE EXCEPTION 'Not authorized to save planning';
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM public.style_orders
    WHERE id = p_order_id AND factory_id = p_factory_id
  ) THEN
    RAISE EXCEPTION 'Order not found';
  END IF;

  IF p_colorway_plans IS NULL OR jsonb_typeof(p_colorway_plans) <> 'array' THEN
    RAISE EXCEPTION 'colorway_plans must be a JSON array';
  END IF;

  FOR v_plan IN SELECT value FROM jsonb_array_elements(p_colorway_plans)
  LOOP
    v_colorway_id := NULLIF(trim(v_plan->>'colorway_id'), '')::uuid;
    IF v_colorway_id IS NULL THEN
      RAISE EXCEPTION 'Each plan entry requires colorway_id';
    END IF;

    IF NOT EXISTS (
      SELECT 1 FROM public.colorways c
      WHERE c.id = v_colorway_id AND c.order_id = p_order_id
    ) THEN
      RAISE EXCEPTION 'Colorway % does not belong to order', v_colorway_id;
    END IF;

    v_keep_ids := ARRAY[]::uuid[];

    IF v_plan ? 'allocations' AND jsonb_typeof(v_plan->'allocations') = 'array' THEN
      FOR v_alloc IN SELECT value FROM jsonb_array_elements(v_plan->'allocations')
      LOOP
        v_alloc_id := NULLIF(trim(v_alloc->>'id'), '')::uuid;
        IF v_alloc_id IS NULL THEN
          v_alloc_id := gen_random_uuid();
        END IF;

        INSERT INTO public.line_allocations (
          id,
          factory_id,
          order_id,
          colorway_id,
          line_id,
          department_id,
          style_name,
          po_number,
          colorway,
          qty,
          daily_target,
          hourly_target,
          start_date,
          end_date,
          completed_is_true,
          sam,
          kpi_inputs,
          status
        ) VALUES (
          v_alloc_id,
          p_factory_id,
          p_order_id,
          v_colorway_id,
          NULLIF(v_alloc->>'line_id', '')::uuid,
          NULLIF(v_alloc->>'department_id', '')::uuid,
          NULLIF(v_alloc->>'style_name', ''),
          NULLIF(v_alloc->>'po_number', ''),
          NULLIF(v_alloc->>'colorway', ''),
          COALESCE((v_alloc->>'qty')::integer, 0),
          COALESCE((v_alloc->>'daily_target')::integer, 0),
          NULLIF(v_alloc->>'hourly_target', '')::numeric,
          NULLIF(v_alloc->>'start_date', '')::date,
          NULLIF(v_alloc->>'end_date', '')::date,
          COALESCE((v_alloc->>'completed_is_true')::boolean, false),
          NULLIF(v_alloc->>'sam', '')::numeric,
          v_alloc->'kpi_inputs',
          COALESCE(NULLIF(v_alloc->>'status', ''), 'planned')
        )
        ON CONFLICT (id) DO UPDATE SET
          line_id = EXCLUDED.line_id,
          department_id = EXCLUDED.department_id,
          style_name = EXCLUDED.style_name,
          po_number = EXCLUDED.po_number,
          colorway = EXCLUDED.colorway,
          qty = EXCLUDED.qty,
          daily_target = EXCLUDED.daily_target,
          hourly_target = EXCLUDED.hourly_target,
          start_date = EXCLUDED.start_date,
          end_date = EXCLUDED.end_date,
          completed_is_true = EXCLUDED.completed_is_true,
          sam = EXCLUDED.sam,
          kpi_inputs = EXCLUDED.kpi_inputs,
          status = EXCLUDED.status,
          updated_at = now();

        v_keep_ids := array_append(v_keep_ids, v_alloc_id);
      END LOOP;
    END IF;

    DELETE FROM public.line_allocations la
    WHERE la.factory_id = p_factory_id
      AND la.order_id = p_order_id
      AND la.colorway_id = v_colorway_id
      AND (
        cardinality(v_keep_ids) = 0
        OR NOT (la.id = ANY (v_keep_ids))
      );
  END LOOP;
END;
$$;

COMMENT ON FUNCTION public.save_line_plan(uuid, uuid, jsonb) IS
  'Factory admin: upsert line_allocations for dirty colorways in one transaction. Rolls back on any error.';

REVOKE ALL ON FUNCTION public.save_line_plan(uuid, uuid, jsonb) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.save_line_plan(uuid, uuid, jsonb) TO authenticated;
