-- Planned SAM per line allocation (authoritative for KPIs; order.sewing_sam is reference only).

ALTER TABLE public.line_allocations
  ADD COLUMN IF NOT EXISTS sam numeric(8,2);

COMMENT ON COLUMN public.line_allocations.sam IS
  'Planned SAM (minutes/piece) for this colorway × department × resource row. Used for efficiency and produced-minutes KPIs.';

-- Backfill from legacy kpi_inputs JSON.
UPDATE public.line_allocations
SET sam = (kpi_inputs->>'sam')::numeric
WHERE sam IS NULL
  AND kpi_inputs IS NOT NULL
  AND kpi_inputs ? 'sam'
  AND (kpi_inputs->>'sam') ~ '^[0-9]+(\.[0-9]+)?$'
  AND (kpi_inputs->>'sam')::numeric > 0;

COMMENT ON COLUMN public.style_orders.sewing_sam IS
  'Reference sewing SAM (minutes/pc) from buyer/OB — not used for floor KPIs; planning uses line_allocations.sam.';
