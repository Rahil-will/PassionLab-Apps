-- Order-level SAM becomes sewing reference only; planning SAM lives in line_allocations.kpi_inputs.
-- Priority for merchandising / planning triage.

ALTER TABLE public.style_orders
  RENAME COLUMN sam TO sewing_sam;

COMMENT ON COLUMN public.style_orders.sewing_sam IS
  'Reference sewing SAM (minutes/pc) from buyer/OB — not used for floor KPIs; planning uses line_allocations.kpi_inputs.sam.';

ALTER TABLE public.style_orders
  ADD COLUMN IF NOT EXISTS priority text NOT NULL DEFAULT 'normal';

ALTER TABLE public.style_orders
  DROP CONSTRAINT IF EXISTS style_orders_priority_check;

ALTER TABLE public.style_orders
  ADD CONSTRAINT style_orders_priority_check
  CHECK (priority IN ('critical', 'high', 'normal'));

COMMENT ON COLUMN public.style_orders.priority IS
  'Order urgency: critical | high | normal — set at order creation.';
