-- Atomic create/update for style_orders + colorways (single transaction).

CREATE OR REPLACE FUNCTION public.save_style_order(
  p_factory_id uuid,
  p_order jsonb,
  p_colorways jsonb DEFAULT '[]'::jsonb
)
RETURNS uuid
LANGUAGE plpgsql
SECURITY INVOKER
SET search_path = public
AS $$
DECLARE
  v_order_id uuid;
  v_cw jsonb;
  v_cw_id uuid;
  v_keep_ids uuid[] := ARRAY[]::uuid[];
  v_is_update boolean;
BEGIN
  IF p_factory_id IS NULL THEN
    RAISE EXCEPTION 'factory_id is required';
  END IF;

  IF p_factory_id IS DISTINCT FROM public.current_factory_id() THEN
    RAISE EXCEPTION 'Factory mismatch';
  END IF;

  IF NOT public.is_factory_admin() THEN
    RAISE EXCEPTION 'Not authorized to save orders';
  END IF;

  IF p_order IS NULL OR p_order = '{}'::jsonb THEN
    RAISE EXCEPTION 'order payload is required';
  END IF;

  v_order_id := NULLIF(trim(p_order->>'id'), '')::uuid;

  v_is_update := v_order_id IS NOT NULL AND EXISTS (
    SELECT 1 FROM public.style_orders
    WHERE id = v_order_id AND factory_id = p_factory_id
  );

  IF v_is_update THEN
    UPDATE public.style_orders SET
      style_name = NULLIF(p_order->>'style_name', ''),
      style_ref = NULLIF(p_order->>'style_ref', ''),
      buyer_id = NULLIF(p_order->>'buyer_id', '')::uuid,
      buyer_name = NULLIF(p_order->>'buyer_name', ''),
      po_number = COALESCE(NULLIF(p_order->>'po_number', ''), po_number),
      order_qty = COALESCE((p_order->>'order_qty')::integer, 0),
      adj_qty = COALESCE((p_order->>'adj_qty')::integer, 0),
      delivery_date = NULLIF(p_order->>'delivery_date', '')::date,
      order_date = NULLIF(p_order->>'order_date', '')::date,
      job_card_date = NULLIF(p_order->>'job_card_date', '')::date,
      garment_type = NULLIF(p_order->>'garment_type', ''),
      sewing_sam = NULLIF(p_order->>'sewing_sam', '')::numeric,
      priority = COALESCE(NULLIF(p_order->>'priority', ''), priority),
      wash_type = NULLIF(p_order->>'wash_type', ''),
      size_group_name = NULLIF(p_order->>'size_group_name', ''),
      size_labels = NULLIF(p_order->>'size_labels', ''),
      process_flow_id = NULLIF(p_order->>'process_flow_id', '')::uuid,
      current_dept = COALESCE(NULLIF(p_order->>'current_dept', ''), current_dept),
      status = COALESCE(NULLIF(p_order->>'status', ''), status),
      image_url = NULLIF(p_order->>'image_url', ''),
      cutting_allowance = COALESCE((p_order->>'cutting_allowance')::numeric, cutting_allowance),
      shipment_allowance = COALESCE((p_order->>'shipment_allowance')::numeric, shipment_allowance),
      progress = COALESCE(p_order->'progress', progress),
      remarks = NULLIF(p_order->>'remarks', ''),
      updated_at = now()
    WHERE id = v_order_id
      AND factory_id = p_factory_id;

    IF NOT FOUND THEN
      RAISE EXCEPTION 'Order not found';
    END IF;
  ELSE
    v_order_id := COALESCE(v_order_id, gen_random_uuid());

    INSERT INTO public.style_orders (
      id,
      factory_id,
      style_name,
      style_ref,
      buyer_id,
      buyer_name,
      po_number,
      order_qty,
      adj_qty,
      delivery_date,
      order_date,
      job_card_date,
      garment_type,
      sewing_sam,
      priority,
      wash_type,
      size_group_name,
      size_labels,
      process_flow_id,
      current_dept,
      status,
      image_url,
      cutting_allowance,
      shipment_allowance,
      progress,
      remarks
    ) VALUES (
      v_order_id,
      p_factory_id,
      NULLIF(p_order->>'style_name', ''),
      NULLIF(p_order->>'style_ref', ''),
      NULLIF(p_order->>'buyer_id', '')::uuid,
      NULLIF(p_order->>'buyer_name', ''),
      COALESCE(NULLIF(p_order->>'po_number', ''), ''),
      COALESCE((p_order->>'order_qty')::integer, 0),
      COALESCE((p_order->>'adj_qty')::integer, 0),
      NULLIF(p_order->>'delivery_date', '')::date,
      NULLIF(p_order->>'order_date', '')::date,
      NULLIF(p_order->>'job_card_date', '')::date,
      NULLIF(p_order->>'garment_type', ''),
      NULLIF(p_order->>'sewing_sam', '')::numeric,
      COALESCE(NULLIF(p_order->>'priority', ''), 'normal'),
      NULLIF(p_order->>'wash_type', ''),
      NULLIF(p_order->>'size_group_name', ''),
      NULLIF(p_order->>'size_labels', ''),
      NULLIF(p_order->>'process_flow_id', '')::uuid,
      COALESCE(NULLIF(p_order->>'current_dept', ''), 'Planned'),
      COALESCE(NULLIF(p_order->>'status', ''), 'Not Started'),
      NULLIF(p_order->>'image_url', ''),
      COALESCE((p_order->>'cutting_allowance')::numeric, 2),
      COALESCE((p_order->>'shipment_allowance')::numeric, 0),
      COALESCE(p_order->'progress', '{}'::jsonb),
      NULLIF(p_order->>'remarks', '')
    );
  END IF;

  IF p_colorways IS NOT NULL AND jsonb_typeof(p_colorways) = 'array' THEN
    FOR v_cw IN SELECT value FROM jsonb_array_elements(p_colorways)
    LOOP
      v_cw_id := NULLIF(trim(v_cw->>'id'), '')::uuid;
      IF v_cw_id IS NULL THEN
        v_cw_id := gen_random_uuid();
      END IF;

      INSERT INTO public.colorways (
        id,
        order_id,
        name,
        color_code,
        qty,
        adj_qty,
        sizes,
        planning_remarks
      ) VALUES (
        v_cw_id,
        v_order_id,
        COALESCE(NULLIF(trim(v_cw->>'name'), ''), 'Unnamed'),
        COALESCE(v_cw->>'color_code', ''),
        COALESCE((v_cw->>'qty')::integer, 0),
        COALESCE((v_cw->>'adj_qty')::integer, 0),
        COALESCE(v_cw->'sizes', '[]'::jsonb),
        NULLIF(v_cw->>'planning_remarks', '')
      )
      ON CONFLICT (id) DO UPDATE SET
        name = EXCLUDED.name,
        color_code = EXCLUDED.color_code,
        qty = EXCLUDED.qty,
        adj_qty = EXCLUDED.adj_qty,
        sizes = EXCLUDED.sizes,
        planning_remarks = EXCLUDED.planning_remarks,
        updated_at = now();

      v_keep_ids := array_append(v_keep_ids, v_cw_id);
    END LOOP;

    IF cardinality(v_keep_ids) > 0 THEN
      DELETE FROM public.colorways cw
      WHERE cw.order_id = v_order_id
        AND NOT (cw.id = ANY (v_keep_ids));
    END IF;
  END IF;

  RETURN v_order_id;
END;
$$;

COMMENT ON FUNCTION public.save_style_order(uuid, jsonb, jsonb) IS
  'Factory admin: insert or update style_order and colorways in one transaction. Rolls back entirely on any error.';

REVOKE ALL ON FUNCTION public.save_style_order(uuid, jsonb, jsonb) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.save_style_order(uuid, jsonb, jsonb) TO authenticated;
