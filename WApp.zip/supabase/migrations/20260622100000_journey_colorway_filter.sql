-- Add optional colorway filter to get_cut_to_ship_journey for Style Report Section 1.

DROP FUNCTION IF EXISTS public.get_cut_to_ship_journey(uuid, uuid);

CREATE OR REPLACE FUNCTION public.get_cut_to_ship_journey(
  p_factory_id uuid,
  p_order_id uuid,
  p_colorway_id uuid DEFAULT NULL
)
RETURNS SETOF public.v_cut_to_ship_dept_journey
LANGUAGE sql
STABLE
SECURITY INVOKER
SET search_path = public
AS $$
  SELECT *
  FROM public.v_cut_to_ship_dept_journey
  WHERE factory_id = p_factory_id
    AND order_id = p_order_id
    AND (p_colorway_id IS NULL OR colorway_id = p_colorway_id)
  ORDER BY colorway_id NULLS LAST, flow_step NULLS LAST, dept_name;
$$;

COMMENT ON FUNCTION public.get_cut_to_ship_journey(uuid, uuid, uuid) IS
  'Department journey rows for one order; optional colorway filter for Style Report.';

REVOKE ALL ON FUNCTION public.get_cut_to_ship_journey(uuid, uuid, uuid) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.get_cut_to_ship_journey(uuid, uuid, uuid) TO authenticated;
REVOKE EXECUTE ON FUNCTION public.get_cut_to_ship_journey(uuid, uuid, uuid) FROM anon;
