import {
  assertFactoryAdmin,
  corsHeaders,
  getServiceClient,
  jsonResponse,
  validateCreateUserBody,
  type UserMutationBody,
} from '../_shared/adminUser.ts';

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }
  if (req.method !== 'POST') {
    return jsonResponse({ error: 'Method not allowed' }, 405);
  }

  try {
    const body = (await req.json()) as UserMutationBody;
    const {
      factoryId,
      fullName = '',
      email = '',
      floorPin = '',
      departmentId = null,
      assignedApps = [],
      status = 'Active',
      userRole = 'operator',
    } = body;

    const validationError = validateCreateUserBody(body);
    if (validationError) {
      return jsonResponse({ error: validationError }, 400);
    }

    const auth = await assertFactoryAdmin(req.headers.get('authorization'), factoryId);
    if ('error' in auth) {
      return jsonResponse({ error: auth.error }, auth.status);
    }

    const admin = getServiceClient();
    const password = crypto.randomUUID();

    const { data: authData, error: authError } = await admin.auth.admin.createUser({
      email: email.trim().toLowerCase(),
      password,
      email_confirm: true,
      user_metadata: { full_name: fullName.trim() },
    });

    if (authError) {
      const msg = authError.message.includes('already been registered')
        ? 'A user with this email already exists'
        : authError.message;
      return jsonResponse({ error: msg }, 400);
    }

    const userId = authData.user?.id;
    if (!userId) {
      return jsonResponse({ error: 'Auth user not created' }, 500);
    }

    const { error: profileError } = await admin.from('profiles').insert({
      id: userId,
      factory_id: factoryId,
      full_name: fullName.trim(),
      email: email.trim().toLowerCase(),
      user_role: userRole,
      department_id: departmentId || null,
      employee_id: null,
      floor_pin: floorPin || null,
      assigned_apps: assignedApps,
      status,
    });

    if (profileError) {
      await admin.auth.admin.deleteUser(userId);
      return jsonResponse({ error: profileError.message }, 400);
    }

    return jsonResponse({ id: userId }, 201);
  } catch (e) {
    console.error('admin-create-user', e);
    const message = e instanceof Error ? e.message : 'Failed to create user';
    const status = message.includes('service credentials') ? 503 : 500;
    return jsonResponse({ error: message }, status);
  }
});
