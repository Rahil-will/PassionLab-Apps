-- =============================================================================
-- PRODIGI MES — complete database schema (fresh Supabase project)
-- Run in SQL Editor on a new project, then point .env.local at that project.
-- =============================================================================

CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- -----------------------------------------------------------------------------
-- Helpers
-- -----------------------------------------------------------------------------

CREATE OR REPLACE FUNCTION public.set_updated_at()
RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

-- -----------------------------------------------------------------------------
-- Tenancy & auth
-- -----------------------------------------------------------------------------

CREATE TABLE public.factories (
  id                uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name              text NOT NULL,
  code              text NOT NULL UNIQUE,
  country           text NOT NULL DEFAULT '',
  transaction_apps  jsonb NOT NULL DEFAULT '["transaction"]'::jsonb,
  production_apps   jsonb NOT NULL DEFAULT '["hourly","qc_log"]'::jsonb,
  workforce_apps    jsonb NOT NULL DEFAULT '["workforce_log","attendance"]'::jsonb,
  audit_apps        jsonb NOT NULL DEFAULT '["audit"]'::jsonb,
  shipment_apps     jsonb NOT NULL DEFAULT '["shipment_log","final_rejection_log"]'::jsonb,
  created_at        timestamptz NOT NULL DEFAULT now(),
  updated_at        timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE public.profiles (
  id              uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  factory_id      uuid NOT NULL REFERENCES public.factories(id) ON DELETE CASCADE,
  full_name       text,
  email           text,
  user_role       text NOT NULL DEFAULT 'operator'
    CHECK (user_role IN ('superadmin', 'admin', 'quality_manager', 'supervisor', 'auditor', 'operator')),
  department_id   uuid,
  employee_id     text,
  floor_pin       text,
  assigned_apps   jsonb NOT NULL DEFAULT '[]'::jsonb,
  status          text NOT NULL DEFAULT 'Active' CHECK (status IN ('Active', 'Inactive')),
  created_at      timestamptz NOT NULL DEFAULT now(),
  updated_at      timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX profiles_factory_id_idx ON public.profiles(factory_id);

CREATE UNIQUE INDEX profiles_factory_employee_unique
  ON public.profiles(factory_id, employee_id)
  WHERE employee_id IS NOT NULL AND trim(employee_id) <> '';

-- -----------------------------------------------------------------------------
-- Settings masters
-- -----------------------------------------------------------------------------

CREATE TABLE public.buyers (
  id                  uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  factory_id          uuid NOT NULL REFERENCES public.factories(id) ON DELETE CASCADE,
  name                text NOT NULL,
  code                text,
  country             text,
  type                text,
  status              text DEFAULT 'Active',
  contact_name        text,
  contact_email       text,
  contact_role        text,
  over_shipment_pct   numeric(5,2) DEFAULT 0,
  under_shipment_pct  numeric(5,2) DEFAULT 0,
  packing_rule        text,
  created_at          timestamptz NOT NULL DEFAULT now(),
  updated_at          timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE public.departments (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  factory_id    uuid NOT NULL REFERENCES public.factories(id) ON DELETE CASCADE,
  name          text NOT NULL,
  sequence      integer NOT NULL DEFAULT 0,
  apps          jsonb NOT NULL DEFAULT '["transaction"]'::jsonb,
  is_outsourced boolean NOT NULL DEFAULT false,
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE public.shifts (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  factory_id   uuid NOT NULL REFERENCES public.factories(id) ON DELETE CASCADE,
  name         text NOT NULL,
  type         text NOT NULL DEFAULT 'Regular',
  start_time   time,
  end_time     time,
  break_start  time,
  break_end    time,
  hours        jsonb NOT NULL DEFAULT '[]'::jsonb,
  created_at   timestamptz NOT NULL DEFAULT now(),
  updated_at   timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE public.process_flows (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  factory_id      uuid NOT NULL REFERENCES public.factories(id) ON DELETE CASCADE,
  name            text NOT NULL,
  base_name       text,
  description     text,
  version         integer NOT NULL DEFAULT 1,
  is_current      boolean NOT NULL DEFAULT true,
  parent_flow_id  uuid REFERENCES public.process_flows(id) ON DELETE SET NULL,
  created_at      timestamptz NOT NULL DEFAULT now(),
  updated_at      timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE public.process_flow_steps (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  flow_id       uuid NOT NULL REFERENCES public.process_flows(id) ON DELETE CASCADE,
  department_id uuid REFERENCES public.departments(id) ON DELETE SET NULL,
  dept_name     text NOT NULL,
  flow_step     integer NOT NULL,
  created_at    timestamptz NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX process_flow_steps_flow_step_uidx
  ON public.process_flow_steps(flow_id, flow_step);

CREATE TABLE public.size_groups (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  factory_id  uuid NOT NULL REFERENCES public.factories(id) ON DELETE CASCADE,
  buyer_id    uuid REFERENCES public.buyers(id) ON DELETE SET NULL,
  name        text NOT NULL,
  sizes       jsonb NOT NULL DEFAULT '[]'::jsonb,
  created_at  timestamptz NOT NULL DEFAULT now(),
  updated_at  timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE public.support_dropdowns (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  factory_id  uuid NOT NULL REFERENCES public.factories(id) ON DELETE CASCADE,
  category    text NOT NULL,
  app_name    text,
  values      jsonb NOT NULL DEFAULT '[]'::jsonb,
  created_at  timestamptz NOT NULL DEFAULT now(),
  updated_at  timestamptz NOT NULL DEFAULT now(),
  UNIQUE (factory_id, category)
);

CREATE TABLE public.workers (
  id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  factory_id       uuid NOT NULL REFERENCES public.factories(id) ON DELETE CASCADE,
  department_id    uuid NOT NULL REFERENCES public.departments(id) ON DELETE CASCADE,
  worker_id        text NOT NULL,
  name             text NOT NULL,
  role             text NOT NULL DEFAULT '',
  is_active        boolean NOT NULL DEFAULT true,
  date_of_joining  date,
  date_of_leaving  date,
  created_at       timestamptz NOT NULL DEFAULT now(),
  updated_at       timestamptz NOT NULL DEFAULT now(),
  UNIQUE (factory_id, worker_id)
);

-- Production lines / outsourced units (settings + planning resources)
CREATE TABLE public.assigned_resources (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  factory_id      uuid NOT NULL REFERENCES public.factories(id) ON DELETE CASCADE,
  department_id   uuid REFERENCES public.departments(id) ON DELETE CASCADE,
  resource_name   text NOT NULL,
  resource_type   text NOT NULL DEFAULT 'inhouse',
  capacity        integer NOT NULL DEFAULT 0,
  status          text NOT NULL DEFAULT 'active',
  created_at      timestamptz NOT NULL DEFAULT now(),
  updated_at      timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX assigned_resources_factory_dept_idx
  ON public.assigned_resources(factory_id, department_id);

-- -----------------------------------------------------------------------------
-- Production orders
-- -----------------------------------------------------------------------------

CREATE TABLE public.style_orders (
  id                   uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  factory_id           uuid NOT NULL REFERENCES public.factories(id) ON DELETE CASCADE,
  style_name           text,
  style_ref            text,
  buyer_id             uuid REFERENCES public.buyers(id) ON DELETE SET NULL,
  buyer_name           text,
  po_number            text NOT NULL DEFAULT '',
  order_qty            integer NOT NULL DEFAULT 0,
  adj_qty              integer NOT NULL DEFAULT 0,
  delivery_date        date,
  order_date           date,
  job_card_date        date,
  garment_type         text,
  sam                  numeric(8,2) DEFAULT 0,
  wash_type            text,
  size_group_id        uuid REFERENCES public.size_groups(id) ON DELETE SET NULL,
  process_flow_id      uuid REFERENCES public.process_flows(id) ON DELETE SET NULL,
  current_dept         text NOT NULL DEFAULT 'Planned',
  status               text NOT NULL DEFAULT 'Not Started',
  image_url            text,
  cutting_allowance    numeric(5,2) DEFAULT 2,
  shipment_allowance   numeric(5,2) DEFAULT 0,
  progress             jsonb NOT NULL DEFAULT '{}'::jsonb,
  remarks              text,
  created_at           timestamptz NOT NULL DEFAULT now(),
  updated_at           timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX style_orders_factory_id_idx ON public.style_orders(factory_id);

CREATE TABLE public.colorways (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id    uuid NOT NULL REFERENCES public.style_orders(id) ON DELETE CASCADE,
  name        text NOT NULL,
  color_code  text DEFAULT '',
  qty         integer NOT NULL DEFAULT 0,
  adj_qty     integer NOT NULL DEFAULT 0,
  sizes       jsonb NOT NULL DEFAULT '[]'::jsonb,
  created_at  timestamptz NOT NULL DEFAULT now(),
  updated_at  timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX colorways_order_id_idx ON public.colorways(order_id);

-- Planning allocations (one row per colorway × department × resource)
CREATE TABLE public.line_allocations (
  id                  uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  factory_id          uuid NOT NULL REFERENCES public.factories(id) ON DELETE CASCADE,
  order_id            uuid NOT NULL,
  colorway_id         uuid REFERENCES public.colorways(id) ON DELETE CASCADE,
  line_id             uuid REFERENCES public.assigned_resources(id) ON DELETE SET NULL,
  department_id       uuid REFERENCES public.departments(id) ON DELETE SET NULL,
  style_name          text,
  po_number           text,
  colorway            text,
  qty                 integer NOT NULL DEFAULT 0,
  daily_target        integer NOT NULL DEFAULT 0,
  hourly_target       numeric(10,2),
  start_date          date,
  end_date            date,
  completed_is_true   boolean NOT NULL DEFAULT false,
  kpi_inputs          jsonb,
  planned_qty         integer,
  actual_qty          integer DEFAULT 0,
  efficiency          numeric(6,2),
  status              text NOT NULL DEFAULT 'planned',
  created_at          timestamptz NOT NULL DEFAULT now(),
  updated_at          timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX line_allocations_factory_order_idx
  ON public.line_allocations(factory_id, order_id);

-- Deferred FK: profiles.department_id
ALTER TABLE public.profiles
  ADD CONSTRAINT profiles_department_id_fkey
  FOREIGN KEY (department_id) REFERENCES public.departments(id) ON DELETE SET NULL;

-- RLS helpers (SECURITY DEFINER — avoids infinite recursion when policies read profiles)
CREATE OR REPLACE FUNCTION public.current_factory_id()
RETURNS uuid
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT p.factory_id
  FROM public.profiles p
  WHERE p.id = auth.uid()
$$;

CREATE OR REPLACE FUNCTION public.is_factory_admin()
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.profiles p
    WHERE p.id = auth.uid() AND p.user_role IN ('admin', 'superadmin')
  )
$$;

CREATE OR REPLACE FUNCTION public.get_my_profile()
RETURNS jsonb
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT to_jsonb(p)
  FROM public.profiles p
  WHERE p.id = auth.uid()
  LIMIT 1
$$;

REVOKE ALL ON FUNCTION public.current_factory_id() FROM PUBLIC;
REVOKE ALL ON FUNCTION public.is_factory_admin() FROM PUBLIC;
REVOKE ALL ON FUNCTION public.get_my_profile() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.current_factory_id() TO authenticated;
GRANT EXECUTE ON FUNCTION public.is_factory_admin() TO authenticated;
GRANT EXECUTE ON FUNCTION public.get_my_profile() TO authenticated;

-- -----------------------------------------------------------------------------
-- updated_at triggers
-- -----------------------------------------------------------------------------

CREATE TRIGGER factories_set_updated_at
  BEFORE UPDATE ON public.factories
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

CREATE TRIGGER profiles_set_updated_at
  BEFORE UPDATE ON public.profiles
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

CREATE TRIGGER buyers_set_updated_at
  BEFORE UPDATE ON public.buyers
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

CREATE TRIGGER departments_set_updated_at
  BEFORE UPDATE ON public.departments
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

CREATE TRIGGER shifts_set_updated_at
  BEFORE UPDATE ON public.shifts
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

CREATE TRIGGER process_flows_set_updated_at
  BEFORE UPDATE ON public.process_flows
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

CREATE TRIGGER size_groups_set_updated_at
  BEFORE UPDATE ON public.size_groups
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

CREATE TRIGGER support_dropdowns_set_updated_at
  BEFORE UPDATE ON public.support_dropdowns
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

CREATE TRIGGER workers_set_updated_at
  BEFORE UPDATE ON public.workers
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

CREATE TRIGGER assigned_resources_set_updated_at
  BEFORE UPDATE ON public.assigned_resources
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

CREATE TRIGGER style_orders_set_updated_at
  BEFORE UPDATE ON public.style_orders
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

CREATE TRIGGER colorways_set_updated_at
  BEFORE UPDATE ON public.colorways
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

CREATE TRIGGER line_allocations_set_updated_at
  BEFORE UPDATE ON public.line_allocations
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- -----------------------------------------------------------------------------
-- Row Level Security
-- -----------------------------------------------------------------------------

ALTER TABLE public.factories ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.buyers ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.departments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.shifts ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.process_flows ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.process_flow_steps ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.size_groups ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.support_dropdowns ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.workers ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.assigned_resources ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.style_orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.colorways ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.line_allocations ENABLE ROW LEVEL SECURITY;
-- factories: readable for floor factory-ID lookup; creation is RBC-only (see docs/FACTORY_ONBOARDING.md)
CREATE POLICY factories_select ON public.factories
  FOR SELECT TO anon, authenticated USING (true);

-- Client apps cannot create factories — use Supabase SQL Editor / service role
CREATE POLICY factories_insert ON public.factories
  FOR INSERT TO authenticated
  WITH CHECK (false);

-- profiles
CREATE POLICY profiles_select_own ON public.profiles
  FOR SELECT TO authenticated USING (id = auth.uid());

CREATE POLICY profiles_select_factory ON public.profiles
  FOR SELECT TO authenticated
  USING (factory_id = public.current_factory_id());

CREATE POLICY profiles_insert_own ON public.profiles
  FOR INSERT TO authenticated WITH CHECK (id = auth.uid());

CREATE POLICY profiles_insert_factory_admin ON public.profiles
  FOR INSERT TO authenticated
  WITH CHECK (
    factory_id = public.current_factory_id()
    AND public.is_factory_admin()
  );

CREATE POLICY profiles_update_factory ON public.profiles
  FOR UPDATE TO authenticated
  USING (factory_id = public.current_factory_id())
  WITH CHECK (factory_id = public.current_factory_id());

CREATE POLICY profiles_delete_factory_admin ON public.profiles
  FOR DELETE TO authenticated
  USING (
    factory_id = public.current_factory_id()
    AND id <> auth.uid()
    AND public.is_factory_admin()
  );

-- Factory-scoped tables (direct factory_id column)
DO $$
DECLARE
  t text;
  tables text[] := ARRAY[
    'buyers', 'departments', 'shifts', 'process_flows',
    'size_groups', 'support_dropdowns', 'workers', 'assigned_resources',
    'style_orders', 'line_allocations'
  ];
BEGIN
  FOREACH t IN ARRAY tables LOOP
    EXECUTE format('CREATE POLICY %I ON public.%I FOR SELECT TO authenticated USING (factory_id = public.current_factory_id())', t || '_select', t);
    EXECUTE format('CREATE POLICY %I ON public.%I FOR INSERT TO authenticated WITH CHECK (factory_id = public.current_factory_id())', t || '_insert', t);
    EXECUTE format('CREATE POLICY %I ON public.%I FOR UPDATE TO authenticated USING (factory_id = public.current_factory_id()) WITH CHECK (factory_id = public.current_factory_id())', t || '_update', t);
    EXECUTE format('CREATE POLICY %I ON public.%I FOR DELETE TO authenticated USING (factory_id = public.current_factory_id())', t || '_delete', t);
  END LOOP;
END $$;

-- colorways: scoped via parent order
CREATE POLICY colorways_select ON public.colorways
  FOR SELECT TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.style_orders o
      WHERE o.id = colorways.order_id AND o.factory_id = public.current_factory_id()
    )
  );

CREATE POLICY colorways_insert ON public.colorways
  FOR INSERT TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.style_orders o
      WHERE o.id = colorways.order_id AND o.factory_id = public.current_factory_id()
    )
  );

CREATE POLICY colorways_update ON public.colorways
  FOR UPDATE TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.style_orders o
      WHERE o.id = colorways.order_id AND o.factory_id = public.current_factory_id()
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.style_orders o
      WHERE o.id = colorways.order_id AND o.factory_id = public.current_factory_id()
    )
  );

CREATE POLICY colorways_delete ON public.colorways
  FOR DELETE TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.style_orders o
      WHERE o.id = colorways.order_id AND o.factory_id = public.current_factory_id()
    )
  );

-- process_flow_steps: scoped via parent flow
CREATE POLICY process_flow_steps_select ON public.process_flow_steps
  FOR SELECT TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.process_flows f
      WHERE f.id = process_flow_steps.flow_id AND f.factory_id = public.current_factory_id()
    )
  );

CREATE POLICY process_flow_steps_insert ON public.process_flow_steps
  FOR INSERT TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.process_flows f
      WHERE f.id = process_flow_steps.flow_id AND f.factory_id = public.current_factory_id()
    )
  );

CREATE POLICY process_flow_steps_update ON public.process_flow_steps
  FOR UPDATE TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.process_flows f
      WHERE f.id = process_flow_steps.flow_id AND f.factory_id = public.current_factory_id()
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.process_flows f
      WHERE f.id = process_flow_steps.flow_id AND f.factory_id = public.current_factory_id()
    )
  );

CREATE POLICY process_flow_steps_delete ON public.process_flow_steps
  FOR DELETE TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.process_flows f
      WHERE f.id = process_flow_steps.flow_id AND f.factory_id = public.current_factory_id()
    )
  );

-- -----------------------------------------------------------------------------
-- Floor capture (mobile plapps)
-- -----------------------------------------------------------------------------

CREATE TABLE public.hourly_counts (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  factory_id      uuid NOT NULL REFERENCES public.factories(id) ON DELETE CASCADE,
  order_id        uuid NOT NULL REFERENCES public.style_orders(id) ON DELETE CASCADE,
  colorway_id     uuid REFERENCES public.colorways(id) ON DELETE SET NULL,
  department_id   uuid NOT NULL REFERENCES public.departments(id) ON DELETE CASCADE,
  resource_id     uuid REFERENCES public.assigned_resources(id) ON DELETE SET NULL,
  shift_id        uuid REFERENCES public.shifts(id) ON DELETE SET NULL,
  hour_slot       text NOT NULL,
  log_date        date NOT NULL DEFAULT (CURRENT_DATE),
  count           integer NOT NULL DEFAULT 0,
  logged_by       uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  logged_at       timestamptz NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX hourly_counts_slot_unique
  ON public.hourly_counts (
    factory_id, order_id, department_id,
    COALESCE(colorway_id, '00000000-0000-0000-0000-000000000000'::uuid),
    hour_slot, log_date
  );

CREATE TABLE public.handover_slips (
  id                  uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  factory_id          uuid NOT NULL REFERENCES public.factories(id) ON DELETE CASCADE,
  order_id            uuid NOT NULL REFERENCES public.style_orders(id) ON DELETE CASCADE,
  from_department_id  uuid NOT NULL REFERENCES public.departments(id) ON DELETE CASCADE,
  to_department_id    uuid NOT NULL REFERENCES public.departments(id) ON DELETE CASCADE,
  sent_qty            integer NOT NULL DEFAULT 0,
  received_qty        integer,
  sent_by             uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  sent_at             timestamptz NOT NULL DEFAULT now(),
  received_by         uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  received_at         timestamptz,
  notes               text,
  status              text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'received')),
  challan_number      text
);

CREATE TABLE public.inspections (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  factory_id      uuid NOT NULL REFERENCES public.factories(id) ON DELETE CASCADE,
  order_id        uuid NOT NULL REFERENCES public.style_orders(id) ON DELETE CASCADE,
  department_id   uuid NOT NULL REFERENCES public.departments(id) ON DELETE CASCADE,
  piece_ref       text,
  result          text NOT NULL CHECK (result IN ('pass', 'fail', 'rework', 'rework_pass')),
  defects         jsonb NOT NULL DEFAULT '[]'::jsonb,
  logged_by       uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  logged_at       timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE public.audit_sessions (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  factory_id      uuid NOT NULL REFERENCES public.factories(id) ON DELETE CASCADE,
  order_id        uuid NOT NULL REFERENCES public.style_orders(id) ON DELETE CASCADE,
  department_id   uuid NOT NULL REFERENCES public.departments(id) ON DELETE CASCADE,
  lot_size        integer NOT NULL DEFAULT 0,
  sample_size       integer NOT NULL DEFAULT 0,
  aql_level       text,
  passed          integer NOT NULL DEFAULT 0,
  failed          integer NOT NULL DEFAULT 0,
  result          text CHECK (result IN ('pass', 'fail')),
  logged_by       uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  logged_at       timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE public.workforce_logs (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  factory_id      uuid NOT NULL REFERENCES public.factories(id) ON DELETE CASCADE,
  order_id        uuid REFERENCES public.style_orders(id) ON DELETE SET NULL,
  department_id   uuid NOT NULL REFERENCES public.departments(id) ON DELETE CASCADE,
  shift_id        uuid REFERENCES public.shifts(id) ON DELETE SET NULL,
  log_date        date NOT NULL DEFAULT CURRENT_DATE,
  operators       integer NOT NULL DEFAULT 0,
  helpers         integer NOT NULL DEFAULT 0,
  supervisors     integer NOT NULL DEFAULT 0,
  trainees        integer NOT NULL DEFAULT 0,
  logged_by       uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  logged_at       timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE public.attendance_records (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  factory_id      uuid NOT NULL REFERENCES public.factories(id) ON DELETE CASCADE,
  worker_id       uuid NOT NULL REFERENCES public.workers(id) ON DELETE CASCADE,
  department_id   uuid NOT NULL REFERENCES public.departments(id) ON DELETE CASCADE,
  shift_id        uuid REFERENCES public.shifts(id) ON DELETE SET NULL,
  record_date     date NOT NULL DEFAULT CURRENT_DATE,
  status          text NOT NULL DEFAULT 'present' CHECK (status IN ('present', 'absent', 'half_day', 'late')),
  logged_by       uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  logged_at       timestamptz NOT NULL DEFAULT now(),
  UNIQUE (worker_id, record_date, shift_id)
);

ALTER TABLE public.hourly_counts ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.handover_slips ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.inspections ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.audit_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.workforce_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.attendance_records ENABLE ROW LEVEL SECURITY;

DO $$
DECLARE
  t text;
  tables text[] := ARRAY[
    'hourly_counts', 'handover_slips', 'inspections',
    'audit_sessions', 'workforce_logs', 'attendance_records'
  ];
BEGIN
  FOREACH t IN ARRAY tables LOOP
    EXECUTE format('CREATE POLICY %I ON public.%I FOR SELECT TO authenticated USING (factory_id = public.current_factory_id())', t || '_select', t);
    EXECUTE format('CREATE POLICY %I ON public.%I FOR INSERT TO authenticated WITH CHECK (factory_id = public.current_factory_id())', t || '_insert', t);
    EXECUTE format('CREATE POLICY %I ON public.%I FOR UPDATE TO authenticated USING (factory_id = public.current_factory_id()) WITH CHECK (factory_id = public.current_factory_id())', t || '_update', t);
    EXECUTE format('CREATE POLICY %I ON public.%I FOR DELETE TO authenticated USING (factory_id = public.current_factory_id())', t || '_delete', t);
  END LOOP;
END $$;

-- Floor login RPCs (anon-safe: factory code + PIN, no service role on device)
CREATE OR REPLACE FUNCTION public.get_floor_users(p_factory_code text)
RETURNS TABLE (
  id uuid,
  full_name text,
  user_role text,
  department_id uuid,
  assigned_apps jsonb,
  employee_id text
)
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT p.id, p.full_name, p.user_role, p.department_id, p.assigned_apps, p.employee_id
  FROM public.profiles p
  JOIN public.factories f ON f.id = p.factory_id
  WHERE lower(f.code) = lower(trim(p_factory_code))
    AND p.status = 'Active'
    AND p.user_role IN ('operator', 'supervisor', 'auditor', 'quality_manager')
  ORDER BY p.full_name;
$$;

CREATE OR REPLACE FUNCTION public.verify_floor_pin(p_user_id uuid, p_pin text)
RETURNS jsonb
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_profile public.profiles%ROWTYPE;
BEGIN
  SELECT * INTO v_profile FROM public.profiles WHERE id = p_user_id AND status = 'Active';
  IF NOT FOUND OR v_profile.floor_pin IS NULL OR v_profile.floor_pin <> p_pin THEN
    RETURN NULL;
  END IF;
  RETURN jsonb_build_object(
    'id', v_profile.id,
    'full_name', v_profile.full_name,
    'user_role', v_profile.user_role,
    'department_id', v_profile.department_id,
    'assigned_apps', v_profile.assigned_apps,
    'factory_id', v_profile.factory_id,
    'employee_id', v_profile.employee_id
  );
END;
$$;

-- Single-step floor login: factory code + employee ID + PIN
CREATE OR REPLACE FUNCTION public.verify_floor_login(
  p_factory_code text,
  p_employee_id text,
  p_pin text
)
RETURNS jsonb
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_profile public.profiles%ROWTYPE;
BEGIN
  SELECT p.* INTO v_profile
  FROM public.profiles p
  JOIN public.factories f ON f.id = p.factory_id
  WHERE lower(f.code) = lower(trim(p_factory_code))
    AND lower(trim(p.employee_id)) = lower(trim(p_employee_id))
    AND p.status = 'Active'
    AND p.user_role IN ('operator', 'supervisor', 'auditor', 'quality_manager')
  LIMIT 1;

  IF NOT FOUND OR v_profile.floor_pin IS NULL OR v_profile.floor_pin <> trim(p_pin) THEN
    RETURN NULL;
  END IF;

  RETURN jsonb_build_object(
    'id', v_profile.id,
    'full_name', v_profile.full_name,
    'user_role', v_profile.user_role,
    'department_id', v_profile.department_id,
    'assigned_apps', v_profile.assigned_apps,
    'factory_id', v_profile.factory_id,
    'employee_id', v_profile.employee_id
  );
END;
$$;

-- Floor login by email + PIN (mobile app)
CREATE OR REPLACE FUNCTION public.verify_floor_login_by_email(
  p_email text,
  p_pin text
)
RETURNS jsonb
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_profile public.profiles%ROWTYPE;
BEGIN
  SELECT p.* INTO v_profile
  FROM public.profiles p
  WHERE lower(trim(p.email)) = lower(trim(p_email))
    AND p.status = 'Active'
    AND p.user_role IN ('operator', 'supervisor', 'auditor', 'quality_manager')
  LIMIT 1;

  IF NOT FOUND OR v_profile.floor_pin IS NULL OR v_profile.floor_pin <> trim(p_pin) THEN
    RETURN NULL;
  END IF;

  RETURN jsonb_build_object(
    'id', v_profile.id,
    'full_name', v_profile.full_name,
    'email', v_profile.email,
    'user_role', v_profile.user_role,
    'department_id', v_profile.department_id,
    'assigned_apps', v_profile.assigned_apps,
    'factory_id', v_profile.factory_id,
    'employee_id', v_profile.employee_id
  );
END;
$$;

REVOKE ALL ON FUNCTION public.get_floor_users(text) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.verify_floor_pin(uuid, text) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.verify_floor_login(text, text, text) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.verify_floor_login_by_email(text, text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.get_floor_users(text) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.verify_floor_pin(uuid, text) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.verify_floor_login(text, text, text) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.verify_floor_login_by_email(text, text) TO anon, authenticated;

-- -----------------------------------------------------------------------------
-- API grants (Supabase Data API)
-- -----------------------------------------------------------------------------

GRANT USAGE ON SCHEMA public TO anon, authenticated;
GRANT ALL ON ALL TABLES IN SCHEMA public TO authenticated;
GRANT SELECT ON ALL TABLES IN SCHEMA public TO anon;
GRANT ALL ON ALL SEQUENCES IN SCHEMA public TO authenticated;
