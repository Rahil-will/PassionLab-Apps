/**
 * Centralized font/style classes for PassionLab
 * 
 * Use these across ALL pages for consistency.
 * Max font: 14px (text-sm). Body: 11px. Labels: 10px. Captions: 9px.
 */

export const styles = {
  // Page-level
  pageTitle: 'text-sm font-bold text-slate-900',        // 14px - page headers only
  pageSubtitle: 'text-[10px] text-slate-500',           // 10px

  // Cards & Sections
  cardTitle: 'text-xs font-bold text-slate-800',        // 12px
  cardSubtitle: 'text-[9px] text-slate-400',            // 9px
  sectionHeader: 'text-[10px] font-bold text-slate-700 uppercase tracking-wider', // 10px

  // Form
  formLabel: 'text-[10px] font-medium text-slate-600',  // 10px
  formValue: 'text-[11px] text-slate-900',              // 11px
  formHint: 'text-[9px] text-slate-400',                // 9px

  // Tables
  tableHeader: 'text-[9px] font-bold text-slate-500 uppercase tracking-wider', // 9px
  tableCell: 'text-[10px] text-slate-700',              // 10px
  tableCellBold: 'text-[10px] font-bold text-slate-800', // 10px

  // KPI / Metrics
  metricValue: 'text-sm font-bold text-slate-900',      // 14px
  metricLabel: 'text-[10px] font-medium text-slate-500', // 10px
  metricSub: 'text-[9px] text-slate-400',               // 9px

  // Badges & Status
  badge: 'text-[8px] font-bold px-1.5 py-0.5 rounded-full', // 8px
  status: 'text-[9px] font-medium',                     // 9px

  // Body text
  body: 'text-[11px] text-slate-700',                   // 11px
  bodySmall: 'text-[10px] text-slate-600',              // 10px
  caption: 'text-[9px] text-slate-400',                 // 9px

  // Buttons
  btnText: 'text-[10px] font-bold',                     // 10px
} as const;
