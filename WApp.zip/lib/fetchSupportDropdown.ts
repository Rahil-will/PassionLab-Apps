import { supabase } from './supabase';
import { catalogDef } from './supportDropdownCatalog';

export async function fetchSupportDropdownValues(
  category: string,
  factoryId: string,
): Promise<string[]> {
  const def = catalogDef(category);
  const { data } = await supabase
    .from('support_dropdowns')
    .select('values')
    .eq('category', category)
    .eq('factory_id', factoryId)
    .maybeSingle();
  const fromDb = (data?.values as string[]) || [];
  if (fromDb.length) return fromDb;
  return def?.defaultValues ?? [];
}
