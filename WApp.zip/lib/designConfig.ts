// Global Design Configuration for PassionLab
// Refactored to use CSS custom properties from designTokens.ts
// This file provides backward compatibility for existing consumers.

import { tokens, applyScale, SCALE_PRESETS } from './designTokens';

// Re-export tokens for direct use
export { tokens, applyScale, SCALE_PRESETS } from './designTokens';

export const DesignConfig = {
  // Font Size Scale - now references CSS variables via Tailwind arbitrary values
  fontSize: {
    display: `text-[${tokens.fontSize.display}]`,
    h1: `text-[${tokens.fontSize.h1}]`,
    h2: `text-[${tokens.fontSize.h2}]`,
    h3: `text-[${tokens.fontSize.h3}]`,
    h4: `text-[${tokens.fontSize.h4}]`,
    body: `text-[${tokens.fontSize.body}]`,
    bodySmall: `text-[${tokens.fontSize.bodySmall}]`,
    caption: `text-[${tokens.fontSize.caption}]`,
    metric: `text-[${tokens.fontSize.metric}]`,
    metricSmall: `text-[${tokens.fontSize.metricSmall}]`,
  },

  // Font Weight
  fontWeight: {
    normal: 'font-normal',
    medium: 'font-medium',
    semibold: 'font-semibold',
    bold: 'font-bold',
  },

  // Spacing Scale
  spacing: {
    xs: 'gap-1',
    sm: 'gap-2',
    md: 'gap-4',
    lg: 'gap-6',
    xl: 'gap-8',
  },

  // Padding Scale
  padding: {
    xs: 'p-1',
    sm: 'p-2',
    md: 'p-4',
    lg: 'p-6',
  },

  // Colors (for reference, Tailwind classes)
  colors: {
    primary: 'text-blue-600',
    secondary: 'text-slate-600',
    success: 'text-emerald-600',
    warning: 'text-amber-600',
    danger: 'text-red-600',
    muted: 'text-slate-400',
  }
};

// Helper function to combine font classes
export const getFontClass = (
  size: keyof typeof DesignConfig.fontSize,
  weight: keyof typeof DesignConfig.fontWeight = 'normal',
  color?: keyof typeof DesignConfig.colors
): string => {
  const classes = [
    DesignConfig.fontSize[size],
    DesignConfig.fontWeight[weight],
  ];
  if (color) {
    classes.push(DesignConfig.colors[color]);
  }
  return classes.join(' ');
};

// Predefined common text patterns - now using CSS variable references
export const TextStyles = {
  pageTitle: `text-[${tokens.fontSize.display}] font-bold text-slate-900`,
  pageSubtitle: `text-[${tokens.fontSize.bodySmall}] text-slate-500`,
  cardTitle: `text-[${tokens.fontSize.h2}] font-bold text-slate-800`,
  cardSubtitle: `text-[${tokens.fontSize.caption}] text-slate-400 uppercase tracking-wider`,
  sectionHeader: `text-[${tokens.fontSize.h4}] font-semibold text-slate-700`,
  formLabel: `text-[${tokens.fontSize.bodySmall}] font-medium text-slate-700`,
  inputText: `text-[${tokens.fontSize.body}] text-slate-900`,
  tableHeader: `text-[${tokens.fontSize.caption}] font-semibold text-slate-500 uppercase tracking-wider`,
  tableCell: `text-[${tokens.fontSize.body}] text-slate-700`,
  kpiValue: `text-[${tokens.fontSize.metric}] font-bold text-slate-900`,
  kpiLabel: `text-[${tokens.fontSize.bodySmall}] font-medium text-slate-500`,
  button: `text-[${tokens.fontSize.bodySmall}] font-semibold`,
  badge: `text-[${tokens.fontSize.caption}] font-medium`,
  navItem: `text-[${tokens.fontSize.bodySmall}] font-medium`,
  modalTitle: `text-[${tokens.fontSize.h2}] font-bold text-slate-900`,
  status: `text-[${tokens.fontSize.caption}] font-medium`,
};
