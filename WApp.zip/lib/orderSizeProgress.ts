import { supabase } from './supabase';
import type { SizeMap } from './mesSizeDisplay';
import { sumSizeMap } from './mesSizeDisplay';

export interface OrderDeptProgress {
  cumulative_produced: number;
  today_produced: number;
  today_target: number;
  cumulative_sent: number;
  today_sent: number;
  available_to_send: number;
  planned_qty_by_size: SizeMap;
  produced_qty_by_size: SizeMap;
  sent_qty_by_size: SizeMap;
  remaining_qty: number;
}

export type ProductionProgressPhase = 'not_started' | 'in_progress' | 'complete';

export interface FlowStepRef {
  dept_id: string;
  dept_name: string;
}

export interface SizeProgressLookup {
  getSizeCount: (colorwayId: string | undefined, deptName: string, size: string) => number;
  getDeptTotal: (colorwayId: string | undefined, deptName: string) => number;
}

function mergeSizeMaps(target: SizeMap, source: SizeMap): void {
  for (const [size, qty] of Object.entries(source)) {
    target[size] = (target[size] || 0) + (Number(qty) || 0);
  }
}

function parseOrderDeptProgress(raw: unknown): OrderDeptProgress {
  const row = (raw || {}) as Record<string, unknown>;
  return {
    cumulative_produced: Number(row.cumulative_produced) || 0,
    today_produced: Number(row.today_produced) || 0,
    today_target: Number(row.today_target) || 0,
    cumulative_sent: Number(row.cumulative_sent) || 0,
    today_sent: Number(row.today_sent) || 0,
    available_to_send: Number(row.available_to_send) || 0,
    planned_qty_by_size: (row.planned_qty_by_size as SizeMap) || {},
    produced_qty_by_size: (row.produced_qty_by_size as SizeMap) || {},
    sent_qty_by_size: (row.sent_qty_by_size as SizeMap) || {},
    remaining_qty: Number(row.remaining_qty) || 0,
  };
}

export async function fetchOrderDeptProgress(
  factoryId: string,
  orderId: string,
  colorwayId: string,
  departmentId: string,
  date?: string,
): Promise<OrderDeptProgress> {
  const { data, error } = await supabase.rpc('get_order_dept_progress', {
    p_factory_id: factoryId,
    p_order_id: orderId,
    p_colorway_id: colorwayId,
    p_department_id: departmentId,
    p_date: date ?? new Date().toISOString().slice(0, 10),
  });
  if (error) throw error;
  return parseOrderDeptProgress(data);
}

export async function buildSizeProgressLookup(
  factoryId: string,
  orderId: string,
  colorwayIds: string[],
  flowSteps: FlowStepRef[],
): Promise<SizeProgressLookup> {
  const activeSteps = flowSteps.filter((s) => s.dept_id);
  const byColorwayDept = new Map<string, SizeMap>();

  await Promise.all(
    colorwayIds.flatMap((colorwayId) =>
      activeSteps.map(async (step) => {
        const progress = await fetchOrderDeptProgress(
          factoryId,
          orderId,
          colorwayId,
          step.dept_id,
        );
        byColorwayDept.set(`${colorwayId}|${step.dept_name}`, progress.produced_qty_by_size || {});
      }),
    ),
  );

  const aggregateByDept = new Map<string, SizeMap>();
  for (const [key, sizeMap] of byColorwayDept) {
    const deptName = key.split('|')[1];
    const agg = aggregateByDept.get(deptName) || {};
    mergeSizeMaps(agg, sizeMap);
    aggregateByDept.set(deptName, agg);
  }

  return {
    getSizeCount(colorwayId, deptName, size) {
      if (colorwayId) {
        return Number(byColorwayDept.get(`${colorwayId}|${deptName}`)?.[size]) || 0;
      }
      return Number(aggregateByDept.get(deptName)?.[size]) || 0;
    },
    getDeptTotal(colorwayId, deptName) {
      if (colorwayId) {
        return sumSizeMap(byColorwayDept.get(`${colorwayId}|${deptName}`));
      }
      return sumSizeMap(aggregateByDept.get(deptName));
    },
  };
}

export function formatProductionStatus(phase: ProductionProgressPhase): string {
  switch (phase) {
    case 'not_started':
      return 'Not Started';
    case 'in_progress':
      return 'In Progress';
    case 'complete':
      return 'Complete';
  }
}

export function statusColorClass(phase: ProductionProgressPhase): string {
  switch (phase) {
    case 'not_started':
      return 'text-slate-500';
    case 'in_progress':
      return 'text-blue-600';
    case 'complete':
      return 'text-emerald-600';
  }
}

export function deriveColorwayProgressPhase(
  flowSteps: string[],
  plannedTotal: number,
  getDeptTotal: (deptName: string) => number,
): ProductionProgressPhase {
  const totals = flowSteps.map((dept) => getDeptTotal(dept));
  if (!totals.some((t) => t > 0)) return 'not_started';
  const lastTotal = totals[totals.length - 1] || 0;
  if (plannedTotal > 0 && lastTotal >= plannedTotal) return 'complete';
  return 'in_progress';
}

export function deriveSizeProgressPhase(
  flowSteps: string[],
  sizeAdjQty: number,
  getSizeCount: (deptName: string) => number,
): ProductionProgressPhase {
  const counts = flowSteps.map((dept) => getSizeCount(dept));
  if (!counts.some((c) => c > 0)) return 'not_started';
  const lastCount = counts[counts.length - 1] || 0;
  if (sizeAdjQty > 0 && lastCount >= sizeAdjQty) return 'complete';
  return 'in_progress';
}

export function colorwayStatusLabel(
  phase: ProductionProgressPhase,
  hasAllocations: boolean,
): string {
  if (phase === 'not_started' && hasAllocations) return 'Configured';
  return formatProductionStatus(phase);
}
