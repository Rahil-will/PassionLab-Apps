import { supabase } from './supabase';
import {
  DEPRECATED_DROPDOWN_CATEGORIES,
  SUPPORT_DROPDOWN_CATALOG,
  SUPPORT_DROPDOWN_CATEGORY_SET,
} from './supportDropdownCatalog';
import type { SupportDropdown } from '../types';

const deprecatedCleanedForFactory = new Set<string>();

/** Remove legacy rows and seed any missing canonical dropdowns for a factory. */
export async function ensureSupportDropdowns(factoryId: string): Promise<void> {
  if (!factoryId) return;

  if (!deprecatedCleanedForFactory.has(factoryId)) {
    await supabase
      .from('support_dropdowns')
      .delete()
      .eq('factory_id', factoryId)
      .in('category', [...DEPRECATED_DROPDOWN_CATEGORIES]);
    deprecatedCleanedForFactory.add(factoryId);
  }

  const { data: existing, error } = await supabase
    .from('support_dropdowns')
    .select('category, app_name, values')
    .eq('factory_id', factoryId);

  if (error) throw error;

  const byCategory = new Map((existing || []).map((r) => [r.category as string, r]));

  for (const def of SUPPORT_DROPDOWN_CATALOG) {
    const row = byCategory.get(def.category);
    if (!row) {
      const { error: insertError } = await supabase.from('support_dropdowns').insert({
        factory_id: factoryId,
        category: def.category,
        app_name: def.appName,
        values: def.defaultValues,
      });
      if (insertError) throw insertError;
      continue;
    }
    const updates: Record<string, unknown> = {};
    if (!(row as { app_name?: string }).app_name) updates.app_name = def.appName;
    const vals = (row.values as string[]) || [];
    if (vals.length === 0 && def.defaultValues.length > 0) {
      updates.values = def.defaultValues;
    }
    if (Object.keys(updates).length > 0) {
      const { error: updateError } = await supabase
        .from('support_dropdowns')
        .update(updates)
        .eq('factory_id', factoryId)
        .eq('category', def.category);
      if (updateError) throw updateError;
    }
  }
}

/** Seed only when canonical catalog rows are missing (avoids re-insert on every settings load). */
export async function ensureSupportDropdownsIfNeeded(factoryId: string): Promise<void> {
  if (!factoryId) return;

  const { data: existing, error } = await supabase
    .from('support_dropdowns')
    .select('category')
    .eq('factory_id', factoryId);

  if (error) throw error;

  const present = new Set((existing || []).map((r) => r.category as string));
  const missingCatalog = SUPPORT_DROPDOWN_CATALOG.some((def) => !present.has(def.category));
  if (missingCatalog) {
    await ensureSupportDropdowns(factoryId);
  } else if (!deprecatedCleanedForFactory.has(factoryId)) {
    await supabase
      .from('support_dropdowns')
      .delete()
      .eq('factory_id', factoryId)
      .in('category', [...DEPRECATED_DROPDOWN_CATEGORIES]);
    deprecatedCleanedForFactory.add(factoryId);
  }
}

export function filterCanonicalSupportDropdowns(list: SupportDropdown[]): SupportDropdown[] {
  return list.filter(sd => SUPPORT_DROPDOWN_CATEGORY_SET.has(sd.category));
}
