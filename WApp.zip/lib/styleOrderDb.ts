import type { StyleOrder } from '../types';
import { normalizeSizeRow } from './colorwaySizesUtils';
import { supabase } from './supabase';

/** Columns on `style_orders` (trimmed remote schema). */
const STYLE_ORDER_COLUMNS = [
  'factory_id',
  'style_name',
  'style_ref',
  'buyer_id',
  'buyer_name',
  'po_number',
  'order_qty',
  'adj_qty',
  'delivery_date',
  'order_date',
  'garment_type',
  'sewing_sam',
  'priority',
  'wash_type',
  'size_group_name',
  'size_labels',
  'process_flow_id',
  'current_dept',
  'status',
  'image_url',
  'cutting_allowance',
  'shipment_allowance',
  'progress',
  'remarks',
  'job_card_date',
] as const;

export function styleOrderToDbRow(
  order: Partial<StyleOrder>,
  factoryId: string,
  orderId?: string,
): Record<string, unknown> {
  const row: Record<string, unknown> = {
    factory_id: factoryId,
    style_name: order.styleName ?? null,
    style_ref: order.styleRef ?? null,
    buyer_id: order.buyerId ?? null,
    buyer_name: order.buyer ?? null,
    po_number: order.poNumber ?? '',
    order_qty: order.orderQty ?? 0,
    adj_qty: order.adjQty ?? 0,
    delivery_date: order.deliveryDate || null,
    order_date: order.orderDate || null,
    job_card_date: order.jobCardDate || order.orderDate || null,
    garment_type: order.garmentType ?? null,
    sewing_sam: order.sewingSam ?? order.sam ?? null,
    priority: order.priority ?? 'normal',
    wash_type: order.washType ?? null,
    size_group_name: order.sizeGroupName?.trim() || null,
    size_labels: order.sizeLabels?.trim() || null,
    process_flow_id: order.processFlow || null,
    current_dept: order.currentDept ?? 'Planned',
    status: order.status ?? 'Not Started',
    image_url: order.image || null,
    cutting_allowance: order.cuttingAllowance ?? 2,
    shipment_allowance: order.shipmentAllowance ?? 0,
    progress: order.progress ?? {},
    remarks: order.remarks ?? null,
  };
  if (orderId) row.id = orderId;
  return row;
}

/** Only fields present on `updates` are included (safe for PATCH-style updates). */
export function styleOrderUpdatePayload(
  updates: Partial<StyleOrder>,
): Record<string, unknown> {
  const row: Record<string, unknown> = {};
  if (updates.styleName !== undefined) row.style_name = updates.styleName ?? null;
  if (updates.styleRef !== undefined) row.style_ref = updates.styleRef ?? null;
  if (updates.buyerId !== undefined) row.buyer_id = updates.buyerId ?? null;
  if (updates.buyer !== undefined) row.buyer_name = updates.buyer ?? null;
  if (updates.poNumber !== undefined) row.po_number = updates.poNumber;
  if (updates.orderQty !== undefined) row.order_qty = updates.orderQty;
  if (updates.adjQty !== undefined) row.adj_qty = updates.adjQty;
  if (updates.deliveryDate !== undefined) row.delivery_date = updates.deliveryDate || null;
  if (updates.orderDate !== undefined) row.order_date = updates.orderDate || null;
  if (updates.jobCardDate !== undefined) {
    row.job_card_date = updates.jobCardDate || updates.orderDate || null;
  }
  if (updates.garmentType !== undefined) row.garment_type = updates.garmentType ?? null;
  if (updates.sewingSam !== undefined) row.sewing_sam = updates.sewingSam;
  if (updates.sam !== undefined) row.sewing_sam = updates.sam;
  if (updates.priority !== undefined) row.priority = updates.priority ?? 'normal';
  if (updates.washType !== undefined) row.wash_type = updates.washType ?? null;
  if (updates.sizeGroupName !== undefined) row.size_group_name = updates.sizeGroupName?.trim() || null;
  if (updates.sizeLabels !== undefined) row.size_labels = updates.sizeLabels?.trim() || null;
  if (updates.processFlow !== undefined) row.process_flow_id = updates.processFlow || null;
  if (updates.currentDept !== undefined) row.current_dept = updates.currentDept;
  if (updates.status !== undefined) row.status = updates.status;
  if (updates.image !== undefined) row.image_url = updates.image || null;
  if (updates.cuttingAllowance !== undefined) row.cutting_allowance = updates.cuttingAllowance;
  if (updates.shipmentAllowance !== undefined) row.shipment_allowance = updates.shipmentAllowance;
  if (updates.progress !== undefined) row.progress = updates.progress;
  if (updates.remarks !== undefined) row.remarks = updates.remarks ?? null;
  return row;
}

export function mapStyleOrderFromDb(o: Record<string, unknown>): StyleOrder {
  return {
    id: o.id as string,
    styleName: (o.style_name as string) || '',
    styleRef: (o.style_ref as string) || '',
    buyer: (o.buyer_name as string) || '',
    buyerId: (o.buyer_id as string) || undefined,
    poNumber: (o.po_number as string) || '',
    orderQty: (o.order_qty as number) || 0,
    adjQty: (o.adj_qty as number) || 0,
    totalQty: (o.order_qty as number) || 0,
    deliveryDate: (o.delivery_date as string) || '',
    orderDate: (o.order_date as string) || '',
    jobCardDate: (o.job_card_date as string) || (o.order_date as string) || '',
    garmentType: (o.garment_type as string) || 'Top',
    sewingSam: o.sewing_sam != null ? Number(o.sewing_sam) : (o.sam != null ? Number(o.sam) : null),
    sam: o.sewing_sam != null ? Number(o.sewing_sam) : (o.sam != null ? Number(o.sam) : 0),
    priority: ((o.priority as StyleOrder['priority']) || 'normal'),
    washType: (o.wash_type as string) || 'None',
    sizeGroupName: (o.size_group_name as string) || '',
    sizeLabels: (o.size_labels as string) || '',
    processFlow: (o.process_flow_id as string) || '',
    currentDept: (o.current_dept as string) || 'Planned',
    status: (o.status as string) || 'Not Started',
    image: (o.image_url as string) || '',
    cuttingAllowance: (o.cutting_allowance as number) || 2,
    shipmentAllowance: (o.shipment_allowance as number) || 0,
    progress: (o.progress as StyleOrder['progress']) || {},
    colorways: ((o.colorways as Record<string, unknown>[]) || []).map((c) => ({
      id: c.id as string,
      name: c.name as string,
      colorCode: (c.color_code as string) || '',
      orderQty: (c.qty as number) || 0,
      adjQty: (c.adj_qty as number) || 0,
      totalQty: (c.qty as number) || 0,
      sizes: ((c.sizes as StyleOrder['colorways'][0]['sizes']) || []).map(normalizeSizeRow),
      planningRemarks: (c.planning_remarks as string) || '',
      completionStatus: (c.completion_status as StyleOrder['colorways'][0]['completionStatus']) || 'ongoing',
      closedAt: (c.closed_at as string) || null,
      closeReason: (c.close_reason as string) || null,
    })),
    remarks: (o.remarks as string) || '',
  };
}

export { STYLE_ORDER_COLUMNS };

/** Delete order + all linked floor/capture rows (requires delete_style_order RPC). */
export async function deleteStyleOrder(factoryId: string, orderId: string): Promise<void> {
  const { error } = await supabase.rpc('delete_style_order', {
    p_factory_id: factoryId,
    p_order_id: orderId,
  });
  if (error) throw error;
}
