import { supabase } from './supabase';
import {
  calcDhu,
  calcWip,
  dailyTargetForStyle,
  efficiencyPct,
  type PlanTarget,
} from './mesMetrics';

export interface HourlyRow {
  id: string;
  orderId: string;
  departmentId: string;
  hourSlot: string;
  count: number;
  logDate: string;
  loggedAt: string;
}

export interface InspectionRow {
  id: string;
  orderId: string;
  departmentId: string;
  result: string;
  loggedAt: string;
}

export interface SlipRow {
  orderId: string;
  fromDepartmentId: string;
  sentQty: number;
  sentAt: string;
}

export interface MesRawData {
  date: string;
  orders: Array<{ id: string; styleName: string; poNumber: string }>;
  departments: Array<{ id: string; name: string }>;
  allocations: PlanTarget[];
  hourly: HourlyRow[];
  inspections: InspectionRow[];
  slips: SlipRow[];
}

export interface DayDeptRow {
  departmentId: string;
  departmentName: string;
  output: number;
  target: number;
  efficiency: number | null;
  dhu: number | null;
  wip: number;
}

export interface StyleReportRow {
  orderId: string;
  styleName: string;
  poNumber: string;
  departmentId: string;
  departmentName: string;
  output: number;
  target: number;
  efficiency: number | null;
  dhu: number | null;
  wip: number;
  hourly: Array<{ hourSlot: string; actual: number; target: number; variance: number }>;
  shiftId?: string;
  shiftName?: string;
}

export async function fetchMesRawData(factoryId: string, date: string): Promise<MesRawData> {
  const dayStart = `${date}T00:00:00`;
  const dayEnd = `${date}T23:59:59.999`;

  const [ordersRes, deptRes, allocRes, hourlyRes, inspRes, slipRes] = await Promise.all([
    supabase.from('style_orders').select('id, style_name, po_number').eq('factory_id', factoryId),
    supabase.from('departments').select('id, name').eq('factory_id', factoryId).order('sequence'),
    supabase.from('line_allocations').select('style_name, department_id, daily_target, start_date, end_date').eq('factory_id', factoryId),
    supabase.from('hourly_counts').select('id, order_id, department_id, hour_slot, log_date, count, logged_at').eq('factory_id', factoryId).gte('logged_at', dayStart).lte('logged_at', dayEnd),
    supabase.from('inspections').select('id, order_id, department_id, result, logged_at').eq('factory_id', factoryId).gte('logged_at', dayStart).lte('logged_at', dayEnd),
    supabase.from('handover_slips').select('order_id, from_department_id, sent_qty, sent_at').eq('factory_id', factoryId).gte('sent_at', dayStart).lte('sent_at', dayEnd),
  ]);

  const orders = (ordersRes.data || []).map((o) => ({
    id: o.id as string,
    styleName: (o.style_name as string) || '',
    poNumber: (o.po_number as string) || '',
  }));

  const departments = (deptRes.data || []).map((d) => ({
    id: d.id as string,
    name: d.name as string,
  }));

  const allocations: PlanTarget[] = (allocRes.data || []).map((a) => ({
    styleName: (a.style_name as string) || '',
    departmentId: (a.department_id as string) || '',
    dailyTarget: (a.daily_target as number) || 0,
    startDate: (a.start_date as string) || undefined,
    endDate: (a.end_date as string) || undefined,
  }));

  const hourly: HourlyRow[] = (hourlyRes.data || []).map((h) => ({
    id: h.id as string,
    orderId: h.order_id as string,
    departmentId: h.department_id as string,
    hourSlot: h.hour_slot as string,
    logDate: (h.log_date as string) || date,
    count: (h.count as number) || 0,
    loggedAt: h.logged_at as string,
  }));

  const inspections: InspectionRow[] = (inspRes.data || []).map((i) => ({
    id: i.id as string,
    orderId: i.order_id as string,
    departmentId: i.department_id as string,
    result: i.result as string,
    loggedAt: i.logged_at as string,
  }));

  const slips: SlipRow[] = (slipRes.data || []).map((s) => ({
    orderId: s.order_id as string,
    fromDepartmentId: s.from_department_id as string,
    sentQty: (s.sent_qty as number) || 0,
    sentAt: s.sent_at as string,
  }));

  return { date, orders, departments, allocations, hourly, inspections, slips };
}

function deptOutput(
  data: MesRawData,
  orderId: string,
  departmentId: string,
  useHourly: boolean,
): number {
  if (useHourly) {
    return data.hourly
      .filter((h) => h.orderId === orderId && h.departmentId === departmentId)
      .reduce((s, h) => s + h.count, 0);
  }
  return data.inspections.filter(
    (i) =>
      i.orderId === orderId &&
      i.departmentId === departmentId &&
      (i.result === 'pass' || i.result === 'rework_pass'),
  ).length;
}

function deptFails(data: MesRawData, orderId: string, departmentId: string): number {
  return data.inspections.filter(
    (i) => i.orderId === orderId && i.departmentId === departmentId && i.result === 'fail',
  ).length;
}

function deptInspected(data: MesRawData, orderId: string, departmentId: string): number {
  return data.inspections.filter(
    (i) =>
      i.orderId === orderId &&
      i.departmentId === departmentId &&
      ['pass', 'fail', 'rework_pass'].includes(i.result),
  ).length;
}

function deptSent(data: MesRawData, orderId: string, departmentId: string): number {
  return data.slips
    .filter((s) => s.orderId === orderId && s.fromDepartmentId === departmentId)
    .reduce((sum, s) => sum + s.sentQty, 0);
}

export function buildDayReport(data: MesRawData): DayDeptRow[] {
  const deptHasHourly = new Set(data.hourly.map((h) => h.departmentId));

  return data.departments.map((dept) => {
    let output = 0;
    let target = 0;
    let failCount = 0;
    let inspectedCount = 0;
    let produced = 0;
    let sent = 0;

    for (const order of data.orders) {
      const useHourly = deptHasHourly.has(dept.id);
      const out = deptOutput(data, order.id, dept.id, useHourly);
      output += out;
      target += dailyTargetForStyle(data.allocations, order.styleName, dept.id, data.date);
      failCount += deptFails(data, order.id, dept.id);
      inspectedCount += deptInspected(data, order.id, dept.id);
      produced += useHourly ? out : deptInspected(data, order.id, dept.id);
      sent += deptSent(data, order.id, dept.id);
    }

    return {
      departmentId: dept.id,
      departmentName: dept.name,
      output,
      target,
      efficiency: efficiencyPct(output, target),
      dhu: calcDhu(failCount, inspectedCount),
      wip: calcWip(produced, sent),
    };
  }).filter((r) => r.output > 0 || r.target > 0);
}

export function buildStyleReport(data: MesRawData, orderId?: string): StyleReportRow[] {
  const orders = orderId ? data.orders.filter((o) => o.id === orderId) : data.orders;
  const shiftHours = 8;
  const rows: StyleReportRow[] = [];

  for (const order of orders) {
    for (const dept of data.departments) {
      const useHourly = data.hourly.some((h) => h.departmentId === dept.id);
      const output = deptOutput(data, order.id, dept.id, useHourly);
      const target = dailyTargetForStyle(data.allocations, order.styleName, dept.id, data.date);
      if (output === 0 && target === 0) continue;

      const hourTarget = target > 0 ? Math.round(target / shiftHours) : 0;
      const hourSlots = [...new Set(
        data.hourly
          .filter((h) => h.orderId === order.id && h.departmentId === dept.id)
          .map((h) => h.hourSlot),
      )];

      const hourly = hourSlots.map((hourSlot) => {
        const actual = data.hourly
          .filter((h) => h.orderId === order.id && h.departmentId === dept.id && h.hourSlot === hourSlot)
          .reduce((s, h) => s + h.count, 0);
        return { hourSlot, actual, target: hourTarget, variance: actual - hourTarget };
      });

      const failCount = deptFails(data, order.id, dept.id);
      const inspectedCount = deptInspected(data, order.id, dept.id);
      const produced = useHourly ? output : inspectedCount;

      rows.push({
        orderId: order.id,
        styleName: order.styleName,
        poNumber: order.poNumber,
        departmentId: dept.id,
        departmentName: dept.name,
        output,
        target,
        efficiency: efficiencyPct(output, target),
        dhu: calcDhu(failCount, inspectedCount),
        wip: calcWip(produced, deptSent(data, order.id, dept.id)),
        hourly,
      });
    }
  }

  return rows;
}

export function buildDepartmentReport(data: MesRawData, departmentId?: string): StyleReportRow[] {
  const filtered = buildStyleReport(data);
  return departmentId ? filtered.filter((r) => r.departmentId === departmentId) : filtered;
}
