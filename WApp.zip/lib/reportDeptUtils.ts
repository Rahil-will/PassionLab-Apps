/** Parse departments.apps JSONB from Supabase into a string array. */
export function parseDeptApps(raw: unknown): string[] | null {
  if (raw == null) return null;
  if (Array.isArray(raw)) {
    return raw.filter((item): item is string => typeof item === 'string');
  }
  return null;
}

/** QC departments run inspection_sessions capture (qc_log app). */
export function isQcDept(apps: string[] | null): boolean {
  return apps?.includes('qc_log') ?? false;
}

/** AQL audit departments run audit_sessions capture (audit app). */
export function isAuditDept(apps: string[] | null): boolean {
  return apps?.includes('audit') ?? false;
}
