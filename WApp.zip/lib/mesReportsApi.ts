import {
  parseSizeQtyMap,
  type FulfillmentAuditRow,
  type FulfillmentRejectionRow,
  type FulfillmentShipmentRow,
} from './fulfillmentData';
import { eachDayOfInterval, format, parseISO } from 'date-fns';
import { supabase } from './supabase';
import { allocationSamValue } from './allocationUtils';
import type { DayDeptRow, StyleReportRow } from './mesReports';
import type { SizeMap } from './mesSizeDisplay';
import { isAuditDept, isQcDept, parseDeptApps } from './reportDeptUtils';
import { getRegularShiftHours, hourlyTargetFromDaily } from './shiftHours';
import { allActiveHourSlots, activeHourSlotsForShift, isOtShift, regularShiftProductiveMins } from './shiftSlots';
import type { Shift, ShiftHourBlock } from '../types';

/** QC output from inspection_sessions — `passed` is total pass (includes rework pass). */
export function qcSessionOutputQty(raw: { passed?: unknown }): number {
  return Number(raw.passed) || 0;
}

/** Defective pieces — `failed` only (`rework` column removed; use `rework_passed` for rework passes). */
export function qcSessionDefectiveQty(raw: { failed?: unknown }): number {
  return Number(raw.failed) || 0;
}

export type {
  FulfillmentAuditRow,
  FulfillmentRejectionRow,
  FulfillmentShipmentRow,
  SizeQtyMap,
} from './fulfillmentData';

export interface ReportMeta {
  departments: Array<{
    id: string;
    name: string;
    apps: string[] | null;
    sequence: number;
  }>;
  orders: Array<{
    id: string;
    styleName: string;
    styleRef: string;
    buyerName: string;
    poNumber: string;
    createdAt: string;
  }>;
  buyers: Array<{ id: string; name: string }>;
  resources: Array<{ id: string; name: string; departmentId: string | null }>;
}

export interface ColorwayLabel {
  id: string;
  orderId: string;
  name: string;
  colorCode: string | null;
}

export interface DailyKpiRpcRow {
  factory_id: string;
  order_id: string;
  department_id: string;
  log_date: string;
  daily_target: number;
  daily_output: number;
  daily_available_mins?: number;
  daily_efficiency_pct: number | null;
  day_completeness: string;
  dhu: number | null;
  defective_pct: number | null;
  wip_qty: number;
  shift_breakdown?: unknown;
}

export interface ShiftKpiRpcRow {
  factory_id: string;
  order_id: string;
  department_id: string;
  log_date: string;
  shift_id: string;
  shift_name: string;
  shift_output: number;
  shift_headcount: number;
  shift_available_mins: number;
  shift_efficiency_pct: number | null;
  shift_productivity: number | null;
  dhu: number | null;
  defective_pct: number | null;
}

function inDateRange(logDate: string, dateFrom: string, dateTo: string): boolean {
  return logDate >= dateFrom && logDate <= dateTo;
}

/** End-of-day WIP per aggregate key — uses latest log_date within the row set. */
function wipByKeyLatestDay(
  rows: DailyKpiRpcRow[],
  keyFn: (row: DailyKpiRpcRow) => string,
): Map<string, number> {
  const latestByKey = new Map<string, string>();
  for (const row of rows) {
    const key = keyFn(row);
    const cur = latestByKey.get(key);
    if (!cur || row.log_date > cur) latestByKey.set(key, row.log_date);
  }
  const wip = new Map<string, number>();
  for (const row of rows) {
    const key = keyFn(row);
    if (row.log_date !== latestByKey.get(key)) continue;
    wip.set(key, (wip.get(key) || 0) + (row.wip_qty || 0));
  }
  return wip;
}

export interface CutToShipRow {
  factory_id: string;
  order_id: string;
  colorway_id: string | null;
  style_name: string;
  buyer_name: string | null;
  po_number: string | null;
  order_qty: number;
  cut_qty: number;
  cut_qty_source: string;
  shipped_qty: number;
  rejected_qty: number;
  wip_qty: number;
  reconciliation_gap: number;
  is_balanced: boolean;
  completion_pct: number | null;
  order_status: string | null;
  last_shipment_date: string | null;
  cut_qty_by_size?: SizeMap;
  shipped_qty_by_size?: SizeMap;
  rejected_qty_by_size?: SizeMap;
  wip_qty_by_size?: SizeMap;
}

export interface CutToShipJourneyRow {
  factory_id: string;
  order_id: string;
  colorway_id: string | null;
  dept_id: string;
  dept_name: string;
  flow_step: number | null;
  is_in_flow: boolean;
  qty_received: number | null;
  qty_produced: number | null;
  qty_sent: number | null;
  qty_rejected: number | null;
  wip_qty: number | null;
  wip_qty_by_size?: SizeMap | null;
  qty_received_by_size?: SizeMap | null;
  qty_produced_by_size?: SizeMap | null;
  qty_sent_by_size?: SizeMap | null;
  qty_rejected_by_size?: SizeMap | null;
  status: string;
}

export interface CutToShipDetail {
  reconciliation: CutToShipRow[];
  shipments: Array<Record<string, unknown>>;
  rejections: Array<Record<string, unknown>>;
  wip_by_dept: Array<Record<string, unknown>>;
  journey: CutToShipJourneyRow[];
}

export async function fetchColorwayLabels(factoryId: string): Promise<ColorwayLabel[]> {
  const { data: orders, error: orderError } = await supabase
    .from('style_orders')
    .select('id')
    .eq('factory_id', factoryId);

  if (orderError) throw orderError;

  const orderIds = (orders || []).map((o) => o.id as string);
  if (orderIds.length === 0) return [];

  const { data, error } = await supabase
    .from('colorways')
    .select('id, name, color_code, order_id')
    .in('order_id', orderIds);

  if (error) throw error;

  return (data || []).map((row) => ({
    id: row.id as string,
    orderId: row.order_id as string,
    name: (row.name as string) || '',
    colorCode: (row.color_code as string) || null,
  }));
}

export function colorwayDisplayLabel(
  colorwayId: string | null | undefined,
  map: Map<string, ColorwayLabel>,
): string {
  if (!colorwayId) return 'Order (legacy)';
  const cw = map.get(colorwayId);
  if (!cw) return colorwayId.slice(0, 8);
  return cw.colorCode ? `${cw.name} (${cw.colorCode})` : cw.name;
}

export async function fetchReportMeta(factoryId: string): Promise<ReportMeta> {
  const [deptRes, orderRes, buyerRes, resourceRes] = await Promise.all([
    supabase.from('departments').select('id, name, apps, sequence').eq('factory_id', factoryId).order('sequence'),
    supabase
      .from('style_orders')
      .select('id, style_name, style_ref, buyer_name, po_number, created_at')
      .eq('factory_id', factoryId)
      .order('created_at', { ascending: false }),
    supabase.from('buyers').select('id, name').eq('factory_id', factoryId).order('name'),
    supabase
      .from('assigned_resources')
      .select('id, resource_name, department_id')
      .eq('factory_id', factoryId)
      .eq('status', 'active')
      .order('resource_name'),
  ]);

  return {
    departments: (deptRes.data || []).map((d) => ({
      id: d.id as string,
      name: d.name as string,
      apps: parseDeptApps(d.apps),
      sequence: Number(d.sequence) || 0,
    })),
    orders: (orderRes.data || []).map((o) => ({
      id: o.id as string,
      styleName: (o.style_name as string) || '',
      styleRef: (o.style_ref as string) || '',
      buyerName: (o.buyer_name as string) || '',
      poNumber: (o.po_number as string) || '',
      createdAt: (o.created_at as string) || '',
    })),
    buyers: (buyerRes.data || []).map((b) => ({
      id: b.id as string,
      name: b.name as string,
    })),
    resources: (resourceRes.data || []).map((r) => ({
      id: r.id as string,
      name: (r.resource_name as string) || '',
      departmentId: (r.department_id as string) || null,
    })),
  };
}

export async function fetchFactoryKpis(
  factoryId: string,
  dateFrom: string,
  dateTo: string,
): Promise<DailyKpiRpcRow[]> {
  const { data, error } = await supabase.rpc('get_factory_kpis', {
    p_factory_id: factoryId,
    p_date_from: dateFrom,
    p_date_to: dateTo,
  });
  if (error) throw error;
  return (data || []) as DailyKpiRpcRow[];
}

export async function fetchDepartmentKpis(
  factoryId: string,
  departmentId: string,
  dateFrom: string,
  dateTo: string,
): Promise<DailyKpiRpcRow[]> {
  const { data, error } = await supabase.rpc('get_department_kpis', {
    p_factory_id: factoryId,
    p_department_id: departmentId,
    p_date_from: dateFrom,
    p_date_to: dateTo,
  });
  if (error) throw error;
  return (data || []) as DailyKpiRpcRow[];
}

export async function fetchStyleKpis(factoryId: string, orderId: string): Promise<DailyKpiRpcRow[]> {
  const { data, error } = await supabase.rpc('get_style_kpis', {
    p_factory_id: factoryId,
    p_order_id: orderId,
  });
  if (error) throw error;
  return (data || []) as DailyKpiRpcRow[];
}

export async function fetchDepartmentKpisByShift(
  factoryId: string,
  departmentId: string,
  dateFrom: string,
  dateTo: string,
): Promise<ShiftKpiRpcRow[]> {
  const { data, error } = await supabase.rpc('get_department_kpis_by_shift', {
    p_factory_id: factoryId,
    p_department_id: departmentId,
    p_date_from: dateFrom,
    p_date_to: dateTo,
  });
  if (!error) return (data || []) as ShiftKpiRpcRow[];

  const viewRes = await supabase
    .from('v_department_kpis_by_shift')
    .select('*')
    .eq('factory_id', factoryId)
    .eq('department_id', departmentId)
    .gte('log_date', dateFrom)
    .lte('log_date', dateTo)
    .order('log_date')
    .order('shift_name')
    .order('order_id');

  if (!viewRes.error) return (viewRes.data || []) as ShiftKpiRpcRow[];
  throw error ?? viewRes.error;
}

export async function fetchCutToShipReport(
  factoryId: string,
  opts?: {
    dateFrom?: string | null;
    dateTo?: string | null;
    buyerId?: string | null;
    balancedOnly?: boolean | null;
  },
): Promise<CutToShipRow[]> {
  const { data, error } = await supabase.rpc('get_cut_to_ship_report', {
    p_factory_id: factoryId,
    p_date_from: opts?.dateFrom ?? null,
    p_date_to: opts?.dateTo ?? null,
    p_buyer_id: opts?.buyerId ?? null,
    p_balanced_only: opts?.balancedOnly ?? null,
  });
  if (error) throw error;
  return (data || []) as CutToShipRow[];
}

export async function fetchCutToShipJourney(
  factoryId: string,
  orderId: string,
  colorwayId?: string | null,
): Promise<CutToShipJourneyRow[]> {
  // Remote DB: get_cut_to_ship_journey(p_factory_id, p_order_id) — no p_colorway_id arg.
  const { data, error } = await supabase.rpc('get_cut_to_ship_journey', {
    p_factory_id: factoryId,
    p_order_id: orderId,
  });
  if (error) throw error;
  let rows = (data || []) as CutToShipJourneyRow[];
  if (colorwayId) {
    rows = rows.filter((r) => r.colorway_id === colorwayId);
  }
  return rows;
}

function parseCutToShipDetail(raw: Record<string, unknown>): CutToShipDetail {
  return {
    reconciliation: (raw.reconciliation as CutToShipRow[]) || [],
    shipments: (raw.shipments as Array<Record<string, unknown>>) || [],
    rejections: (raw.rejections as Array<Record<string, unknown>>) || [],
    wip_by_dept: (raw.wip_by_dept as Array<Record<string, unknown>>) || [],
    journey: (raw.journey as CutToShipJourneyRow[]) || [],
  };
}

export async function fetchCutToShipDetail(
  factoryId: string,
  orderId: string,
): Promise<CutToShipDetail> {
  const { data, error } = await supabase.rpc('get_cut_to_ship_detail', {
    p_factory_id: factoryId,
    p_order_id: orderId,
  });

  if (!error && data) {
    return parseCutToShipDetail((data || {}) as Record<string, unknown>);
  }

  const [reconRes, shipRes, rejRes, journey] = await Promise.all([
    supabase
      .from('v_cut_to_ship')
      .select('*')
      .eq('factory_id', factoryId)
      .eq('order_id', orderId),
    supabase
      .from('shipments')
      .select('*')
      .eq('factory_id', factoryId)
      .eq('order_id', orderId)
      .order('shipment_date', { ascending: false }),
    supabase
      .from('rejections')
      .select('*')
      .eq('factory_id', factoryId)
      .eq('order_id', orderId)
      .order('rejected_date', { ascending: false }),
    fetchCutToShipJourney(factoryId, orderId).catch(() => [] as CutToShipJourneyRow[]),
  ]);

  const firstErr = reconRes.error || shipRes.error || rejRes.error;
  if (firstErr) throw firstErr;

  return {
    reconciliation: (reconRes.data || []) as CutToShipRow[],
    shipments: (shipRes.data || []) as Array<Record<string, unknown>>,
    rejections: (rejRes.data || []) as Array<Record<string, unknown>>,
    wip_by_dept: [],
    journey,
  };
}

export function buildDayReportFromRpc(
  rows: DailyKpiRpcRow[],
  departments: ReportMeta['departments'],
  dateFrom: string,
  dateTo: string,
): DayDeptRow[] {
  const deptMap = new Map(departments.map((d) => [d.id, d.name]));
  const byDept = new Map<string, {
    output: number;
    target: number;
    effSum: number;
    effCount: number;
    dhuSum: number;
    dhuWeight: number;
    wip: number;
  }>();

  const inRange = rows.filter((r) => inDateRange(r.log_date, dateFrom, dateTo));
  const wipByDept = wipByKeyLatestDay(inRange, (r) => r.department_id);

  for (const row of inRange) {
    const agg = byDept.get(row.department_id) ?? {
      output: 0, target: 0, effSum: 0, effCount: 0, dhuSum: 0, dhuWeight: 0, wip: 0,
    };
    agg.output += row.daily_output || 0;
    agg.target += row.daily_target || 0;
    if (row.daily_efficiency_pct != null) {
      agg.effSum += Number(row.daily_efficiency_pct);
      agg.effCount += 1;
    }
    if (row.dhu != null) {
      const weight = row.daily_output > 0 ? row.daily_output : 1;
      agg.dhuSum += Number(row.dhu) * weight;
      agg.dhuWeight += weight;
    }
    byDept.set(row.department_id, agg);
  }

  return [...byDept.entries()]
    .map(([departmentId, agg]) => ({
      departmentId,
      departmentName: deptMap.get(departmentId) || departmentId,
      output: agg.output,
      target: agg.target,
      efficiency: agg.effCount ? agg.effSum / agg.effCount : (agg.target > 0 ? (agg.output / agg.target) * 100 : null),
      dhu: agg.dhuWeight > 0 ? Math.round(agg.dhuSum / agg.dhuWeight) : null,
      wip: wipByDept.get(departmentId) || 0,
    }))
    .filter((r) => r.output > 0 || r.target > 0)
    .sort((a, b) => a.departmentName.localeCompare(b.departmentName));
}

export function buildStyleReportFromRpc(
  rows: DailyKpiRpcRow[],
  meta: ReportMeta,
  dateFrom: string,
  dateTo: string,
  orderId?: string,
): StyleReportRow[] {
  const deptMap = new Map(meta.departments.map((d) => [d.id, d.name]));
  const orderMap = new Map(meta.orders.map((o) => [o.id, o]));
  const filtered = rows.filter(
    (r) => inDateRange(r.log_date, dateFrom, dateTo) && (!orderId || r.order_id === orderId),
  );
  const wipByOrderDept = wipByKeyLatestDay(filtered, (r) => `${r.order_id}|${r.department_id}`);

  const agg = new Map<string, {
    orderId: string;
    departmentId: string;
    output: number;
    target: number;
    wip: number;
    effSum: number;
    effCount: number;
    dhuSum: number;
    dhuWeight: number;
    hourly: StyleReportRow['hourly'];
  }>();

  for (const row of filtered) {
    const key = `${row.order_id}|${row.department_id}`;
    const cur = agg.get(key) ?? {
      orderId: row.order_id,
      departmentId: row.department_id,
      output: 0,
      target: 0,
      wip: 0,
      effSum: 0,
      effCount: 0,
      dhuSum: 0,
      dhuWeight: 0,
      hourly: [],
    };
    cur.output += row.daily_output || 0;
    cur.target += row.daily_target || 0;
    if (row.daily_efficiency_pct != null) {
      cur.effSum += Number(row.daily_efficiency_pct);
      cur.effCount += 1;
    }
    if (row.dhu != null) {
      const weight = row.daily_output > 0 ? row.daily_output : 1;
      cur.dhuSum += Number(row.dhu) * weight;
      cur.dhuWeight += weight;
    }
    const breakdown = Array.isArray(row.shift_breakdown) ? row.shift_breakdown : [];
    for (const s of breakdown) {
      const slot = (s as { shift_name?: string; shift_output?: number }).shift_name || 'Shift';
      const actual = (s as { shift_output?: number }).shift_output || 0;
      const existing = cur.hourly.find((h) => h.hourSlot === slot);
      if (existing) {
        existing.actual += actual;
        existing.variance += actual;
      } else {
        cur.hourly.push({ hourSlot: slot, actual, target: 0, variance: actual });
      }
    }
    agg.set(key, cur);
  }

  return [...agg.values()].map((a) => {
    const order = orderMap.get(a.orderId);
    const wipKey = `${a.orderId}|${a.departmentId}`;
    return {
      orderId: a.orderId,
      styleName: order?.styleName || '',
      poNumber: order?.poNumber || '',
      departmentId: a.departmentId,
      departmentName: deptMap.get(a.departmentId) || a.departmentId,
      output: a.output,
      target: a.target,
      efficiency: a.effCount
        ? a.effSum / a.effCount
        : a.target > 0
          ? (a.output / a.target) * 100
          : null,
      dhu: a.dhuWeight > 0 ? Math.round(a.dhuSum / a.dhuWeight) : null,
      wip: wipByOrderDept.get(wipKey) || 0,
      hourly: a.hourly,
    };
  });
}

export function buildDepartmentReportFromRpc(
  rows: DailyKpiRpcRow[],
  meta: ReportMeta,
  dateFrom: string,
  dateTo: string,
  departmentId?: string,
): StyleReportRow[] {
  const styleRows = buildStyleReportFromRpc(rows, meta, dateFrom, dateTo);
  return departmentId ? styleRows.filter((r) => r.departmentId === departmentId) : styleRows;
}

export function buildDepartmentShiftReportFromRpc(
  rows: ShiftKpiRpcRow[],
  meta: ReportMeta,
  dateFrom: string,
  dateTo: string,
  departmentId: string,
  shiftId?: string,
): StyleReportRow[] {
  const deptMap = new Map(meta.departments.map((d) => [d.id, d.name]));
  const orderMap = new Map(meta.orders.map((o) => [o.id, o]));
  const filtered = rows.filter(
    (r) =>
      r.department_id === departmentId &&
      inDateRange(r.log_date, dateFrom, dateTo) &&
      (!shiftId || r.shift_id === shiftId),
  );

  const agg = new Map<string, {
    orderId: string;
    shiftId: string;
    shiftName: string;
    output: number;
    effSum: number;
    effCount: number;
    dhuSum: number;
    dhuWeight: number;
  }>();

  for (const row of filtered) {
    const key = `${row.order_id}|${row.shift_id}`;
    const cur = agg.get(key) ?? {
      orderId: row.order_id,
      shiftId: row.shift_id,
      shiftName: row.shift_name,
      output: 0,
      effSum: 0,
      effCount: 0,
      dhuSum: 0,
      dhuWeight: 0,
    };
    cur.output += row.shift_output || 0;
    if (row.shift_efficiency_pct != null) {
      cur.effSum += Number(row.shift_efficiency_pct);
      cur.effCount += 1;
    }
    if (row.dhu != null) {
      const weight = row.shift_output > 0 ? row.shift_output : 1;
      cur.dhuSum += Number(row.dhu) * weight;
      cur.dhuWeight += weight;
    }
    agg.set(key, cur);
  }

  return [...agg.values()]
    .map((a) => {
      const order = orderMap.get(a.orderId);
      return {
        orderId: a.orderId,
        styleName: order?.styleName || '',
        poNumber: order?.poNumber || '',
        departmentId,
        departmentName: deptMap.get(departmentId) || departmentId,
        shiftId: a.shiftId,
        shiftName: a.shiftName,
        output: a.output,
        target: 0,
        efficiency: a.effCount ? a.effSum / a.effCount : null,
        dhu: a.dhuWeight > 0 ? Math.round(a.dhuSum / a.dhuWeight) : null,
        wip: 0,
        hourly: [],
      };
    })
    .filter((r) => r.output > 0)
    .sort((a, b) => a.styleName.localeCompare(b.styleName) || (a.shiftName || '').localeCompare(b.shiftName || ''));
}

export function listShiftsFromKpiRows(rows: ShiftKpiRpcRow[]): Array<{ id: string; name: string }> {
  const map = new Map<string, string>();
  for (const row of rows) {
    if (row.shift_id) map.set(row.shift_id, row.shift_name || row.shift_id);
  }
  return [...map.entries()]
    .map(([id, name]) => ({ id, name }))
    .sort((a, b) => a.name.localeCompare(b.name));
}

export interface DayStyleColorHourRow {
  orderId: string;
  colorwayId: string | null;
  resourceId: string | null;
  styleName: string;
  poNumber: string;
  colorName: string;
  resourceName: string;
  hours: Record<string, number>;
  total: number;
}

export interface DayStyleColorHourReport {
  hourColumns: string[];
  rows: DayStyleColorHourRow[];
}

/** Department day report: one row per style/color, hour slots as columns. */
export async function fetchDayStyleColorHourReport(
  factoryId: string,
  date: string,
  departmentId: string,
  meta: ReportMeta,
  colorwayLabels: ColorwayLabel[],
): Promise<DayStyleColorHourReport> {
  const { data, error } = await supabase
    .from('hourly_counts')
    .select('order_id, colorway_id, resource_id, hour_slot, count')
    .eq('factory_id', factoryId)
    .eq('department_id', departmentId)
    .eq('log_date', date);

  if (error) throw error;

  const orderMap = new Map(meta.orders.map((o) => [o.id, o]));
  const colorMap = new Map(colorwayLabels.map((c) => [c.id, c]));
  const resourceMap = new Map(meta.resources.map((r) => [r.id, r]));
  const hourSet = new Set<string>();
  const rowMap = new Map<string, DayStyleColorHourRow>();

  for (const raw of data || []) {
    const orderId = raw.order_id as string;
    const colorwayId = (raw.colorway_id as string) || null;
    const resourceId = (raw.resource_id as string) || null;
    const hourSlot = String(raw.hour_slot ?? '');
    const count = Number(raw.count) || 0;
    if (!hourSlot) continue;
    hourSet.add(hourSlot);
    const key = `${orderId}|${colorwayId ?? ''}|${resourceId ?? ''}`;
    const order = orderMap.get(orderId);
    const resource = resourceId ? resourceMap.get(resourceId) : undefined;
    const row =
      rowMap.get(key) ??
      {
        orderId,
        colorwayId,
        resourceId,
        styleName: order?.styleName || orderId.slice(0, 8),
        poNumber: order?.poNumber || '',
        colorName: colorwayDisplayLabel(colorwayId, colorMap),
        resourceName: resource?.name || '—',
        hours: {},
        total: 0,
      };
    row.hours[hourSlot] = (row.hours[hourSlot] || 0) + count;
    row.total += count;
    rowMap.set(key, row);
  }

  const hourColumns = [...hourSet].sort((a, b) => a.localeCompare(b, undefined, { numeric: true }));
  const rows = [...rowMap.values()]
    .filter((r) => r.total > 0)
    .sort(
      (a, b) =>
        a.styleName.localeCompare(b.styleName) ||
        a.colorName.localeCompare(b.colorName) ||
        a.resourceName.localeCompare(b.resourceName),
    );

  return { hourColumns, rows };
}

export interface WorkforceCategoryCount {
  category: string;
  count: number;
}

export interface DayResourceHourRow {
  logDate?: string;
  shiftId?: string;
  resourceId: string;
  resourceName: string;
  orderId: string;
  styleName: string;
  styleRef: string;
  buyerName: string;
  poNumber: string;
  colorwayId: string | null;
  colorName: string;
  hours: Record<string, number>;
  hourTargets: Record<string, number>;
  /** Per-hour plan target from line_allocations.hourly_target or daily ÷ shift hours. */
  hourlyTarget: number;
  total: number;
  workforce: number | null;
  workforceBreakdown: WorkforceCategoryCount[];
  producedMins: number;
  resourceAvailableMins: number;
  daysRunning: number | null;
  plannedEndDate: string | null;
  allocationId?: string | null;
  efficiencyPct: number | null;
  productivity: number | null;
}

export interface DayShiftHourSection {
  shiftId: string;
  shiftName: string;
  hourColumns: string[];
  rows: DayResourceHourRow[];
}

export interface DayResourceHourReport {
  isQcDept: boolean;
  hourColumns: string[];
  rows: DayResourceHourRow[];
  shiftSections: DayShiftHourSection[];
  productiveMinsPerWorker: number;
  kpi: {
    output: number;
    target: number;
    efficiency: number | null;
    productivity: number | null;
    dhu: number | null;
    inspected?: number;
    passed?: number;
    passPct?: number | null;
    wip?: number;
  };
  handover?: DayHandoverSummary;
  handoverByDay?: Array<{ date: string; handover: DayHandoverSummary }>;
}

import {
  handoverDbToDisplay,
  handoverDisplayLabel,
  type HandoverDisplayStatus,
} from './handoverStatus';

export type { HandoverDisplayStatus as DayHandoverRowStatus };
export { handoverDisplayLabel as dayHandoverStatusLabel, handoverDbToDisplay };

export interface DayDeptReceivedRow {
  fromDepartmentName: string;
  styleName: string;
  colorName: string;
  qty: number;
  status: DayHandoverRowStatus;
}

export interface DayDeptSentRow {
  toDepartmentName: string;
  styleName: string;
  colorName: string;
  qty: number;
  status: DayHandoverRowStatus;
}

export interface DayHandoverSummary {
  received: DayDeptReceivedRow[];
  sent: DayDeptSentRow[];
}

/** Handovers in/out of one department for the selected day (attributed by sent_at, same as transaction report). */
export async function fetchDayDeptHandoverSummary(
  factoryId: string,
  date: string,
  departmentId: string,
  _meta: ReportMeta,
  _colorwayLabels: ColorwayLabel[],
): Promise<DayHandoverSummary> {
  const rpcArgs = {
    p_factory_id: factoryId,
    p_date_from: date,
    p_date_to: date,
    p_from_department_id: null as string | null,
    p_to_department_id: null as string | null,
    p_status: null as string | null,
    p_order_id: null as string | null,
    p_colorway_id: null as string | null,
    p_search: null as string | null,
  };

  const [inboundRes, outboundRes] = await Promise.all([
    supabase.rpc('get_handover_report', {
      ...rpcArgs,
      p_to_department_id: departmentId,
    }),
    supabase.rpc('get_handover_report', {
      ...rpcArgs,
      p_from_department_id: departmentId,
    }),
  ]);

  if (inboundRes.error) throw inboundRes.error;
  if (outboundRes.error) throw outboundRes.error;

  const receivedMap = new Map<string, DayDeptReceivedRow>();
  for (const raw of inboundRes.data || []) {
    const rpcStatus = (raw.status as string) || 'pending';
    const rowStatus = handoverDbToDisplay(rpcStatus);
    const qty =
      rpcStatus === 'received'
        ? Number(raw.received_qty) || 0
        : Number(raw.sent_qty) || 0;
    if (qty <= 0) continue;
    const fromDepartmentName = (raw.from_department_name as string) || '—';
    const styleName = (raw.style_name as string) || '—';
    const colorName =
      (raw.colorway_name as string) || (raw.color_code as string) || '—';
    const key = `${fromDepartmentName}|${styleName}|${colorName}|${rowStatus}`;
    const existing = receivedMap.get(key);
    if (existing) {
      existing.qty += qty;
    } else {
      receivedMap.set(key, {
        fromDepartmentName,
        styleName,
        colorName,
        qty,
        status: rowStatus,
      });
    }
  }

  const sentMap = new Map<string, DayDeptSentRow>();
  for (const raw of outboundRes.data || []) {
    const rpcStatus = (raw.status as string) || 'pending';
    const rowStatus = handoverDbToDisplay(rpcStatus);
    const qty = Number(raw.sent_qty) || 0;
    if (qty <= 0) continue;
    const toDepartmentName = (raw.to_department_name as string) || '—';
    const styleName = (raw.style_name as string) || '—';
    const colorName =
      (raw.colorway_name as string) || (raw.color_code as string) || '—';
    const key = `${toDepartmentName}|${styleName}|${colorName}|${rowStatus}`;
    const existing = sentMap.get(key);
    if (existing) {
      existing.qty += qty;
    } else {
      sentMap.set(key, {
        toDepartmentName,
        styleName,
        colorName,
        qty,
        status: rowStatus,
      });
    }
  }

  return {
    received: [...receivedMap.values()].sort(
      (a, b) =>
        a.fromDepartmentName.localeCompare(b.fromDepartmentName) ||
        a.styleName.localeCompare(b.styleName),
    ),
    sent: [...sentMap.values()].sort(
      (a, b) =>
        a.styleName.localeCompare(b.styleName) ||
        a.toDepartmentName.localeCompare(b.toDepartmentName),
    ),
  };
}

function mergeHandoverSummaries(summaries: DayHandoverSummary[]): DayHandoverSummary {
  const receivedMap = new Map<string, DayDeptReceivedRow>();
  const sentMap = new Map<string, DayDeptSentRow>();

  for (const summary of summaries) {
    for (const row of summary.received) {
      const key = `${row.fromDepartmentName}|${row.styleName}|${row.colorName}|${row.status}`;
      const existing = receivedMap.get(key);
      if (existing) existing.qty += row.qty;
      else receivedMap.set(key, { ...row });
    }
    for (const row of summary.sent) {
      const key = `${row.toDepartmentName}|${row.styleName}|${row.colorName}|${row.status}`;
      const existing = sentMap.get(key);
      if (existing) existing.qty += row.qty;
      else sentMap.set(key, { ...row });
    }
  }

  return {
    received: [...receivedMap.values()].sort(
      (a, b) =>
        a.fromDepartmentName.localeCompare(b.fromDepartmentName) ||
        a.styleName.localeCompare(b.styleName),
    ),
    sent: [...sentMap.values()].sort(
      (a, b) =>
        a.styleName.localeCompare(b.styleName) ||
        a.toDepartmentName.localeCompare(b.toDepartmentName),
    ),
  };
}

function listDatesInRange(dateFrom: string, dateTo: string): string[] {
  const from = dateFrom <= dateTo ? dateFrom : dateTo;
  const to = dateFrom <= dateTo ? dateTo : dateFrom;
  return eachDayOfInterval({ start: parseISO(from), end: parseISO(to) }).map((d) =>
    format(d, 'yyyy-MM-dd'),
  );
}

function mapShiftRow(raw: Record<string, unknown>): Shift {
  return {
    id: raw.id as string,
    factory_id: raw.factory_id as string,
    name: (raw.name as string) || '',
    type: (raw.type as string) || 'Regular',
    startTime: (raw.start_time as string) || null,
    endTime: (raw.end_time as string) || null,
    breakStart: (raw.break_start as string) || null,
    breakEnd: (raw.break_end as string) || null,
    hours: ((raw.hours as ShiftHourBlock[]) || []) as ShiftHourBlock[],
  };
}

function workforceHeadcountFromLog(raw: Record<string, unknown>): number {
  const extra = raw.headcount_by_category as Record<string, number> | null;
  if (!extra || typeof extra !== 'object') return 0;
  return Object.values(extra).reduce((sum, n) => sum + (Number(n) || 0), 0);
}

/** Sum headcount per resource_id across shift logs for the day. */
function buildResourceWorkforceDetails(
  logs: Array<Record<string, unknown>>,
): Map<string, { total: number; breakdown: WorkforceCategoryCount[] }> {
  const catMaps = new Map<string, Map<string, number>>();
  for (const raw of logs) {
    const resourceId = raw.resource_id as string | null;
    if (!resourceId) continue;
    const cats = catMaps.get(resourceId) ?? new Map<string, number>();
    const headcount = raw.headcount_by_category as Record<string, number> | null;
    if (headcount && typeof headcount === 'object') {
      for (const [cat, count] of Object.entries(headcount)) {
        const n = Number(count) || 0;
        if (n <= 0) continue;
        cats.set(cat, (cats.get(cat) || 0) + n);
      }
    }
    catMaps.set(resourceId, cats);
  }
  const result = new Map<string, { total: number; breakdown: WorkforceCategoryCount[] }>();
  for (const [resourceId, cats] of catMaps) {
    const breakdown = [...cats.entries()]
      .map(([category, count]) => ({ category, count }))
      .sort((a, b) => b.count - a.count);
    const total = breakdown.reduce((sum, row) => sum + row.count, 0);
    if (total > 0) result.set(resourceId, { total, breakdown });
  }
  return result;
}

function allocRowKey(orderId: string, colorwayId: string | null, resourceId: string): string {
  return `${orderId}|${colorwayId ?? ''}|${resourceId}`;
}

interface AllocPlanRow {
  id: string;
  order_id: string;
  colorway_id: string | null;
  line_id: string;
  department_id: string | null;
  daily_target: number;
  hourly_target: number | null;
  qty: number;
  start_date: string | null;
  end_date: string | null;
  sam: number | null;
  kpi_inputs: { sam?: number } | null;
}

function lineIdMatches(allocLineId: string, resourceId: string): boolean {
  if (!resourceId) return true;
  if (!allocLineId) return true;
  return allocLineId === resourceId;
}

function colorwayMatches(allocColorwayId: string | null, rowColorwayId: string | null): boolean {
  if (!rowColorwayId) return true;
  if (!allocColorwayId) return true;
  return allocColorwayId === rowColorwayId;
}

function allocInPlanWindow(
  alloc: AllocPlanRow,
  logDate: string,
  strict: boolean,
): boolean {
  const start = alloc.start_date?.split('T')[0] ?? null;
  const end = alloc.end_date?.split('T')[0] ?? null;
  if (start && logDate < start) return false;
  if (strict && end && logDate > end) return false;
  return true;
}

function scoreAllocationMatch(
  alloc: AllocPlanRow,
  orderId: string,
  colorwayId: string | null,
  resourceId: string,
  logDate: string,
  departmentId: string,
): number {
  if (alloc.order_id !== orderId) return -1;
  if (!lineIdMatches(alloc.line_id, resourceId)) return -1;
  if (!colorwayMatches(alloc.colorway_id, colorwayId)) return -1;

  let score = 0;
  if (resourceId && alloc.line_id === resourceId) score += 80;
  if (colorwayId && alloc.colorway_id === colorwayId) score += 60;
  if (departmentId && alloc.department_id === departmentId) score += 40;
  else if (!alloc.department_id) score += 10;
  if (allocInPlanWindow(alloc, logDate, true)) score += 50;
  else if (allocInPlanWindow(alloc, logDate, false)) score += 20;
  if (alloc.end_date) score += 5;
  if (alloc.hourly_target != null && alloc.hourly_target > 0) score += 5;
  return score;
}

/** Match line_allocations.end_date + hourly_target to a floor capture row. */
function findAllocationForDayRow(
  allocs: AllocPlanRow[],
  orderId: string,
  colorwayId: string | null,
  resourceId: string,
  logDate: string,
  departmentId: string,
): AllocPlanRow | null {
  let best: AllocPlanRow | null = null;
  let bestScore = -1;
  for (const alloc of allocs) {
    const score = scoreAllocationMatch(
      alloc,
      orderId,
      colorwayId,
      resourceId,
      logDate,
      departmentId,
    );
    if (score > bestScore) {
      bestScore = score;
      best = alloc;
    }
  }
  return best;
}

async function fetchLineAllocPlanRows(
  factoryId: string,
  orderIds: string[],
): Promise<AllocPlanRow[]> {
  if (orderIds.length === 0) return [];

  const baseSelect =
    'id, order_id, colorway_id, line_id, department_id, sam, kpi_inputs, daily_target, qty, start_date, end_date';

  let { data, error } = await supabase
    .from('line_allocations')
    .select(`${baseSelect}, hourly_target`)
    .eq('factory_id', factoryId)
    .in('order_id', orderIds);

  if (error) {
    const msg = String(error.message ?? '');
    if (msg.includes('hourly_target') || msg.includes('column')) {
      const fallback = await supabase
        .from('line_allocations')
        .select(baseSelect)
        .eq('factory_id', factoryId)
        .in('order_id', orderIds);
      if (fallback.error) throw fallback.error;
      data = (fallback.data ?? []).map((row) => ({ ...row, hourly_target: null }));
    } else {
      throw error;
    }
  }

  return (data || []).map((raw) => ({
    id: raw.id as string,
    order_id: raw.order_id as string,
    colorway_id: (raw.colorway_id as string) || null,
    line_id: (raw.line_id as string) || '',
    department_id: (raw.department_id as string) || null,
    daily_target: Number(raw.daily_target) || 0,
    hourly_target:
      raw.hourly_target != null ? Number(raw.hourly_target as number) : null,
    qty: Number(raw.qty) || 0,
    start_date: (raw.start_date as string) || null,
    end_date: (raw.end_date as string) || null,
    sam: (raw.sam as number) ?? null,
    kpi_inputs: (raw.kpi_inputs as { sam?: number } | null) ?? null,
  }));
}

const UNASSIGNED_SHIFT = '__unassigned__';

function resolveShiftIdForSlot(
  shifts: Shift[],
  hourSlot: string,
  storedShiftId: string | null,
): string {
  if (storedShiftId) return storedShiftId;
  const matches = shifts.filter((s) => activeHourSlotsForShift(s).includes(hourSlot));
  if (matches.length === 0) return UNASSIGNED_SHIFT;
  const nonOt = matches.find((s) => !isOtShift(s));
  return (nonOt ?? matches[0]).id;
}

function shiftDisplayName(shifts: Shift[], shiftId: string): string {
  if (shiftId === UNASSIGNED_SHIFT) return 'Shift';
  return shifts.find((s) => s.id === shiftId)?.name ?? 'Shift';
}

function hourColumnsForShift(
  shifts: Shift[],
  shiftId: string,
  dataSlots: Set<string>,
): string[] {
  if (shiftId === UNASSIGNED_SHIFT) {
    return [...dataSlots].sort((a, b) => a.localeCompare(b, undefined, { numeric: true }));
  }
  const shift = shifts.find((s) => s.id === shiftId);
  const planned = activeHourSlotsForShift(shift);
  const cols = planned.length > 0 ? planned : [...dataSlots];
  return cols.sort((a, b) => a.localeCompare(b, undefined, { numeric: true }));
}

function sortShiftIds(shifts: Shift[], shiftIds: string[]): string[] {
  return [...shiftIds].sort((a, b) => {
    const shiftA = shifts.find((s) => s.id === a);
    const shiftB = shifts.find((s) => s.id === b);
    const otA = shiftA ? isOtShift(shiftA) : a === UNASSIGNED_SHIFT;
    const otB = shiftB ? isOtShift(shiftB) : b === UNASSIGNED_SHIFT;
    if (otA !== otB) return otA ? 1 : -1;
    return shiftDisplayName(shifts, a).localeCompare(shiftDisplayName(shifts, b));
  });
}

function mergeShiftSectionsFromDailyReports(
  dailyReports: DayResourceHourReport[],
  days: string[],
): DayShiftHourSection[] {
  const byShift = new Map<
    string,
    { shiftName: string; hourColumns: Set<string>; rows: DayResourceHourRow[] }
  >();

  for (let i = 0; i < dailyReports.length; i++) {
    const sections =
      dailyReports[i].shiftSections?.length > 0
        ? dailyReports[i].shiftSections
        : [
            {
              shiftId: UNASSIGNED_SHIFT,
              shiftName: 'Shift',
              hourColumns: dailyReports[i].hourColumns,
              rows: dailyReports[i].rows,
            },
          ];
    for (const sec of sections) {
      const bucket = byShift.get(sec.shiftId) ?? {
        shiftName: sec.shiftName,
        hourColumns: new Set<string>(),
        rows: [],
      };
      for (const col of sec.hourColumns) bucket.hourColumns.add(col);
      for (const row of sec.rows) {
        bucket.rows.push({ ...row, logDate: days[i], shiftId: sec.shiftId });
      }
      byShift.set(sec.shiftId, bucket);
    }
  }

  return [...byShift.entries()].map(([shiftId, bucket]) => ({
    shiftId,
    shiftName: bucket.shiftName,
    hourColumns: [...bucket.hourColumns].sort((a, b) =>
      a.localeCompare(b, undefined, { numeric: true }),
    ),
    rows: bucket.rows,
  }));
}

function allocWorkingDays(startDate: string | null, endDate: string | null): number {
  if (!startDate || !endDate) return 0;
  const start = startDate.split('T')[0];
  const end = endDate.split('T')[0];
  let days = 0;
  for (let d = new Date(start); d <= new Date(end); d.setDate(d.getDate() + 1)) {
    if (d.getDay() !== 0) days++;
  }
  return days;
}

function impliedDailyTarget(alloc: AllocPlanRow): number {
  const stored = Number(alloc.daily_target) || 0;
  if (stored > 0) return stored;
  const qty = Number(alloc.qty) || 0;
  const wd = allocWorkingDays(alloc.start_date, alloc.end_date);
  return wd > 0 && qty > 0 ? Math.ceil(qty / wd) : 0;
}

function applyAllocationPlanToDayRows(
  rows: DayResourceHourRow[],
  allocs: AllocPlanRow[],
  logDate: string,
  hourColumns: string[],
  regularShiftHours: number,
  departmentId: string,
): void {
  for (const row of rows) {
    const rowDate = row.logDate ?? logDate;
    const alloc = findAllocationForDayRow(
      allocs,
      row.orderId,
      row.colorwayId,
      row.resourceId,
      rowDate,
      departmentId,
    );
    if (!alloc) continue;

    const dailyTarget = impliedDailyTarget(alloc);
    const storedHr = alloc.hourly_target != null ? Number(alloc.hourly_target) : 0;
    const hrTarget =
      storedHr > 0
        ? storedHr
        : dailyTarget > 0
          ? hourlyTargetFromDaily(dailyTarget, regularShiftHours)
          : 0;
    row.hourlyTarget = hrTarget;
    row.hourTargets = {};
    for (const h of hourColumns) {
      row.hourTargets[h] = hrTarget;
    }
    row.daysRunning = daysRunningFromStart(alloc.start_date, rowDate);
    row.plannedEndDate = alloc.end_date ? alloc.end_date.split('T')[0] : null;
    row.allocationId = alloc.id;
  }
}

function daysRunningFromStart(startDate: string | null, logDate: string): number | null {
  if (!startDate) return null;
  const start = startDate.split('T')[0];
  if (logDate < start) return null;
  const diff = new Date(logDate).getTime() - new Date(start).getTime();
  return Math.floor(diff / 86_400_000) + 1;
}

function enrichDayResourceRows(
  rows: DayResourceHourRow[],
  samByAllocKey: Map<string, number>,
  sewingSamByOrder: Map<string, number>,
  resourceWorkforce: Map<string, { total: number; breakdown: WorkforceCategoryCount[] }>,
  productiveMinsPerWorker: number,
): void {
  const resourceAgg = new Map<string, { output: number; producedMins: number }>();

  for (const row of rows) {
    const wf = resourceWorkforce.get(row.resourceId);
    row.workforce = wf && wf.total > 0 ? wf.total : null;
    row.workforceBreakdown = wf?.breakdown ?? [];
    const key = allocRowKey(row.orderId, row.colorwayId, row.resourceId);
    const sam = samByAllocKey.get(key) ?? sewingSamByOrder.get(row.orderId) ?? 0;
    row.producedMins = row.total * sam;
    const agg = resourceAgg.get(row.resourceId) ?? { output: 0, producedMins: 0 };
    agg.output += row.total;
    agg.producedMins += row.producedMins;
    resourceAgg.set(row.resourceId, agg);
  }

  for (const row of rows) {
    const workforce = row.workforce;
    const agg = resourceAgg.get(row.resourceId);
    const availableMins =
      workforce != null && workforce > 0 && productiveMinsPerWorker > 0
        ? workforce * productiveMinsPerWorker
        : 0;
    row.resourceAvailableMins = availableMins;
    if (!workforce || workforce <= 0 || !agg) {
      row.efficiencyPct = null;
      row.productivity = null;
      continue;
    }
    row.efficiencyPct =
      agg.producedMins > 0 && availableMins > 0
        ? (agg.producedMins / availableMins) * 100
        : null;
    row.productivity = agg.output > 0 ? agg.output / workforce : null;
  }
}

export function computeDayDeptMetricsFromRows(
  rows: DayResourceHourRow[],
): { output: number; workforce: number; efficiency: number | null; productivity: number | null } {
  let output = 0;
  let producedMins = 0;
  let availableMins = 0;
  let workforce = 0;
  const seenResources = new Set<string>();

  for (const row of rows) {
    output += row.total;
    producedMins += row.producedMins;
    if (!row.resourceId || seenResources.has(row.resourceId)) continue;
    seenResources.add(row.resourceId);
    workforce += row.workforce || 0;
    availableMins += row.resourceAvailableMins;
  }

  return {
    output,
    workforce,
    efficiency:
      producedMins > 0 && availableMins > 0 ? (producedMins / availableMins) * 100 : null,
    productivity: workforce > 0 && output > 0 ? output / workforce : null,
  };
}

function aggregateDeptDayKpi(
  rows: DailyKpiRpcRow[],
): Pick<
  DayResourceHourReport['kpi'],
  'target' | 'dhu' | 'wip'
> {
  let target = 0;
  let wip = 0;
  let dhuSum = 0;
  let dhuWeight = 0;

  for (const row of rows) {
    target += row.daily_target || 0;
    wip += row.wip_qty || 0;
    if (row.dhu != null) {
      const weight = row.daily_output > 0 ? row.daily_output : 1;
      dhuSum += Number(row.dhu) * weight;
      dhuWeight += weight;
    }
  }

  return {
    target,
    wip,
    dhu: dhuWeight > 0 ? Math.round(dhuSum / dhuWeight) : null,
  };
}

/** Department day report: hourly_counts or inspection_sessions pivoted by resource × style × color. */
export async function fetchDayResourceHourReport(
  factoryId: string,
  date: string,
  departmentId: string,
  meta: ReportMeta,
  colorwayLabels: ColorwayLabel[],
): Promise<DayResourceHourReport> {
  const dept = meta.departments.find((d) => d.id === departmentId);
  const qcDept = isQcDept(dept?.apps ?? null);

  const orderMap = new Map(meta.orders.map((o) => [o.id, o]));
  const colorMap = new Map(colorwayLabels.map((c) => [c.id, c]));
  const resourceMap = new Map(meta.resources.map((r) => [r.id, r]));
  const shiftRowMaps = new Map<string, Map<string, DayResourceHourRow>>();
  const shiftDataSlots = new Map<string, Set<string>>();

  const ensureShiftRowMap = (shiftId: string): Map<string, DayResourceHourRow> => {
    if (!shiftRowMaps.has(shiftId)) shiftRowMaps.set(shiftId, new Map());
    return shiftRowMaps.get(shiftId)!;
  };

  const trackShiftSlot = (shiftId: string, hourSlot: string) => {
    if (!shiftDataSlots.has(shiftId)) shiftDataSlots.set(shiftId, new Set());
    shiftDataSlots.get(shiftId)!.add(hourSlot);
  };

  const emptyRow = (
    resourceId: string,
    orderId: string,
    colorwayId: string | null,
  ): DayResourceHourRow => {
    const order = orderMap.get(orderId);
    const resource = resourceId ? resourceMap.get(resourceId) : undefined;
    return {
      resourceId,
      resourceName: resource?.name || '—',
      orderId,
      styleName: order?.styleName || orderId.slice(0, 8),
      styleRef: order?.styleRef || '',
      buyerName: order?.buyerName || '',
      poNumber: order?.poNumber || '',
      colorwayId,
      colorName: colorwayDisplayLabel(colorwayId, colorMap),
      hours: {},
      hourTargets: {},
      hourlyTarget: 0,
      total: 0,
      workforce: null,
      workforceBreakdown: [],
      producedMins: 0,
      resourceAvailableMins: 0,
      daysRunning: null,
      plannedEndDate: null,
      efficiencyPct: null,
      productivity: null,
    };
  };

  const ingestCapture = (
    shifts: Shift[],
    resourceId: string,
    orderId: string,
    colorwayId: string | null,
    hourSlot: string,
    count: number,
    storedShiftId: string | null,
  ) => {
    if (!hourSlot || count <= 0) return;
    const shiftId = resolveShiftIdForSlot(shifts, hourSlot, storedShiftId);
    trackShiftSlot(shiftId, hourSlot);
    const rowMap = ensureShiftRowMap(shiftId);
    const key = `${resourceId}|${orderId}|${colorwayId ?? ''}`;
    const row = rowMap.get(key) ?? emptyRow(resourceId, orderId, colorwayId);
    row.shiftId = shiftId;
    row.logDate = date;
    row.hours[hourSlot] = (row.hours[hourSlot] || 0) + count;
    row.total += count;
    rowMap.set(key, row);
  };

  let captureRows: Array<Record<string, unknown>> = [];
  if (qcDept) {
    const { data, error } = await supabase
      .from('inspection_sessions')
      .select('order_id, colorway_id, resource_id, hour_slot, shift_id, passed, rework_passed')
      .eq('factory_id', factoryId)
      .eq('department_id', departmentId)
      .eq('log_date', date);
    if (error) throw error;
    captureRows = data || [];
  } else {
    const { data, error } = await supabase
      .from('hourly_counts')
      .select('order_id, colorway_id, resource_id, hour_slot, shift_id, count')
      .eq('factory_id', factoryId)
      .eq('department_id', departmentId)
      .eq('log_date', date);
    if (error) throw error;
    captureRows = data || [];
  }

  const [kpiRows, qcRes, shiftRes, workforceRes] = await Promise.all([
    fetchDepartmentKpis(factoryId, departmentId, date, date),
    qcDept
      ? supabase
          .from('inspection_sessions')
          .select('total_inspected, passed, rework_passed')
          .eq('factory_id', factoryId)
          .eq('department_id', departmentId)
          .eq('log_date', date)
      : Promise.resolve({ data: null, error: null }),
    supabase.from('shifts').select('id, name, type, hours, productive_mins').eq('factory_id', factoryId),
    supabase
      .from('workforce_logs')
      .select('resource_id, headcount_by_category')
      .eq('factory_id', factoryId)
      .eq('department_id', departmentId)
      .eq('log_date', date),
  ]);

  if (qcRes.error) throw qcRes.error;
  if (shiftRes.error) throw shiftRes.error;
  if (workforceRes.error) throw workforceRes.error;

  const kpiRes = { data: kpiRows, error: null as null };

  const shifts = (shiftRes.data || []).map((s) => mapShiftRow(s as Record<string, unknown>));

  for (const raw of captureRows) {
    const orderId = raw.order_id as string;
    const colorwayId = (raw.colorway_id as string) || null;
    const resourceId = (raw.resource_id as string) || '';
    const hourSlot = String(raw.hour_slot ?? '');
    const count = qcDept
      ? qcSessionOutputQty(raw)
      : Number(raw.count) || 0;
    ingestCapture(
      shifts,
      resourceId,
      orderId,
      colorwayId,
      hourSlot,
      count,
      (raw.shift_id as string) || null,
    );
  }

  const hourColumns = allActiveHourSlots(shifts);
  const regularShiftHours = getRegularShiftHours(shifts);
  let productiveMinsPerWorker = regularShiftProductiveMins(shifts);
  if (productiveMinsPerWorker <= 0) {
    for (const raw of shiftRes.data || []) {
      const pm = Number((raw as { productive_mins?: number }).productive_mins);
      if (pm > 0) {
        productiveMinsPerWorker = pm;
        break;
      }
    }
  }
  if (productiveMinsPerWorker <= 0) productiveMinsPerWorker = 480;

  const shiftIds =
    shiftRowMaps.size > 0
      ? sortShiftIds(shifts, [...shiftRowMaps.keys()])
      : [UNASSIGNED_SHIFT];

  const shiftSections: DayShiftHourSection[] = [];
  for (const shiftId of shiftIds) {
    const rowMap = shiftRowMaps.get(shiftId) ?? new Map<string, DayResourceHourRow>();
    const sectionHourColumns = hourColumnsForShift(
      shifts,
      shiftId,
      shiftDataSlots.get(shiftId) ?? new Set(),
    );
    const sectionRows = [...rowMap.values()].sort(
      (a, b) =>
        a.resourceName.localeCompare(b.resourceName) ||
        a.styleName.localeCompare(b.styleName) ||
        a.colorName.localeCompare(b.colorName),
    );
    for (const row of sectionRows) {
      row.logDate = date;
    }
    shiftSections.push({
      shiftId,
      shiftName: shiftDisplayName(shifts, shiftId),
      hourColumns: sectionHourColumns,
      rows: sectionRows,
    });
  }

  const rows = shiftSections.flatMap((s) => s.rows);
  const displayHourColumns =
    shiftSections.length === 1 ? shiftSections[0].hourColumns : hourColumns;

  const orderIds = [...new Set(rows.map((r) => r.orderId))];
  const sewingSamByOrder = new Map<string, number>();
  const samByAllocKey = new Map<string, number>();
  let allocPlanRows: AllocPlanRow[] = [];

  if (orderIds.length > 0) {
    allocPlanRows = await fetchLineAllocPlanRows(factoryId, orderIds);

    const { data: samRows, error: samErr } = await supabase
      .from('style_orders')
      .select('id, sewing_sam')
      .eq('factory_id', factoryId)
      .in('id', orderIds);
    if (samErr) throw samErr;
    for (const raw of samRows || []) {
      sewingSamByOrder.set(raw.id as string, Number(raw.sewing_sam) || 0);
    }

    for (const alloc of allocPlanRows) {
      const start = alloc.start_date?.split('T')[0] ?? null;
      const end = alloc.end_date?.split('T')[0] ?? null;
      if (start && date < start) continue;
      if (end && date > end) continue;
      const plannedSam = allocationSamValue({
        sam: alloc.sam,
        kpi_inputs: alloc.kpi_inputs,
      });
      if (plannedSam <= 0) continue;
      const key = allocRowKey(alloc.order_id, alloc.colorway_id, alloc.line_id);
      samByAllocKey.set(key, plannedSam);
    }
  }

  const resourceWorkforce = buildResourceWorkforceDetails(
    (workforceRes.data || []) as Array<Record<string, unknown>>,
  );

  for (const section of shiftSections) {
    enrichDayResourceRows(
      section.rows,
      samByAllocKey,
      sewingSamByOrder,
      resourceWorkforce,
      productiveMinsPerWorker,
    );
    applyAllocationPlanToDayRows(
      section.rows,
      allocPlanRows,
      date,
      section.hourColumns,
      regularShiftHours,
      departmentId,
    );
  }

  const tableOutput = rows.reduce((sum, r) => sum + r.total, 0);
  const deptMetrics = computeDayDeptMetricsFromRows(rows);

  const kpiBase = aggregateDeptDayKpi((kpiRes.data || []) as DailyKpiRpcRow[]);
  const handover = await fetchDayDeptHandoverSummary(
    factoryId,
    date,
    departmentId,
    meta,
    colorwayLabels,
  );
  const kpi: DayResourceHourReport['kpi'] = {
    ...kpiBase,
    output: tableOutput,
    efficiency: deptMetrics.efficiency,
    productivity: deptMetrics.productivity,
  };

  if (qcDept && qcRes.data) {
    let inspected = 0;
    let passed = 0;
    for (const row of qcRes.data) {
      inspected += Number(row.total_inspected) || 0;
      passed += qcSessionOutputQty(row);
    }
    kpi.inspected = inspected;
    kpi.passed = passed;
    kpi.passPct = inspected > 0 ? (passed / inspected) * 100 : null;
  }

  return {
    isQcDept: qcDept,
    hourColumns: displayHourColumns,
    rows,
    shiftSections,
    productiveMinsPerWorker,
    kpi,
    handover,
    handoverByDay: [{ date, handover }],
  };
}

/** Department day report across a date range (one row set per day with logDate). */
export async function fetchDayResourceHourReportRange(
  factoryId: string,
  dateFrom: string,
  dateTo: string,
  departmentId: string,
  meta: ReportMeta,
  colorwayLabels: ColorwayLabel[],
): Promise<DayResourceHourReport> {
  const days = listDatesInRange(dateFrom, dateTo);
  if (days.length === 0) {
    return fetchDayResourceHourReport(
      factoryId,
      format(new Date(), 'yyyy-MM-dd'),
      departmentId,
      meta,
      colorwayLabels,
    );
  }
  if (days.length === 1) {
    return fetchDayResourceHourReport(
      factoryId,
      days[0],
      departmentId,
      meta,
      colorwayLabels,
    );
  }

  const dailyReports = await Promise.all(
    days.map((date) =>
      fetchDayResourceHourReport(factoryId, date, departmentId, meta, colorwayLabels),
    ),
  );

  const handoverByDay = days.map((date, i) => ({
    date,
    handover: dailyReports[i].handover ?? { received: [], sent: [] },
  }));
  const handover = mergeHandoverSummaries(handoverByDay.map((d) => d.handover));

  const shiftSections = mergeShiftSectionsFromDailyReports(dailyReports, days);
  const rows = shiftSections.flatMap((s) => s.rows);

  const hourColumns =
    shiftSections.length === 1
      ? shiftSections[0].hourColumns
      : dailyReports[0]?.hourColumns ?? [];
  const isQcDept = dailyReports[0]?.isQcDept ?? false;
  const productiveMinsPerWorker = dailyReports[0]?.productiveMinsPerWorker ?? 480;
  const deptMetrics = computeDayDeptMetricsFromRows(rows);

  let inspected = 0;
  let passed = 0;
  let target = 0;
  let wip = 0;
  let dhuSum = 0;
  let dhuWeight = 0;

  for (const report of dailyReports) {
    target += report.kpi.target || 0;
    wip = report.kpi.wip ?? wip;
    if (report.kpi.dhu != null) {
      const w = report.kpi.output > 0 ? report.kpi.output : 1;
      dhuSum += (report.kpi.dhu || 0) * w;
      dhuWeight += w;
    }
    if (report.isQcDept) {
      inspected += report.kpi.inspected ?? 0;
      passed += report.kpi.passed ?? 0;
    }
  }

  const kpi: DayResourceHourReport['kpi'] = {
    target,
    wip,
    dhu: dhuWeight > 0 ? Math.round(dhuSum / dhuWeight) : null,
    output: deptMetrics.output,
    efficiency: deptMetrics.efficiency,
    productivity: deptMetrics.productivity,
  };

  if (isQcDept) {
    kpi.inspected = inspected;
    kpi.passed = passed;
    kpi.passPct = inspected > 0 ? (passed / inspected) * 100 : null;
  }

  return {
    isQcDept,
    hourColumns,
    rows,
    shiftSections,
    productiveMinsPerWorker,
    kpi,
    handover,
    handoverByDay,
  };
}

export interface DeptDailyTrendRow {
  date: string;
  output: number;
  target: number;
  efficiency: number | null;
  dhu: number | null;
}

export interface DeptStyleSummaryRow {
  orderId: string;
  styleName: string;
  poNumber: string;
  totalOutput: number;
  totalTarget: number;
  avgEfficiency: number | null;
  avgDhu: number | null;
  currentWip: number;
  daysActive: number;
  resourceBreakdown: Array<{
    resourceId: string;
    resourceName: string;
    output: number;
    efficiency: number | null;
  }>;
}

export interface DeptResourceStyleRow {
  resourceId: string;
  resourceName: string;
  orderId: string;
  styleName: string;
  poNumber: string;
  output: number;
  styleEfficiency: number | null;
}

export function flattenDeptResourceStyleRows(
  styleRows: DeptStyleSummaryRow[],
): DeptResourceStyleRow[] {
  const out: DeptResourceStyleRow[] = [];
  for (const style of styleRows) {
    if (style.resourceBreakdown.length === 0) {
      out.push({
        resourceId: '',
        resourceName: '—',
        orderId: style.orderId,
        styleName: style.styleName,
        poNumber: style.poNumber,
        output: style.totalOutput,
        styleEfficiency: style.avgEfficiency,
      });
      continue;
    }
    for (const res of style.resourceBreakdown) {
      out.push({
        resourceId: res.resourceId,
        resourceName: res.resourceName,
        orderId: style.orderId,
        styleName: style.styleName,
        poNumber: style.poNumber,
        output: res.output,
        styleEfficiency: style.avgEfficiency,
      });
    }
  }
  return out.sort(
    (a, b) =>
      b.output - a.output ||
      a.resourceName.localeCompare(b.resourceName) ||
      a.styleName.localeCompare(b.styleName),
  );
}

export interface DeptPeriodReport {
  dailyTrend: DeptDailyTrendRow[];
  styleRows: DeptStyleSummaryRow[];
  kpiSummary: {
    totalOutput: number;
    avgDailyOutput: number;
    avgEfficiency: number | null;
    avgDhu: number | null;
    currentWip: number;
  };
}

/** Department period report: daily trend, per-style summary, and resource breakdown. */
export async function fetchDeptPeriodReport(
  factoryId: string,
  departmentId: string,
  dateFrom: string,
  dateTo: string,
  meta: ReportMeta,
): Promise<DeptPeriodReport> {
  const kpiRows = await fetchDepartmentKpis(factoryId, departmentId, dateFrom, dateTo);
  const orderMap = new Map(meta.orders.map((o) => [o.id, o]));
  const resourceMap = new Map(meta.resources.map((r) => [r.id, r]));

  const byDate = new Map<string, {
    output: number;
    target: number;
    effSum: number;
    effCount: number;
    dhuSum: number;
    dhuWeight: number;
  }>();

  const byOrder = new Map<string, {
    orderId: string;
    output: number;
    target: number;
    effSum: number;
    effCount: number;
    dhuSum: number;
    dhuWeight: number;
    dates: Set<string>;
    wipByDate: Map<string, number>;
  }>();

  for (const row of kpiRows) {
    const dateAgg = byDate.get(row.log_date) ?? {
      output: 0, target: 0, effSum: 0, effCount: 0, dhuSum: 0, dhuWeight: 0,
    };
    dateAgg.output += row.daily_output || 0;
    dateAgg.target += row.daily_target || 0;
    if (row.daily_efficiency_pct != null) {
      dateAgg.effSum += Number(row.daily_efficiency_pct);
      dateAgg.effCount += 1;
    }
    if (row.dhu != null) {
      const weight = row.daily_output > 0 ? row.daily_output : 1;
      dateAgg.dhuSum += Number(row.dhu) * weight;
      dateAgg.dhuWeight += weight;
    }
    byDate.set(row.log_date, dateAgg);

    const orderAgg = byOrder.get(row.order_id) ?? {
      orderId: row.order_id,
      output: 0,
      target: 0,
      effSum: 0,
      effCount: 0,
      dhuSum: 0,
      dhuWeight: 0,
      dates: new Set<string>(),
      wipByDate: new Map<string, number>(),
    };
    orderAgg.output += row.daily_output || 0;
    orderAgg.target += row.daily_target || 0;
    orderAgg.dates.add(row.log_date);
    orderAgg.wipByDate.set(row.log_date, (orderAgg.wipByDate.get(row.log_date) || 0) + (row.wip_qty || 0));
    if (row.daily_efficiency_pct != null) {
      orderAgg.effSum += Number(row.daily_efficiency_pct);
      orderAgg.effCount += 1;
    }
    if (row.dhu != null) {
      const weight = row.daily_output > 0 ? row.daily_output : 1;
      orderAgg.dhuSum += Number(row.dhu) * weight;
      orderAgg.dhuWeight += weight;
    }
    byOrder.set(row.order_id, orderAgg);
  }

  const dailyTrend: DeptDailyTrendRow[] = [...byDate.entries()]
    .map(([date, agg]) => ({
      date,
      output: agg.output,
      target: agg.target,
      efficiency: agg.effCount
        ? agg.effSum / agg.effCount
        : agg.target > 0
          ? (agg.output / agg.target) * 100
          : null,
      dhu: agg.dhuWeight > 0 ? Math.round(agg.dhuSum / agg.dhuWeight) : null,
    }))
    .sort((a, b) => a.date.localeCompare(b.date));

  const { data: hourlyData, error: hourlyError } = await supabase
    .from('hourly_counts')
    .select('order_id, resource_id, count')
    .eq('factory_id', factoryId)
    .eq('department_id', departmentId)
    .gte('log_date', dateFrom)
    .lte('log_date', dateTo);

  if (hourlyError) throw hourlyError;

  const resourceByOrder = new Map<string, Map<string, number>>();
  for (const raw of hourlyData || []) {
    const orderId = raw.order_id as string;
    const resourceId = (raw.resource_id as string) || '';
    const count = Number(raw.count) || 0;
    const orderResources = resourceByOrder.get(orderId) ?? new Map<string, number>();
    orderResources.set(resourceId, (orderResources.get(resourceId) || 0) + count);
    resourceByOrder.set(orderId, orderResources);
  }

  const latestDate = dailyTrend.length > 0 ? dailyTrend[dailyTrend.length - 1].date : null;
  let currentWipTotal = 0;
  if (latestDate) {
    for (const row of kpiRows) {
      if (row.log_date === latestDate) currentWipTotal += row.wip_qty || 0;
    }
  }

  const styleRows: DeptStyleSummaryRow[] = [...byOrder.values()]
    .map((agg) => {
      const order = orderMap.get(agg.orderId);
      const latestWipDate = [...agg.wipByDate.keys()].sort().pop();
      const resources = resourceByOrder.get(agg.orderId);
      const resourceBreakdown = resources
        ? [...resources.entries()]
            .map(([resourceId, output]) => ({
              resourceId,
              resourceName: resourceMap.get(resourceId)?.name || '—',
              output,
              efficiency: null,
            }))
            .sort((a, b) => b.output - a.output)
        : [];

      return {
        orderId: agg.orderId,
        styleName: order?.styleName || agg.orderId.slice(0, 8),
        poNumber: order?.poNumber || '',
        totalOutput: agg.output,
        totalTarget: agg.target,
        avgEfficiency: agg.effCount
          ? agg.effSum / agg.effCount
          : agg.target > 0
            ? (agg.output / agg.target) * 100
            : null,
        avgDhu: agg.dhuWeight > 0 ? Math.round(agg.dhuSum / agg.dhuWeight) : null,
        currentWip: latestWipDate ? agg.wipByDate.get(latestWipDate) || 0 : 0,
        daysActive: agg.dates.size,
        resourceBreakdown,
      };
    })
    .sort((a, b) => b.totalOutput - a.totalOutput);

  const totalOutput = dailyTrend.reduce((s, d) => s + d.output, 0);
  const dayCount = dailyTrend.length || 1;
  let effSum = 0;
  let effCount = 0;
  let dhuSum = 0;
  let dhuWeight = 0;
  for (const d of dailyTrend) {
    if (d.efficiency != null) {
      effSum += d.efficiency;
      effCount += 1;
    }
    if (d.dhu != null) {
      const weight = d.output > 0 ? d.output : 1;
      dhuSum += d.dhu * weight;
      dhuWeight += weight;
    }
  }

  return {
    dailyTrend,
    styleRows,
    kpiSummary: {
      totalOutput,
      avgDailyOutput: totalOutput / dayCount,
      avgEfficiency: effCount ? effSum / effCount : null,
      avgDhu: dhuWeight > 0 ? Math.round(dhuSum / dhuWeight) : null,
      currentWip: currentWipTotal,
    },
  };
}

export interface StyleJourneyDept {
  deptId: string;
  deptName: string;
  flowStep: number;
  isQcDept: boolean;
  isAuditDept: boolean;
  produced: number;
  sent: number;
  received: number;
  remaining: number;
  wip: number;
  status: 'not_started' | 'in_progress' | 'complete';
  completedAt: string | null;
  startDate: string | null;
  endDate: string | null;
  /** SAM from line_allocations.sam for this department. */
  plannedSam: number | null;
  lineBreakdown: Array<{
    resourceId: string;
    resourceName: string;
    produced: number;
    completedAt: string | null;
  }>;
}

export interface StyleJourneyReport {
  order: {
    id: string;
    styleName: string;
    styleRef: string | null;
    buyerName: string | null;
    poNumber: string;
    orderQty: number;
    adjQty: number;
    orderDate: string | null;
    deliveryDate: string | null;
    jobCardDate: string | null;
    sewingSam: number | null;
    /** @deprecated use sewingSam */
    sam: number | null;
    priority: string | null;
    status: string;
    garmentType: string | null;
    washType: string | null;
    sizeGroupName: string | null;
    sizeLabels: string | null;
    processFlowName: string | null;
    cuttingAllowance: number | null;
    shipmentAllowance: number | null;
    remarks: string | null;
    imageUrl: string | null;
  };
  colorways: Array<{
    id: string;
    name: string;
    colorCode: string | null;
    qty: number;
  }>;
  flowDepts: StyleJourneyDept[];
  shipmentSummary: {
    shippedQty: number;
    rejectedQty: number;
    balance: number;
    shipments: FulfillmentShipmentRow[];
    rejections: FulfillmentRejectionRow[];
    audits: FulfillmentAuditRow[];
  };
  deptAudits: StyleDeptAuditGroup[];
}

export interface StyleDeptAuditSessionRow {
  date: string;
  lotSize: number;
  sampleSize: number;
  aqlLevel: string | null;
  passed: number;
  failed: number;
  majorFailed: number;
  minorFailed: number;
  result: string | null;
}

export interface StyleDeptAuditGroup {
  deptId: string;
  deptName: string;
  sessions: StyleDeptAuditSessionRow[];
}

function deriveDeptStatus(
  produced: number,
  lineRows: StyleJourneyDept['lineBreakdown'],
): StyleJourneyDept['status'] {
  if (produced <= 0) return 'not_started';
  if (lineRows.length > 0 && lineRows.every((l) => l.completedAt != null)) return 'complete';
  if (lineRows.some((l) => l.completedAt != null)) return 'complete';
  return 'in_progress';
}

/** Style lifecycle journey: process flow, line breakdown, and shipment summary. */
export async function fetchStyleJourneyReport(
  factoryId: string,
  orderId: string,
  colorwayId: string | null,
): Promise<StyleJourneyReport> {
  const [orderRes, colorwayRes, journeyRows, deptRes] = await Promise.all([
    supabase
      .from('style_orders')
      .select(
        `id, style_name, style_ref, buyer_name, po_number, order_qty, adj_qty,
        order_date, delivery_date, job_card_date, sewing_sam, priority, status, garment_type, image_url,
        size_group_name, size_labels,
        wash_type, cutting_allowance, shipment_allowance, remarks,
        process_flows(name)`,
      )
      .eq('factory_id', factoryId)
      .eq('id', orderId)
      .maybeSingle(),
    supabase
      .from('colorways')
      .select('id, name, color_code, qty')
      .eq('order_id', orderId)
      .order('name'),
    fetchCutToShipJourney(factoryId, orderId, colorwayId),
    supabase.from('departments').select('id, name, apps').eq('factory_id', factoryId),
  ]);

  if (orderRes.error) throw orderRes.error;
  if (colorwayRes.error) throw colorwayRes.error;
  if (deptRes.error) throw deptRes.error;
  if (!orderRes.data) throw new Error('Order not found');

  const deptApps = new Map(
    (deptRes.data || []).map((d) => [d.id as string, parseDeptApps(d.apps)]),
  );
  const deptMeta = (deptRes.data || []).map((d) => ({
    id: d.id as string,
    name: (d.name as string) || '',
    apps: parseDeptApps(d.apps),
  }));

  let allocQuery = supabase
    .from('line_allocations')
    .select(
      'line_id, department_id, start_date, end_date, production_produced_qty, production_completed_at, sam, kpi_inputs',
    )
    .eq('factory_id', factoryId)
    .eq('order_id', orderId);
  if (colorwayId) allocQuery = allocQuery.eq('colorway_id', colorwayId);

  let shipQuery = supabase
    .from('shipments')
    .select('shipment_date, shipped_qty, shipped_qty_by_size, invoice_number, shipment_type')
    .eq('factory_id', factoryId)
    .eq('order_id', orderId)
    .order('shipment_date', { ascending: false });
  if (colorwayId) shipQuery = shipQuery.eq('colorway_id', colorwayId);

  let rejQuery = supabase
    .from('rejections')
    .select('rejected_date, qty, size, stage, reason_code, reason_detail')
    .eq('factory_id', factoryId)
    .eq('order_id', orderId)
    .order('rejected_date', { ascending: false });
  if (colorwayId) rejQuery = rejQuery.eq('colorway_id', colorwayId);

  const [allocRes, shipRes, rejRes, resourceRes, audits, deptAudits] = await Promise.all([
    allocQuery,
    shipQuery,
    rejQuery,
    supabase
      .from('assigned_resources')
      .select('id, resource_name')
      .eq('factory_id', factoryId)
      .eq('status', 'active'),
    fetchFulfillmentAudits(factoryId, orderId, colorwayId).catch(() => [] as FulfillmentAuditRow[]),
    fetchStyleOrderDeptAudits(factoryId, orderId, colorwayId, deptMeta).catch(
      () => [] as StyleDeptAuditGroup[],
    ),
  ]);

  if (allocRes.error) throw allocRes.error;
  if (shipRes.error) throw shipRes.error;
  if (rejRes.error) throw rejRes.error;
  if (resourceRes.error) throw resourceRes.error;

  const resourceMap = new Map(
    (resourceRes.data || []).map((r) => [r.id as string, (r.resource_name as string) || '']),
  );

  const allocByDept = new Map<string, StyleJourneyDept['lineBreakdown']>();
  const allocDatesByDept = new Map<string, { startDate: string | null; endDate: string | null }>();
  const samByDept = new Map<string, number>();

  for (const raw of allocRes.data || []) {
    const deptId = raw.department_id as string;
    const allocSam = allocationSamValue({
      sam: raw.sam as number | null,
      kpi_inputs: raw.kpi_inputs as { sam?: number } | null,
    });
    if (allocSam > 0 && !samByDept.has(deptId)) samByDept.set(deptId, allocSam);
    const resourceId = (raw.line_id as string) || '';
    const produced = Number(raw.production_produced_qty) || 0;
    const completedAt = (raw.production_completed_at as string) || null;
    const startRaw = (raw.start_date as string) || null;
    const endRaw = (raw.end_date as string) || null;

    const dates = allocDatesByDept.get(deptId) ?? { startDate: null, endDate: null };
    if (startRaw && (!dates.startDate || startRaw < dates.startDate)) dates.startDate = startRaw;
    if (endRaw && (!dates.endDate || endRaw > dates.endDate)) dates.endDate = endRaw;
    allocDatesByDept.set(deptId, dates);

    const lines = allocByDept.get(deptId) ?? [];
    const existing = lines.find((l) => l.resourceId === resourceId);
    if (existing) {
      existing.produced += produced;
      if (completedAt && (!existing.completedAt || completedAt > existing.completedAt)) {
        existing.completedAt = completedAt;
      }
    } else {
      lines.push({
        resourceId,
        resourceName: resourceMap.get(resourceId) || '—',
        produced,
        completedAt,
      });
    }
    allocByDept.set(deptId, lines);
  }

  const journeyByDept = new Map<string, {
    deptId: string;
    deptName: string;
    flowStep: number;
    produced: number;
    sent: number;
    received: number;
    wip: number;
  }>();

  for (const row of journeyRows) {
    if (!row.is_in_flow) continue;
    const cur = journeyByDept.get(row.dept_id) ?? {
      deptId: row.dept_id,
      deptName: row.dept_name,
      flowStep: row.flow_step ?? 0,
      produced: 0,
      sent: 0,
      received: 0,
      wip: 0,
    };
    cur.produced += row.qty_produced ?? 0;
    cur.sent += row.qty_sent ?? 0;
    cur.received += row.qty_received ?? 0;
    cur.wip += row.wip_qty ?? 0;
    if (row.flow_step != null && row.flow_step > cur.flowStep) cur.flowStep = row.flow_step;
    journeyByDept.set(row.dept_id, cur);
  }

  const maxFlowStep = Math.max(0, ...[...journeyByDept.values()].map((d) => d.flowStep));

  const flowDepts: StyleJourneyDept[] = [...journeyByDept.values()]
    .map((d) => {
      const lineBreakdown = (allocByDept.get(d.deptId) ?? []).sort(
        (a, b) => b.produced - a.produced,
      );
      const isLast = d.flowStep === maxFlowStep;
      const remaining = isLast ? Math.max(0, d.produced - d.sent) : Math.max(0, d.produced - d.sent);
      const completedAt = lineBreakdown.reduce<string | null>((latest, line) => {
        if (!line.completedAt) return latest;
        if (!latest || line.completedAt > latest) return line.completedAt;
        return latest;
      }, null);

      const dates = allocDatesByDept.get(d.deptId);
      return {
        deptId: d.deptId,
        deptName: d.deptName,
        flowStep: d.flowStep,
        isQcDept: isQcDept(deptApps.get(d.deptId) ?? null),
        isAuditDept: isAuditDept(deptApps.get(d.deptId) ?? null),
        produced: d.produced,
        sent: d.sent,
        received: d.received,
        remaining,
        wip: d.wip,
        status: deriveDeptStatus(d.produced, lineBreakdown),
        completedAt,
        startDate: dates?.startDate?.split('T')[0] ?? null,
        endDate: dates?.endDate?.split('T')[0] ?? null,
        plannedSam: samByDept.get(d.deptId) ?? null,
        lineBreakdown,
      };
    })
    .sort((a, b) => a.flowStep - b.flowStep);

  const shipments: FulfillmentShipmentRow[] = (shipRes.data || []).map((s) => ({
    date: String(s.shipment_date ?? ''),
    qty: Number(s.shipped_qty) || 0,
    invoiceNumber: (s.invoice_number as string) || null,
    shipmentType: String(s.shipment_type ?? ''),
    qtyBySize: parseSizeQtyMap(s.shipped_qty_by_size),
  }));

  const rejections: FulfillmentRejectionRow[] = (rejRes.data || []).map((r) => ({
    date: String(r.rejected_date ?? ''),
    qty: Number(r.qty) || 0,
    size: (r.size as string) || null,
    stage: String(r.stage ?? ''),
    reasonCode: String(r.reason_code ?? ''),
    reasonDetail: (r.reason_detail as string) || null,
  }));

  const shippedQty = shipments.reduce((s, row) => s + row.qty, 0);
  const rejectedQty = rejections.reduce((s, row) => s + row.qty, 0);
  const orderQty = Number(orderRes.data.order_qty) || 0;

  const o = orderRes.data;
  const processFlow = o.process_flows as { name?: string } | null;
  return {
    order: {
      id: o.id as string,
      styleName: (o.style_name as string) || '',
      styleRef: (o.style_ref as string) || null,
      buyerName: (o.buyer_name as string) || null,
      poNumber: (o.po_number as string) || '',
      orderQty,
      adjQty: Number(o.adj_qty) || 0,
      orderDate: (o.order_date as string) || null,
      deliveryDate: (o.delivery_date as string) || null,
      jobCardDate: (o.job_card_date as string) || null,
      sewingSam: o.sewing_sam != null ? Number(o.sewing_sam) : null,
      sam: o.sewing_sam != null ? Number(o.sewing_sam) : null,
      priority: (o.priority as string) || 'normal',
      status: (o.status as string) || '',
      garmentType: (o.garment_type as string) || null,
      washType: (o.wash_type as string) || null,
      sizeGroupName: (o.size_group_name as string) || null,
      sizeLabels: (o.size_labels as string) || null,
      processFlowName: processFlow?.name || null,
      cuttingAllowance: o.cutting_allowance != null ? Number(o.cutting_allowance) : null,
      shipmentAllowance: o.shipment_allowance != null ? Number(o.shipment_allowance) : null,
      remarks: (o.remarks as string) || null,
      imageUrl: (o.image_url as string) || null,
    },
    colorways: (colorwayRes.data || []).map((cw) => ({
      id: cw.id as string,
      name: (cw.name as string) || '',
      colorCode: (cw.color_code as string) || null,
      qty: Number(cw.qty) || 0,
    })),
    flowDepts,
    shipmentSummary: {
      shippedQty,
      rejectedQty,
      balance: orderQty - shippedQty - rejectedQty,
      shipments,
      rejections,
      audits,
    },
    deptAudits,
  };
}

export interface StyleDeptDailyRow {
  date: string;
  deptId: string;
  deptName: string;
  output: number;
  target: number;
  dailyAvailableMins: number;
  efficiency: number | null;
  productivity: number | null;
  dhu: number | null;
  defectivePct: number | null;
}

/** Floor AQL audit sessions grouped by production department. */
export async function fetchStyleOrderDeptAudits(
  factoryId: string,
  orderId: string,
  colorwayId: string | null,
  deptMeta: Array<{ id: string; name: string; apps: string[] | null }>,
): Promise<StyleDeptAuditGroup[]> {
  const auditDeptIds = new Set(
    deptMeta.filter((d) => isAuditDept(d.apps)).map((d) => d.id),
  );
  if (auditDeptIds.size === 0) return [];

  let query = supabase
    .from('audit_sessions')
    .select(
      'department_id, logged_at, completed_at, lot_size, sample_size, aql_level, passed, failed, major_failed, minor_failed, result, status, departments(name)',
    )
    .eq('factory_id', factoryId)
    .eq('order_id', orderId)
    .eq('status', 'completed')
    .order('logged_at', { ascending: false });
  // Floor AQL audit_sessions are order-scoped (no colorway_id column).

  const { data, error } = await query;
  if (error) {
    const code = String(error.code ?? '');
    const msg = String(error.message ?? '');
    if (
      code === '42501' ||
      code === '42P01' ||
      code === 'PGRST205' ||
      msg.includes('permission denied') ||
      msg.includes('does not exist')
    ) {
      return [];
    }
    throw error;
  }

  const deptNameMap = new Map(deptMeta.map((d) => [d.id, d.name]));
  const byDept = new Map<string, StyleDeptAuditSessionRow[]>();

  for (const raw of data || []) {
    const deptId = raw.department_id as string;
    if (!auditDeptIds.has(deptId)) continue;
    const dateRaw =
      (raw.completed_at as string) ||
      (raw.logged_at as string) ||
      '';
    const session: StyleDeptAuditSessionRow = {
      date: dateRaw.split('T')[0],
      lotSize: Number(raw.lot_size) || 0,
      sampleSize: Number(raw.sample_size) || 0,
      aqlLevel: (raw.aql_level as string) || null,
      passed: Number(raw.passed) || 0,
      failed: Number(raw.failed) || 0,
      majorFailed: Number(raw.major_failed) || 0,
      minorFailed: Number(raw.minor_failed) || 0,
      result: (raw.result as string) || null,
    };
    const list = byDept.get(deptId) ?? [];
    list.push(session);
    byDept.set(deptId, list);
  }

  return [...byDept.entries()]
    .map(([deptId, sessions]) => ({
      deptId,
      deptName: deptNameMap.get(deptId) || (sessions.length > 0 ? deptId.slice(0, 8) : 'Department'),
      sessions,
    }))
    .filter((g) => g.sessions.length > 0)
    .sort((a, b) => a.deptName.localeCompare(b.deptName));
}

/** Shipment / buyer QA audits for an order (colorway-scoped via v_audit_colorway_summary). */
export async function fetchFulfillmentAudits(
  factoryId: string,
  orderId: string,
  colorwayId?: string | null,
): Promise<FulfillmentAuditRow[]> {
  let colorwayQuery = supabase
    .from('v_audit_colorway_summary')
    .select(
      `colorway_id, department_id, log_date,
      lots_total, lots_passed, lots_failed, lots_pass_pct,
      pieces_sampled, failed_pieces, defective_pct, dhu`,
    )
    .eq('factory_id', factoryId)
    .eq('order_id', orderId)
    .order('log_date', { ascending: false });
  if (colorwayId) colorwayQuery = colorwayQuery.eq('colorway_id', colorwayId);

  const { data: colorwayRows, error: colorwayError } = await colorwayQuery;
  if (!colorwayError && colorwayRows && colorwayRows.length > 0) {
    return colorwayRows.map((row) => {
      const piecesSampled = Number(row.pieces_sampled) || 0;
      const failedPieces = Number(row.failed_pieces) || 0;
      const lotsFailed = Number(row.lots_failed) || 0;
      const lotsTotal = Number(row.lots_total) || 0;
      return {
        id: `${row.colorway_id}-${row.department_id}-${row.log_date}`,
        date: String(row.log_date ?? ''),
        auditType: 'Audit',
        colorwayName: '',
        lotSize: lotsTotal,
        sampleSize: piecesSampled,
        aqlLevel: null,
        passed: Math.max(0, piecesSampled - failedPieces),
        failed: failedPieces,
        majorFailed: failedPieces,
        minorFailed: 0,
        result: lotsTotal > 0 && lotsFailed === 0 ? 'pass' : lotsFailed > 0 ? 'fail' : null,
        status: 'completed',
        notes: null,
      };
    });
  }

  if (colorwayError) {
    console.warn('v_audit_colorway_summary unavailable, falling back to shipment_audits', colorwayError);
  }

  let query = supabase
    .from('shipment_audits')
    .select(
      'id, audit_date, audit_type, lot_size, sample_size, aql_level, passed, failed, major_failed, minor_failed, result, status, notes, colorway_id, colorways(name)',
    )
    .eq('factory_id', factoryId)
    .eq('order_id', orderId)
    .eq('status', 'completed')
    .order('audit_date', { ascending: false });
  if (colorwayId) query = query.eq('colorway_id', colorwayId);

  const { data, error } = await query;
  if (error) {
    if (isMissingRelationError(error)) return [];
    throw error;
  }

  return (data || []).map((row) => ({
    id: String(row.id),
    date: String(row.audit_date ?? ''),
    auditType: String(row.audit_type ?? ''),
    colorwayName: String((row.colorways as { name?: string } | null)?.name ?? ''),
    lotSize: Number(row.lot_size) || 0,
    sampleSize: Number(row.sample_size) || 0,
    aqlLevel: (row.aql_level as string) || null,
    passed: Number(row.passed) || 0,
    failed: Number(row.failed) || 0,
    majorFailed: Number(row.major_failed) || 0,
    minorFailed: Number(row.minor_failed) || 0,
    result: (row.result as string) || null,
    status: String(row.status ?? ''),
    notes: (row.notes as string) || null,
  }));
}

function isMissingRelationError(error: { code?: string; message?: string }): boolean {
  const code = String(error.code ?? '');
  const msg = String(error.message ?? '');
  return (
    code === '42501' ||
    code === '42P01' ||
    code === 'PGRST205' ||
    code === 'PGRST116' ||
    msg.includes('permission denied') ||
    msg.includes('does not exist') ||
    msg.includes('Could not find') ||
    msg.includes('404')
  );
}

function isMissingColumnError(error: { code?: string; message?: string }): boolean {
  const code = String(error.code ?? '');
  const msg = String(error.message ?? '');
  return code === '42703' || msg.includes('does not exist') || msg.includes('column');
}

export interface StyleDeptDefectRow {
  name: string;
  count: number;
}

export interface StyleDeptQualitySummary {
  inspected: number;
  firstTimePass: number;
  reworkPass: number;
  ftrPct: number | null;
  avgDhu: number | null;
  avgDefectivePct: number | null;
  topDefects: StyleDeptDefectRow[];
  dailyDefective: Array<{ date: string; label: string; pct: number | null }>;
}

export interface StyleDeptAuditMetrics {
  totalAudits: number;
  passedAudits: number;
  failedAudits: number;
  passPct: number | null;
  defectivePct: number | null;
  majorDefectivePct: number | null;
  dhu: number | null;
  daily: Array<{
    label: string;
    passPct: number | null;
    defectivePct: number | null;
    majorDefectivePct: number | null;
    auditCount: number;
    passedCount: number;
    failedCount: number;
  }>;
}

function qcFirstTimePassFromRow(raw: Record<string, unknown>): number {
  const explicit = Number(raw.first_time_pass);
  if (!Number.isNaN(explicit) && explicit >= 0) return explicit;
  const passed = Number(raw.passed) || 0;
  const reworkPass = Number(raw.rework_passed ?? raw.rework_pass) || 0;
  return Math.max(passed - reworkPass, 0);
}

function mergeTopDefectsFromView(rows: unknown[]): StyleDeptDefectRow[] {
  const totals = new Map<string, number>();
  for (const raw of rows) {
    if (!raw) continue;
    if (Array.isArray(raw)) {
      for (const item of raw) {
        if (!item || typeof item !== 'object') continue;
        const name = String((item as { name?: string }).name ?? '').trim();
        const count = Number((item as { count?: number }).count) || 0;
        if (name && count > 0) totals.set(name, (totals.get(name) || 0) + count);
      }
    } else if (typeof raw === 'object') {
      for (const [name, count] of Object.entries(raw as Record<string, unknown>)) {
        const n = Number(count) || 0;
        if (n > 0) totals.set(name, (totals.get(name) || 0) + n);
      }
    }
  }
  return [...totals.entries()]
    .map(([name, count]) => ({ name, count }))
    .sort((a, b) => b.count - a.count)
    .slice(0, 7);
}

function aggregateQualityViewRows(
  rows: Array<Record<string, unknown>>,
): StyleDeptQualitySummary {
  let inspected = 0;
  let firstTimePass = 0;
  let reworkPass = 0;
  let dhuSum = 0;
  let dhuWeight = 0;
  let defSum = 0;
  let defWeight = 0;
  const byDate = new Map<string, { inspected: number; failed: number }>();
  const topDefectParts: unknown[] = [];

  for (const raw of rows) {
    const date = String(raw.log_date ?? '');
    const rowInspected = Number(raw.inspected) || 0;
    const rowFirst =
      Number(raw.first_time_pass) ||
      qcFirstTimePassFromRow({ passed: raw.passed, rework_pass: raw.rework_pass ?? raw.rework_passed });
    const rowRework = Number(raw.rework_pass ?? raw.rework_passed) || 0;
    const rowFailed = Number(raw.failed) || 0;

    inspected += rowInspected;
    firstTimePass += rowFirst;
    reworkPass += rowRework;

    if (raw.dhu != null && rowInspected > 0) {
      const dhu = Number(raw.dhu);
      if (!Number.isNaN(dhu)) {
        dhuSum += dhu * rowInspected;
        dhuWeight += rowInspected;
      }
    }
    if (raw.defective_pct != null && rowInspected > 0) {
      const def = Number(raw.defective_pct);
      if (!Number.isNaN(def)) {
        defSum += def * rowInspected;
        defWeight += rowInspected;
      }
    }

    if (date) {
      const cur = byDate.get(date) ?? { inspected: 0, failed: 0 };
      cur.inspected += rowInspected;
      cur.failed += rowFailed;
      byDate.set(date, cur);
    }
    if (raw.top_defects) topDefectParts.push(raw.top_defects);
  }

  const ftrPct = inspected > 0 ? (firstTimePass / inspected) * 100 : null;
  const dailyDefective = [...byDate.entries()]
    .sort(([a], [b]) => a.localeCompare(b))
    .map(([date, d]) => ({
      date,
      label: date.slice(5),
      pct: d.inspected > 0 ? (d.failed / d.inspected) * 100 : null,
    }));

  return {
    inspected,
    firstTimePass,
    reworkPass,
    ftrPct,
    avgDhu: dhuWeight > 0 ? dhuSum / dhuWeight : null,
    avgDefectivePct: defWeight > 0 ? defSum / defWeight : null,
    topDefects: mergeTopDefectsFromView(topDefectParts),
    dailyDefective,
  };
}

async function fetchStyleDeptTopDefectsFromSessions(
  factoryId: string,
  orderId: string,
  departmentId: string,
  dateFrom: string,
  dateTo: string,
  colorwayId?: string | null,
  resourceId?: string | null,
): Promise<StyleDeptDefectRow[]> {
  let query = supabase
    .from('inspection_sessions')
    .select('defect_summary')
    .eq('factory_id', factoryId)
    .eq('order_id', orderId)
    .eq('department_id', departmentId)
    .gte('log_date', dateFrom)
    .lte('log_date', dateTo);
  if (colorwayId) {
    const includeNull = await orderHasSingleColorway(orderId);
    query = applyColorwayCaptureFilter(query, colorwayId, includeNull);
  }
  if (resourceId) query = query.eq('resource_id', resourceId);

  const { data, error } = await query;
  if (error) throw error;
  return mergeTopDefectsFromView((data || []).map((r) => r.defect_summary));
}

async function fetchStyleDeptQualityFromSessions(
  factoryId: string,
  orderId: string,
  departmentId: string,
  dateFrom: string,
  dateTo: string,
  colorwayId?: string | null,
  resourceId?: string | null,
): Promise<StyleDeptQualitySummary> {
  let query = supabase
    .from('inspection_sessions')
    .select(
      'log_date, total_inspected, passed, rework_passed, first_time_pass, failed, defect_summary, dhu, defective_pct',
    )
    .eq('factory_id', factoryId)
    .eq('order_id', orderId)
    .eq('department_id', departmentId)
    .gte('log_date', dateFrom)
    .lte('log_date', dateTo);
  if (colorwayId) {
    const includeNull = await orderHasSingleColorway(orderId);
    query = applyColorwayCaptureFilter(query, colorwayId, includeNull);
  }
  if (resourceId) query = query.eq('resource_id', resourceId);

  let { data, error } = await query;
  if (error && isMissingColumnError(error)) {
    let fallback = supabase
      .from('inspection_sessions')
      .select('log_date, total_inspected, passed, rework_passed, failed, defect_summary')
      .eq('factory_id', factoryId)
      .eq('order_id', orderId)
      .eq('department_id', departmentId)
      .gte('log_date', dateFrom)
      .lte('log_date', dateTo);
    if (colorwayId) {
      const includeNull = await orderHasSingleColorway(orderId);
      fallback = applyColorwayCaptureFilter(fallback, colorwayId, includeNull);
    }
    if (resourceId) fallback = fallback.eq('resource_id', resourceId);
    const res = await fallback;
    data = res.data;
    error = res.error;
  }
  if (error) throw error;

  const viewLike: Array<Record<string, unknown>> = [];
  const defectParts: unknown[] = [];

  for (const raw of data || []) {
    const row = raw as Record<string, unknown>;
    const date = String(row.log_date ?? '');
    const rowInspected = Number(row.total_inspected) || 0;
    const rowFirst = qcFirstTimePassFromRow(row);
    const rowRework = Number(row.rework_passed) || 0;
    const rowFailed = Number(row.failed) || 0;
    const defects = sumDefectCountFromSummary(row.defect_summary as Record<string, unknown>);

    viewLike.push({
      log_date: date,
      inspected: rowInspected,
      passed: rowFirst + rowRework,
      first_time_pass: rowFirst,
      rework_pass: rowRework,
      failed: rowFailed,
      dhu: row.dhu ?? (rowInspected > 0 ? (defects / rowInspected) * 100 : null),
      defective_pct:
        row.defective_pct ?? (rowInspected > 0 ? (rowFailed / rowInspected) * 100 : null),
    });

    if (row.defect_summary) defectParts.push(row.defect_summary);
  }

  const summary = aggregateQualityViewRows(viewLike);
  if (summary.topDefects.length === 0 && defectParts.length > 0) {
    summary.topDefects = mergeTopDefectsFromView(defectParts);
  }
  return summary;
}

/** QC department KPIs from v_daily_quality (falls back to inspection_sessions). */
export async function fetchStyleDeptQualitySummary(
  factoryId: string,
  orderId: string,
  departmentId: string,
  dateFrom: string,
  dateTo: string,
  colorwayId?: string | null,
  resourceId?: string | null,
): Promise<StyleDeptQualitySummary> {
  const needsSessionGrain = Boolean(colorwayId || resourceId);

  if (!needsSessionGrain) {
    const { data, error } = await supabase
      .from('v_daily_quality')
      .select('log_date, inspected, passed, failed, rework_pass, dhu, defective_pct')
      .eq('factory_id', factoryId)
      .eq('order_id', orderId)
      .eq('department_id', departmentId)
      .gte('log_date', dateFrom)
      .lte('log_date', dateTo);

    if (!error && data && data.length > 0) {
      const summary = aggregateQualityViewRows(data as Array<Record<string, unknown>>);
      if (summary.topDefects.length === 0) {
        try {
          summary.topDefects = await fetchStyleDeptTopDefectsFromSessions(
            factoryId,
            orderId,
            departmentId,
            dateFrom,
            dateTo,
          );
        } catch {
          // keep empty top defects
        }
      }
      return summary;
    }

    if (error && !isMissingRelationError(error) && !isMissingColumnError(error)) {
      throw error;
    }
  }

  return fetchStyleDeptQualityFromSessions(
    factoryId,
    orderId,
    departmentId,
    dateFrom,
    dateTo,
    colorwayId,
    resourceId,
  );
}

function formatAuditDayLabel(logDate: string): string {
  try {
    return format(parseISO(logDate), 'd MMM');
  } catch {
    return logDate.slice(5);
  }
}

/** Floor AQL audit KPIs from v_audit_colorway_summary / v_audit_summary. */
export async function fetchStyleDeptAuditMetrics(
  factoryId: string,
  orderId: string,
  departmentId: string,
  dateFrom: string,
  dateTo: string,
  colorwayId?: string | null,
): Promise<StyleDeptAuditMetrics | null> {
  if (colorwayId) {
    const { data, error } = await supabase
      .from('v_audit_colorway_summary')
      .select(
        'log_date, lots_total, lots_passed, lots_failed, lots_pass_pct, pieces_sampled, failed_pieces, defective_pct, dhu',
      )
      .eq('factory_id', factoryId)
      .eq('order_id', orderId)
      .eq('department_id', departmentId)
      .eq('colorway_id', colorwayId)
      .gte('log_date', dateFrom)
      .lte('log_date', dateTo)
      .order('log_date');

    if (!error && data && data.length > 0) {
      let sample = 0;
      let failedPieces = 0;
      let lotsTotal = 0;
      let lotsPassed = 0;
      let lotsFailed = 0;
      let dhuSum = 0;
      let dhuWeight = 0;
      let defSum = 0;
      let defWeight = 0;
      const daily = data.map((row) => {
        const dayLots = Number(row.lots_total) || 0;
        const dayPassed = Number(row.lots_passed) || 0;
        const dayFailed = Number(row.lots_failed) || 0;
        const daySample = Number(row.pieces_sampled) || 0;
        const dayFailedPieces = Number(row.failed_pieces) || 0;
        const logDate = String(row.log_date ?? '');
        lotsTotal += dayLots;
        lotsPassed += dayPassed;
        lotsFailed += dayFailed;
        sample += daySample;
        failedPieces += dayFailedPieces;
        if (row.dhu != null && daySample > 0) {
          dhuSum += Number(row.dhu) * daySample;
          dhuWeight += daySample;
        }
        if (row.defective_pct != null && daySample > 0) {
          defSum += Number(row.defective_pct) * daySample;
          defWeight += daySample;
        }
        return {
          label: formatAuditDayLabel(logDate),
          passPct: row.lots_pass_pct != null ? Number(row.lots_pass_pct) : null,
          defectivePct: row.defective_pct != null ? Number(row.defective_pct) : null,
          majorDefectivePct: null,
          auditCount: dayLots,
          passedCount: dayPassed,
          failedCount: dayFailed,
        };
      });
      return {
        totalAudits: lotsTotal,
        passedAudits: lotsPassed,
        failedAudits: lotsFailed,
        passPct: sample > 0 ? ((sample - failedPieces) / sample) * 100 : null,
        defectivePct:
          defWeight > 0 ? defSum / defWeight : sample > 0 ? (failedPieces / sample) * 100 : null,
        majorDefectivePct: null,
        dhu: dhuWeight > 0 ? dhuSum / dhuWeight : sample > 0 ? (failedPieces / sample) * 100 : null,
        daily,
      };
    }
    if (error && !isMissingRelationError(error)) {
      console.warn('v_audit_colorway_summary unavailable', error);
    }
  }

  const { data, error } = await supabase
    .from('v_audit_summary')
    .select('log_date, lots, total_samples, total_passed, total_failed, aql_pass_pct')
    .eq('factory_id', factoryId)
    .eq('order_id', orderId)
    .eq('department_id', departmentId)
    .gte('log_date', dateFrom)
    .lte('log_date', dateTo)
    .order('log_date');

  if (error) {
    if (isMissingRelationError(error)) return null;
    throw error;
  }
  if (!data || data.length === 0) return null;

  let lotsTotal = 0;
  let sample = 0;
  let passed = 0;
  let failed = 0;
  const daily = data.map((row) => {
    const dayLots = Number(row.lots) || 0;
    const daySample = Number(row.total_samples) || 0;
    const dayPassed = Number(row.total_passed) || 0;
    const dayFailed = Number(row.total_failed) || 0;
    const logDate = String(row.log_date ?? '');
    lotsTotal += dayLots;
    sample += daySample;
    passed += dayPassed;
    failed += dayFailed;
    return {
      label: formatAuditDayLabel(logDate),
      passPct:
        row.aql_pass_pct != null
          ? Number(row.aql_pass_pct)
          : daySample > 0
            ? (dayPassed / daySample) * 100
            : null,
      defectivePct: daySample > 0 ? (dayFailed / daySample) * 100 : null,
      majorDefectivePct: null,
      auditCount: dayLots,
      passedCount: dayPassed,
      failedCount: dayFailed,
    };
  });

  return {
    totalAudits: lotsTotal,
    passedAudits: daily.reduce((s, d) => s + d.passedCount, 0),
    failedAudits: daily.reduce((s, d) => s + d.failedCount, 0),
    passPct: sample > 0 ? (passed / sample) * 100 : null,
    defectivePct: sample > 0 ? (failed / sample) * 100 : null,
    majorDefectivePct: null,
    dhu: sample > 0 ? (failed / sample) * 100 : null,
    daily,
  };
}

/** First-time-right % for a style in a QC department over a date range. */
export async function fetchStyleDeptQcFtr(
  factoryId: string,
  orderId: string,
  departmentId: string,
  dateFrom: string,
  dateTo: string,
  colorwayId?: string | null,
  resourceId?: string | null,
): Promise<number | null> {
  const summary = await fetchStyleDeptQualitySummary(
    factoryId,
    orderId,
    departmentId,
    dateFrom,
    dateTo,
    colorwayId,
    resourceId,
  );
  return summary.ftrPct;
}

/** @deprecated use fetchStyleDeptQualitySummary */
export async function fetchStyleDeptDefects(
  factoryId: string,
  orderId: string,
  departmentId: string,
  dateFrom: string,
  dateTo: string,
  colorwayId?: string | null,
  resourceId?: string | null,
): Promise<StyleDeptDefectRow[]> {
  const summary = await fetchStyleDeptQualitySummary(
    factoryId,
    orderId,
    departmentId,
    dateFrom,
    dateTo,
    colorwayId,
    resourceId,
  );
  return summary.topDefects;
}

function sumDefectCountFromSummary(summary: Record<string, unknown> | null | undefined): number {
  if (!summary || typeof summary !== 'object') return 0;
  return Object.values(summary).reduce(
    (sum, value) => sum + (typeof value === 'number' ? value : parseInt(String(value ?? '0'), 10) || 0),
    0,
  );
}

/** Scope capture queries to a colorway; include NULL colorway rows on single-colorway orders. */
function applyColorwayCaptureFilter<
  Q extends { eq: (col: string, val: string) => Q; or: (filters: string) => Q },
>(query: Q, colorwayId: string, includeNullColorway: boolean): Q {
  if (includeNullColorway) {
    return query.or(`colorway_id.eq.${colorwayId},colorway_id.is.null`);
  }
  return query.eq('colorway_id', colorwayId);
}

async function orderHasSingleColorway(orderId: string): Promise<boolean> {
  const { count, error } = await supabase
    .from('colorways')
    .select('id', { count: 'exact', head: true })
    .eq('order_id', orderId);
  if (error) return false;
  return (count ?? 0) <= 1;
}

async function fetchStyleDailyKpisForColorway(
  factoryId: string,
  orderId: string,
  colorwayId: string,
  deptMap: Map<string, string>,
): Promise<StyleDeptDailyRow[]> {
  const includeNullColorway = await orderHasSingleColorway(orderId);

  let hourlyQuery = supabase
    .from('hourly_counts')
    .select('log_date, department_id, count')
    .eq('factory_id', factoryId)
    .eq('order_id', orderId);
  hourlyQuery = applyColorwayCaptureFilter(hourlyQuery, colorwayId, includeNullColorway);

  let qcQuery = supabase
    .from('inspection_sessions')
    .select(
      'log_date, department_id, passed, rework_passed, total_inspected, failed, defect_summary',
    )
    .eq('factory_id', factoryId)
    .eq('order_id', orderId);
  qcQuery = applyColorwayCaptureFilter(qcQuery, colorwayId, includeNullColorway);

  const wfQuery = supabase
    .from('workforce_logs')
    .select('log_date, department_id, headcount_by_category, operators, helpers, supervisors, trainees')
    .eq('factory_id', factoryId);

  let allocQuery = supabase
    .from('line_allocations')
    .select('department_id, sam, kpi_inputs, daily_target')
    .eq('factory_id', factoryId)
    .eq('order_id', orderId);
  allocQuery = applyColorwayCaptureFilter(allocQuery, colorwayId, includeNullColorway);

  const shiftQuery = supabase
    .from('shifts')
    .select('id, name, type, hours, productive_mins')
    .eq('factory_id', factoryId);

  const [hourlyRes, qcRes, wfRes, allocRes, shiftRes] = await Promise.all([
    hourlyQuery,
    qcQuery,
    wfQuery,
    allocQuery,
    shiftQuery,
  ]);

  if (hourlyRes.error) throw hourlyRes.error;
  if (qcRes.error) throw qcRes.error;
  if (shiftRes.error) throw shiftRes.error;
  if (wfRes.error) {
    const code = String(wfRes.error.code ?? '');
    if (code !== '42703') throw wfRes.error;
  }
  if (allocRes.error) {
    const code = String(allocRes.error.code ?? '');
    if (code !== '42703') throw allocRes.error;
  }

  const shifts = (shiftRes.data || []).map((s) => mapShiftRow(s as Record<string, unknown>));
  let productiveMinsPerWorker = regularShiftProductiveMins(shifts);
  if (productiveMinsPerWorker <= 0) {
    for (const raw of shiftRes.data || []) {
      const pm = Number((raw as { productive_mins?: number }).productive_mins);
      if (pm > 0) {
        productiveMinsPerWorker = pm;
        break;
      }
    }
  }
  if (productiveMinsPerWorker <= 0) productiveMinsPerWorker = 480;

  const samByDept = new Map<string, number>();
  const targetByDept = new Map<string, number>();
  for (const raw of allocRes.data || []) {
    const deptId = raw.department_id as string;
    const sam = allocationSamValue({
      sam: raw.sam as number | null,
      kpi_inputs: raw.kpi_inputs as { sam?: number } | null,
    });
    if (sam > 0 && !samByDept.has(deptId)) samByDept.set(deptId, sam);
    const target = Number(raw.daily_target) || 0;
    if (target > 0) targetByDept.set(deptId, (targetByDept.get(deptId) || 0) + target);
  }

  const outputByKey = new Map<string, number>();
  for (const raw of hourlyRes.data || []) {
    const date = raw.log_date as string;
    const deptId = raw.department_id as string;
    const key = `${date}|${deptId}`;
    outputByKey.set(key, (outputByKey.get(key) || 0) + (Number(raw.count) || 0));
  }

  const qcByKey = new Map<
    string,
    { inspected: number; defects: number; defectivePieces: number; output: number }
  >();
  for (const raw of qcRes.data || []) {
    const date = raw.log_date as string;
    const deptId = raw.department_id as string;
    const key = `${date}|${deptId}`;
    const cur = qcByKey.get(key) ?? {
      inspected: 0,
      defects: 0,
      defectivePieces: 0,
      output: 0,
    };
    const passed = qcSessionOutputQty(raw);
    const inspected = Number(raw.total_inspected) || 0;
    const defects = sumDefectCountFromSummary(raw.defect_summary as Record<string, unknown>);
    const defectivePieces = qcSessionDefectiveQty(raw);
    qcByKey.set(key, {
      inspected: cur.inspected + inspected,
      defects: cur.defects + defects,
      defectivePieces: cur.defectivePieces + defectivePieces,
      output: cur.output + passed,
    });
    if (!outputByKey.has(key)) outputByKey.set(key, 0);
    outputByKey.set(key, (outputByKey.get(key) || 0) + passed);
  }

  const workforceByKey = new Map<string, number>();
  for (const raw of wfRes.data || []) {
    const date = raw.log_date as string;
    const deptId = raw.department_id as string;
    const key = `${date}|${deptId}`;
    let headcount = workforceHeadcountFromLog(raw as Record<string, unknown>);
    if (headcount <= 0) {
      headcount =
        (Number(raw.operators) || 0) +
        (Number(raw.helpers) || 0) +
        (Number(raw.supervisors) || 0) +
        (Number(raw.trainees) || 0);
    }
    if (headcount > 0) {
      workforceByKey.set(key, (workforceByKey.get(key) || 0) + headcount);
    }
  }

  const allKeys = new Set<string>([...outputByKey.keys(), ...qcByKey.keys(), ...workforceByKey.keys()]);
  const rows: StyleDeptDailyRow[] = [];

  for (const key of allKeys) {
    const [date, deptId] = key.split('|');
    const output = outputByKey.get(key) ?? 0;
    const qc = qcByKey.get(key);
    const workforce = workforceByKey.get(key) ?? 0;
    const sam = samByDept.get(deptId) ?? 0;
    const dailyAvailableMins = workforce > 0 ? workforce * productiveMinsPerWorker : 0;
    const inspected = qc?.inspected ?? 0;
    const defects = qc?.defects ?? 0;
    const defectivePieces = qc?.defectivePieces ?? 0;
    const producedMins = output * sam;
    const efficiency =
      producedMins > 0 && dailyAvailableMins > 0
        ? (producedMins / dailyAvailableMins) * 100
        : null;
    const productivity = workforce > 0 && output > 0 ? output / workforce : null;

    if (output <= 0 && dailyAvailableMins <= 0 && inspected <= 0) continue;

    rows.push({
      date,
      deptId,
      deptName: deptMap.get(deptId) || deptId,
      output,
      target: targetByDept.get(deptId) || 0,
      dailyAvailableMins,
      efficiency,
      productivity,
      dhu: inspected > 0 ? (defects / inspected) * 100 : null,
      defectivePct: inspected > 0 ? (defectivePieces / inspected) * 100 : null,
    });
  }

  return rows.sort((a, b) => a.date.localeCompare(b.date) || a.deptName.localeCompare(b.deptName));
}

/** Per-dept daily output for one planned resource (all shifts; hourly + QC sessions). */
export async function fetchStyleDeptResourceDailyRows(
  factoryId: string,
  orderId: string,
  departmentId: string,
  resourceId: string,
  colorwayId: string | null,
  baseRows: StyleDeptDailyRow[],
  plannedSam: number | null,
): Promise<StyleDeptDailyRow[]> {
  const includeNullColorway = colorwayId ? await orderHasSingleColorway(orderId) : false;

  let hourlyQuery = supabase
    .from('hourly_counts')
    .select('log_date, count')
    .eq('factory_id', factoryId)
    .eq('order_id', orderId)
    .eq('department_id', departmentId)
    .eq('resource_id', resourceId);
  if (colorwayId) {
    hourlyQuery = applyColorwayCaptureFilter(hourlyQuery, colorwayId, includeNullColorway);
  }

  let qcQuery = supabase
    .from('inspection_sessions')
    .select(
      'log_date, passed, rework_passed, total_inspected, failed, defect_summary',
    )
    .eq('factory_id', factoryId)
    .eq('order_id', orderId)
    .eq('department_id', departmentId)
    .eq('resource_id', resourceId);
  if (colorwayId) {
    qcQuery = applyColorwayCaptureFilter(qcQuery, colorwayId, includeNullColorway);
  }

  let wfQuery = supabase
    .from('workforce_logs')
    .select('log_date, headcount_by_category, operators, helpers, supervisors, trainees')
    .eq('factory_id', factoryId)
    .eq('department_id', departmentId);

  let wfResourceQuery = wfQuery.eq('resource_id', resourceId);

  const shiftQuery = supabase
    .from('shifts')
    .select('id, name, type, hours, productive_mins')
    .eq('factory_id', factoryId);

  const [hourlyRes, qcRes, wfResourceRes, wfDeptRes, shiftRes] = await Promise.all([
    hourlyQuery,
    qcQuery,
    wfResourceQuery,
    wfQuery,
    shiftQuery,
  ]);

  if (hourlyRes.error) throw hourlyRes.error;
  if (qcRes.error) throw qcRes.error;
  if (shiftRes.error) throw shiftRes.error;

  if (wfResourceRes.error && wfDeptRes.error) {
    const code = String(wfResourceRes.error.code ?? wfDeptRes.error.code ?? '');
    if (code !== '42703' && !String(wfResourceRes.error.message).includes('resource_id')) {
      throw wfDeptRes.error;
    }
  }

  const shifts = (shiftRes.data || []).map((s) => mapShiftRow(s as Record<string, unknown>));
  let productiveMinsPerWorker = regularShiftProductiveMins(shifts);
  if (productiveMinsPerWorker <= 0) {
    for (const raw of shiftRes.data || []) {
      const pm = Number((raw as { productive_mins?: number }).productive_mins);
      if (pm > 0) {
        productiveMinsPerWorker = pm;
        break;
      }
    }
  }
  if (productiveMinsPerWorker <= 0) productiveMinsPerWorker = 480;

  const outputByDate = new Map<string, number>();
  for (const raw of hourlyRes.data || []) {
    const date = raw.log_date as string;
    outputByDate.set(date, (outputByDate.get(date) || 0) + (Number(raw.count) || 0));
  }

  const qcByDate = new Map<
    string,
    { inspected: number; defects: number; defectivePieces: number; output: number }
  >();
  for (const raw of qcRes.data || []) {
    const date = raw.log_date as string;
    const cur = qcByDate.get(date) ?? {
      inspected: 0,
      defects: 0,
      defectivePieces: 0,
      output: 0,
    };
    const passed = qcSessionOutputQty(raw);
    const inspected = Number(raw.total_inspected) || 0;
    const defects = sumDefectCountFromSummary(raw.defect_summary as Record<string, unknown>);
    const defectivePieces = qcSessionDefectiveQty(raw);
    qcByDate.set(date, {
      inspected: cur.inspected + inspected,
      defects: cur.defects + defects,
      defectivePieces: cur.defectivePieces + defectivePieces,
      output: cur.output + passed,
    });
    outputByDate.set(date, (outputByDate.get(date) || 0) + passed);
  }

  const workforceByDate = new Map<string, number>();
  const wfRows =
    !wfResourceRes.error && (wfResourceRes.data?.length ?? 0) > 0
      ? wfResourceRes.data
      : wfDeptRes.error
        ? []
        : wfDeptRes.data || [];
  for (const raw of wfRows) {
    const date = raw.log_date as string;
    let headcount = workforceHeadcountFromLog(raw as Record<string, unknown>);
    if (headcount <= 0) {
      headcount =
        (Number(raw.operators) || 0) +
        (Number(raw.helpers) || 0) +
        (Number(raw.supervisors) || 0) +
        (Number(raw.trainees) || 0);
    }
    if (headcount > 0) {
      workforceByDate.set(date, (workforceByDate.get(date) || 0) + headcount);
    }
  }

  const deptName = baseRows[0]?.deptName ?? departmentId;
  const sam = plannedSam ?? 0;
  const baseByDate = new Map(baseRows.map((r) => [r.date, r]));
  const allDates = new Set<string>([
    ...outputByDate.keys(),
    ...qcByDate.keys(),
    ...workforceByDate.keys(),
    ...baseRows.map((r) => r.date),
  ]);

  return [...allDates]
    .map((date) => {
      const output = outputByDate.get(date) ?? 0;
      const qc = qcByDate.get(date);
      let workforce = workforceByDate.get(date) ?? 0;
      const base = baseByDate.get(date);
      let dailyAvailableMins = workforce > 0 ? workforce * productiveMinsPerWorker : 0;
      if (dailyAvailableMins <= 0 && base && base.dailyAvailableMins > 0) {
        const deptOutput = base.output;
        if (deptOutput > 0 && output > 0) {
          dailyAvailableMins = base.dailyAvailableMins * (output / deptOutput);
        } else {
          dailyAvailableMins = base.dailyAvailableMins;
        }
        if (workforce <= 0 && productiveMinsPerWorker > 0) {
          workforce = dailyAvailableMins / productiveMinsPerWorker;
        }
      }
      const inspected = qc?.inspected ?? 0;
      const defects = qc?.defects ?? 0;
      const defectivePieces = qc?.defectivePieces ?? 0;
      const producedMins = output * sam;
      const efficiency =
        producedMins > 0 && dailyAvailableMins > 0
          ? (producedMins / dailyAvailableMins) * 100
          : null;
      const productivity = workforce > 0 && output > 0 ? output / workforce : null;

      return {
        date,
        deptId: departmentId,
        deptName,
        output,
        target: 0,
        dailyAvailableMins,
        efficiency,
        productivity,
        dhu: inspected > 0 ? (defects / inspected) * 100 : null,
        defectivePct: inspected > 0 ? (defectivePieces / inspected) * 100 : null,
      };
    })
    .filter((r) => r.output > 0 || r.dailyAvailableMins > 0 || r.dhu != null)
    .sort((a, b) => a.date.localeCompare(b.date));
}

/** Per-dept daily KPI rows for one style order (Style Report Section 2). */
export async function fetchStyleDailyKpis(
  factoryId: string,
  orderId: string,
  meta?: ReportMeta,
  colorwayId?: string | null,
): Promise<StyleDeptDailyRow[]> {
  const reportMeta = meta ?? (await fetchReportMeta(factoryId));
  const deptMap = new Map(reportMeta.departments.map((d) => [d.id, d.name]));

  if (colorwayId) {
    return fetchStyleDailyKpisForColorway(factoryId, orderId, colorwayId, deptMap);
  }

  const rows = await fetchStyleKpis(factoryId, orderId);

  return rows.map((row) => ({
    date: row.log_date,
    deptId: row.department_id,
    deptName: deptMap.get(row.department_id) || row.department_id,
    output: row.daily_output || 0,
    target: row.daily_target || 0,
    dailyAvailableMins: Number(row.daily_available_mins) || 0,
    efficiency: row.daily_efficiency_pct != null ? Number(row.daily_efficiency_pct) : null,
    productivity:
      (row as { daily_productivity?: number | null }).daily_productivity != null
        ? Number((row as { daily_productivity?: number | null }).daily_productivity)
        : null,
    dhu: row.dhu != null ? Number(row.dhu) : null,
    defectivePct: row.defective_pct != null ? Number(row.defective_pct) : null,
  }));
}

export { formatPct, formatPct2, formatEffPct, formatDhu } from './mesMetrics';
