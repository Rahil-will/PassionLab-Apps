import type { ProcessFlow, ProcessFlowStep } from '../types/settings';

/** `process_flows` columns used by the app. */
export function processFlowToDbRow(flow: Partial<ProcessFlow> & { factory_id: string }) {
  return {
    id: flow.id,
    factory_id: flow.factory_id,
    name: flow.name,
    description: flow.description?.trim() || null,
    version: flow.version ?? 1,
    is_current: flow.is_current ?? true,
    parent_flow_id: flow.parent_flow_id ?? null,
  };
}

export function processFlowUpdatePayload(flow: Partial<ProcessFlow>) {
  const row: Record<string, unknown> = {};
  if (flow.name !== undefined) row.name = flow.name;
  if (flow.description !== undefined) row.description = flow.description?.trim() || null;
  if (flow.version !== undefined) row.version = flow.version;
  if (flow.is_current !== undefined) row.is_current = flow.is_current;
  if (flow.parent_flow_id !== undefined) row.parent_flow_id = flow.parent_flow_id ?? null;
  return row;
}

/** `process_flow_steps` columns: flow_id, department_id, dept_name, flow_step */
export function processFlowStepToDbRow(flowId: string, step: ProcessFlowStep) {
  return {
    flow_id: flowId,
    department_id: step.dept_id || null,
    dept_name: step.dept_name,
    flow_step: step.flow_step,
  };
}

export interface ProcessFlowStepRef {
  dept_id: string;
  dept_name: string;
}

export interface ResolvedOrderProcessFlow {
  flowSteps: string[];
  flowStepObjects: ProcessFlowStepRef[];
  flowLabel: string | null;
  flow: ProcessFlow | null;
}

/** Ordered department display names for a process flow id. Returns [] when flow is unknown. */
export function processFlowDeptNames(processFlows: ProcessFlow[], flowId?: string): string[] {
  return resolveOrderProcessFlow(processFlows, flowId).flowSteps;
}

/** Resolve an order's process flow from settings only — no hardcoded fallback steps. */
export function resolveOrderProcessFlow(
  processFlows: ProcessFlow[],
  flowId?: string,
): ResolvedOrderProcessFlow {
  const empty: ResolvedOrderProcessFlow = {
    flowSteps: [],
    flowStepObjects: [],
    flowLabel: null,
    flow: null,
  };
  if (!flowId) return empty;

  const flow = processFlows.find((f) => f.id === flowId) ?? null;
  if (!flow?.steps?.length) {
    return { ...empty, flowLabel: flow?.name ?? null, flow };
  }

  const flowStepObjects: ProcessFlowStepRef[] = flow.steps.map((s) => ({
    dept_id: s.dept_id || '',
    dept_name: s.dept_name || String(s.dept_id),
  }));

  return {
    flowSteps: flowStepObjects.map((s) => s.dept_name),
    flowStepObjects,
    flowLabel: flow.name,
    flow,
  };
}

export function mapProcessFlowFromDb(row: Record<string, unknown>) {
  const steps = ((row.process_flow_steps as Record<string, unknown>[]) || [])
    .sort((a, b) => (a.flow_step as number) - (b.flow_step as number))
    .map((s) => ({
      flow_step: s.flow_step as number,
      dept_id: (s.department_id as string) || '',
      dept_name: s.dept_name as string,
    }));
  return {
    id: row.id as string,
    factory_id: row.factory_id as string,
    name: row.name as string,
    description: (row.description as string) || null,
    version: (row.version as number) || 1,
    is_current: row.is_current !== false,
    parent_flow_id: (row.parent_flow_id as string) || null,
    steps,
  } satisfies ProcessFlow;
}
