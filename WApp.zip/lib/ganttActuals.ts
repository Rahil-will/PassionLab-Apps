import type { ProductionSummaryRow } from '../types';
import type { LineAllocation } from '../types/production';
import type { GanttAlloc } from '../components/production/GanttResourceRows';

function actualForAllocation(
  alloc: LineAllocation,
  deptName: string,
  productionSummary: ProductionSummaryRow[],
): { qty: number; startDate?: string; endDate?: string } {
  if (!deptName) return { qty: 0 };
  const cwId = alloc.colorwayId || '';
  const rows = productionSummary.filter(
    (r) =>
      r.order_id === alloc.orderId &&
      r.department === deptName &&
      (cwId ? r.colorway_id === cwId : true),
  );
  const qty = rows.reduce((sum, r) => sum + (r.total_passed || r.total_scanned || 0), 0);
  let startDate: string | undefined;
  let endDate: string | undefined;
  for (const r of rows) {
    if (r.first_output_date) {
      if (!startDate || r.first_output_date < startDate) startDate = r.first_output_date;
    }
    if (r.last_output_date) {
      if (!endDate || r.last_output_date > endDate) endDate = r.last_output_date;
    }
  }
  return { qty, startDate, endDate };
}

function statusFromActual(actualQty: number, plannedQty: number, prev?: string): string {
  if (actualQty <= 0) return prev || 'planned';
  if (plannedQty > 0 && actualQty >= plannedQty) return 'completed';
  return 'running';
}

function resolveDeptName(
  alloc: LineAllocation,
  deptNameByLineId: Map<string, string>,
  deptNameById?: Map<string, string>,
): string {
  const fromLine = deptNameByLineId.get(alloc.lineId);
  if (fromLine) return fromLine;
  if (alloc.departmentId && deptNameById) {
    return deptNameById.get(alloc.departmentId) || '';
  }
  return '';
}

/** Attach cumulative MES output as `actualQty` for gantt running rows. */
export function enrichAllocationsWithActuals<T extends LineAllocation>(
  allocations: T[],
  productionSummary: ProductionSummaryRow[],
  deptNameByLineId: Map<string, string>,
  deptNameById?: Map<string, string>,
): Array<T & GanttAlloc> {
  return allocations.map((alloc) => {
    const deptName = resolveDeptName(alloc, deptNameByLineId, deptNameById);
    const actual = actualForAllocation(alloc, deptName, productionSummary);
    return {
      ...alloc,
      actualQty: actual.qty,
      actualStartDate: actual.startDate,
      actualEndDate: actual.endDate,
      status: statusFromActual(actual.qty, alloc.qty || 0, alloc.status),
      styleName: alloc.styleName,
      poNumber: alloc.poNumber,
      colorway: alloc.colorway,
    };
  });
}

export function buildDeptNameByLineId(
  lines: Array<{ id: string; departmentName?: string; departmentId?: string }>,
  deptNameById?: Map<string, string>,
): Map<string, string> {
  return new Map(
    lines.map((l) => {
      const name =
        l.departmentName ||
        (l.departmentId && deptNameById?.get(l.departmentId)) ||
        '';
      return [l.id, name];
    }),
  );
}
