import { invokeAdminEdgeFunction } from './adminApi';
import type { DeptAppId } from './floorApps';

export interface CreateFactoryUserInput {
  factoryId: string;
  fullName: string;
  email: string;
  floorPin: string;
  departmentId: string | null;
  assignedApps: DeptAppId[];
  userRole?: string;
  status?: 'Active' | 'Inactive';
}

/**
 * Creates a floor user via Supabase Edge Function (service role, no confirmation email).
 */
export async function createFactoryUser(input: CreateFactoryUserInput): Promise<{ id: string }> {
  const payload = await invokeAdminEdgeFunction<{ id?: string }>('admin-create-user', {
    ...input,
  });

  if (!payload.id) {
    throw new Error('User created but no id returned');
  }

  return { id: payload.id };
}
