import type { ProductionSummaryRow } from '../types';
import type { StyleOrder } from '../types/production';

const TERMINAL = new Set(['Completed', 'Cancelled']);

/** Derive order status from cumulative production vs order qty. */
export function deriveOrderStatus(
  order: StyleOrder,
  productionSummary: ProductionSummaryRow[],
  lastDeptName?: string,
): string {
  if (TERMINAL.has(order.status)) return order.status;

  const orderRows = productionSummary.filter((r) => r.order_id === order.id);
  if (orderRows.length === 0) return order.status || 'Not Started';

  const totalOutput = orderRows.reduce(
    (sum, r) => sum + (r.total_passed || r.total_scanned || 0),
    0,
  );
  const target = order.adjQty || order.totalQty || 0;

  if (target > 0 && totalOutput >= target) return 'Completed';
  if (totalOutput > 0) return 'In Progress';
  return order.status || 'Not Started';
}

export function syncOrdersWithProduction(
  orders: StyleOrder[],
  productionSummary: ProductionSummaryRow[],
): StyleOrder[] {
  return orders.map((order) => ({
    ...order,
    status: deriveOrderStatus(order, productionSummary),
  }));
}
