/** Natural sort — matches Settings → Departments resource list order (by resource_name). */
export function compareResourceNames(a: string, b: string): number {
  return (a || '').localeCompare(b || '', undefined, { numeric: true, sensitivity: 'base' });
}

export function sortResourcesBySequence<T extends { resourceName: string }>(resources: T[]): T[] {
  return [...resources].sort((a, b) => compareResourceNames(a.resourceName, b.resourceName));
}
