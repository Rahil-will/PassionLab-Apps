import { supabase } from './supabase';

export class MesCaptureError extends Error {
  code?: string;
  details?: Record<string, unknown>;

  constructor(message: string, code?: string, details?: Record<string, unknown>) {
    super(message);
    this.name = 'MesCaptureError';
    this.code = code;
    this.details = details;
  }
}

export async function postMesCapture(
  factoryId: string,
  userId: string,
  type: string,
  payload: Record<string, unknown>,
): Promise<Record<string, unknown>> {
  const { data, error } = await supabase.rpc('floor_capture', {
    p_factory_id: factoryId,
    p_user_id: userId,
    p_type: type,
    p_payload: payload,
  });
  if (error) throw new MesCaptureError(error.message, 'RPC_ERROR');

  const result = (data || {}) as Record<string, unknown>;
  if (result.error) {
    throw new MesCaptureError(
      String(result.error),
      result.code as string | undefined,
      (result.details as Record<string, unknown>) || {},
    );
  }
  return result;
}

export async function logShipmentCapture(
  factoryId: string,
  userId: string,
  payload: {
    orderId: string;
    colorwayId?: string | null;
    shippedQty: number;
    shippedQtyBySize?: Record<string, number>;
    shipmentType: string;
    shipmentDate: string;
    invoiceNumber?: string;
    awbNumber?: string;
    destination?: string;
    notes?: string;
  },
): Promise<void> {
  await postMesCapture(factoryId, userId, 'shipment_log', {
    orderId: payload.orderId,
    colorwayId: payload.colorwayId ?? null,
    shippedQty: payload.shippedQty,
    shippedQtyBySize: payload.shippedQtyBySize ?? {},
    shipmentType: payload.shipmentType,
    shipmentDate: payload.shipmentDate,
    invoiceNumber: payload.invoiceNumber ?? '',
    awbNumber: payload.awbNumber ?? '',
    destination: payload.destination ?? '',
    notes: payload.notes ?? '',
    loggedAt: new Date().toISOString(),
  });
}

export async function deleteShipmentRecord(
  factoryId: string,
  shipmentId: string,
): Promise<void> {
  const { error } = await supabase
    .from('shipments')
    .delete()
    .eq('id', shipmentId)
    .eq('factory_id', factoryId);
  if (error) throw new MesCaptureError(error.message, 'DELETE_ERROR');
}

export async function logRejectionCapture(
  factoryId: string,
  userId: string,
  payload: {
    orderId: string;
    colorwayId?: string | null;
    size?: string;
    qty: number;
    reasonCode: string;
    reasonDetail?: string;
    stage: string;
    rejectedDate: string;
    notes?: string;
  },
): Promise<void> {
  await postMesCapture(factoryId, userId, 'rejection_log', {
    orderId: payload.orderId,
    colorwayId: payload.colorwayId ?? null,
    size: payload.size ?? '',
    qty: payload.qty,
    reasonCode: payload.reasonCode,
    reasonDetail: payload.reasonDetail ?? '',
    stage: payload.stage,
    rejectedDate: payload.rejectedDate,
    notes: payload.notes ?? '',
    loggedAt: new Date().toISOString(),
  });
}
