import { supabase } from './supabase';
import { qcSessionOutputQty } from './mesReportsApi';
import type { ProductionSummaryRow } from '../types';

interface DailyOutputRow {
  order_id: string;
  colorway_id: string | null;
  department_id: string;
  output_qty: number;
  log_date: string;
}

function aggregateProductionSummary(
  rows: DailyOutputRow[],
  deptIdToName: Map<string, string>,
): ProductionSummaryRow[] {
  const agg = new Map<string, ProductionSummaryRow>();
  for (const row of rows) {
    const colorwayId = row.colorway_id || '';
    const deptName = deptIdToName.get(row.department_id) || row.department_id;
    const key = `${row.order_id}|${colorwayId}|${deptName}`;
    const qty = Number(row.output_qty) || 0;
    if (qty <= 0) continue;
    const logDate = row.log_date;
    const existing = agg.get(key);
    if (existing) {
      existing.total_passed = (existing.total_passed || 0) + qty;
      existing.total_scanned = (existing.total_scanned || 0) + qty;
      if (logDate) {
        if (!existing.first_output_date || logDate < existing.first_output_date) {
          existing.first_output_date = logDate;
        }
        if (!existing.last_output_date || logDate > existing.last_output_date) {
          existing.last_output_date = logDate;
        }
      }
    } else {
      agg.set(key, {
        order_id: row.order_id,
        colorway_id: colorwayId,
        department: deptName,
        total_passed: qty,
        total_scanned: qty,
        first_output_date: logDate || undefined,
        last_output_date: logDate || undefined,
      });
    }
  }
  return [...agg.values()];
}

async function fetchProductionSummaryFromTables(
  factoryId: string,
  deptIdToName: Map<string, string>,
): Promise<ProductionSummaryRow[]> {
  const [hourlyRes, qcRes] = await Promise.all([
    supabase
      .from('hourly_counts')
      .select('order_id, colorway_id, department_id, count, log_date')
      .eq('factory_id', factoryId),
    supabase
      .from('inspection_sessions')
      .select('order_id, colorway_id, department_id, passed, rework_passed, log_date')
      .eq('factory_id', factoryId),
  ]);

  if (hourlyRes.error) throw hourlyRes.error;
  if (qcRes.error) throw qcRes.error;

  const rows: DailyOutputRow[] = [];

  const hourlyByKey = new Map<string, number>();
  for (const raw of hourlyRes.data || []) {
    const deptId = raw.department_id as string;
    if (!deptId) continue;
    const logDate = (raw.log_date as string) || '';
    const key = `${raw.order_id}|${raw.colorway_id ?? ''}|${deptId}|${logDate}`;
    hourlyByKey.set(key, (hourlyByKey.get(key) || 0) + (Number(raw.count) || 0));
  }

  const qcByKey = new Map<string, number>();
  for (const raw of qcRes.data || []) {
    const deptId = raw.department_id as string;
    if (!deptId) continue;
    const logDate = (raw.log_date as string) || '';
    const key = `${raw.order_id}|${raw.colorway_id ?? ''}|${deptId}|${logDate}`;
    const qty = qcSessionOutputQty(raw);
    qcByKey.set(key, (qcByKey.get(key) || 0) + qty);
  }

  const outputByKey = new Map<string, number>();
  for (const [key, qty] of hourlyByKey) {
    outputByKey.set(key, qty);
  }
  for (const [key, qcQty] of qcByKey) {
    if (!outputByKey.has(key)) {
      outputByKey.set(key, qcQty);
    }
  }

  for (const [key, outputQty] of outputByKey) {
    if (outputQty <= 0) continue;
    const [orderId, colorwayId, departmentId, logDate] = key.split('|');
    rows.push({
      order_id: orderId,
      colorway_id: colorwayId || null,
      department_id: departmentId,
      output_qty: outputQty,
      log_date: logDate,
    });
  }

  return aggregateProductionSummary(rows, deptIdToName);
}

/** Cumulative produced qty from `v_daily_output` (hourly + QC), not style_orders.progress. */
export async function fetchProductionSummaryFromViews(
  factoryId: string,
): Promise<ProductionSummaryRow[]> {
  const { data: depts } = await supabase
    .from('departments')
    .select('id, name')
    .eq('factory_id', factoryId);
  const deptIdToName = new Map((depts || []).map((d) => [d.id as string, d.name as string]));

  const viewRes = await supabase
    .from('v_daily_output')
    .select('order_id, colorway_id, department_id, output_qty, log_date')
    .eq('factory_id', factoryId);

  if (!viewRes.error) {
    return aggregateProductionSummary((viewRes.data || []) as DailyOutputRow[], deptIdToName);
  }

  return fetchProductionSummaryFromTables(factoryId, deptIdToName);
}
