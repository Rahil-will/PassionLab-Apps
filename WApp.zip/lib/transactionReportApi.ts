import { format, subDays } from 'date-fns';
import { supabase } from './supabase';

export interface HandoverReportRow {
  id: string;
  orderId: string;
  colorwayId: string | null;
  fromDepartmentId: string;
  toDepartmentId: string;
  sentQty: number;
  receivedQty: number | null;
  qtyBySize: Record<string, number>;
  receivedQtyBySize: Record<string, number>;
  sentAt: string;
  receivedAt: string | null;
  status: 'pending' | 'received' | 'disputed';
  challanNumber: string | null;
  notes: string | null;
  receivedNotes: string | null;
  sentBy: string | null;
  receivedBy: string | null;
  styleName: string;
  poNumber: string;
  colorwayName: string | null;
  colorCode: string | null;
  fromDepartmentName: string;
  toDepartmentName: string;
  sentByName: string | null;
  receivedByName: string | null;
  logDate: string;
  shiftId: string | null;
  shiftName: string | null;
  hourSlot: string;
}

export interface HandoverReportFilters {
  dateFrom?: string;
  dateTo?: string;
  fromDepartmentId?: string | null;
  toDepartmentId?: string | null;
  status?: 'pending' | 'received' | 'disputed' | null;
  orderId?: string | null;
  colorwayId?: string | null;
  search?: string;
}

export interface HourSlotGroup {
  hourSlot: string;
  rows: HandoverReportRow[];
  totalQty: number;
}

export interface ShiftGroup {
  shiftId: string | null;
  shiftName: string;
  hourSlotGroups: HourSlotGroup[];
  totalQty: number;
}

export interface DateGroup {
  logDate: string;
  shiftGroups: ShiftGroup[];
  totalQty: number;
}

const SHIFT_KEY_SEP = '\u001f';

function mapSizeJson(raw: unknown): Record<string, number> {
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return {};
  const out: Record<string, number> = {};
  for (const [k, v] of Object.entries(raw as Record<string, unknown>)) {
    const n = Number(v);
    if (!Number.isNaN(n)) out[k] = n;
  }
  return out;
}

function mapRow(r: Record<string, unknown>): HandoverReportRow {
  return {
    id: r.id as string,
    orderId: r.order_id as string,
    colorwayId: (r.colorway_id as string) ?? null,
    fromDepartmentId: r.from_department_id as string,
    toDepartmentId: r.to_department_id as string,
    sentQty: (r.sent_qty as number) ?? 0,
    receivedQty: (r.received_qty as number) ?? null,
    qtyBySize: mapSizeJson(r.qty_by_size),
    receivedQtyBySize: mapSizeJson(r.received_qty_by_size),
    sentAt: r.sent_at as string,
    receivedAt: (r.received_at as string) ?? null,
    status: (r.status as HandoverReportRow['status']) ?? 'pending',
    challanNumber: (r.challan_number as string) ?? null,
    notes: (r.notes as string) ?? null,
    receivedNotes: (r.received_notes as string) ?? null,
    sentBy: (r.sent_by as string) ?? null,
    receivedBy: (r.received_by as string) ?? null,
    styleName: (r.style_name as string) ?? '',
    poNumber: (r.po_number as string) ?? '',
    colorwayName: (r.colorway_name as string) ?? null,
    colorCode: (r.color_code as string) ?? null,
    fromDepartmentName: (r.from_department_name as string) ?? '',
    toDepartmentName: (r.to_department_name as string) ?? '',
    sentByName: (r.sent_by_name as string) ?? null,
    receivedByName: (r.received_by_name as string) ?? null,
    logDate: (r.log_date as string) ?? '',
    shiftId: (r.shift_id as string) ?? null,
    shiftName: (r.shift_name as string) ?? null,
    hourSlot: (r.hour_slot as string) ?? '',
  };
}

function shiftKey(row: HandoverReportRow): string {
  const id = row.shiftId ?? '';
  const name = (row.shiftName ?? 'Unallocated').trim() || 'Unallocated';
  return `${id}${SHIFT_KEY_SEP}${name}`;
}

function parseShiftKey(key: string): { shiftId: string | null; shiftName: string } {
  const idx = key.indexOf(SHIFT_KEY_SEP);
  if (idx < 0) return { shiftId: null, shiftName: key || 'Unallocated' };
  const id = key.slice(0, idx);
  const name = key.slice(idx + SHIFT_KEY_SEP.length) || 'Unallocated';
  return { shiftId: id || null, shiftName: name };
}

/** Hour bucket from sent_at (calendar hour) — reliable for UI grouping. */
export function hourSlotFromSentAt(sentAt: string, fallback = ''): string {
  try {
    const d = new Date(sentAt);
    if (Number.isNaN(d.getTime())) return fallback || '—';
    const h = d.getHours();
    const nextH = (h + 1) % 24;
    const pad = (n: number) => String(n).padStart(2, '0');
    return `${pad(h)}:00-${pad(nextH)}:00`;
  } catch {
    return fallback || '—';
  }
}

function hourSlotSortKey(slot: string): number {
  const start = slot.split('-')[0]?.trim() || slot;
  const [hh, mm] = start.split(':').map((p) => parseInt(p, 10));
  if (!Number.isFinite(hh)) return Number.MAX_SAFE_INTEGER;
  return hh * 60 + (Number.isFinite(mm) ? mm : 0);
}

/** Group by calendar day, then factory shift (not hour slot). */
export function groupHandoverRows(
  rows: HandoverReportRow[],
  shiftOrder: string[] = [],
): DateGroup[] {
  const dateMap = new Map<string, HandoverReportRow[]>();
  for (const row of rows) {
    const key = row.logDate;
    const list = dateMap.get(key) ?? [];
    list.push(row);
    dateMap.set(key, list);
  }

  const dates = [...dateMap.keys()].sort((a, b) => b.localeCompare(a));

  return dates.map((logDate) => {
    const dayRows = dateMap.get(logDate) ?? [];
    const shiftMap = new Map<string, HandoverReportRow[]>();

    for (const row of dayRows) {
      const key = shiftKey(row);
      const list = shiftMap.get(key) ?? [];
      list.push(row);
      shiftMap.set(key, list);
    }

    const shiftRank = (g: ShiftGroup): number => {
      if (!g.shiftId) return Number.MAX_SAFE_INTEGER;
      const idx = shiftOrder.indexOf(g.shiftId);
      return idx >= 0 ? idx : Number.MAX_SAFE_INTEGER - 1;
    };

    const shiftGroups: ShiftGroup[] = [...shiftMap.entries()]
      .map(([key, shiftRows]) => {
        const { shiftId, shiftName } = parseShiftKey(key);
        const hourMap = new Map<string, HandoverReportRow[]>();

        for (const row of shiftRows) {
          const hourKey = hourSlotFromSentAt(row.sentAt, row.hourSlot);
          const list = hourMap.get(hourKey) ?? [];
          list.push(row);
          hourMap.set(hourKey, list);
        }

        const hourSlotGroups: HourSlotGroup[] = [...hourMap.entries()]
          .map(([hourSlot, slotRows]) => {
            const sorted = [...slotRows].sort(
              (a, b) => new Date(a.sentAt).getTime() - new Date(b.sentAt).getTime(),
            );
            return {
              hourSlot,
              rows: sorted,
              totalQty: sorted.reduce((s, r) => s + r.sentQty, 0),
            };
          })
          .sort((a, b) => hourSlotSortKey(a.hourSlot) - hourSlotSortKey(b.hourSlot));

        return {
          shiftId,
          shiftName,
          hourSlotGroups,
          totalQty: shiftRows.reduce((s, r) => s + r.sentQty, 0),
        };
      })
      .sort((a, b) => {
        const diff = shiftRank(a) - shiftRank(b);
        return diff !== 0 ? diff : a.shiftName.localeCompare(b.shiftName);
      });

    return {
      logDate,
      shiftGroups,
      totalQty: dayRows.reduce((s, r) => s + r.sentQty, 0),
    };
  });
}

export function defaultTransactionReportRange(): { dateFrom: string; dateTo: string } {
  const today = new Date();
  return {
    dateFrom: format(subDays(today, 30), 'yyyy-MM-dd'),
    dateTo: format(today, 'yyyy-MM-dd'),
  };
}

export async function fetchHandoverReport(
  factoryId: string,
  filters: HandoverReportFilters = {},
): Promise<HandoverReportRow[]> {
  const defaults = defaultTransactionReportRange();
  const { data, error } = await supabase.rpc('get_handover_report', {
    p_factory_id: factoryId,
    p_date_from: filters.dateFrom ?? defaults.dateFrom,
    p_date_to: filters.dateTo ?? defaults.dateTo,
    p_from_department_id: filters.fromDepartmentId ?? null,
    p_to_department_id: filters.toDepartmentId ?? null,
    p_status: filters.status ?? null,
    p_order_id: filters.orderId ?? null,
    p_colorway_id: filters.colorwayId ?? null,
    p_search: filters.search?.trim() || null,
  });

  if (error) throw error;
  return ((data as Record<string, unknown>[]) ?? []).map(mapRow);
}
