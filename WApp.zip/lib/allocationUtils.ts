import type { LineAllocation } from '../types';

/** SAM from a line_allocations row (column preferred; kpi_inputs fallback for legacy rows). */
export function allocationSamValue(row: {
  sam?: number | null;
  kpiInputs?: { sam?: number } | null;
  kpi_inputs?: { sam?: number } | null;
}): number {
  const direct = row.sam != null ? Number(row.sam) : NaN;
  if (!Number.isNaN(direct) && direct > 0) return direct;
  const kpi = row.kpiInputs ?? row.kpi_inputs;
  return Number(kpi?.sam) || 0;
}
export function allocationColorwayId(alloc: LineAllocation): string {
  return alloc.colorwayId || alloc.orderId;
}

export function allocationsForColorway(
  allocations: LineAllocation[],
  colorwayId: string,
): LineAllocation[] {
  return allocations.filter((a) => allocationColorwayId(a) === colorwayId);
}
