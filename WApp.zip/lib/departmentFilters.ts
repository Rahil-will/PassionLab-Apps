import type { DepartmentEntity } from '../types/settings';

export const PSEUDO_DEPT_NAMES = new Set(['Shipment', 'Quality Audit']);

/** Non-production departments (Shipment, Quality Audit) — not shown in Settings/planning lists. */
export function isProductionDepartment(
  dept: Pick<DepartmentEntity, 'name'> & { is_production?: boolean; isProduction?: boolean },
): boolean {
  if (dept.is_production === false || dept.isProduction === false) return false;
  return !PSEUDO_DEPT_NAMES.has(dept.name);
}

export function filterProductionDepartments<T extends Pick<DepartmentEntity, 'name'> & { is_production?: boolean; isProduction?: boolean }>(
  departments: T[],
): T[] {
  return departments.filter((d) => isProductionDepartment(d));
}
