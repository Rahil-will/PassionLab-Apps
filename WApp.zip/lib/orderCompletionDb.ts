import type { ColorwayCompletionStatus } from '../types';
import { supabase } from './supabase';

export class OrderCompletionError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'OrderCompletionError';
  }
}

export async function closeColorway(params: {
  factoryId: string;
  orderId: string;
  colorwayId: string;
  userId: string;
  mode: 'complete' | 'short_closed';
  reason?: string;
}): Promise<void> {
  const { factoryId, orderId, colorwayId, userId, mode, reason } = params;

  const status: ColorwayCompletionStatus = mode === 'complete' ? 'complete' : 'short_closed';
  const trimmedReason = reason?.trim() ?? '';

  if (mode === 'short_closed' && !trimmedReason) {
    throw new OrderCompletionError('A reason is required for short close.');
  }

  const { data: cw, error: cwErr } = await supabase
    .from('colorways')
    .select('id, order_id, completion_status')
    .eq('id', colorwayId)
    .eq('order_id', orderId)
    .single();

  if (cwErr || !cw) {
    throw new OrderCompletionError('Colorway not found.');
  }

  if (cw.completion_status === 'complete' || cw.completion_status === 'short_closed') {
    throw new OrderCompletionError('This colorway is already closed.');
  }

  const { error: updErr } = await supabase
    .from('colorways')
    .update({
      completion_status: status,
      closed_at: new Date().toISOString(),
      closed_by: userId || null,
      close_reason: trimmedReason || null,
    })
    .eq('id', colorwayId)
    .eq('order_id', orderId);

  if (updErr) throw new OrderCompletionError(updErr.message);

  const { data: siblings, error: sibErr } = await supabase
    .from('colorways')
    .select('completion_status')
    .eq('order_id', orderId);

  if (sibErr) throw new OrderCompletionError(sibErr.message);

  const allClosed =
    (siblings ?? []).length > 0 &&
    (siblings ?? []).every(
      (r) => r.completion_status === 'complete' || r.completion_status === 'short_closed',
    );

  if (allClosed) {
    const { error: orderErr } = await supabase
      .from('style_orders')
      .update({ status: 'Completed' })
      .eq('id', orderId)
      .eq('factory_id', factoryId);

    if (orderErr) throw new OrderCompletionError(orderErr.message);
  }
}

export async function reopenColorway(params: {
  factoryId: string;
  orderId: string;
  colorwayId: string;
}): Promise<void> {
  const { factoryId, orderId, colorwayId } = params;

  const { error: updErr } = await supabase
    .from('colorways')
    .update({
      completion_status: 'ongoing',
      closed_at: null,
      closed_by: null,
      close_reason: null,
    })
    .eq('id', colorwayId)
    .eq('order_id', orderId);

  if (updErr) throw new OrderCompletionError(updErr.message);

  const { error: orderErr } = await supabase
    .from('style_orders')
    .update({ status: 'In Production' })
    .eq('id', orderId)
    .eq('factory_id', factoryId)
    .eq('status', 'Completed');

  if (orderErr) throw new OrderCompletionError(orderErr.message);
}
