import { supabase } from './supabase';
import { invokeAdminEdgeFunction } from './adminApi';

export interface DeleteFactoryUserResult {
  authDeleted: boolean;
}

/**
 * Deletes a floor user via Supabase Edge Function (auth + profile cascade).
 * Falls back to profile-only delete if the edge function is not deployed yet.
 */
export async function deleteFactoryUser(
  userId: string,
  factoryId: string,
): Promise<DeleteFactoryUserResult> {
  try {
    await invokeAdminEdgeFunction('admin-delete-user', { userId, factoryId });
    return { authDeleted: true };
  } catch (err) {
    const message = err instanceof Error ? err.message : '';
    const edgeUnavailable =
      message.includes('Failed to send a request to the Edge Function') ||
      message.includes('Function not found') ||
      message.includes('404') ||
      message.includes('503') ||
      message.includes('service credentials');

    if (!edgeUnavailable) throw err;

    const { error } = await supabase
      .from('profiles')
      .delete()
      .eq('id', userId)
      .eq('factory_id', factoryId);
    if (error) throw error;
    return { authDeleted: false };
  }
}
