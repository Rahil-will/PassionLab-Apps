/** Format ISO date (yyyy-mm-dd) for display as dd-mm-yyyy */
export function formatDateDDMMYYYY(iso: string | undefined | null): string {
  if (!iso) return '—';
  const parts = iso.split('T')[0].split('-');
  if (parts.length !== 3) return iso;
  const [y, m, d] = parts;
  return `${d}-${m}-${y}`;
}

export function daysBetween(startIso: string, endIso: string): number {
  if (!startIso || !endIso) return 0;
  const start = new Date(startIso.split('T')[0]);
  const end = new Date(endIso.split('T')[0]);
  const diff = Math.ceil((end.getTime() - start.getTime()) / (1000 * 60 * 60 * 24));
  return diff > 0 ? diff : 0;
}

export function todayIso(): string {
  return new Date().toISOString().split('T')[0];
}
