/** Department app IDs stored in `departments.apps` (Settings → Department editor). */

import type { FactoryEntitlements } from './factoryEntitlements';
import { departmentEntitledApps, isFactoryFunctionEnabled } from './factoryEntitlements';

export type DeptAppId =
  | 'transaction'
  | 'hourly'
  | 'qc_log'
  | 'workforce_log'
  | 'attendance'
  | 'audit'
  | 'shipment_log'
  | 'final_rejection_log';

/** Assigned on user profile — not tied to a production department. */
export const FACTORY_FUNCTION_APPS: DeptAppId[] = ['shipment_log', 'final_rejection_log'];

export interface DeptAppOption {
  id: DeptAppId;
  label: string;
  description: string;
  group: 'core' | 'output' | 'workforce' | 'optional' | 'factory';
}

export const DEPT_APP_OPTIONS: DeptAppOption[] = [
  { id: 'transaction', label: 'Transaction', description: 'Handover challans between departments', group: 'core' },
  { id: 'hourly', label: 'Hourly Output', description: 'Hourly production count capture', group: 'output' },
  { id: 'qc_log', label: 'QC Log', description: 'Piece-wise quality inspection', group: 'output' },
  { id: 'workforce_log', label: 'Workforce Log', description: 'Headcount per shift', group: 'workforce' },
  { id: 'attendance', label: 'Attendance', description: 'Daily worker attendance', group: 'workforce' },
  { id: 'audit', label: 'Audit', description: 'Optional AQL batch audit', group: 'optional' },
  { id: 'shipment_log', label: 'Shipment Log', description: 'Log shipped quantities (factory function)', group: 'factory' },
  { id: 'final_rejection_log', label: 'Rejection Log', description: 'Log rejections (factory function)', group: 'factory' },
];

const SKIP = new Set(['none', 'none_workforce']);
const FACTORY_SET = new Set<string>(FACTORY_FUNCTION_APPS);

export function appsEnabledForDepartment(
  deptApps: string[] | undefined,
  entitlements?: FactoryEntitlements,
): DeptAppId[] {
  const raw = deptApps?.length ? deptApps : ['transaction'];
  const enabled = new Set<DeptAppId>();
  const entitled = entitlements ? departmentEntitledApps(entitlements) : null;
  for (const id of raw) {
    if (SKIP.has(id)) continue;
    if (!DEPT_APP_OPTIONS.some((o) => o.id === id)) continue;
    if (entitled && !entitled.has(id as DeptAppId)) continue;
    enabled.add(id as DeptAppId);
  }
  if (!enabled.has('transaction') && (!entitled || entitled.has('transaction'))) {
    enabled.add('transaction');
  }
  return DEPT_APP_OPTIONS.map((o) => o.id).filter((id) => enabled.has(id));
}

/** Production floor apps only (excludes shipment/rejection). */
export function departmentFloorApps(
  deptApps: string[] | undefined,
  entitlements?: FactoryEntitlements,
): DeptAppId[] {
  return appsEnabledForDepartment(deptApps, entitlements).filter((id) => !FACTORY_SET.has(id));
}

export function defaultAssignedApps(
  deptApps: string[] | undefined,
  entitlements?: FactoryEntitlements,
): DeptAppId[] {
  return departmentFloorApps(deptApps, entitlements);
}

const CANONICAL_APP_ORDER = DEPT_APP_OPTIONS.map((o) => o.id);

/** Preserve department / catalog order when persisting `profiles.assigned_apps`. */
export function sortAssignedApps(
  assigned: DeptAppId[],
  referenceOrder: readonly DeptAppId[] = CANONICAL_APP_ORDER,
): DeptAppId[] {
  const rank = new Map(referenceOrder.map((id, i) => [id, i]));
  return [...assigned].sort((a, b) => (rank.get(a) ?? 999) - (rank.get(b) ?? 999));
}

export function deptAppOptionsForFactory(entitlements: FactoryEntitlements): DeptAppOption[] {
  const entitled = departmentEntitledApps(entitlements);
  return DEPT_APP_OPTIONS.filter((o) => {
    if (FACTORY_SET.has(o.id)) return isFactoryFunctionEnabled(entitlements);
    return entitled.has(o.id);
  });
}

export function labelForDeptApp(id: string): string {
  return DEPT_APP_OPTIONS.find((o) => o.id === id)?.label ?? id;
}

export function canCaptureOnDesktop(role: string | undefined): boolean {
  return role === 'admin' || role === 'superadmin' || role === 'quality_manager';
}
