import { supabase } from './supabase';
import { useNavigationStore, type UserProfile } from '../stores/navigationStore';

export const DESKTOP_LOGIN_ROLES = new Set(['admin', 'superadmin']);

export interface RpcProfileRow {
  id: string;
  factory_id: string | null;
  full_name: string | null;
  email: string | null;
  user_role: string;
  status: string;
}

export function parseMyProfile(data: unknown): RpcProfileRow | null {
  if (!data || typeof data !== 'object') return null;
  const row = data as RpcProfileRow;
  if (!row.id) return null;
  return row;
}

export function profileToUserProfile(profile: RpcProfileRow, fallbackEmail: string): UserProfile {
  return {
    id: profile.id,
    fullName: profile.full_name || fallbackEmail.split('@')[0],
    email: profile.email || fallbackEmail,
    userRole: profile.user_role || 'admin',
  };
}

/** Returns an error message when this profile may not use the desktop app. */
export function desktopAccessError(profile: RpcProfileRow): string | null {
  if (!profile.factory_id) {
    return 'No factory assigned to this account. Contact RBC support.';
  }
  if (profile.status !== 'Active') {
    return 'Your account is inactive. Contact your administrator.';
  }
  if (!DESKTOP_LOGIN_ROLES.has(profile.user_role)) {
    return 'This account is for the floor mobile app. Sign in there with email and PIN.';
  }
  return null;
}

export async function fetchMyProfile(): Promise<{ profile: RpcProfileRow | null; error: string | null }> {
  const { data, error } = await supabase.rpc('get_my_profile');
  if (error) {
    const isNotFound = error.code === 'PGRST116';
    const message = isNotFound
      ? 'No user profile found for this account. Contact RBC support.'
      : error.message.includes('recursion')
        ? 'Account setup error. Contact RBC support.'
        : error.message || 'Could not load your profile.';
    return { profile: null, error: message };
  }
  const profile = parseMyProfile(data);
  if (!profile) {
    return { profile: null, error: 'No user profile found for this account. Contact RBC support.' };
  }
  return { profile, error: null };
}

export function applyAuthenticatedProfile(profile: RpcProfileRow, emailFallback: string): void {
  const store = useNavigationStore.getState();
  store.setAuthenticated(true);
  store.setFactoryId(profile.factory_id);
  store.setUserProfile(profileToUserProfile(profile, emailFallback));
}

export function clearAuthenticatedSession(): void {
  const store = useNavigationStore.getState();
  store.setAuthenticated(false);
  store.setFactoryId(null);
  store.setUserProfile(null);
}

/** Validate Supabase session + desktop profile; sync navigation store. */
export async function restoreAuthSession(): Promise<boolean> {
  const { data: sessionData } = await supabase.auth.getSession();
  const session = sessionData.session;
  if (!session) {
    clearAuthenticatedSession();
    return false;
  }

  const { profile, error } = await fetchMyProfile();
  if (error || !profile) {
    await supabase.auth.signOut();
    clearAuthenticatedSession();
    return false;
  }

  const accessError = desktopAccessError(profile);
  if (accessError) {
    await supabase.auth.signOut();
    clearAuthenticatedSession();
    return false;
  }

  applyAuthenticatedProfile(profile, session.user.email || '');
  return true;
}

export async function logoutDesktopSession(): Promise<void> {
  await supabase.auth.signOut();
  clearAuthenticatedSession();
}
