import {
  departmentFloorApps,
  FACTORY_FUNCTION_APPS,
  labelForDeptApp,
  sortAssignedApps,
  type DeptAppId,
} from './floorApps';
import type { FactoryEntitlements } from './factoryEntitlements';
import { defaultShipmentFunctionApps, isFactoryFunctionEnabled } from './factoryEntitlements';

export const FLOOR_LOGIN_ROLES = ['operator', 'supervisor', 'auditor', 'quality_manager'] as const;
export type FloorLoginRole = (typeof FLOOR_LOGIN_ROLES)[number];

export type UserAssignmentMode = 'department' | 'factory_function';

export const SHIPMENT_QA_LABEL = 'Shipment / QA';

export function isFloorLoginRole(role: string): role is FloorLoginRole {
  return (FLOOR_LOGIN_ROLES as readonly string[]).includes(role);
}

export function inferAssignmentMode(departmentId: string | null | undefined): UserAssignmentMode {
  return departmentId ? 'department' : 'factory_function';
}

export function hasShipmentQaApps(assigned: DeptAppId[]): boolean {
  return assigned.some((a) => FACTORY_FUNCTION_APPS.includes(a));
}

/** Floor apps selectable in User Management for department-assigned users. */
export function appsForAssignmentMode(
  mode: UserAssignmentMode,
  deptApps: string[] | undefined,
  entitlements?: FactoryEntitlements,
): DeptAppId[] {
  if (mode === 'factory_function') return [];
  return departmentFloorApps(deptApps, entitlements);
}

export function clampAssignedAppsToDepartment(
  assigned: DeptAppId[],
  deptApps: string[] | undefined,
  entitlements?: FactoryEntitlements,
): DeptAppId[] {
  const order = departmentFloorApps(deptApps, entitlements);
  const allowed = new Set(order);
  return sortAssignedApps(assigned.filter((a) => allowed.has(a)), order);
}

export function clampAssignedAppsToFactoryFunction(
  assigned: DeptAppId[],
  entitlements?: FactoryEntitlements,
): DeptAppId[] {
  const allowed = new Set(defaultShipmentFunctionApps(entitlements ?? {
    transaction: ['transaction'],
    production: [],
    workforce: [],
    audit: [],
    shipment: [...FACTORY_FUNCTION_APPS],
  }));
  return assigned.filter((a) => allowed.has(a));
}

export function formatAssignedAppsLabel(assigned: DeptAppId[]): string {
  const shipment = assigned.filter((a) => FACTORY_FUNCTION_APPS.includes(a));
  const floor = sortAssignedApps(assigned.filter((a) => !FACTORY_FUNCTION_APPS.includes(a)));
  const parts = floor.map(labelForDeptApp);
  if (shipment.length > 0) parts.push(SHIPMENT_QA_LABEL);
  return parts.join(', ');
}

export function validateFloorUserPayload(input: {
  fullName: string;
  email: string;
  floorPin: string;
  departmentId: string | null | undefined;
  assignedApps: DeptAppId[];
  deptApps: string[] | undefined;
  userRole?: string;
  entitlements?: FactoryEntitlements;
}): string | null {
  if (!input.fullName.trim()) return 'Full name is required';
  if (!input.email.trim() || !input.email.includes('@')) return 'Valid email is required';
  if (input.floorPin.length !== 4) return 'PIN must be 4 digits';
  if (input.assignedApps.length === 0) return 'Select at least one floor app';

  const mode = inferAssignmentMode(input.departmentId || null);

  if (mode === 'department') {
    if (!input.departmentId) return 'Department is required for floor operators';
    const allowed = new Set(departmentFloorApps(input.deptApps, input.entitlements));
    if (!input.assignedApps.every((a) => allowed.has(a))) {
      return 'Assigned apps must be enabled for this department';
    }
    if (input.assignedApps.some((a) => FACTORY_FUNCTION_APPS.includes(a))) {
      return 'Shipment / QA is a factory function — use that assignment mode';
    }
    return null;
  }

  if (!isFactoryFunctionEnabled(input.entitlements ?? {
    transaction: ['transaction'],
    production: [],
    workforce: [],
    audit: [],
    shipment: [],
  })) {
    return 'Shipment / QA is not enabled for this factory';
  }

  if (input.departmentId) {
    return 'Clear department when using Shipment / QA assignment mode';
  }
  const allowed = new Set(defaultShipmentFunctionApps(input.entitlements ?? {
    transaction: ['transaction'],
    production: [],
    workforce: [],
    audit: [],
    shipment: [...FACTORY_FUNCTION_APPS],
  }));
  if (!input.assignedApps.every((a) => allowed.has(a))) {
    return 'Shipment / QA users can only use enabled shipment apps for this factory';
  }
  return null;
}
