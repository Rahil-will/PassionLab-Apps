import type { StyleOrder } from '../types';
import { supabase } from './supabase';
import { colorwayToDbRow } from './colorwayDb';
import { styleOrderToDbRow } from './styleOrderDb';

function rpcDeployHint(message: string): string {
  if (
    message.includes('Could not find the function') ||
    message.includes('function public.save_style_order') ||
    message.includes('schema cache')
  ) {
    return ' Apply migration save_style_order_rpc to Supabase.';
  }
  return '';
}

/**
 * Persist style order header + all colorways in a single DB transaction.
 * On any failure the entire write rolls back — no partial order saves.
 */
export async function saveStyleOrderAtomic(
  factoryId: string,
  order: Partial<StyleOrder>,
  orderId?: string,
): Promise<string> {
  const resolvedId = orderId ?? order.id ?? crypto.randomUUID();
  const orderRow = styleOrderToDbRow(order, factoryId, resolvedId);
  const colorwayRows = (order.colorways ?? []).map((c) => colorwayToDbRow(c, resolvedId));

  const { data, error } = await supabase.rpc('save_style_order', {
    p_factory_id: factoryId,
    p_order: orderRow,
    p_colorways: colorwayRows,
  });

  if (error) {
    throw new Error(error.message + rpcDeployHint(error.message));
  }

  if (typeof data !== 'string' || !data) {
    throw new Error('Save order did not return an id');
  }

  return data;
}
