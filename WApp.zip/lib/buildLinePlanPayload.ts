import type { AssignedResource } from '../types';
import type { PlanningRow } from '../pages/planning/types';
import { calculateDailyAverage, calculateWorkingDays } from '../pages/planning/utils/planningCalculations';
import { referenceSewingSam } from './orderPriority';
import { hourlyTargetFromDaily } from './shiftHours';
import type { ColorwayPlanPayload, LinePlanAllocationPayload } from './saveLinePlan';

export interface ColorwayPlanningRows {
  colorId: string;
  colorName: string;
  rows: PlanningRow[];
}

export interface BuildLinePlanResult {
  colorwayPlans: ColorwayPlanPayload[];
  totalSaved: number;
  colorsSaved: number;
}

export function buildColorwayPlanPayloads(
  order: {
    styleName?: string;
    poNumber?: string;
    sewingSam?: number | null;
    sam?: number | null;
  },
  colorRows: ColorwayPlanningRows[],
  assignedResources: AssignedResource[],
  regularShiftHours: number,
  regularShiftMinsPerDay: number,
): BuildLinePlanResult {
  const colorwayPlans: ColorwayPlanPayload[] = [];
  let totalSaved = 0;
  let colorsSaved = 0;
  const referenceSam = referenceSewingSam(order);

  for (const { colorId, colorName, rows } of colorRows) {
    const validRows = rows.filter(
      (r) => r.resourceId && r.startDate && r.endDate && r.plannedQty > 0,
    );

    const allocations: LinePlanAllocationPayload[] = [];

    for (const row of validRows) {
      const resource = assignedResources.find((r) => r.id === row.resourceId);
      const rowWorkforce = row.workforce || (resource as { avgWF?: number })?.avgWF || 1;
      const rowSam = row.sam ?? referenceSam;
      const workingDays =
        row.startDate && row.endDate
          ? Math.max(1, calculateWorkingDays(row.startDate, row.endDate))
          : 1;
      const dailyTarget = row.dailyTargetOverridden
        ? row.dailyTarget
        : calculateDailyAverage(row.plannedQty, workingDays);
      const hourlyTarget = hourlyTargetFromDaily(dailyTarget, regularShiftHours);
      const totalMins = rowWorkforce * regularShiftMinsPerDay * workingDays;
      const efficiency = totalMins > 0 ? ((row.plannedQty * rowSam) / totalMins) * 100 : 0;
      const productivity =
        rowWorkforce > 0 && workingDays > 0 ? row.plannedQty / (rowWorkforce * workingDays) : 0;

      const allocId = row.id?.startsWith('temp-') ? crypto.randomUUID() : (row.id || crypto.randomUUID());

      allocations.push({
        id: allocId,
        line_id: row.resourceId,
        department_id: resource?.departmentId || null,
        start_date: row.startDate,
        end_date: row.endDate,
        qty: row.plannedQty,
        daily_target: dailyTarget,
        hourly_target: hourlyTarget,
        sam: rowSam,
        kpi_inputs: {
          workforce: rowWorkforce,
          sam: rowSam,
          efficiency: Math.round(efficiency * 10) / 10,
          productivity: Math.round(productivity * 10) / 10,
        },
        style_name: order.styleName || '',
        po_number: order.poNumber || '',
        colorway: colorName,
        completed_is_true: false,
      });
      totalSaved++;
    }

    colorwayPlans.push({ colorway_id: colorId, allocations });
    colorsSaved++;
  }

  return { colorwayPlans, totalSaved, colorsSaved };
}
