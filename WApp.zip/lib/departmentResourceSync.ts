import type { SupabaseClient } from '@supabase/supabase-js';
import { assignedResourceToDbRow } from './assignedResourceDb';
import type { DepartmentResource } from '../types/settings';

export function mapDepartmentResourceFromDb(
  row: Record<string, unknown>,
  departmentId: string,
  departmentName?: string,
): DepartmentResource {
  return {
    id: row.id as string,
    resourceName: (row.resource_name as string) || '',
    departmentId,
    departmentName,
    defaultPcs: (row.capacity as number) || 0,
  };
}

function cloneResources(resources: DepartmentResource[]): DepartmentResource[] {
  return resources.map((r) => ({ ...r }));
}

export interface DepartmentResourceDiff {
  toDelete: string[];
  toInsert: DepartmentResource[];
  toUpdate: DepartmentResource[];
}

export function diffDepartmentResources(
  baseline: DepartmentResource[],
  draft: DepartmentResource[],
): DepartmentResourceDiff {
  const baselineById = new Map(baseline.map((r) => [r.id, r]));
  const draftIds = new Set(draft.map((r) => r.id));

  const toDelete = baseline.filter((r) => !draftIds.has(r.id)).map((r) => r.id);
  const toInsert = draft.filter((r) => !baselineById.has(r.id));
  // Existing rows are updated so name/capacity/type stay aligned (e.g. outsourced toggle).
  const toUpdate = draft.filter((r) => baselineById.has(r.id));

  return { toDelete, toInsert, toUpdate };
}

export async function syncDepartmentResourcesToDb(
  client: SupabaseClient,
  opts: {
    departmentId: string;
    factoryId: string;
    isOutsourced: boolean;
    draft: DepartmentResource[];
    baseline: DepartmentResource[];
  },
): Promise<DepartmentResource[]> {
  const { departmentId, factoryId, isOutsourced, draft, baseline } = opts;
  const resourceType = isOutsourced ? 'outsourced' : 'inhouse';
  const { toDelete, toInsert, toUpdate } = diffDepartmentResources(baseline, draft);

  if (toDelete.length > 0) {
    const { error } = await client.from('assigned_resources').delete().in('id', toDelete);
    if (error) throw error;
  }

  for (const resource of toUpdate) {
    const { error } = await client
      .from('assigned_resources')
      .update({
        resource_name: resource.resourceName.trim(),
        capacity: resource.defaultPcs ?? 0,
        resource_type: resourceType,
      })
      .eq('id', resource.id);
    if (error) throw error;
  }

  if (toInsert.length > 0) {
    const { error } = await client.from('assigned_resources').insert(
      toInsert.map((resource) =>
        assignedResourceToDbRow(
          {
            id: resource.id,
            resourceName: resource.resourceName,
            defaultPcs: resource.defaultPcs,
          },
          { factoryId, departmentId, resourceType },
        ),
      ),
    );
    if (error) throw error;
  }

  return cloneResources(draft);
}
