export function actualDateRange(alloc: {
  startDate: string;
  endDate: string;
  actualStartDate?: string;
  actualEndDate?: string;
}): { start: string; end: string } | null {
  const start = alloc.actualStartDate?.slice(0, 10);
  const end = alloc.actualEndDate?.slice(0, 10);
  if (start && end) return { start, end };
  if (start) return { start, end: end || start };
  return null;
}
