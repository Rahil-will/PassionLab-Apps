import React, { useCallback, useEffect, useMemo, useState } from "react";
import { format, startOfMonth, endOfMonth } from "date-fns";
import { Search } from "lucide-react";
import { useDataStore, useNavigationStore, useSettingsStore } from "../stores";
import { PageShell, PageToolbarCard } from "../components/layout/PageShell";
import { RoutePath } from "../types";
import {
  Activity,
  Gauge,
  PackageCheck,
  Ship,
  Target,
  TrendingUp,
} from "lucide-react";
import { SelectDropdown } from "../components/ui";
import { DateRangePicker, DateRangeValue } from "../components/DateRangePicker";
import { fetchCutToShipReport, fetchFactoryKpis } from "../lib/mesReportsApi";
import { buildColorwayCutShipItems, matchesColorwaySearch } from "../lib/cutToShipList";
import {
  aggregateFulfillmentKpis,
  buildFulfillmentSnapshot,
  deliveryInRange,
  formatFulfillmentPct,
} from "../lib/fulfillmentMetrics";
import {
  aggregateByDay,
  isOrderInProduction,
  wipForLatestDay,
} from "../lib/dashboardData";
import { DailyTrendChart, EfficiencyLineChart } from "../components/reports/ReportCharts";

const KPICard: React.FC<{
  title: string;
  value: string;
  subtext: string;
  icon: React.ElementType;
  accent: string;
  iconAccent: string;
}> = ({ title, value, subtext, icon: Icon, accent, iconAccent }) => (
  <div className="relative bg-white border border-slate-200 rounded-xl shadow-sm min-h-[92px] overflow-hidden flex flex-col justify-center px-4 py-3">
    <Icon
      className={`absolute -right-2 -bottom-2 w-16 h-16 opacity-[0.1] pointer-events-none ${iconAccent}`}
      strokeWidth={1.25}
    />
    <div className="relative z-10">
      <div className="text-[9px] font-bold text-slate-400 uppercase tracking-wider mb-0.5">{title}</div>
      <div className={`text-xl font-bold tracking-tight ${accent}`}>{value}</div>
      <div className="text-[10px] text-slate-500 mt-0.5">{subtext}</div>
    </div>
  </div>
);

function toYmd(iso: string): string {
  return format(new Date(iso), "yyyy-MM-dd");
}

function avg(nums: number[]): number | null {
  if (nums.length === 0) return null;
  return nums.reduce((a, b) => a + b, 0) / nums.length;
}

export const Dashboard: React.FC = () => {
  const { orders, loading: dataLoading, fetchData } = useDataStore();
  const { navigate, factoryId } = useNavigationStore();
  const { loading: settingsLoading } = useSettingsStore();

  const today = new Date();
  const [dateRange, setDateRange] = useState<DateRangeValue>({
    startDate: startOfMonth(today).toISOString(),
    endDate: endOfMonth(today).toISOString(),
  });
  const [buyerFilter, setBuyerFilter] = useState("");
  const [searchQuery, setSearchQuery] = useState("");
  const [cutRows, setCutRows] = useState<Awaited<ReturnType<typeof fetchCutToShipReport>>>([]);
  const [kpiRows, setKpiRows] = useState<Awaited<ReturnType<typeof fetchFactoryKpis>>>([]);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState<string | null>(null);

  const dateFrom = toYmd(dateRange.startDate);
  const dateTo = toYmd(dateRange.endDate);

  useEffect(() => {
    void fetchData();
  }, [fetchData]);

  const loadDashboard = useCallback(async () => {
    if (!factoryId) {
      setCutRows([]);
      setKpiRows([]);
      setLoading(false);
      return;
    }
    setLoading(true);
    setLoadError(null);
    try {
      const [cut, kpis] = await Promise.all([
        fetchCutToShipReport(factoryId, { buyerId: buyerFilter || null }),
        fetchFactoryKpis(factoryId, dateFrom, dateTo),
      ]);
      setCutRows(cut);
      setKpiRows(kpis);
    } catch (err) {
      setLoadError(err instanceof Error ? err.message : "Failed to load dashboard");
      setCutRows([]);
      setKpiRows([]);
    } finally {
      setLoading(false);
    }
  }, [factoryId, buyerFilter, dateFrom, dateTo]);

  useEffect(() => {
    void loadDashboard();
  }, [loadDashboard]);

  const buyerOptions = useMemo(() => {
    const names = new Set<string>();
    for (const o of orders) {
      if (o.buyer) names.add(o.buyer);
    }
    return [{ value: "", label: "All buyers" }, ...[...names].sort().map((b) => ({ value: b, label: b }))];
  }, [orders]);

  const colorwayItems = useMemo(
    () => buildColorwayCutShipItems(cutRows, orders, new Map()),
    [cutRows, orders],
  );

  const scopedItems = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return colorwayItems.filter((item) => {
      const order = orders.find((o) => o.id === item.orderId);
      if (!order) return false;
      if (buyerFilter && order.buyer !== buyerFilter) return false;
      if (q && !matchesColorwaySearch(item, q)) return false;
      return deliveryInRange(order.deliveryDate, dateFrom, dateTo);
    });
  }, [colorwayItems, orders, buyerFilter, searchQuery, dateFrom, dateTo]);

  const snapshots = useMemo(() => {
    return scopedItems.map((item) => {
      const order = orders.find((o) => o.id === item.orderId);
      return buildFulfillmentSnapshot(item.row, order?.deliveryDate, item.completionStatus);
    });
  }, [scopedItems, orders]);

  const fulfillmentKpis = useMemo(() => aggregateFulfillmentKpis(snapshots), [snapshots]);

  const dailyOutput = useMemo(() => aggregateByDay(kpiRows), [kpiRows]);

  const efficiencyByDay = useMemo(() => {
    const byDay = new Map<string, number[]>();
    for (const row of kpiRows) {
      if (row.daily_efficiency_pct == null) continue;
      const list = byDay.get(row.log_date) ?? [];
      list.push(row.daily_efficiency_pct);
      byDay.set(row.log_date, list);
    }
    return [...byDay.entries()]
      .sort(([a], [b]) => a.localeCompare(b))
      .map(([date, effs]) => ({
        date,
        efficiency: avg(effs) != null ? Math.round(avg(effs)!) : null,
      }));
  }, [kpiRows]);

  const productionKpis = useMemo(() => {
    const periodOutput = kpiRows.reduce((s, r) => s + (r.daily_output || 0), 0);
    const periodTarget = kpiRows.reduce((s, r) => s + (r.daily_target || 0), 0);
    const effValues = kpiRows
      .map((r) => r.daily_efficiency_pct)
      .filter((v): v is number => v != null);
    const avgEff = avg(effValues);
    const activeOrders = orders.filter((o) => isOrderInProduction(o.status)).length;
    const wip = wipForLatestDay(kpiRows);
    const efficiencyPct =
      periodTarget > 0 ? Math.round((periodOutput / periodTarget) * 100) : avgEff != null ? Math.round(avgEff) : null;
    const todayKey = format(new Date(), "yyyy-MM-dd");
    const todayOutput = kpiRows
      .filter((r) => r.log_date === todayKey)
      .reduce((s, r) => s + (r.daily_output || 0), 0);
    return { periodOutput, periodTarget, efficiencyPct, activeOrders, wip, todayOutput };
  }, [kpiRows, orders]);

  const attentionOrders = useMemo(() => {
    const byOrder = new Map<
      string,
      { orderId: string; styleName: string; poNumber: string; o2s: number | null; gap: number }
    >();
    for (let i = 0; i < scopedItems.length; i++) {
      const item = scopedItems[i];
      const snap = snapshots[i];
      const existing = byOrder.get(item.orderId);
      const o2s = snap.orderToShipPct;
      const gap = Math.max(0, snap.orderQty - snap.shippedQty);
      if (!existing) {
        byOrder.set(item.orderId, {
          orderId: item.orderId,
          styleName: item.styleName,
          poNumber: item.poNumber,
          o2s,
          gap,
        });
      } else {
        existing.gap += gap;
        if (o2s != null) {
          existing.o2s = existing.o2s == null ? o2s : Math.min(existing.o2s, o2s);
        }
      }
    }
    return [...byOrder.values()]
      .filter((o) => o.gap > 0)
      .sort((a, b) => (a.o2s ?? 0) - (b.o2s ?? 0))
      .slice(0, 8);
  }, [scopedItems, snapshots]);

  const pageLoading = dataLoading || settingsLoading || loading;

  return (
    <PageShell loading={pageLoading} skeleton="card" className="space-y-4 pb-20">
      <PageToolbarCard className="mes-page-chrome !overflow-visible relative z-20">
        <div className="flex flex-col lg:flex-row lg:items-center gap-3 w-full min-w-0">
          <div className="flex items-center gap-2 flex-1 min-w-0 w-full lg:max-w-md">
            <Search size={14} className="text-slate-400 shrink-0" />
            <input
              className="text-xs bg-transparent border-b border-slate-200 focus:border-blue-500 focus:outline-none py-1 flex-1 w-full min-w-0"
              placeholder="Search style, PO…"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          <div className="flex flex-col sm:flex-row flex-wrap items-stretch sm:items-center gap-3 w-full lg:w-auto lg:ml-auto lg:justify-end">
            <DateRangePicker
              variant="pill"
              dropdownAlign="right"
              value={dateRange}
              onChange={setDateRange}
              className="w-full sm:w-auto"
            />
            <SelectDropdown
              value={buyerFilter}
              onChange={setBuyerFilter}
              options={buyerOptions}
              className="w-full sm:w-44"
            />
          </div>
        </div>
      </PageToolbarCard>

      {loadError && (
        <div className="text-xs text-red-600 bg-red-50 border border-red-100 rounded-lg px-3 py-2">
          {loadError}
        </div>
      )}

      <div className="grid grid-cols-[repeat(auto-fit,minmax(9.5rem,1fr))] gap-3">
        <KPICard
          title="Today output"
          value={productionKpis.todayOutput.toLocaleString()}
          subtext="All departments · today"
          icon={TrendingUp}
          accent="text-blue-700"
          iconAccent="text-blue-600"
        />
        <KPICard
          title="Period output"
          value={productionKpis.periodOutput.toLocaleString()}
          subtext={`Target ${productionKpis.periodTarget.toLocaleString()} pcs`}
          icon={TrendingUp}
          accent="text-slate-800"
          iconAccent="text-slate-500"
        />
        <KPICard
          title="Efficiency"
          value={productionKpis.efficiencyPct != null ? `${productionKpis.efficiencyPct}%` : "—"}
          subtext="Output vs plan"
          icon={Gauge}
          accent="text-violet-700"
          iconAccent="text-violet-600"
        />
        <KPICard
          title="Floor WIP"
          value={productionKpis.wip.toLocaleString()}
          subtext="Pieces on floor now"
          icon={Activity}
          accent="text-amber-700"
          iconAccent="text-amber-600"
        />
        <KPICard
          title="Active orders"
          value={String(productionKpis.activeOrders)}
          subtext="In production"
          icon={Target}
          accent="text-slate-800"
          iconAccent="text-slate-500"
        />
        <KPICard
          title="Order → Ship"
          value={formatFulfillmentPct(fulfillmentKpis.orderToShipPct)}
          subtext={`${fulfillmentKpis.shippedQty.toLocaleString()} / ${fulfillmentKpis.orderQty.toLocaleString()} pcs`}
          icon={Ship}
          accent="text-emerald-700"
          iconAccent="text-emerald-600"
        />
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
        <DailyTrendChart
          data={dailyOutput.map((d) => ({ date: d.logDate, output: d.output, target: d.target }))}
          title="Factory output trend"
          subtitle="All departments combined · pieces out vs daily plan"
          height={280}
        />
        <EfficiencyLineChart
          data={efficiencyByDay}
          title="Efficiency trend"
          subtitle="All departments · daily average %"
          height={280}
        />
      </div>

      {attentionOrders.length > 0 && (
        <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-4">
          <p className="text-xs font-bold text-slate-700 uppercase tracking-wide mb-3">
            Orders with balance to ship
          </p>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2">
            {attentionOrders.map((o) => (
              <button
                key={o.orderId}
                type="button"
                onClick={() => navigate(RoutePath.ORDER_COMPLETION, { orderId: o.orderId })}
                className="text-left rounded-lg border border-slate-100 px-3 py-2.5 hover:bg-slate-50 transition-colors"
              >
                <div className="text-xs font-semibold text-slate-800 truncate">{o.styleName}</div>
                <div className="text-[10px] text-slate-500 mt-0.5">PO {o.poNumber}</div>
                <div className="mt-1.5 flex items-center justify-between text-[10px]">
                  <span className="text-emerald-700 font-semibold tabular-nums">
                    O→S {formatFulfillmentPct(o.o2s)}
                  </span>
                  <span className="text-amber-700 font-semibold tabular-nums">
                    {o.gap.toLocaleString()} short
                  </span>
                </div>
              </button>
            ))}
          </div>
        </div>
      )}
    </PageShell>
  );
};
