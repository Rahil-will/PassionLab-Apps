﻿import React, { useState, useEffect, useMemo } from 'react';
import { useNavigationStore, useDataStore, useSettingsStore } from '../../stores';
import { RoutePath } from '../../types';
import { Factory, ExternalLink, FileText, Eye, Calendar, BarChart3, TrendingUp, Scissors } from 'lucide-react';
import { flowTableClasses as t } from '../../lib/productionFlowTable';
import { sizeAdjQty, sizeOrderQty } from '../../lib/colorwaySizesUtils';
import { resolveOrderProcessFlow } from '../../lib/processFlowDb';
import { Card, Skeleton } from '../../components/ui';
import { PageShell } from '../../components/layout/PageShell';
import { StyleInformationCard } from '../../components/production/StyleInformationCard';
import { DepartmentScheduleGantt } from '../../components/production/DepartmentScheduleGantt';
import { allocationsForColorway } from '../../lib/allocationUtils';
import { useOrderSizeProgress } from '../../hooks/useOrderSizeProgress';
import {
    deriveColorwayProgressPhase,
    deriveSizeProgressPhase,
    formatProductionStatus,
    statusColorClass,
} from '../../lib/orderSizeProgress';
import { SummaryModal } from '../planning/components/SummaryModal';
import { buildColorwayPlansForSummary } from '../planning/utils/planningSummary';
import { getRegularShiftHours } from '../../lib/shiftHours';
import { buildPlanningDetailParams } from '../../lib/planningNavigation';
import { useRefreshProductionDataOnMount } from '../../hooks/useRefreshProductionDataOnMount';

function renderProgressCount(loading: boolean, count: number): React.ReactNode {
    if (loading) return <Skeleton className="h-3 w-8 mx-auto rounded" />;
    if (count > 0) return count.toLocaleString();
    return <span className="text-slate-200">—</span>;
}

export const StyleColorDetails: React.FC = () => {
    const { navigate, routeParams, factoryId } = useNavigationStore();
    const { orders, allocations = [], productionSummary, setWipOrder, loading, assignedResources } = useDataStore();
    const { processFlows, sizeGroups, shifts, loading: settingsLoading } = useSettingsStore();

    useRefreshProductionDataOnMount();

    const [activeTab, setActiveTab] = useState<'production' | 'reports'>('production');
    const [showSummaryModal, setShowSummaryModal] = useState(false);

    useEffect(() => {
        window.scrollTo(0, 0);
    }, []);

    const orderId = routeParams?.id;
    const colorId = routeParams?.colorId;

    const order = orders.find(o => o.id === orderId);
    const colorway = order?.colorways.find(c => c.id === colorId);

    const flowMeta = useMemo(() => {
        if (!order || settingsLoading) return null;
        return resolveOrderProcessFlow(processFlows, order.processFlow);
    }, [order, processFlows, settingsLoading]);

    const flowSteps = flowMeta?.flowSteps ?? [];
    const flowStepObjects = flowMeta?.flowStepObjects ?? [];
    const flowLabel = flowMeta?.flowLabel ?? null;

    const styleAllocations = useMemo(
        () => (colorway ? allocationsForColorway(allocations, colorway.id) : []),
        [allocations, colorway],
    );

    const regularShiftHours = useMemo(() => getRegularShiftHours(shifts), [shifts]);

    const colorwayPlansForSummary = useMemo(() => {
        if (!order || !colorway) return [];
        return buildColorwayPlansForSummary(order, allocations, assignedResources, colorway.id);
    }, [order, colorway, allocations, assignedResources]);

    const totalOrderQty = colorway
        ? (colorway.orderQty || colorway.sizes.reduce((a, s) => a + sizeOrderQty(s), 0))
        : 0;
    const totalPlannedQty = colorway
        ? colorway.sizes.reduce((a, s) => a + sizeAdjQty(s), 0)
        : 0;

    const pageReady = !loading && !settingsLoading && flowMeta !== null;

    const { lookup: sizeProgress, loading: progressLoading } = useOrderSizeProgress(
        factoryId,
        orderId,
        colorway ? [colorway.id] : [],
        flowStepObjects,
    );

    const getDeptTotal = (deptName: string): number => {
        if (!order || !colorway) return 0;
        if (sizeProgress) return sizeProgress.getDeptTotal(colorway.id, deptName);
        return productionSummary
            .filter(
                (r) =>
                    r.order_id === order.id &&
                    r.colorway_id === colorway.id &&
                    r.department === deptName,
            )
            .reduce((sum, r) => sum + (r.total_passed || r.total_scanned || 0), 0);
    };

    const getSizeCount = (deptName: string, size: string): number => {
        if (!colorway) return 0;
        if (sizeProgress) return sizeProgress.getSizeCount(colorway.id, deptName, size);
        return 0;
    };

    const colorwayPhase = useMemo(
        () =>
            deriveColorwayProgressPhase(flowSteps, totalPlannedQty, getDeptTotal),
        [flowSteps, totalPlannedQty, sizeProgress, productionSummary, order?.id, colorway?.id],
    );

    const matrixTotals = useMemo(() => {
        const totals = { orderQty: 0, adjQty: 0 };
        if (!colorway) return totals;
        colorway.sizes.forEach(s => {
            totals.orderQty += sizeOrderQty(s);
            totals.adjQty += sizeAdjQty(s);
        });
        return totals;
    }, [colorway]);

    const planDeptSummary = useMemo(() => {
        const byDept = new Map<string, number>();
        for (const alloc of styleAllocations) {
            const resource = assignedResources.find((r) => r.id === alloc.lineId);
            const deptName = resource?.departmentName ?? 'Unassigned';
            byDept.set(deptName, (byDept.get(deptName) ?? 0) + alloc.qty);
        }
        return [...byDept.entries()]
            .map(([dept, qty]) => `${dept}: ${qty.toLocaleString()}`)
            .join(', ');
    }, [styleAllocations, assignedResources]);

    const sizeGroupName = order?.sizeGroupName || 'Standard';

    const planStartDate = styleAllocations.reduce<string | null>((earliest, a) => {
        if (!a.startDate) return earliest;
        if (!earliest || a.startDate < earliest) return a.startDate;
        return earliest;
    }, null);

    const reportRows = useMemo(() => {
        if (!order || !colorway) return [];
        const reportScope = { order: order.id, colorway: colorway.id };
        const rows: Array<{
            key: string;
            label: string;
            icon: typeof Calendar;
            tone: string;
            date: string;
            details: string;
            status: string;
            onView?: () => void;
            onOpen?: () => void;
        }> = [];

        if (styleAllocations.length > 0) {
            rows.push({
                key: 'plan',
                label: 'Production Plan',
                icon: Calendar,
                tone: 'emerald',
                date: planStartDate || '—',
                details: `${styleAllocations.length} allocations${planDeptSummary ? ` · (${planDeptSummary})` : ''}`,
                status: 'Saved',
                onView: () => setShowSummaryModal(true),
                onOpen: () =>
                    navigate(
                        RoutePath.PLANNING_DETAIL,
                        buildPlanningDetailParams(order.id, orders, colorway.id),
                    ),
            });
        }

        rows.push(
            {
                key: 'style',
                label: 'Style Report',
                icon: BarChart3,
                tone: 'blue',
                date: 'Live',
                details: `Output, target, efficiency for ${order.styleName}`,
                status: 'Actuals',
                onView: () => navigate(RoutePath.REPORTS_STYLE, reportScope),
            },
            {
                key: 'day',
                label: 'Day Report',
                icon: TrendingUp,
                tone: 'violet',
                date: 'Live',
                details: `Hourly output for ${colorway.name}`,
                status: 'Actuals',
                onView: () => navigate(RoutePath.REPORTS_DAY, reportScope),
            },
            {
                key: 'order-completion',
                label: 'Order Completion',
                icon: Scissors,
                tone: 'rose',
                date: 'Live',
                details: `Balance, rejections, and shipment for ${colorway.name}`,
                status: 'Actuals',
                onView: () => navigate(RoutePath.ORDER_COMPLETION, reportScope),
            },
        );

        return rows;
    }, [order, colorway, styleAllocations, planDeptSummary, planStartDate, navigate, orders]);

    React.useEffect(() => {
        if (!pageReady) return;
        if (!orderId || !colorId || !order || !colorway) navigate(RoutePath.LINE_ASSIGNMENT);
    }, [pageReady, orderId, colorId, order, colorway, navigate]);

    if (!pageReady) {
        return <PageShell loading skeleton="spinner" />;
    }

    if (!order || !colorway) {
        return (
            <div className="flex flex-col items-center justify-center h-[50vh] text-slate-400">
                <p>Redirecting...</p>
            </div>
        );
    }

    const toneClasses: Record<string, { bg: string; icon: string; badge: string }> = {
        emerald: { bg: 'bg-emerald-100', icon: 'text-emerald-600', badge: 'bg-emerald-100 text-emerald-700' },
        blue: { bg: 'bg-blue-100', icon: 'text-blue-600', badge: 'bg-blue-100 text-blue-700' },
        violet: { bg: 'bg-violet-100', icon: 'text-violet-600', badge: 'bg-violet-100 text-violet-700' },
        amber: { bg: 'bg-amber-100', icon: 'text-amber-600', badge: 'bg-amber-100 text-amber-700' },
        rose: { bg: 'bg-rose-100', icon: 'text-rose-600', badge: 'bg-rose-100 text-rose-700' },
    };

    return (
        <>
        <PageShell className="w-full pb-32">
            <div className="space-y-8">

                <StyleInformationCard
                    order={order}
                    sizeGroupName={sizeGroupName}
                    flowSteps={flowSteps}
                    flowLabel={flowLabel || '—'}
                    colorwayName={colorway.name}
                    stats={{
                        orderQty: totalOrderQty,
                        cutAllow: order.cuttingAllowance || 0,
                        shipAllow: order.shipmentAllowance || 0,
                        totalAdjusted: totalPlannedQty,
                    }}
                    onEdit={() => {
                        setWipOrder(JSON.parse(JSON.stringify(order)));
                        navigate(RoutePath.CREATE_ORDER, { id: order.id });
                    }}
                />

                <div className="flex items-center gap-1 border-b border-slate-200 bg-transparent pt-2">
                    <button
                        onClick={() => setActiveTab('production')}
                        className={`px-6 py-3 text-xs font-bold flex items-center gap-2 border-b-2 transition-all ${activeTab === 'production' ? 'border-blue-500 text-blue-600 bg-white shadow-sm rounded-t-lg' : 'border-transparent text-slate-500 hover:text-slate-700 hover:bg-slate-50 rounded-t-lg'}`}
                    >
                        <Factory size={16} /> Production
                    </button>
                    <button
                        onClick={() => setActiveTab('reports')}
                        className={`px-6 py-3 text-xs font-bold flex items-center gap-2 border-b-2 transition-all ${activeTab === 'reports' ? 'border-blue-500 text-blue-600 bg-white shadow-sm rounded-t-lg' : 'border-transparent text-slate-500 hover:text-slate-700 hover:bg-slate-50 rounded-t-lg'}`}
                    >
                        <FileText size={16} /> Reports
                    </button>
                </div>

                <div className="animate-in fade-in duration-300">
                    {activeTab === 'production' && (
                        <div className="space-y-8">
                            <Card title="Production Matrix" subtitle={flowLabel || '—'} className="shadow-sm border-slate-200" noPadding>
                                <div className="p-6">
                                <div className={t.wrapper}>
                                <div className={t.scroll}>
                                    <table className={t.table}>
                                        <thead className={t.thead}>
                                            <tr>
                                                <th className={t.firstHead}>Size</th>
                                                <th className={t.numHead}>Order</th>
                                                <th className={t.adjHead}>Adj.</th>
                                                {flowSteps.map(dept => (
                                                    <th key={dept} className={t.deptHead}>{dept}</th>
                                                ))}
                                                <th className={t.statusHead}>Status</th>
                                            </tr>
                                        </thead>
                                        <tbody className="divide-y divide-slate-100 bg-white">
                                            {colorway.sizes.length === 0 ? (
                                                <tr><td colSpan={4 + flowSteps.length} className="p-6 text-center text-slate-400 italic">No size data.</td></tr>
                                            ) : colorway.sizes.map(s => (
                                                <tr key={s.size} className="hover:bg-slate-50">
                                                    <td className={`${t.firstCell} font-bold text-slate-700`}>{s.size}</td>
                                                    <td className={t.numCell}>{sizeOrderQty(s) > 0 ? sizeOrderQty(s).toLocaleString() : <span className="text-slate-300">—</span>}</td>
                                                    <td className={t.adjCell}>{sizeAdjQty(s) > 0 ? sizeAdjQty(s).toLocaleString() : <span className="text-slate-300">—</span>}</td>
                                                    {flowSteps.map(dept => {
                                                        const count = getSizeCount(dept, s.size);
                                                        return (
                                                            <td key={dept} className={t.deptCell}>
                                                                {renderProgressCount(progressLoading, count)}
                                                            </td>
                                                        );
                                                    })}
                                                    <td className={`${t.statusCell} ${progressLoading ? '' : statusColorClass(
                                                        deriveSizeProgressPhase(
                                                            flowSteps,
                                                            sizeAdjQty(s),
                                                            (dept) => getSizeCount(dept, s.size),
                                                        ),
                                                    )}`}>
                                                        {progressLoading ? (
                                                            <Skeleton className="h-3 w-14 mx-auto rounded" />
                                                        ) : (
                                                            formatProductionStatus(
                                                                deriveSizeProgressPhase(
                                                                    flowSteps,
                                                                    sizeAdjQty(s),
                                                                    (dept) => getSizeCount(dept, s.size),
                                                                ),
                                                            )
                                                        )}
                                                    </td>
                                                </tr>
                                            ))}
                                        </tbody>
                                        <tfoot className="bg-slate-100 border-t-2 border-slate-200 font-bold text-slate-700">
                                            <tr>
                                                <td className={t.footFirst}>Total</td>
                                                <td className={t.footNum}>{matrixTotals.orderQty.toLocaleString()}</td>
                                                <td className={t.footAdj}>{matrixTotals.adjQty.toLocaleString()}</td>
                                                {flowSteps.map(dept => {
                                                    const count = getDeptTotal(dept);
                                                    return (
                                                        <td key={dept} className={t.footDept}>
                                                            {renderProgressCount(progressLoading, count)}
                                                        </td>
                                                    );
                                                })}
                                                <td className={`${t.footStatus} ${progressLoading ? '' : statusColorClass(colorwayPhase)}`}>
                                                    {progressLoading ? (
                                                        <Skeleton className="h-3 w-14 mx-auto rounded" />
                                                    ) : (
                                                        formatProductionStatus(colorwayPhase)
                                                    )}
                                                </td>
                                            </tr>
                                        </tfoot>
                                    </table>
                                </div>
                                </div>
                                </div>
                            </Card>

                            <DepartmentScheduleGantt
                                orderId={order.id}
                                colorwayId={colorway.id}
                                poNumber={order.poNumber}
                                deliveryDate={order.deliveryDate}
                            />
                        </div>
                    )}

                    {activeTab === 'reports' && (
                        <div className="space-y-6">
                            <Card title="Reports" subtitle="Planning summary and live production actuals" className="shadow-sm border-slate-200" noPadding>
                                <div className="overflow-x-auto">
                                    <table className="w-full text-xs">
                                        <thead className="bg-gradient-to-r from-slate-50 to-slate-100 text-slate-600 font-semibold border-b border-slate-200 text-[11px] uppercase tracking-wide">
                                            <tr>
                                                <th className="px-6 py-4 text-left">Report Type</th>
                                                <th className="px-4 py-4 text-left">Date</th>
                                                <th className="px-4 py-4 text-left">Details</th>
                                                <th className="px-4 py-4 text-center">Status</th>
                                                <th className="px-6 py-4 text-center">Action</th>
                                            </tr>
                                        </thead>
                                        <tbody className="divide-y divide-slate-100">
                                            {reportRows.map((row) => {
                                                const tone = toneClasses[row.tone];
                                                const Icon = row.icon;
                                                return (
                                                    <tr key={row.key} className="hover:bg-slate-50/50 transition-colors">
                                                        <td className="px-6 py-4">
                                                            <div className="flex items-center gap-3">
                                                                <div className={`w-8 h-8 rounded-lg ${tone.bg} flex items-center justify-center`}>
                                                                    <Icon size={16} className={tone.icon} />
                                                                </div>
                                                                <span className="font-semibold text-slate-800">{row.label}</span>
                                                            </div>
                                                        </td>
                                                        <td className="px-4 py-4 text-xs text-slate-600">{row.date}</td>
                                                        <td className="px-4 py-4 text-[10px] text-slate-600">{row.details}</td>
                                                        <td className="px-4 py-4 text-center">
                                                            <span className={`text-[10px] font-bold px-3 py-1.5 rounded-full ${tone.badge}`}>
                                                                {row.status}
                                                            </span>
                                                        </td>
                                                        <td className="px-6 py-4 text-center">
                                                            <div className="flex items-center justify-center gap-2">
                                                                <button
                                                                    type="button"
                                                                    onClick={row.onView}
                                                                    className={`p-2 rounded-lg transition-colors ${row.key === 'plan' ? 'bg-emerald-50 hover:bg-emerald-100 text-emerald-600' : 'bg-blue-50 hover:bg-blue-100 text-blue-600'}`}
                                                                    title={row.key === 'plan' ? 'View planning summary' : 'Open report'}
                                                                >
                                                                    <Eye size={16} />
                                                                </button>
                                                                {row.onOpen && (
                                                                    <button
                                                                        type="button"
                                                                        onClick={row.onOpen}
                                                                        className="p-2 bg-slate-100 hover:bg-slate-200 text-slate-600 rounded-lg transition-colors"
                                                                        title="Go to Planning Board"
                                                                    >
                                                                        <ExternalLink size={16} />
                                                                    </button>
                                                                )}
                                                            </div>
                                                        </td>
                                                    </tr>
                                                );
                                            })}
                                        </tbody>
                                    </table>
                                </div>
                            </Card>
                        </div>
                    )}
                </div>
            </div>
        </PageShell>

        <SummaryModal
            isOpen={showSummaryModal}
            onClose={() => setShowSummaryModal(false)}
            flowSteps={flowStepObjects}
            selectedOrder={order}
            colorwayPlans={colorwayPlansForSummary}
            assignedResources={assignedResources}
            regularShiftHours={regularShiftHours}
            orderId={order.id}
        />
        </>
    );
};
