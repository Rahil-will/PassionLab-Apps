import React, { useState, useEffect, useMemo, useRef } from 'react';
import { useNavigationStore, useDataStore, useSettingsStore, useNotificationStore } from '../../stores';
import { RoutePath, StyleOrder, Colorway, type OrderPriority } from '../../types';
import { Save, ArrowRight, Image as ImageIcon, Edit2, Upload, Info, X, Trash2, CheckSquare, Square, CheckCircle2, Clock, Package, AlertTriangle, Plus, Loader2 } from 'lucide-react';
import { ColorQuantitiesGrid } from '../../components/production/ColorQuantitiesGrid';
import { Button, Card, Input, SelectDropdown, Badge, Modal, Spinner } from '../../components/ui';
import { PageShell } from '../../components/layout/PageShell';
import { tokens } from '../../lib/designTokens';
import { daysBetween, formatDateDDMMYYYY, todayIso } from '../../lib/orderDateUtils';
import { sizeAdjQty, sizeOrderQty, sumSizeAdjQty, sumSizeOrderQty, orderedSizeKeys } from '../../lib/colorwaySizesUtils';
import { dropdownValuesForCategory } from '../../lib/supportDropdownValues';
import { findOrderColorConflict } from '../../lib/orderUniqueness';
import { OrderPriorityChips } from '../../lib/orderPriority';
import {
    SIZE_GROUP_SNAPSHOT,
    buildSizeGroupDropdownOptions,
    collectSizeKeysFromColorways,
    displaySizesForOrder,
    formatSizeLabels,
    mergeTemplateSizesIntoColorways,
    parseSizeGroupTemplateValue,
    parseSizeLabels,
    pruneSizeColumnIfAllZero,
    pruneOrphanSizesFromTemplate,
} from '../../lib/orderSizeGroupSelection';
function cloneColorways(rows: Colorway[]): Colorway[] {
    return rows.map((cw) => ({
        ...cw,
        sizes: cw.sizes.map((s) => ({ ...s })),
    }));
}

export const CreateOrderMaster: React.FC = () => {
    const {
        navigate,
        routeParams,
        isUnsaved,
        setUnsaved,
        setPendingSaveAction,
    } = useNavigationStore();
    const { orders, loading: ordersLoading, addOrder, updateOrder, deleteOrder, wipOrder, setWipOrder } = useDataStore();
    const { sizeGroups, buyers, processFlows, supportDropdowns } = useSettingsStore();
    const { showNotification } = useNotificationStore();

    const editOrderId = routeParams?.id ?? null;
    const isEditingExistingOrder = Boolean(editOrderId);

    const hydratedIdRef = useRef<string | null>(null);
    const savedColorwaysSnapshotRef = useRef<Colorway[]>([]);
    const skipAllowanceRecalcRef = useRef(false);
    const handleConfirmOrderRef = useRef<(options?: { silent?: boolean }) => Promise<boolean>>(async () => false);

    // Validation State
    const [errors, setErrors] = useState<Record<string, boolean>>({});

    const garmentTypes = useMemo(
        () => dropdownValuesForCategory(supportDropdowns, 'garment_type'),
        [supportDropdowns],
    );
    const washTypes = useMemo(
        () => dropdownValuesForCategory(supportDropdowns, 'wash_type'),
        [supportDropdowns],
    );

    // Success Modal State
    const [successModalOpen, setSuccessModalOpen] = useState(false);
    const [savedOrderId, setSavedOrderId] = useState<string | null>(null);

    const [deleteModalOpen, setDeleteModalOpen] = useState(false);
    const [deleteLoading, setDeleteLoading] = useState(false);
    const [showDiscardDialog, setShowDiscardDialog] = useState(false);

    // If we have a WIP order, use it. Otherwise defaults.
    const [styleName, setStyleName] = useState('');
    const [styleRef, setStyleRef] = useState('');
    const [poNumber, setPoNumber] = useState('');
    const [selectedBuyer, setSelectedBuyer] = useState('');
    const [orderDate, setOrderDate] = useState('');
    const [jobCardDate, setJobCardDate] = useState(todayIso());
    const [deliveryDate, setDeliveryDate] = useState('');
    const [sizeGroupSelection, setSizeGroupSelection] = useState('');
    const [snapshottedGroupName, setSnapshottedGroupName] = useState('');
    const [snapshottedSizeKeys, setSnapshottedSizeKeys] = useState<string[]>([]);

    // Control Parameters
    const [sewingSam, setSewingSam] = useState('');
    const [priority, setPriority] = useState<OrderPriority>('normal');
    const [garmentType, setGarmentType] = useState('');
    const [washType, setWashType] = useState('');
    const [selectedProcessFlow, setSelectedProcessFlow] = useState('');
    const [cuttingAllowance, setCuttingAllowance] = useState(2);
    const [remarks, setRemarks] = useState(''); // New Remarks State

    // Shipment Allowance Checkbox State
    const [applyExtraAllowance, setApplyExtraAllowance] = useState(false);

    // Image
    const [styleImage, setStyleImage] = useState('');
    const [showImageInput, setShowImageInput] = useState(false);

    const [colorways, setColorways] = useState<Colorway[]>([]);

    const [saving, setSaving] = useState(false);
    const draftOrderIdRef = useRef<string | null>(null);

    const resolveNewOrderId = (): string => {
        if (isEditingExistingOrder && editOrderId) return editOrderId;
        if (wipOrder?.id) return wipOrder.id;
        if (!draftOrderIdRef.current) draftOrderIdRef.current = crypto.randomUUID();
        return draftOrderIdRef.current;
    };

    const populateState = (order: StyleOrder) => {
        skipAllowanceRecalcRef.current = true;
        setStyleName(order.styleName || '');
        setStyleRef(order.styleRef || '');
        setPoNumber(order.poNumber || '');

        const buyerObj =
            buyers.find(b => b.id === order.buyerId) ||
            buyers.find(b => b.name === order.buyer);
        if (buyerObj) setSelectedBuyer(buyerObj.id);

        setOrderDate(order.orderDate || '');
        setJobCardDate(order.jobCardDate || order.orderDate || todayIso());
        setDeliveryDate(order.deliveryDate || '');
        setSnapshottedGroupName(order.sizeGroupName || '');
        setSnapshottedSizeKeys(
            order.sizeLabels
                ? parseSizeLabels(order.sizeLabels)
                : orderedSizeKeys(order.colorways?.[0]?.sizes, collectSizeKeysFromColorways(order.colorways || [])),
        );
        setSizeGroupSelection(isEditingExistingOrder ? SIZE_GROUP_SNAPSHOT : '');
        savedColorwaysSnapshotRef.current = cloneColorways(order.colorways || []);
        setSewingSam(order.sewingSam?.toString() || order.sam?.toString() || '');
        setPriority(order.priority ?? 'normal');

        setGarmentType(order.garmentType || '');
        setWashType(order.washType || '');

        setSelectedProcessFlow(order.processFlow || '');
        setStyleImage(order.image || '');
        setCuttingAllowance(order.cuttingAllowance || 2);
        setApplyExtraAllowance((order.shipmentAllowance || 0) > 0);
        setColorways(order.colorways || []);
        setRemarks(order.remarks || '');
    };

    // Hydrate edit form when order data arrives — never re-sync on background order refreshes
    useEffect(() => {
        if (!editOrderId) return;
        const existing = orders.find((o) => o.id === editOrderId);
        if (!existing) return;
        if (hydratedIdRef.current === editOrderId) return;

        populateState(existing);
        hydratedIdRef.current = editOrderId;
        setUnsaved(false);
    }, [editOrderId, orders]);

    // Hydrate create / WIP draft once — independent of orders refresh
    useEffect(() => {
        if (editOrderId) return;

        if (wipOrder) {
            const wipKey = `wip:${wipOrder.id}`;
            if (hydratedIdRef.current === wipKey) return;
            draftOrderIdRef.current = wipOrder.id;
            populateState(wipOrder);
            hydratedIdRef.current = wipKey;
            return;
        }

        if (hydratedIdRef.current === 'new') return;
        hydratedIdRef.current = 'new';
        if (!draftOrderIdRef.current) {
            draftOrderIdRef.current = crypto.randomUUID();
        }
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [editOrderId, wipOrder?.id]);

    useEffect(() => {
        if (!editOrderId || selectedBuyer) return;
        const existing = orders.find((o) => o.id === editOrderId);
        if (!existing?.buyerId) return;
        const buyerObj = buyers.find((b) => b.id === existing.buyerId);
        if (buyerObj) setSelectedBuyer(buyerObj.id);
    }, [editOrderId, orders, buyers, selectedBuyer]);

    const existingOrder = editOrderId ? orders.find((o) => o.id === editOrderId) : null;
    const isOrderLoading = Boolean(editOrderId) && !existingOrder && ordersLoading;
    const isOrderMissing = Boolean(editOrderId) && !ordersLoading && !existingOrder;

    const activeFlowSteps = processFlows.find(pf => pf.id === selectedProcessFlow)?.steps || [];

    const selectedBuyerObj = buyers.find(b => b.id === selectedBuyer);
    const buyerExtraPct = selectedBuyerObj?.overShipmentAllowance || 0;

    const templateGroupId = parseSizeGroupTemplateValue(sizeGroupSelection);
    const activeTemplateGroup = templateGroupId
        ? sizeGroups.find((sg) => sg.id === templateGroupId)
        : undefined;

    const totalAllowancePct = cuttingAllowance + (applyExtraAllowance ? buyerExtraPct : 0);
    const displaySizes = useMemo(
        () => displaySizesForOrder(colorways, sizeGroupSelection, activeTemplateGroup?.sizes),
        [colorways, sizeGroupSelection, activeTemplateGroup],
    );

    const hasSizeContext =
        sizeGroupSelection === SIZE_GROUP_SNAPSHOT || Boolean(templateGroupId);

    const applyAllowanceToColorways = (rows: Colorway[], allowancePct: number): Colorway[] =>
        rows.map(cw => {
            const newSizes = cw.sizes.map(s => {
                const orderQty = sizeOrderQty(s);
                return {
                    size: s.size,
                    order_qty: orderQty,
                    adj_qty: Math.round(orderQty * (1 + allowancePct / 100)),
                };
            });
            const orderQty = sumSizeOrderQty(newSizes);
            const adjQty = sumSizeAdjQty(newSizes);
            return { ...cw, sizes: newSizes, totalQty: orderQty, orderQty, adjQty };
        });

    useEffect(() => {
        if (colorways.length === 0) return;
        if (skipAllowanceRecalcRef.current) {
            skipAllowanceRecalcRef.current = false;
            return;
        }
        setColorways((prev) => {
            const next = applyAllowanceToColorways(prev, totalAllowancePct);
            const unchanged = prev.every((cw, i) =>
                cw.sizes.every((s, j) => s.adj_qty === next[i]?.sizes[j]?.adj_qty),
            );
            return unchanged ? prev : next;
        });
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [totalAllowancePct]);

    // Auto-set extra allowance checkbox when buyer changes (if not already set manually/loaded)
    useEffect(() => {
        if (selectedBuyerObj && buyerExtraPct > 0 && !isEditingExistingOrder && !wipOrder) {
            setApplyExtraAllowance(true);
        }
    }, [selectedBuyerObj, buyerExtraPct, isEditingExistingOrder, wipOrder]);

    const filteredSizeGroups = useMemo(() => {
        return sizeGroups.filter(sg =>
            !sg.buyerId ||
            (selectedBuyer && sg.buyerId === selectedBuyer),
        );
    }, [sizeGroups, selectedBuyer]);

    const sizeGroupDropdownOptions = useMemo(
        () =>
            buildSizeGroupDropdownOptions({
                isEditing: isEditingExistingOrder,
                snapshottedName: snapshottedGroupName,
                storedSizeKeys: snapshottedSizeKeys,
                filteredGroups: filteredSizeGroups,
            }),
        [isEditingExistingOrder, snapshottedGroupName, snapshottedSizeKeys, filteredSizeGroups],
    );

    // Process Flow Options - only show current flows (is_current = true)
    const processFlowOptions = useMemo(() => {
        const opts = processFlows
            .filter(pf => pf.is_current === true)
            .map(pf => ({ value: pf.id, label: pf.name }));
        if (selectedProcessFlow && !opts.find(o => o.value === selectedProcessFlow)) {
            const bound = processFlows.find((pf) => pf.id === selectedProcessFlow);
            const label = bound
                ? `${bound.name} (v${bound.version ?? 1}${bound.is_current === false ? ', archived' : ''})`
                : 'Archived flow';
            opts.push({ value: selectedProcessFlow, label });
        }
        return opts;
    }, [processFlows, selectedProcessFlow]);


    const handleSizeGroupChange = (value: string) => {
        setSizeGroupSelection(value);
        setUnsaved(true);
        if (errors.selectedSizeGroup) {
            setErrors((prev) => ({ ...prev, selectedSizeGroup: false }));
        }
        if (value === SIZE_GROUP_SNAPSHOT) {
            if (savedColorwaysSnapshotRef.current.length > 0) {
                setColorways(cloneColorways(savedColorwaysSnapshotRef.current));
            }
            return;
        }
        const nextTemplateId = parseSizeGroupTemplateValue(value);
        if (nextTemplateId) {
            const sg = sizeGroups.find((g) => g.id === nextTemplateId);
            if (!sg) return;
            if (!snapshottedGroupName) setSnapshottedGroupName(sg.name);
            if (colorways.length > 0) {
                const templateSizes = (sg.sizes || []).filter(Boolean);
                let updated = mergeTemplateSizesIntoColorways(colorways, templateSizes);
                const templateSet = new Set(templateSizes);
                for (const size of collectSizeKeysFromColorways(updated)) {
                    if (!templateSet.has(size)) {
                        updated = pruneSizeColumnIfAllZero(updated, size);
                    }
                }
                syncColorways(updated);
            }
        }
    };

    const handleFieldChange = (setter: any, value: any, fieldName?: string) => {
        setter(value);
        setUnsaved(true);
        if (fieldName && errors[fieldName]) {
            setErrors(prev => ({ ...prev, [fieldName]: false }));
        }
    };

    const constructOrderObject = (): StyleOrder => {
        const finalShipmentAllowance = applyExtraAllowance ? buyerExtraPct : 0;

        // Recalculate planned qtys if global allowances change
        const finalColorways = colorways.map(cw => {
            const bySize = new Map(cw.sizes.map((s) => [s.size, s]));
            const newSizes = displaySizes.map((label) => {
                const s = bySize.get(label);
                const orderQty = s ? sizeOrderQty(s) : 0;
                const adjQty = s && sizeAdjQty(s) > 0
                    ? sizeAdjQty(s)
                    : Math.round(orderQty * (1 + (cuttingAllowance + finalShipmentAllowance) / 100));
                return { size: label, order_qty: orderQty, adj_qty: adjQty };
            });
            const cwOrderQty = sumSizeOrderQty(newSizes);
            const cwAdjQty = sumSizeAdjQty(newSizes);
            return {
                ...cw,
                sizes: newSizes,
                orderQty: cwOrderQty,
                adjQty: cwAdjQty,
                totalQty: cwOrderQty,
            };
        });

        // Calculate order-level totals from colorways
        const orderQty = finalColorways.reduce((acc, c) => acc + (c.orderQty || 0), 0);
        const adjQty = finalColorways.reduce((acc, c) => acc + (c.adjQty || 0), 0);

        return {
            id: resolveNewOrderId(),
            styleId: '',
            styleName,
            styleRef,
            buyer: selectedBuyerObj?.name || '',
            buyerId: selectedBuyer,
            poNumber,
            orderQty,
            adjQty,
            totalQty: orderQty,  // Legacy compatibility
            deliveryDate,
            orderDate,
            jobCardDate,
            garmentType,
            sewingSam: sewingSam ? Number(sewingSam) : null,
            priority,
            washType,
            sizeGroupName: snapshottedGroupName || activeTemplateGroup?.name || '',
            sizeLabels: formatSizeLabels(displaySizes),
            processFlow: selectedProcessFlow,
            currentDept: 'Planned', // Initial State set to Planned
            status: 'Not Started',
            image: styleImage,
            cuttingAllowance,
            shipmentAllowance: finalShipmentAllowance,
            progress: {} as StyleOrder['progress'],
            colorways: finalColorways,
            remarks: remarks
        };
    };

    const validateHeader = () => {
        const newErrors: Record<string, boolean> = {};
        if (!styleName.trim()) newErrors.styleName = true;
        if (!styleRef.trim()) newErrors.styleRef = true;
        if (!selectedBuyer) newErrors.selectedBuyer = true;
        if (!hasSizeContext) newErrors.selectedSizeGroup = true;

        setErrors(newErrors);
        return Object.keys(newErrors).length === 0;
    };

    const syncColorways = (updated: Colorway[]) => {
        const templateSizes = activeTemplateGroup?.sizes?.filter(Boolean) ?? [];
        const pruned =
            templateGroupId && templateSizes.length > 0
                ? pruneOrphanSizesFromTemplate(updated, templateSizes)
                : updated;
        setColorways(pruned);
        setUnsaved(true);
    };

    const ensureColorwaySizes = (sizes: Colorway['sizes']): Colorway['sizes'] => {
        const bySize = new Map(sizes.map((s) => [s.size, s]));
        return displaySizes.map((label) => {
            const row = bySize.get(label);
            return row ?? { size: label, order_qty: 0, adj_qty: 0 };
        });
    };

    const patchColorway = (id: string, patch: (cw: Colorway) => Colorway) => {
        syncColorways(colorways.map((cw) => (cw.id === id ? patch(cw) : cw)));
    };

    const recalcColorwayTotals = (sizes: Colorway['sizes']) => {
        const orderQty = sumSizeOrderQty(sizes);
        const adjQty = sumSizeAdjQty(sizes);
        return { sizes, orderQty, adjQty, totalQty: orderQty };
    };

    const addColorway = () => {
        if (!hasSizeContext) return;
        const sizes = displaySizes.map((s) => ({ size: s, order_qty: 0, adj_qty: 0 }));
        syncColorways([
            ...colorways,
            { id: crypto.randomUUID(), name: '', sizes, orderQty: 0, adjQty: 0, totalQty: 0 },
        ]);
    };

    const updateColorwayName = (id: string, name: string) => {
        patchColorway(id, (cw) => ({ ...cw, name }));
    };

    const updateColorwayOrderQty = (id: string, size: string, qty: number) => {
        patchColorway(id, (cw) => {
            const sizes = ensureColorwaySizes(cw.sizes).map((s) =>
                s.size === size
                    ? { ...s, order_qty: qty, adj_qty: Math.round(qty * (1 + totalAllowancePct / 100)) }
                    : s,
            );
            return { ...cw, ...recalcColorwayTotals(sizes) };
        });
    };

    const updateColorwayAdjQty = (id: string, size: string, qty: number) => {
        patchColorway(id, (cw) => {
            const sizes = ensureColorwaySizes(cw.sizes).map((s) =>
                s.size === size ? { ...s, adj_qty: qty } : s,
            );
            return { ...cw, ...recalcColorwayTotals(sizes) };
        });
    };

    const duplicateColorway = (id: string) => {
        const src = colorways.find((c) => c.id === id);
        if (!src) return;
        const sizes = ensureColorwaySizes(src.sizes).map((s) => ({
            size: s.size,
            order_qty: sizeOrderQty(s),
            adj_qty: sizeAdjQty(s),
        }));
        syncColorways([
            ...colorways,
            {
                id: crypto.randomUUID(),
                name: '',
                sizes,
                orderQty: src.orderQty,
                adjQty: src.adjQty,
                totalQty: src.totalQty,
            },
        ]);
    };

    const deleteColorway = (id: string) => {
        syncColorways(colorways.filter((c) => c.id !== id));
    };

    const getColorRowTotal = (cw: Colorway, field: 'order_qty' | 'adj_qty') =>
        field === 'order_qty' ? sumSizeOrderQty(cw.sizes) : sumSizeAdjQty(cw.sizes);

    // Final Save to DB
    const handleConfirmOrder = async (options?: { silent?: boolean }): Promise<boolean> => {
        if (saving) return false;
        if (!validateHeader()) {
            showNotification("Please fill in all required fields highlighted in red.", "error");
            return false;
        }
        if (colorways.length === 0) {
            showNotification('Add at least one color with quantities before saving.', 'error');
            return false;
        }
        const emptyColor = colorways.find(c => !c.name.trim());
        if (emptyColor) {
            showNotification('All color rows must have a name.', 'error');
            return false;
        }
        const seenNames = new Set<string>();
        for (const cw of colorways) {
            const key = cw.name.trim().toLowerCase();
            if (seenNames.has(key)) {
                showNotification(`Duplicate color name "${cw.name.trim()}" — each color must be unique.`, 'error');
                return false;
            }
            seenNames.add(key);
        }
        const zeroQty = colorways.every(c => sumSizeOrderQty(c.sizes) === 0);
        if (zeroQty) {
            showNotification('Enter quantities in the size breakdown.', 'error');
            return false;
        }

        const colorConflict = findOrderColorConflict(
            orders,
            styleName,
            poNumber,
            colorways,
            isEditingExistingOrder ? editOrderId : undefined,
        );
        if (colorConflict) {
            showNotification(colorConflict, 'error');
            return false;
        }

        setSaving(true);
        try {
            const finalOrder = constructOrderObject();
            const saved = isEditingExistingOrder
                ? await updateOrder(editOrderId, finalOrder)
                : await addOrder(finalOrder);
            if (!saved) return false;
            const newOrderId = isEditingExistingOrder ? editOrderId : finalOrder.id;
            savedColorwaysSnapshotRef.current = cloneColorways(finalOrder.colorways);
            setSnapshottedSizeKeys([...displaySizes]);
            setSnapshottedGroupName(finalOrder.sizeGroupName || '');
            setSizeGroupSelection(isEditingExistingOrder ? SIZE_GROUP_SNAPSHOT : sizeGroupSelection);
            setSavedOrderId(newOrderId);
            setUnsaved(false);
            setWipOrder(null);
            if (!isEditingExistingOrder) {
                resetForm();
            } else {
                showNotification('Order updated successfully', 'success');
                if (!options?.silent && newOrderId) {
                    navigate(RoutePath.STYLE_DETAILS, { id: newOrderId });
                }
            }
            if (!options?.silent && !isEditingExistingOrder) {
                setSuccessModalOpen(true);
            }
            return true;
        } catch (error) {
            console.error("Save failed", error);
            showNotification("Failed to save order. Please try again.", "error");
            return false;
        } finally {
            setSaving(false);
        }
    };

    handleConfirmOrderRef.current = handleConfirmOrder;

    useEffect(() => {
        setPendingSaveAction(async () => {
            await handleConfirmOrderRef.current({ silent: true });
        });
        return () => {
            setPendingSaveAction(null);
        };
    }, [setPendingSaveAction]);

    const handleSuccessRedirect = () => {
        setSuccessModalOpen(false);
        if (savedOrderId) {
            navigate(RoutePath.STYLE_DETAILS, { id: savedOrderId });
        } else {
            navigate(RoutePath.STATUS_TRACKER);
        }
    };

    const resetForm = () => {
        setStyleName('');
        setStyleRef('');
        setPoNumber('');
        setSelectedBuyer('');
        setOrderDate('');
        setJobCardDate(todayIso());
        setDeliveryDate('');
        setSizeGroupSelection('');
        setSnapshottedGroupName('');
        setSewingSam('');
        setPriority('normal');
        setGarmentType('');
        setWashType('');
        setSelectedProcessFlow('');
        setCuttingAllowance(2);
        setRemarks('');
        setStyleImage('');
        setShowImageInput(false);
        setApplyExtraAllowance(false);
        setColorways([]);
        setWipOrder(null);
        setUnsaved(false);
        setErrors({});
        draftOrderIdRef.current = null;
    };

    const handleCreateAnother = () => {
        setSuccessModalOpen(false);
        resetForm();
        setSavedOrderId(null);
        // Ensure we are in "Create" mode not edit
        // If we were editing, we need to clear editId and mode?
        // Navigation might be needed to clear URL params if we are at /edit/:id
        navigate(RoutePath.CREATE_ORDER);
    };

    const performCancel = () => {
        resetForm();
        if (isEditingExistingOrder && editOrderId) {
            navigate(RoutePath.STYLE_DETAILS, { id: editOrderId });
        } else {
            showNotification('Order form cleared', 'success');
        }
    };

    const handleCancel = () => {
        if (isUnsaved) {
            setShowDiscardDialog(true);
            return;
        }
        performCancel();
    };

    const cancelDiscardDialog = () => {
        setShowDiscardDialog(false);
    };

    const confirmDiscardCancel = () => {
        setShowDiscardDialog(false);
        setUnsaved(false);
        setWipOrder(null);
        performCancel();
    };

    const confirmSaveAndCloseCancel = async () => {
        const saved = await handleConfirmOrder();
        if (saved) {
            setShowDiscardDialog(false);
            if (isEditingExistingOrder && editOrderId) {
                navigate(RoutePath.STYLE_DETAILS, { id: editOrderId });
            }
        }
    };

    const handleDeleteOrder = async () => {
        if (!editOrderId) return;
        setDeleteLoading(true);
        try {
            await deleteOrder(editOrderId);
            setDeleteModalOpen(false);
            setUnsaved(false);
            resetForm();
            navigate(RoutePath.STATUS_TRACKER);
        } catch (error) {
            console.error('Delete order failed', error);
            const message = error instanceof Error ? error.message : 'Failed to delete order';
            showNotification(message, 'error');
        } finally {
            setDeleteLoading(false);
        }
    };

    // --- AGGREGATIONS ---
    const aggregateSizeData = useMemo(() => {
        const sizes = displaySizes;
        const data: Record<string, { order: number; adjusted: number }> = {};
        sizes.forEach((s) => { data[s] = { order: 0, adjusted: 0 }; });
        colorways.forEach((cw) => {
            cw.sizes.forEach((s) => {
                if (!data[s.size]) data[s.size] = { order: 0, adjusted: 0 };
                data[s.size].order += sizeOrderQty(s);
                data[s.size].adjusted += sizeAdjQty(s);
            });
        });
        return { data, sizes };
    }, [colorways, displaySizes]);

    const totalOrderQty = Object.values(aggregateSizeData.data).reduce((a: number, b: { order: number, adjusted: number }) => a + b.order, 0);
    const totalAdjustedQty = Object.values(aggregateSizeData.data).reduce((a: number, b: { order: number, adjusted: number }) => a + b.adjusted, 0);

    // Calculate Lead Days
    const overallLeadDays = useMemo(
        () => daysBetween(orderDate, deliveryDate),
        [orderDate, deliveryDate],
    );
    const productionLeadDays = useMemo(
        () => daysBetween(jobCardDate, deliveryDate),
        [jobCardDate, deliveryDate],
    );

    const estProdMins = Number(totalAdjustedQty) * (Number(sewingSam) || 0);
    const estProdHours = estProdMins > 0 ? (estProdMins / 60).toFixed(1) : '0';

    return (
        <PageShell loading={isOrderLoading} skeleton="card" className="w-full pb-20">
            {isOrderMissing && (
                <div className="rounded-xl border border-amber-200 bg-amber-50 px-4 py-6 text-center text-sm text-amber-900 mb-6">
                    Order not found. It may have been deleted.
                    <div className="mt-3">
                        <Button size="sm" variant="secondary" onClick={() => navigate(RoutePath.STATUS_TRACKER)}>
                            Back to Status Tracker
                        </Button>
                    </div>
                </div>
            )}

            {!isOrderMissing && (
            <div className={`grid grid-cols-12 gap-6 [&_input]:shadow-none [&_input]:text-[11px] [&_input]:py-1.5 [&_button[role=combobox]]:text-[11px] [&_label]:text-[10px] ${saving ? 'opacity-60 pointer-events-none' : ''}`}>

                {/* ROW 1: INFO & IMAGE */}
                <div className="col-span-12 flex flex-col lg:flex-row gap-6 items-stretch">

                    {/* LEFT: STYLE INFO (70%) */}
                    <div className="lg:w-[70%] flex flex-col">
                        <Card
                            title="Style Information"
                            subtitle="Style and order details"
                            className="shadow-sm border-slate-200 h-full"
                        >
                            <div className="space-y-4">

                                <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
                                    <Input id="style-name" name="styleName" label="Style Name" placeholder="e.g. Basic Tee" value={styleName} onChange={e => handleFieldChange(setStyleName, e.target.value, 'styleName')} className="bg-white" error={errors.styleName} />
                                    <Input id="style-ref" name="styleRef" label="Style Ref No." placeholder="e.g. ST-2026-001" value={styleRef} onChange={e => handleFieldChange(setStyleRef, e.target.value, 'styleRef')} className="bg-white" error={errors.styleRef} />
                                    <div>
                                        <Input id="job-card-date" name="jobCardDate" label="Job Card Date" type="date" value={jobCardDate} onChange={e => handleFieldChange(setJobCardDate, e.target.value)} className="bg-white" />
                                    </div>
                                </div>
                                <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
                                    <SelectDropdown id="buyer" name="buyer" label="Buyer" value={selectedBuyer} onChange={v => handleFieldChange(setSelectedBuyer, v, 'selectedBuyer')} options={[{ value: '', label: 'Select...' }, ...buyers.map(b => ({ value: b.id, label: b.name }))]} error={errors.selectedBuyer} className="w-full" />
                                    <Input id="po-number" name="poNumber" label="PO Number" placeholder="PO-XXXXX" value={poNumber} onChange={e => handleFieldChange(setPoNumber, e.target.value)} className="bg-white" />
                                    <div>
                                        <label
                                            htmlFor="size-group"
                                            className={`block font-medium mb-1.5 ${errors.selectedSizeGroup ? 'text-red-600' : 'text-slate-700'}`}
                                            style={{ fontSize: tokens.fontSize.body }}
                                        >
                                            Size Group
                                            {hasSizeContext && displaySizes.length > 0 && (
                                                <span className="font-medium text-slate-500"> ({displaySizes.join(', ')})</span>
                                            )}
                                        </label>
                                        <SelectDropdown
                                            id="size-group"
                                            name="sizeGroup"
                                            value={sizeGroupSelection}
                                            onChange={v => handleSizeGroupChange(v)}
                                            options={[
                                                { value: '', label: selectedBuyer ? 'Select...' : 'Select Buyer First' },
                                                ...sizeGroupDropdownOptions,
                                            ]}
                                            error={errors.selectedSizeGroup}
                                            className="w-full"
                                        />
                                    </div>
                                </div>

                                <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
                                    <div>
                                        <Input id="order-received-date" name="orderDate" label="Order Received Date" type="date" value={orderDate} onChange={e => handleFieldChange(setOrderDate, e.target.value)} className="bg-white" />
                                        </div>
                                    <div>
                                        <Input id="delivery-date" name="deliveryDate" label="Delivery Date" type="date" value={deliveryDate} onChange={e => handleFieldChange(setDeliveryDate, e.target.value)} className="bg-white" />
                                        </div>
                                    <SelectDropdown id="process-flow" name="processFlow" label="Process Flow"
                                        value={selectedProcessFlow}
                                        onChange={v => handleFieldChange(setSelectedProcessFlow, v)}
                                        options={[{ value: '', label: 'Select Flow...' }, ...processFlowOptions]}
                                        className="w-full"
                                    />
                                </div>

                                {selectedProcessFlow && activeFlowSteps.length > 0 && (
                                    <div className="pt-4 border-t border-slate-100 animate-in fade-in slide-in-from-top-1">
                                        <label className="text-[10px] font-bold text-slate-400 uppercase mb-3 block">Process Flow Route</label>
                                        <div className="flex items-center gap-2 overflow-x-auto pb-2 no-scrollbar">
                                            {activeFlowSteps.map((step, idx) => (
                                                <React.Fragment key={step.dept_id || idx}>
                                                    <div className="flex items-center justify-center px-4 py-2 bg-sky-50 border border-sky-100 rounded-lg text-[10px] font-bold text-sky-800 shadow-sm min-w-[100px]">
                                                        {step.dept_name || String(step.flow_step ?? idx + 1)}
                                                    </div>
                                                    {idx < activeFlowSteps.length - 1 && <ArrowRight size={14} className="text-slate-300 flex-shrink-0" />}
                                                </React.Fragment>
                                            ))}
                                        </div>
                                    </div>
                                )}
                            </div>
                        </Card>
                    </div>

                    {/* RIGHT: IMAGE (30%) */}
                    <div className="lg:w-[30%] flex flex-col">
                        <Card title="Style Image" className="shadow-sm border-slate-200 h-full flex flex-col p-0" noPadding>
                            <div className="bg-slate-50 relative group flex items-center justify-center flex-1 min-h-[300px] w-full overflow-hidden">
                                {styleImage && !showImageInput ? (
                                    <>
                                        <img src={styleImage} alt="Style" className="absolute inset-0 w-full h-full object-cover" />
                                        <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                                            <Button variant="secondary" size="sm" onClick={() => setShowImageInput(true)}>Change URL</Button>
                                        </div>
                                    </>
                                ) : (
                                    <div className="p-6 flex flex-col items-center justify-center w-full h-full">
                                        {!showImageInput ? (
                                            <div onClick={() => setShowImageInput(true)} className="cursor-pointer text-center text-slate-400 hover:text-blue-500 transition-colors flex flex-col items-center justify-center h-full">
                                                <Upload size={32} className="mb-3 text-slate-300" />
                                                <span className="text-[10px] font-bold uppercase tracking-wider">Click to Add Image</span>
                                            </div>
                                        ) : (
                                            <div className="w-full space-y-3 px-4">
                                                <Input id="style-image-url" name="styleImage" placeholder="Image URL..." value={styleImage} onChange={e => handleFieldChange(setStyleImage, e.target.value)} autoFocus className="text-[10px]" />
                                                <div className="flex gap-2">
                                                    <Button size="sm" onClick={() => setShowImageInput(false)} className="flex-1 h-8 text-[10px]">Load</Button>
                                                    <Button size="sm" variant="ghost" onClick={() => { setShowImageInput(false); setStyleImage(''); }} className="h-8 text-[10px]">Clear</Button>
                                                </div>
                                            </div>
                                        )}
                                    </div>
                                )}
                            </div>
                        </Card>
                    </div>
                </div>

                {/* ROW 2: COLOR & SIZES + CONTROL */}
                <div className="col-span-12 flex flex-col lg:flex-row gap-6 lg:items-stretch">
                    <div className="lg:w-[70%] w-full flex flex-col">
                        <Card
                            title="Color & Quantities"
                            subtitle={
                                hasSizeContext
                                    ? `${colorways.length} ${colorways.length === 1 ? 'color' : 'colors'} · order / adj qty per size · allowance +${totalAllowancePct}%`
                                    : 'Select a size group to enter order and adjusted quantities'
                            }
                            className="shadow-sm border-slate-200 w-full flex-1 flex flex-col min-h-[28rem] max-h-[28rem] overflow-hidden"
                            noPadding
                            action={
                                hasSizeContext ? (
                                    <button
                                        type="button"
                                        onClick={addColorway}
                                        className="inline-flex items-center gap-1.5 px-3 py-1.5 text-[10px] font-semibold text-blue-700 border border-blue-200 bg-blue-50 hover:bg-blue-100 rounded-lg transition-colors"
                                    >
                                        <Plus size={14} />
                                        Add color
                                    </button>
                                ) : undefined
                            }
                        >
                            <ColorQuantitiesGrid
                                colorways={colorways}
                                displaySizes={displaySizes}
                                totalAllowancePct={totalAllowancePct}
                                onNameChange={updateColorwayName}
                                onOrderChange={updateColorwayOrderQty}
                                onAdjChange={updateColorwayAdjQty}
                                onDuplicate={duplicateColorway}
                                onDelete={deleteColorway}
                                rowOrderTotal={(cw) => getColorRowTotal(cw, 'order_qty')}
                                rowAdjTotal={(cw) => getColorRowTotal(cw, 'adj_qty')}
                                aggregateBySize={aggregateSizeData.data}
                                totalOrderQty={totalOrderQty}
                                totalAdjustedQty={totalAdjustedQty}
                                hasSizeContext={hasSizeContext}
                            />
                        </Card>
                    </div>

                    <div className="lg:w-[30%] w-full flex flex-col">
                        <Card
                            title="Control Parameters"
                            subtitle="Garment type, priority & allowances"
                            className="shadow-sm border-slate-200 flex-1 h-[28rem]"
                        >
                            <div className="space-y-4">
                                <div>
                                    <label htmlFor="garment-type" className="block text-[10px] font-medium text-slate-700 mb-1.5">Garment Type</label>
                                    <SelectDropdown
                                        id="garment-type"
                                        name="garmentType"
                                        value={garmentType}
                                        onChange={(v) => handleFieldChange(setGarmentType, v)}
                                        options={[{ value: '', label: 'Select...' }, ...garmentTypes.map((t) => ({ value: t, label: t }))]}
                                        className="w-full"
                                    />
                                </div>
                                <div>
                                    <label htmlFor="wash-type" className="block text-[10px] font-medium text-slate-700 mb-1.5">Wash Type</label>
                                    <SelectDropdown
                                        id="wash-type"
                                        name="washType"
                                        value={washType}
                                        onChange={(v) => handleFieldChange(setWashType, v)}
                                        options={[{ value: '', label: 'Select...' }, ...washTypes.map((t) => ({ value: t, label: t }))]}
                                        className="w-full"
                                    />
                                </div>
                                <div>
                                    <label className="block text-[10px] font-medium text-slate-700 mb-1.5">Priority</label>
                                    <OrderPriorityChips value={priority} onChange={(v) => { setPriority(v); setUnsaved(true); }} />
                                </div>
                                <Input
                                    id="sewing-sam"
                                    name="sewingSam"
                                    label="Sewing SAM (reference)"
                                    type="number"
                                    placeholder="e.g. 12.5"
                                    value={sewingSam}
                                    onChange={(e) => handleFieldChange(setSewingSam, e.target.value)}
                                />
                                <div className="grid grid-cols-2 gap-4">
                                    <div>
                                        <label className="text-[10px] font-bold text-blue-500 uppercase mb-1 block">Cut Allowance %</label>
                                        <input
                                            id="cutting-allowance"
                                            name="cuttingAllowance"
                                            type="number"
                                            value={cuttingAllowance}
                                            onChange={(e) => handleFieldChange(setCuttingAllowance, parseFloat(e.target.value))}
                                            className="w-full p-2 border border-slate-300 font-bold text-[10px] text-blue-600 focus:border-blue-500 outline-none shadow-none"
                                        />
                                    </div>
                                    <div>
                                        <label className="text-[10px] font-bold text-blue-500 uppercase mb-1 block">Extra Allowed %</label>
                                        <div
                                            onClick={() => {
                                                if (!selectedBuyer) { showNotification('Select a buyer first', 'error'); return; }
                                                handleFieldChange(setApplyExtraAllowance, !applyExtraAllowance);
                                            }}
                                            className={`flex items-center gap-2 p-2 border cursor-pointer transition-all ${applyExtraAllowance ? 'bg-emerald-50 border-emerald-200 text-emerald-800' : 'bg-white border-slate-300 text-slate-400'}`}
                                        >
                                            {applyExtraAllowance ? <CheckSquare size={16} className="text-emerald-600" /> : <Square size={16} />}
                                            <span className="font-bold text-[10px]">{buyerExtraPct > 0 ? `${buyerExtraPct}%` : '0%'}</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </Card>
                    </div>
                </div>

                <div className="col-span-12">
                    <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm flex flex-col gap-5">
                        <h4 className="text-[10px] font-bold text-slate-800 uppercase flex items-center gap-2"><Info size={16} /> Order Summary</h4>

                        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                            <div className="rounded-lg border border-slate-200 bg-slate-50 px-4 py-3">
                                <div className="text-[9px] font-bold text-slate-400 uppercase mb-1">Order Qty</div>
                                <div className="text-lg font-bold text-slate-900">{totalOrderQty.toLocaleString()} <span className="text-[10px] font-medium text-slate-500">pcs</span></div>
                            </div>
                            <div className="rounded-lg border border-blue-100 bg-blue-50 px-4 py-3">
                                <div className="text-[9px] font-bold text-blue-500 uppercase mb-1">Production Qty</div>
                                <div className="text-lg font-bold text-blue-700">{totalAdjustedQty.toLocaleString()} <span className="text-[10px] font-medium text-blue-400">pcs</span></div>
                            </div>
                            <div className="rounded-lg border border-slate-200 bg-slate-50 px-4 py-3">
                                <div className="text-[9px] font-bold text-slate-400 uppercase mb-2 flex items-center gap-1">
                                    <Clock size={10} />
                                    Lead Time
                                </div>

                                <div className="flex items-center justify-between">
                                    <div>
                                        <span className="text-[10px] font-medium text-slate-500 block">
                                            Overall
                                        </span>
                                        <div className="text-sm font-bold text-slate-800">
                                            {overallLeadDays}
                                            <span className="text-[10px] font-medium text-slate-500 ml-1">
                                                days
                                            </span>
                                        </div>
                                    </div>

                                    <div className="text-slate-300 font-light">|</div>

                                    <div>
                                        <span className="text-[10px] font-medium text-blue-400 block">
                                            Production
                                        </span>
                                        <div className="text-sm font-bold text-blue-700">
                                            {productionLeadDays}
                                            <span className="text-[10px] font-medium text-blue-400 ml-1">
                                                days
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div className="rounded-lg border border-slate-200 bg-slate-50 px-4 py-3">
                                <div className="text-[9px] font-bold text-slate-400 uppercase mb-1 flex items-center gap-1"><Package size={10} /> Est. Sewing</div>
                                <div className="text-lg font-bold text-slate-800">{estProdHours} <span className="text-[10px] font-medium text-slate-500">hrs</span></div>
                                {Number(sewingSam) > 0 && <div className="text-[9px] text-slate-400 mt-0.5">@ {sewingSam} min/pc ref. sewing SAM</div>}
                            </div>
                        </div>

                        <div className="flex flex-wrap items-center gap-4 text-[10px] text-slate-600 border-t border-slate-100 pt-4">
                            <span><strong className="text-slate-500">Colors:</strong> {colorways.length}</span>
                            <span><strong className="text-slate-500">Buyer:</strong> {selectedBuyerObj?.name || '—'}</span>
                            <span><strong className="text-slate-500">PO:</strong> {poNumber || '—'}</span>
                            <span><strong className="text-slate-500">Delivery:</strong> {deliveryDate || '—'}</span>
                            <Badge variant={colorways.length > 0 && totalOrderQty > 0 ? 'success' : 'warning'}>
                                {colorways.length > 0 && totalOrderQty > 0 ? 'Ready to save' : 'Incomplete'}
                            </Badge>
                        </div>

                        <div>
                            <label htmlFor="order-remarks" className="text-[10px] font-bold text-slate-500 uppercase block mb-1.5">Remarks / Instructions</label>
                            <textarea
                                id="order-remarks"
                                name="remarks"
                                className="w-full bg-slate-50 border border-slate-200 rounded-lg p-3 text-[11px] text-slate-700 focus:outline-none focus:border-blue-500 resize-none h-20"
                                placeholder="Special instructions for production..."
                                value={remarks}
                                onChange={e => handleFieldChange(setRemarks, e.target.value)}
                            />
                        </div>

                        <div className="flex items-center justify-between gap-4 pt-2 border-t border-slate-100">
                            {isEditingExistingOrder ? (
                                <Button
                                    variant="danger-light"
                                    icon={Trash2}
                                    onClick={() => setDeleteModalOpen(true)}
                                    className="text-[10px]"
                                >
                                    Delete Order
                                </Button>
                            ) : (
                                <span />
                            )}
                            <div className="flex items-center gap-4">
                                <Button variant="secondary" onClick={handleCancel} icon={X} className="text-slate-500 hover:text-slate-800">
                                    Discard
                                </Button>
                                <Button
                                    onClick={() => void handleConfirmOrder()}
                                    disabled={saving}
                                    icon={isEditingExistingOrder ? Edit2 : Save}
                                    className="bg-blue-600 hover:bg-blue-700 shadow-lg shadow-blue-100 px-8 py-2.5 h-auto text-[10px] disabled:opacity-60"
                                >
                                    {saving ? 'Saving…' : isEditingExistingOrder ? 'Update Order' : 'Create Order'}
                                </Button>
                            </div>
                        </div>
                    </div>
                </div>

                {/* DELETE ORDER WARNING */}
                <Modal isOpen={deleteModalOpen} onClose={() => !deleteLoading && setDeleteModalOpen(false)}>
                    <div className="p-6">
                        <div className="flex items-start gap-4">
                            <div className="w-12 h-12 rounded-full bg-red-50 text-red-600 flex items-center justify-center shrink-0">
                                <AlertTriangle size={24} />
                            </div>
                            <div className="flex-1 min-w-0">
                                <h3 className="text-sm font-bold text-slate-900 mb-1">Delete this order?</h3>
                                <p className="text-[11px] text-slate-600 leading-relaxed">
                                    <span className="font-semibold text-slate-800">{styleName || 'This order'}</span>
                                    {poNumber ? ` · PO ${poNumber}` : ''} will be permanently removed.
                                </p>
                                <ul className="mt-3 text-[11px] text-slate-500 space-y-1 list-disc pl-4">
                                    <li>All colorways and size breakdowns for this order</li>
                                    <li>Line allocations linked to those colorways</li>
                                    <li>This cannot be undone</li>
                                </ul>
                                <p className="mt-3 text-[10px] text-amber-700 bg-amber-50 border border-amber-100 rounded-lg px-3 py-2">
                                    If floor teams have logged output, handovers, or shipments against this order, deletion may be blocked until that data is cleared.
                                </p>
                            </div>
                        </div>
                        <div className="flex justify-end gap-3 mt-6 pt-4 border-t border-slate-100">
                            <Button
                                variant="secondary"
                                onClick={() => setDeleteModalOpen(false)}
                                disabled={deleteLoading}
                            >
                                Cancel
                            </Button>
                            <Button
                                variant="danger"
                                icon={Trash2}
                                onClick={handleDeleteOrder}
                                disabled={deleteLoading}
                            >
                                {deleteLoading ? 'Deleting…' : 'Delete Order'}
                            </Button>
                        </div>
                    </div>
                </Modal>

                {/* SUCCESS MODAL */}
                <Modal isOpen={successModalOpen} onClose={handleSuccessRedirect}>
                    <div className="p-6 text-center">
                        <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto mb-4 shadow-sm">
                            <CheckCircle2 size={32} />
                        </div>
                        <h3 className="text-[10px] font-bold text-slate-900 mb-2">Success!</h3>
                        <p className="text-slate-500 mb-6">
                            Order has been {isEditingExistingOrder ? 'updated' : 'created'} successfully.
                        </p>
                        <div className="flex flex-col gap-3">
                            <Button onClick={handleSuccessRedirect} className="w-full justify-center">
                                View Style Details
                            </Button>
                            <Button variant="secondary" onClick={handleCreateAnother} className="w-full justify-center bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100">
                                Create Another Order
                            </Button>
                        </div>
                    </div>
                </Modal>

                <Modal isOpen={showDiscardDialog} onClose={cancelDiscardDialog}>
                    <div className="relative">
                        <button
                            onClick={cancelDiscardDialog}
                            className="absolute top-4 right-4 text-slate-400 hover:text-red-600 transition-colors p-1 hover:bg-red-50 rounded-full"
                        >
                            <X size={20} />
                        </button>
                        <div className="flex flex-col items-center p-8 pb-4 text-center">
                            <div className="w-16 h-16 bg-amber-100 text-amber-600 rounded-2xl flex items-center justify-center mb-4 shadow-sm ring-4 ring-amber-50">
                                <AlertTriangle size={32} />
                            </div>
                            <h3 className="text-base font-bold text-slate-900 mb-2">Unsaved Changes</h3>
                            <p className="text-slate-500 text-xs max-w-[260px] leading-relaxed">
                                You have unsaved modifications. What would you like to do?
                            </p>
                        </div>
                        <div className="p-6 pt-2 flex flex-col gap-3">
                            <Button
                                onClick={() => void confirmSaveAndCloseCancel()}
                                disabled={saving}
                                className="w-full shadow-lg shadow-blue-100 py-2.5 text-xs"
                            >
                                {saving ? <Loader2 size={14} className="animate-spin mx-auto" /> : 'Save Changes'}
                            </Button>
                            <Button
                                variant="danger-light"
                                onClick={confirmDiscardCancel}
                                className="w-full text-xs"
                            >
                                Discard &amp; {isEditingExistingOrder ? 'Leave' : 'Clear'}
                            </Button>
                        </div>
                    </div>
                </Modal>

            </div>
            )}
        </PageShell>
    );
};


