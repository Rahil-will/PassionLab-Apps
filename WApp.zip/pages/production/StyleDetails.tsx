import React, { useState, useMemo } from 'react';
import { useNavigationStore, useDataStore, useSettingsStore } from '../../stores';
import { RoutePath } from '../../types';
import { Card, Skeleton } from '../../components/ui';
import { PageShell } from '../../components/layout/PageShell';
import { StyleInformationCard } from '../../components/production/StyleInformationCard';
import { DepartmentScheduleGantt } from '../../components/production/DepartmentScheduleGantt';
import { flowTableClasses as t } from '../../lib/productionFlowTable';
import { sizeAdjQty, sizeOrderQty, sumSizeAdjQty } from '../../lib/colorwaySizesUtils';
import { useOrderSizeProgress } from '../../hooks/useOrderSizeProgress';
import { resolveOrderProcessFlow } from '../../lib/processFlowDb';
import { allocationsForColorway } from '../../lib/allocationUtils';
import { useRefreshProductionDataOnMount } from '../../hooks/useRefreshProductionDataOnMount';
import {
    colorwayStatusLabel,
    deriveColorwayProgressPhase,
    deriveSizeProgressPhase,
    formatProductionStatus,
    statusColorClass,
} from '../../lib/orderSizeProgress';

export const StyleDetails: React.FC = () => {
    const { navigate, routeParams, factoryId } = useNavigationStore();
    const { orders, allocations = [], productionSummary, loading } = useDataStore();
    const { processFlows, sizeGroups, loading: settingsLoading } = useSettingsStore();

    useRefreshProductionDataOnMount();

    const [matrixView, setMatrixView] = useState<'aggregate' | 'breakdown'>('aggregate');

    const orderId = routeParams?.id;
    const order = orders.find(o => o.id === orderId);

    const flowMeta = useMemo(() => {
        if (!order || settingsLoading) return null;
        return resolveOrderProcessFlow(processFlows, order.processFlow);
    }, [order, processFlows, settingsLoading]);

    const flowSteps = flowMeta?.flowSteps ?? [];
    const flowStepObjects = flowMeta?.flowStepObjects ?? [];
    const flowLabel = flowMeta?.flowLabel ?? null;

    const sizeGroupName = order?.sizeGroupName || 'Standard';

    const totalAdjustedQty = useMemo(() => {
        if (!order) return 0;
        return order.colorways.reduce((acc, cw) => acc + sumSizeAdjQty(cw.sizes), 0);
    }, [order]);

    const allSizes = useMemo(() => {
        if (!order) return [] as string[];
        return Array.from(new Set(order.colorways.flatMap(cw => cw.sizes.map(s => s.size))));
    }, [order]);

    const pageReady = !loading && !settingsLoading && flowMeta !== null;

    const colorwayIds = useMemo(() => order?.colorways.map((cw) => cw.id) ?? [], [order]);
    const { lookup: sizeProgress, loading: progressLoading } = useOrderSizeProgress(
        factoryId,
        orderId,
        colorwayIds,
        flowStepObjects,
    );

    const getDeptTotal = (colorwayId: string | undefined, deptName: string): number => {
        if (sizeProgress) return sizeProgress.getDeptTotal(colorwayId, deptName);
        if (!order) return 0;
        return productionSummary
            .filter(
                (r) =>
                    r.order_id === order.id &&
                    r.department === deptName &&
                    (!colorwayId || r.colorway_id === colorwayId),
            )
            .reduce((sum, r) => sum + (r.total_passed || r.total_scanned || 0), 0);
    };

    const getSizeCount = (
        colorwayId: string | undefined,
        deptName: string,
        size: string,
    ): number => {
        if (sizeProgress) return sizeProgress.getSizeCount(colorwayId, deptName, size);
        return 0;
    };

    const colorwayHasAllocations = (colorwayId: string): boolean =>
        allocationsForColorway(allocations, colorwayId).length > 0;

    React.useEffect(() => {
        if (!pageReady) return;
        if (!orderId || !order) navigate(RoutePath.STATUS_TRACKER);
    }, [pageReady, orderId, order, navigate]);

    if (!pageReady) {
        return <PageShell loading skeleton="spinner" />;
    }

    if (!order) {
        return (
            <div className="flex flex-col items-center justify-center h-[50vh] text-slate-400">
                <p>Redirecting...</p>
            </div>
        );
    }

    const renderMatrixTable = (colorName?: string) => {
        const colorwayId = colorName ? order.colorways.find(c => c.name === colorName)?.id : undefined;
        let totalOrderQty = 0; let totalAdjQty = 0;
        const deptTotals: Record<string, number> = {};

        allSizes.forEach(size => {
            if (colorName) {
                const cw = order.colorways.find(c => c.name === colorName);
                const s = cw?.sizes.find(sz => sz.size === size);
                if (s) {
                    totalOrderQty += sizeOrderQty(s);
                    totalAdjQty += sizeAdjQty(s);
                }
            } else {
                order.colorways.forEach(cw => {
                    const s = cw.sizes.find(sz => sz.size === size);
                    if (s) {
                        totalOrderQty += sizeOrderQty(s);
                        totalAdjQty += sizeAdjQty(s);
                    }
                });
            }
        });

        flowSteps.forEach(dept => {
            deptTotals[dept] = getDeptTotal(colorwayId, dept);
        });

        return (
            <div className={t.scroll}>
                <table className={t.table}>
                    <thead className={t.thead}>
                        <tr>
                            <th className={t.firstHead}>Size</th>
                            <th className={t.numHead}>Order</th>
                            <th className={t.adjHead}>Adj.</th>
                            {flowSteps.map(dept => (
                                <th key={dept} className={t.deptHead}>{dept}</th>
                            ))}
                            <th className={t.statusHead}>Status</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 bg-white">
                        {allSizes.length === 0 ? (
                            <tr><td colSpan={4 + flowSteps.length} className="p-6 text-center text-slate-400 italic">No size data.</td></tr>
                        ) : allSizes.map(size => {
                            let orderQty = 0; let adjQty = 0;
                            if (colorName) {
                                const cw = order.colorways.find(c => c.name === colorName);
                                const s = cw?.sizes.find(sz => sz.size === size);
                                if (s) {
                                    orderQty = sizeOrderQty(s);
                                    adjQty = sizeAdjQty(s);
                                }
                            } else {
                                order.colorways.forEach(cw => {
                                    const s = cw.sizes.find(sz => sz.size === size);
                                    if (s) {
                                        orderQty += sizeOrderQty(s);
                                        adjQty += sizeAdjQty(s);
                                    }
                                });
                            }
                            return (
                                <tr key={size} className="hover:bg-slate-50">
                                    <td className={`${t.firstCell} font-bold text-slate-700`}>{size}</td>
                                    <td className={t.numCell}>{orderQty > 0 ? orderQty.toLocaleString() : <span className="text-slate-300">—</span>}</td>
                                    <td className={t.adjCell}>{adjQty > 0 ? adjQty.toLocaleString() : <span className="text-slate-300">—</span>}</td>
                                    {flowSteps.map(dept => {
                                        const count = getSizeCount(colorwayId, dept, size);
                                        return (
                                            <td key={dept} className={t.deptCell}>
                                                {progressLoading ? (
                                                    <Skeleton className="h-3 w-8 mx-auto rounded" />
                                                ) : count > 0 ? count.toLocaleString() : (
                                                    <span className="text-slate-200">—</span>
                                                )}
                                            </td>
                                        );
                                    })}
                                    <td className={`${t.statusCell} ${progressLoading ? '' : statusColorClass(
                                        deriveSizeProgressPhase(
                                            flowSteps,
                                            adjQty,
                                            (dept) => getSizeCount(colorwayId, dept, size),
                                        ),
                                    )}`}>
                                        {progressLoading ? (
                                            <Skeleton className="h-3 w-14 mx-auto rounded" />
                                        ) : (
                                            formatProductionStatus(
                                                deriveSizeProgressPhase(
                                                    flowSteps,
                                                    adjQty,
                                                    (dept) => getSizeCount(colorwayId, dept, size),
                                                ),
                                            )
                                        )}
                                    </td>
                                </tr>
                            );
                        })}
                    </tbody>
                    <tfoot className="bg-slate-100 border-t-2 border-slate-200 font-bold text-slate-700">
                        <tr>
                            <td className={t.footFirst}>Total</td>
                            <td className={t.footNum}>{totalOrderQty.toLocaleString()}</td>
                            <td className={t.footAdj}>{totalAdjQty.toLocaleString()}</td>
                            {flowSteps.map(dept => (
                                <td key={dept} className={t.footDept}>
                                    {progressLoading ? (
                                        <Skeleton className="h-3 w-8 mx-auto rounded" />
                                    ) : deptTotals[dept] > 0 ? deptTotals[dept].toLocaleString() : '—'}
                                </td>
                            ))}
                            <td className={t.footStatus} />
                        </tr>
                    </tfoot>
                </table>
            </div>
        );
    };

    return (
        <PageShell className="w-full pb-32">
            <div className="space-y-8">
                <StyleInformationCard
                    order={order}
                    sizeGroupName={sizeGroupName}
                    flowSteps={flowSteps}
                    flowLabel={flowLabel || '—'}
                    stats={{
                        orderQty: order.orderQty || order.totalQty || 0,
                        cutAllow: order.cuttingAllowance || 0,
                        shipAllow: order.shipmentAllowance || 0,
                        totalAdjusted: order.adjQty || totalAdjustedQty,
                    }}
                    onEdit={() => navigate(RoutePath.CREATE_ORDER, { id: order.id })}
                />



                {/* 2. COLORS TABLE */}
                <Card title="Colors" subtitle="Colorway summary with flow progress" className="shadow-sm border-slate-200" noPadding>
                    <div className="p-6">
                    <div className={t.wrapper}>
                    <div className={t.scroll}>
                        <table className={t.table}>
                            <thead className={t.thead}>
                                <tr>
                                    <th className={t.firstHead}>Color</th>
                                    <th className={t.numHead}>Order</th>
                                    <th className={t.adjHead}>Adj.</th>
                                    {flowSteps.map(dept => (
                                        <th key={dept} className={t.deptHead}>{dept}</th>
                                    ))}
                                    <th className={t.statusHead}>Status</th>
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-slate-100">
                                {order.colorways.map(cw => {
                                    const adjQty = sumSizeAdjQty(cw.sizes);
                                    const cwPhase = deriveColorwayProgressPhase(
                                        flowSteps,
                                        adjQty,
                                        (dept) => getDeptTotal(cw.id, dept),
                                    );
                                    const cwStatus = colorwayStatusLabel(cwPhase, colorwayHasAllocations(cw.id));
                                    return (
                                        <tr key={cw.id} className="hover:bg-slate-50 cursor-pointer" onClick={() => navigate(RoutePath.STYLE_COLOR_DETAILS, { id: order.id, colorId: cw.id })}>
                                            <td className={t.firstCell}>
                                                <div className="flex items-center gap-2"><div className="w-2.5 h-2.5 rounded-full bg-blue-500 flex-shrink-0"></div><span className="font-medium text-[10px] text-slate-700">{cw.name}</span></div>
                                            </td>
                                            <td className={t.numCell}>{(cw.orderQty || cw.totalQty || 0).toLocaleString()}</td>
                                            <td className={t.adjCell}>{adjQty.toLocaleString()}</td>
                                            {flowSteps.map(dept => {
                                                const count = getDeptTotal(cw.id, dept);
                                                return (
                                                    <td key={dept} className={t.deptCell}>
                                                        {progressLoading ? (
                                                            <Skeleton className="h-3 w-8 mx-auto rounded" />
                                                        ) : count > 0 ? count.toLocaleString() : (
                                                            <span className="text-slate-200">—</span>
                                                        )}
                                                    </td>
                                                );
                                            })}
                                            <td className={`${t.statusCell} ${statusColorClass(cwPhase)}`}>{cwStatus}</td>
                                        </tr>
                                    );
                                })}
                                {order.colorways.length === 0 && <tr><td colSpan={3 + flowSteps.length + 1} className="p-8 text-center text-slate-400 italic">No colors added yet.</td></tr>}
                            </tbody>
                        </table>
                    </div>
                    </div>
                    </div>
                </Card>

                {/* 3. PRODUCTION MATRIX */}
                <Card
                    title="Production Matrix"
                    subtitle={`Size-wise Flow Progress${flowLabel ? ` (${flowLabel})` : ''}`}
                    action={
                        <div className="flex bg-slate-100 p-1 rounded-lg">
                            <button onClick={() => setMatrixView('aggregate')} className={`px-3 py-1 text-[10px] font-medium rounded-md transition-all ${matrixView === 'aggregate' ? 'bg-white text-blue-600 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}>Aggregate View</button>
                            <button onClick={() => setMatrixView('breakdown')} className={`px-3 py-1 text-[10px] font-medium rounded-md transition-all ${matrixView === 'breakdown' ? 'bg-white text-blue-600 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}>Color-wise Breakdown</button>
                        </div>
                    }
                    className="shadow-sm border-slate-200"
                    noPadding
                >
                    {matrixView === 'aggregate' ? (
                        <div className="p-6">
                            <div className="border border-slate-200 rounded-lg overflow-hidden">
                                {renderMatrixTable()}
                            </div>
                        </div>
                    ) : (
                        <div className="space-y-8 p-6">
                            {order.colorways.map(cw => {
                                const adjQty = sumSizeAdjQty(cw.sizes);
                                return (
                                    <div key={cw.id} className="animate-in fade-in slide-in-from-bottom-2 w-full">
                                        {/* Color Header Row - REMOVED QTY BRACKET */}
                                        <div className="w-full bg-blue-50 border border-blue-200 rounded-t-lg px-4 py-3 flex items-center gap-4">
                                            <div className="flex items-center gap-2">
                                                <div className="w-3 h-3 rounded-full bg-blue-600 border-2 border-white shadow-sm"></div>
                                                <span className="text-xs font-bold text-slate-800">{cw.name}</span>
                                            </div>
                                        </div>

                                        {/* Table Wrapper */}
                                        <div className="border border-t-0 border-slate-200 rounded-b-lg overflow-hidden bg-white">
                                            {renderMatrixTable(cw.name)}
                                        </div>
                                    </div>
                                );
                            })}
                        </div>
                    )}
                </Card>

                <DepartmentScheduleGantt
                    orderId={order.id}
                    poNumber={order.poNumber}
                    deliveryDate={order.deliveryDate}
                />

            </div>
        </PageShell>
    );
};
