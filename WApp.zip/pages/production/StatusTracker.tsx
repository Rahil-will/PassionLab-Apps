﻿import React, { useState, useMemo } from 'react';
import { format, startOfMonth, endOfMonth, subMonths, addMonths } from 'date-fns';
import { useDataStore, useSettingsStore } from '../../stores';
import { RoutePath } from '../../types';
import { useNavigationStore } from '../../stores';
import { ChevronDown, ChevronRight, Search, User, Layers, Package, Filter, Calendar, ChevronLeft, RefreshCw, CheckCircle } from 'lucide-react';
import { Card, SelectDropdown, Spinner, Toast } from '../../components/ui';
import { PageShell } from '../../components/layout/PageShell';
import { DateRangePicker, type DateRangeValue } from '../../components/DateRangePicker';
import { processFlowDeptNames, resolveOrderProcessFlow } from '../../lib/processFlowDb';
import { sizeAdjQty } from '../../lib/colorwaySizesUtils';
import { OrderPriorityChip } from '../../lib/orderPriority';
import { isQcDept } from '../../lib/reportDeptUtils';
import { deliveryInRange } from '../../lib/fulfillmentMetrics';
import { useRefreshProductionDataOnMount } from '../../hooks/useRefreshProductionDataOnMount';

const PAGE_SIZE = 20;

function toYmd(iso: string): string {
    return format(new Date(iso), 'yyyy-MM-dd');
}

function deliverySortKey(deliveryDate: string | undefined): string {
    return deliveryDate?.split('T')[0] || '9999-12-31';
}

function statusTrackerDefaultDateRange(): DateRangeValue {
    const today = new Date();
    return {
        startDate: startOfMonth(subMonths(today, 1)).toISOString(),
        endDate: endOfMonth(addMonths(today, 1)).toISOString(),
    };
}

function DeptQcBadge() {
    return (
        <span className="text-[7px] font-bold uppercase text-amber-700 bg-amber-50 border border-amber-200 rounded px-1 py-px leading-none">
            QC
        </span>
    );
}

export const StatusTracker: React.FC = () => {
    const { orders, loading, productionSummary } = useDataStore();
    const { processFlows, departments, loading: settingsLoading } = useSettingsStore();
    const { navigate } = useNavigationStore();

    useRefreshProductionDataOnMount();

    const [expandedOrderIds, setExpandedOrderIds] = useState<Set<string>>(new Set());
    const [searchQuery, setSearchQuery] = useState('');
    const [filterBuyer, setFilterBuyer] = useState('');
    const [filterStatus, setFilterStatus] = useState('');
    const [carouselPositions, setCarouselPositions] = useState<Record<string, number>>({});
    const [refreshing, setRefreshing] = useState(false);
    const [lastRefresh, setLastRefresh] = useState<Date | null>(null);
    const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' } | null>(null);

    const [dateRange, setDateRange] = useState<DateRangeValue>(statusTrackerDefaultDateRange);
    const dateFrom = toYmd(dateRange.startDate);
    const dateTo = toYmd(dateRange.endDate);

    // Get unique buyers
    const allBuyers = useMemo(() => {
        return Array.from(new Set(orders.map(o => o.buyer))).sort();
    }, [orders]);

    // Per-order dept output from v_daily_output (hourly_counts + inspection_sessions) via productionSummary.
    // Hourly depts: SUM(hourly_counts.count). QC depts: SUM(inspection_sessions.passed + rework_passed).
    const orderDeptCounts = useMemo(() => {
        const result: Record<string, Record<string, number>> = {};
        productionSummary.forEach(row => {
            if (!row.department) return; // skip placeholder rows
            if (!result[row.order_id]) result[row.order_id] = {};
            const deptName = row.department;
            const count = row.total_passed || row.total_scanned || 0;

            if (!result[row.order_id][deptName]) result[row.order_id][deptName] = 0;
            result[row.order_id][deptName] += count;
        });
        return result;
    }, [productionSummary]);

    /** dept name → QC flag from settings (process flow step dept_id → departments.apps). */
    const qcDeptByName = useMemo(() => {
        const deptById = new Map(departments.map((d) => [d.id, d]));
        const map = new Map<string, boolean>();
        for (const flow of processFlows) {
            for (const step of flow.steps || []) {
                const name = step.dept_name;
                if (!name) continue;
                const entity = step.dept_id ? deptById.get(step.dept_id) : undefined;
                const byName = departments.find((d) => d.name === name);
                const apps = entity?.apps ?? byName?.apps ?? null;
                map.set(name, isQcDept(apps));
            }
        }
        return map;
    }, [processFlows, departments]);

    const isStepQc = (orderId: string, stepName: string): boolean => {
        if (qcDeptByName.has(stepName)) return qcDeptByName.get(stepName) ?? false;
        const order = orders.find((o) => o.id === orderId);
        if (!order?.processFlow) return false;
        const resolved = resolveOrderProcessFlow(processFlows, order.processFlow);
        const step = resolved.flowStepObjects.find((s) => s.dept_name === stepName);
        if (!step?.dept_id) return false;
        const entity = departments.find((d) => d.id === step.dept_id);
        return isQcDept(entity?.apps ?? null);
    };

    /** Pipeline columns per order — only from the order's process flow, built after settings load. */
    const pipelineStepsByOrderId = useMemo(() => {
        if (settingsLoading) return null;
        const map = new Map<string, string[]>();
        for (const order of orders) {
            map.set(order.id, processFlowDeptNames(processFlows, order.processFlow));
        }
        return map;
    }, [orders, processFlows, settingsLoading]);

    const pageReady = !loading && !settingsLoading && pipelineStepsByOrderId !== null;

    const toggleExpand = (e: React.MouseEvent, id: string) => {
        e.stopPropagation();
        const newSet = new Set(expandedOrderIds);
        if (newSet.has(id)) newSet.delete(id);
        else newSet.add(id);
        setExpandedOrderIds(newSet);
    };

    const goToDetails = (id: string) => {
        navigate(RoutePath.STYLE_DETAILS, { id });
    };

    const getOrderPipelineSteps = (orderId: string, flowId?: string): string[] => {
        if (!pipelineStepsByOrderId) return [];
        return pipelineStepsByOrderId.get(orderId) ?? processFlowDeptNames(processFlows, flowId);
    };

    const getDaysToDelivery = (deliveryDate: string) => {
        const today = new Date();
        const delivery = new Date(deliveryDate);
        const diffTime = delivery.getTime() - today.getTime();
        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
        return diffDays;
    };

    // Carousel navigation
    const scrollCarousel = (orderId: string, direction: 'left' | 'right', maxItems: number) => {
        const currentPos = carouselPositions[orderId] || 0;
        const visibleCards = 2.25; // Show 2 and 1/4 cards
        const maxPos = Math.max(0, maxItems - Math.floor(visibleCards));
        
        if (direction === 'left') {
            setCarouselPositions(prev => ({ ...prev, [orderId]: Math.max(0, currentPos - 1) }));
        } else {
            setCarouselPositions(prev => ({ ...prev, [orderId]: Math.min(maxPos, currentPos + 1) }));
        }
    };

    const filteredOrdersAll = useMemo(() => {
        return orders
            .filter((o) => {
                const matchesSearch = !searchQuery || o.styleName.toLowerCase().includes(searchQuery.toLowerCase()) ||
                    o.poNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
                    (o.styleRef || '').toLowerCase().includes(searchQuery.toLowerCase()) ||
                    o.buyer.toLowerCase().includes(searchQuery.toLowerCase());
                const matchesBuyer = !filterBuyer || o.buyer === filterBuyer;
                const matchesDelivery = deliveryInRange(o.deliveryDate, dateFrom, dateTo);
                let matchesStatus = true;
                if (filterStatus) {
                    const totalAdj = o.colorways.reduce((acc, cw) => acc + cw.sizes.reduce((sAcc, s) => sAcc + sizeAdjQty(s), 0), 0);
                    const steps = pipelineStepsByOrderId?.get(o.id) ?? processFlowDeptNames(processFlows, o.processFlow);
                    const deptCounts = orderDeptCounts[o.id] || {};
                    const allDone = steps.length > 0 && steps.every((step: string) => (deptCounts[step] ?? 0) >= totalAdj);
                    const anyActive = steps.some((step: string) => (deptCounts[step] ?? 0) > 0);
                    const daysLeft = getDaysToDelivery(o.deliveryDate);
                    const isOverdue = daysLeft < 0;
                    if (filterStatus === 'Completed') matchesStatus = allDone;
                    else if (filterStatus === 'Active') matchesStatus = anyActive && !allDone;
                    else if (filterStatus === 'Delayed') matchesStatus = isOverdue && !allDone;
                }
                return matchesSearch && matchesBuyer && matchesStatus && matchesDelivery;
            })
            .sort((a, b) => deliverySortKey(a.deliveryDate).localeCompare(deliverySortKey(b.deliveryDate)));
    }, [orders, searchQuery, filterBuyer, filterStatus, dateFrom, dateTo, orderDeptCounts, pipelineStepsByOrderId, processFlows]);

    const displayOrders = useMemo(
        () => filteredOrdersAll.slice(0, PAGE_SIZE),
        [filteredOrdersAll],
    );

    // Get status label
    const getStatusLabel = (status: string | undefined, actual: number, planned: number) => {
        if (status === 'completed' || actual >= planned) return 'Done';
        if (status === 'active' || actual > 0) return 'Active';
        if (status === 'delayed') return 'Delayed';
        return 'Pending';
    };

    return (
        <PageShell loading={!pageReady} skeleton="list" className="w-full pb-20">

            {/* Single Giant Card */}
            <Card noPadding className="shadow-sm border-slate-200 overflow-visible">
                {/* Filter Bar - Standard Pattern */}
                <div className="px-4 py-3 border-b border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between bg-slate-50/50 gap-3">
                    {/* Left: Search */}
                    <div className="flex items-center gap-2 flex-1 max-w-sm min-w-0">
                        <Search size={14} className="text-slate-400 shrink-0" />
                        <input
                            className="text-xs bg-transparent border-b border-slate-200 focus:border-blue-500 focus:outline-none py-1 flex-1 min-w-0"
                            placeholder="Search style, PO, buyer..."
                            value={searchQuery}
                            onChange={(e) => setSearchQuery(e.target.value)}
                        />
                    </div>

                    {/* Right: Filter Pills + Refresh */}
                    <div className="flex flex-col sm:flex-row flex-wrap items-stretch sm:items-center gap-3 sm:ml-auto">
                        <button 
                            onClick={async () => {
                                setRefreshing(true);
                                try {
                                    await useDataStore.getState().fetchData({ silent: true });
                                    await useDataStore.getState().refreshProductionSummary();
                                    setLastRefresh(new Date());
                                    setToast({ message: 'Table data refreshed', type: 'success' });
                                    setRefreshing(false);
                                } catch (err: any) {
                                    setToast({ message: `Refresh failed: ${err.message}`, type: 'error' });
                                    setRefreshing(false);
                                }
                            }} 
                            disabled={refreshing}
                            className={`w-8 h-8 rounded-full flex items-center justify-center transition-colors ${refreshing ? 'bg-slate-100 text-slate-400' : 'bg-slate-100 hover:bg-slate-200 text-slate-600'}`}
                            title="Refresh summary tables"
                        >
                            {refreshing ? <Spinner size="sm" /> : <RefreshCw size={14} />}
                        </button>
                        {lastRefresh && (
                            <span className="text-[10px] text-slate-400 flex items-center gap-1">
                                <CheckCircle size={10} className="text-emerald-500" />
                                {lastRefresh.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                            </span>
                        )}
                        <SelectDropdown
                            value={filterStatus}
                            onChange={setFilterStatus}
                            options={[
                                { value: '', label: 'All Status' },
                                { value: 'Active', label: 'Active' },
                                { value: 'Completed', label: 'Completed' },
                                { value: 'Delayed', label: 'Delayed' }
                            ]}
                            icon={Filter}
                            className="w-32"
                        />
                        <SelectDropdown
                            value={filterBuyer}
                            onChange={setFilterBuyer}
                            options={[
                                { value: '', label: 'All Buyers' },
                                ...allBuyers.map(b => ({ value: b, label: b }))
                            ]}
                            className="w-full sm:w-36"
                        />
                        <DateRangePicker
                            variant="pill"
                            dropdownAlign="right"
                            value={dateRange}
                            onChange={setDateRange}
                            className="w-full sm:w-auto"
                        />
                    </div>
                </div>
                {filteredOrdersAll.length > PAGE_SIZE && (
                    <div className="px-4 py-1.5 border-b border-slate-100 bg-white text-[10px] text-slate-500">
                        Showing {displayOrders.length} of {filteredOrdersAll.length} orders (nearest delivery first)
                    </div>
                )}
                {/* Table Header */}
                <div className="flex items-center border-b border-slate-200 bg-slate-50 text-[10px] font-bold text-slate-500 uppercase tracking-wider">
                    <div className="w-10 p-3"></div>
                    <div className="flex-1 p-3 min-w-[200px]">Order Details</div>
                    <div className="w-[55%] p-3 flex">
                        <div className="flex-1 text-center">Production Pipeline</div>
                    </div>
                    <div className="w-28 p-3 text-center">Delivery</div>
                </div>

                {/* Order Rows */}
                <div className="flex flex-col">
                    {displayOrders.map((order, orderIdx) => {
                        const isExpanded = expandedOrderIds.has(order.id);
                        const steps = getOrderPipelineSteps(order.id, order.processFlow);
                        const totalAdjusted = order.colorways.reduce((acc, cw) => acc + cw.sizes.reduce((sAcc, s) => sAcc + sizeAdjQty(s), 0), 0);
                        const daysLeft = getDaysToDelivery(order.deliveryDate);
                        const isOverdue = daysLeft < 0;
                        const isUrgent = daysLeft >= 0 && daysLeft <= 7;
                        const carouselPos = carouselPositions[order.id] || 0;
                        const cardWidth = 380; // Width of each color card - shows 2 + 1/4 cards
                        const cardGap = 12;

                        return (
                            <React.Fragment key={order.id}>
                                {/* Spacer between rows */}
                                {orderIdx > 0 && <div className="h-3 bg-slate-100"></div>}
                                
                                {/* Main Row */}
                                <div className={`flex items-stretch hover:bg-slate-50/50 transition-colors ${isExpanded ? 'bg-slate-50/30' : ''}`}>
                                    {/* Expand Button */}
                                    <div 
                                        className="w-10 flex items-center justify-center cursor-pointer"
                                        onClick={(e) => toggleExpand(e, order.id)}
                                    >
                                        <div className={`p-1 rounded-md ${isExpanded ? 'bg-slate-200 text-slate-600' : 'text-slate-400 hover:text-slate-600'}`}>
                                            {isExpanded ? <ChevronDown size={16} /> : <ChevronRight size={16} />}
                                        </div>
                                    </div>

                                    {/* Order Info */}
                                    <div className="flex-1 py-3 pr-4 cursor-pointer min-w-[200px]" onClick={() => goToDetails(order.id)}>
                                        <div className="flex items-center gap-3">
                                            {/* Image */}
                                            <div className="w-12 h-12 bg-slate-100 rounded-lg border border-slate-200 flex-shrink-0 overflow-hidden">
                                                {order.image ? (
                                                    <img src={order.image} alt={order.styleName} className="w-full h-full object-cover" />
                                                ) : (
                                                    <div className="w-full h-full flex items-center justify-center text-slate-300">
                                                        <Layers size={18} />
                                                    </div>
                                                )}
                                            </div>

                                            {/* Details */}
                                            <div className="flex-1 min-w-0">
                                                <div className="flex items-center gap-2 mb-0.5">
                                                    <span className="font-bold text-slate-900 hover:text-blue-600 transition-colors" style={{ fontSize: '12px' }}>{order.styleName}</span>
                                                    <OrderPriorityChip priority={order.priority} />
                                                </div>
                                                <div className="flex items-center gap-3 text-[10px] text-slate-400">
                                                    <span className="flex items-center gap-1"><Package size={11} className="text-slate-400" /> {order.poNumber}</span>
                                                    <span className="text-slate-300">|</span>
                                                    <span className="flex items-center gap-1"><User size={11} /> {order.buyer}</span>
                                                    <span className="text-slate-300">|</span>
                                                    {order.styleRef && <><span className="font-medium text-slate-500">{order.styleRef}</span><span className="text-slate-300">|</span></>}
                                                    <span className="flex items-center gap-1"><Package size={11} /> {totalAdjusted.toLocaleString()} pcs</span>
                                                    <span className="text-slate-300">|</span>
                                                    <span>{order.colorways.length} Colors</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    {/* Production Pipeline - 55% */}
                                    <div className="w-[55%] flex border-l border-slate-100">
                                        {steps.map((step, idx) => {
                                            const actual = orderDeptCounts[order.id]?.[step] ?? 0;
                                            const qcStep = isStepQc(order.id, step);
                                            const pct = totalAdjusted > 0 ? Math.round((actual / totalAdjusted) * 100) : 0;
                                            const statusLabel = getStatusLabel(undefined, actual, totalAdjusted);

                                            return (
                                                <div key={step} className={`flex-1 flex flex-col justify-center p-3 relative ${idx < steps.length - 1 ? 'border-r border-slate-100' : ''}`}>
                                                    {/* Progress bar at bottom */}
                                                    <div className="absolute bottom-0 left-0 h-1 bg-slate-100 w-full">
                                                        <div 
                                                            className={`h-full transition-all ${statusLabel === 'Done' ? 'bg-emerald-500' : statusLabel === 'Active' ? 'bg-blue-500' : statusLabel === 'Delayed' ? 'bg-red-500' : 'bg-slate-200'}`} 
                                                            style={{ width: `${Math.min(pct, 100)}%` }}
                                                        ></div>
                                                    </div>
                                                    
                                                    {/* Department name */}
                                                    <div className="flex items-center gap-1 mb-1">
                                                        <div className="text-[9px] font-bold text-slate-400 uppercase truncate">{step}</div>
                                                        {qcStep && <DeptQcBadge />}
                                                    </div>
                                                    
                                                    {/* Pieces */}
                                                    <div className="text-xs font-bold text-slate-800 mb-1">
                                                        {actual.toLocaleString()}
                                                        <span className="text-slate-400 font-normal text-xs"> / {totalAdjusted.toLocaleString()}</span>
                                                    </div>
                                                    
                                                    {/* Status dot + text */}
                                                    <div className="flex items-center gap-1">
                                                        <div className={`w-1.5 h-1.5 rounded-full ${statusLabel === 'Done' ? 'bg-emerald-500' : statusLabel === 'Active' ? 'bg-blue-500' : statusLabel === 'Delayed' ? 'bg-red-500' : 'bg-slate-300'}`}></div>
                                                        <span className={`text-[10px] font-medium ${statusLabel === 'Done' ? 'text-emerald-600' : statusLabel === 'Active' ? 'text-blue-600' : statusLabel === 'Delayed' ? 'text-red-600' : 'text-slate-400'}`}>
                                                            {statusLabel}
                                                        </span>
                                                    </div>
                                                </div>
                                            );
                                        })}
                                    </div>

                                    {/* Delivery Date Column */}
                                    <div className="w-28 flex flex-col items-center justify-center border-l border-slate-100 py-2">
                                        <div className="flex items-center gap-1 text-[10px] text-slate-400 mb-1">
                                            <Calendar size={11} />
                                            <span>{order.deliveryDate}</span>
                                        </div>
                                        <div className={`text-xs font-bold ${isOverdue ? 'text-red-600' : isUrgent ? 'text-amber-600' : 'text-slate-700'}`}>
                                            {isOverdue ? Math.abs(daysLeft) : daysLeft}
                                        </div>
                                        <div className={`text-[9px] font-medium ${isOverdue ? 'text-red-500' : isUrgent ? 'text-amber-500' : 'text-slate-400'}`}>
                                            {isOverdue ? 'DAYS LATE' : 'DAYS LEFT'}
                                        </div>
                                    </div>
                                </div>

                                {/* Expanded: Colorways Carousel */}
                                {isExpanded && (
                                    <div className="bg-slate-50/50 py-4 border-t border-slate-100">
                                        {/* Carousel with side arrows */}
                                        <div className="flex items-center gap-2 px-2">
                                            {/* Left Arrow */}
                                            <button 
                                                onClick={() => scrollCarousel(order.id, 'left', order.colorways.length)}
                                                disabled={carouselPos === 0}
                                                className={`p-1 rounded transition-colors flex-shrink-0 ${carouselPos === 0 ? 'text-slate-300 cursor-not-allowed' : 'text-slate-500 hover:text-slate-700 hover:bg-slate-200'}`}
                                            >
                                                <ChevronLeft size={18} />
                                            </button>

                                            {/* Carousel Container */}
                                            <div className="flex-1 overflow-hidden">
                                                <div 
                                                    className="flex gap-3 transition-transform duration-300 ease-out"
                                                    style={{ transform: `translateX(-${carouselPos * (cardWidth + cardGap)}px)` }}
                                                >
                                                    {order.colorways.map((cw: any) => {
                                                        const cwQty = cw.sizes.reduce((a: number, b: any) => a + sizeAdjQty(b), 0);

                                                        // Get actual per-colorway counts from productionSummary
                                                        const cwRows = productionSummary.filter(r => r.order_id === order.id && r.colorway_id === cw.id);

                                                        return (
                                                            <div 
                                                                key={cw.id} 
                                                                style={{ width: `${cardWidth}px` }}
                                                                className="flex-shrink-0 bg-white rounded-lg border border-slate-200 p-3 hover:border-blue-300 hover:shadow-sm transition-all cursor-pointer"
                                                                onClick={() => navigate(RoutePath.STYLE_COLOR_DETAILS, { id: order.id, colorId: cw.id })}
                                                            >
                                                                {/* Color Header */}
                                                                <div className="flex items-center justify-between mb-2">
                                                                    <div className="flex items-center gap-2">
                                                                        <div className="w-3 h-3 rounded-full bg-blue-500"></div>
                                                                        <span className="font-bold text-[10px] text-slate-800">{cw.name}</span>
                                                                    </div>
                                                                    <span className="text-[10px] text-slate-400">{cwQty.toLocaleString()} pcs</span>
                                                                </div>
                                                                
                                                                {/* Department Progress - Horizontal */}
                                                                <div className="flex gap-1">
                                                                    {steps.map((step) => {
                                                                        const deptRow = cwRows.find(r => r.department === step);
                                                                        const cwActual = deptRow
                                                                            ? (deptRow.total_passed || deptRow.total_scanned || 0)
                                                                            : 0;
                                                                        const qcStep = isStepQc(order.id, step);
                                                                        const pct = cwQty > 0 ? Math.round((cwActual / cwQty) * 100) : 0;
                                                                        
                                                                        return (
                                                                            <div key={step} className="flex-1 min-w-0">
                                                                                <div className="flex items-center gap-0.5 mb-0.5">
                                                                                    <div className="text-[8px] text-slate-400 uppercase truncate">{step}</div>
                                                                                    {qcStep && <DeptQcBadge />}
                                                                                </div>
                                                                                <div className="text-xs font-bold text-slate-700 mb-0.5">
                                                                                    {cwActual.toLocaleString()}
                                                                                </div>
                                                                                <div className="h-1.5 bg-slate-100 rounded-full overflow-hidden">
                                                                                    <div 
                                                                                        className={`h-full rounded-full ${pct >= 100 ? 'bg-emerald-500' : pct > 0 ? 'bg-blue-500' : 'bg-slate-200'}`} 
                                                                                        style={{ width: `${pct}%` }}
                                                                                    ></div>
                                                                                </div>
                                                                            </div>
                                                                        );
                                                                    })}
                                                                </div>
                                                            </div>
                                                        );
                                                    })}
                                                </div>
                                            </div>

                                            {/* Right Arrow */}
                                            <button 
                                                onClick={() => scrollCarousel(order.id, 'right', order.colorways.length)}
                                                disabled={carouselPos >= order.colorways.length - 2}
                                                className={`p-1 rounded transition-colors flex-shrink-0 ${carouselPos >= order.colorways.length - 2 ? 'text-slate-300 cursor-not-allowed' : 'text-slate-500 hover:text-slate-700 hover:bg-slate-200'}`}
                                            >
                                                <ChevronRight size={18} />
                                            </button>
                                        </div>
                                    </div>
                                )}
                            </React.Fragment>
                        );
                    })}

                    {filteredOrdersAll.length === 0 && (
                        <div className="p-10 text-center text-slate-400 italic">
                            No orders found matching criteria.
                        </div>
                    )}
                </div>
            </Card>
            {toast && <Toast message={toast.message} type={toast.type} onClose={() => setToast(null)} />}
        </PageShell>
    );
};
