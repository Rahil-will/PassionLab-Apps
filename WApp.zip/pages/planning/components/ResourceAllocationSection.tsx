import React from 'react';
import { Search } from 'lucide-react';
import { PlanningTable } from './PlanningTable';
import { LineAllocation } from '../../../types';

interface ResourceAllocationSectionProps {
    isFullScreen: boolean;
    viewStartDate: string;
    selectedOrderId: string;
    selectedColor: string;
    flowSteps: any[];
    assignedResources: any[];
    allAllocations: LineAllocation[];
    selectedColorData: any;
    timelineData: any[];
    cellWidth: number;
    deliveryDate?: string;
    editingAlloc: any;
    planningTotals: { targetTotal: number; plannedTotal: number; remainingTotal: number };
    selectedOrder: any;
    regularShiftHours: number;
    onToggleFullScreen: () => void;
    onViewStartDateChange: (date: string) => void;
    onPrev: () => void;
    onNext: () => void;
    onBarClick: (alloc: LineAllocation) => void;
    onBarDragStart: (alloc: LineAllocation, edge: 'left' | 'right' | 'center') => void;
    onBarHover?: (allocation: LineAllocation | null, anchorRect?: DOMRect) => void;
    onTimelineClick?: (resourceId: string, date: string) => void;
    onEditingAllocChange: (alloc: any) => void;
    onSave: () => void;
    onRemove: () => void;
    onCancel: () => void;
    planningRows: any[];
    setPlanningRows: (rows: any[]) => void;
}

export const ResourceAllocationSection: React.FC<ResourceAllocationSectionProps> = ({
    isFullScreen,
    viewStartDate,
    selectedOrderId,
    selectedColor,
    flowSteps,
    assignedResources,
    allAllocations,
    selectedColorData,
    timelineData,
    cellWidth,
    deliveryDate,
    editingAlloc,
    planningTotals,
    selectedOrder,
    regularShiftHours,
    onToggleFullScreen,
    onViewStartDateChange,
    onPrev,
    onNext,
    onBarClick,
    onBarDragStart,
    onBarHover,
    onTimelineClick,
    onEditingAllocChange,
    onSave,
    onRemove,
    onCancel,
    planningRows,
    setPlanningRows
}) => {

    // Convert planning rows to allocations for Gantt display
    const planningAllocations = React.useMemo(() => {
        return planningRows
            .filter(row => row.resourceId && row.startDate && row.endDate && row.plannedQty > 0)
            .map(row => ({
                id: row.id,
                lineId: row.resourceId,
                orderId: selectedColorData?.id || '',
                startDate: row.startDate,
                endDate: row.endDate,
                qty: row.plannedQty,
                dailyTarget: row.dailyTarget,
                learningCurve: null,
                completed_is_true: false,
                styleName: selectedOrder?.styleName || '',
                colorway: selectedColorData?.name || '',
                departmentId: assignedResources.find((r: any) => r.id === row.resourceId)?.departmentId,
                poNumber: selectedOrder?.poNumber || '',
                status: 'pending',
                progress: 0,
                plannedMetrics: {
                    workers: 0,
                    hours: 0,
                    efficiency: 0
                }
            }));
    }, [planningRows, selectedColorData, selectedOrder, assignedResources]);

    // Combine with existing allocations
    const combinedAllocations = React.useMemo(() => {
        // Filter out planning allocations from allAllocations (those with temp IDs)
        const savedAllocations = allAllocations.filter(a => !a.id.startsWith('temp-'));
        return [...savedAllocations, ...planningAllocations];
    }, [allAllocations, planningAllocations]);

    return (
        <>
            {/* Planning Table with embedded Gantt Timeline */}
            {selectedOrderId && selectedColor && selectedColorData ? (
                <PlanningTable
                    flowSteps={flowSteps}
                    assignedResources={assignedResources}
                    selectedColorData={selectedColorData}
                    selectedOrder={selectedOrder}
                    planningRows={planningRows}
                    onRowsChange={setPlanningRows}
                    allAllocations={allAllocations}
                    timelineData={timelineData}
                    cellWidth={cellWidth}
                    deliveryDate={deliveryDate}
                    viewStartDate={viewStartDate}
                    onPrev={onPrev}
                    onNext={onNext}
                    onViewStartDateChange={onViewStartDateChange}
                    onBarClick={onBarClick}
                    onBarDragStart={onBarDragStart}
                    onBarHover={onBarHover}
                    onTimelineClick={onTimelineClick}
                    dailyShiftHours={Math.round(regularShiftHours * 10) / 10}
                />
            ) : (
                <div className="bg-white border border-slate-200 rounded-xl p-12 text-center">
                    <div className="w-16 h-16 bg-blue-50 text-blue-600 rounded-full flex items-center justify-center mx-auto mb-4">
                        <Search size={32} />
                    </div>
                    <h3 className="text-base font-bold text-slate-900 mb-2">Ready to Plan?</h3>
                    <p className="text-slate-500">Select a Style and Colorway to activate the board.</p>
                </div>
            )}
        </>
    );
};
