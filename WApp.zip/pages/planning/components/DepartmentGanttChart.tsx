import React, { useState, useMemo } from 'react';
import { ChevronDown, ChevronRight } from 'lucide-react';
import { LineAllocation } from '../../../types';

interface DepartmentGanttChartProps {
    flowSteps: any[];
    assignedResources: any[];
    allAllocations: LineAllocation[];
    selectedColorData: any;
    timelineData: any[];
    cellWidth: number;
    deliveryDate?: string;
    onBarClick: (allocation: LineAllocation) => void;
    onBarDragStart: (allocation: LineAllocation, edge: 'left' | 'right' | 'center') => void;
    onBarHover?: (allocation: LineAllocation | null, anchorRect?: DOMRect) => void;
    onTimelineClick?: (resourceId: string, date: string) => void;
}

export const DepartmentGanttChart: React.FC<DepartmentGanttChartProps> = ({
    flowSteps,
    assignedResources,
    allAllocations,
    selectedColorData,
    timelineData,
    cellWidth,
    deliveryDate,
    onBarClick,
    onBarDragStart,
    onBarHover,
    onTimelineClick
}) => {
    const [collapsedDepts, setCollapsedDepts] = useState<Set<string>>(new Set());
    const [hoveredBar, setHoveredBar] = useState<string | null>(null);

    // Calculate delivery date position as percentage
    const deliveryDatePosition = useMemo(() => {
        if (!deliveryDate || timelineData.length === 0) return null;
        const idx = timelineData.findIndex(d => d.iso === deliveryDate);
        if (idx === -1) return null;
        return (idx / timelineData.length) * 100;
    }, [deliveryDate, timelineData]);

    // Task 8.2: Calculate today's position as percentage
    const todayPosition = useMemo(() => {
        const today = new Date().toISOString().split('T')[0];
        const idx = timelineData.findIndex(d => d.iso === today);
        if (idx === -1) return null;
        return (idx / timelineData.length) * 100;
    }, [timelineData]);

    // Group resources by department based on flowSteps
    const departmentGroups = useMemo(() => {
        return flowSteps.map((step: any) => {
            const deptName = step.dept_name || step.deptName || step;
            const deptId = step.dept_id || step.deptId;
            
            // Filter resources for this department
            const deptResources = assignedResources.filter(r => 
                r.departmentId === deptId || r.departmentName === deptName
            );

            return {
                name: deptName,
                id: deptId,
                resources: deptResources,
                color: getDeptColor(deptName)
            };
        }).filter(g => g.resources.length > 0);
    }, [flowSteps, assignedResources]);

    const toggleDept = (deptName: string) => {
        setCollapsedDepts(prev => {
            const next = new Set(prev);
            if (next.has(deptName)) {
                next.delete(deptName);
            } else {
                next.add(deptName);
            }
            return next;
        });
    };

    // Calculate vertical stacking for overlapping bars
    const calculateBarRows = (bars: any[]): Map<string, number> => {
        const rowMap = new Map<string, number>();
        const sorted = [...bars].sort((a, b) => new Date(a.startDate).getTime() - new Date(b.startDate).getTime());
        const rows: { end: Date }[] = [];
        
        for (const bar of sorted) {
            const start = new Date(bar.startDate);
            const end = new Date(bar.endDate);
            
            // Find first row where this bar doesn't overlap
            let placed = false;
            for (let i = 0; i < rows.length; i++) {
                if (start > rows[i].end) {
                    rows[i].end = end;
                    rowMap.set(bar.id, i);
                    placed = true;
                    break;
                }
            }
            if (!placed) {
                rowMap.set(bar.id, rows.length);
                rows.push({ end });
            }
        }
        return rowMap;
    };

    // Get allocation bars for a resource - SHOW ALL ALLOCATIONS
    const getResourceBars = (resourceId: string) => {
        // Show ALL allocations for this resource, regardless of colorway
        return allAllocations.filter(a => a.lineId === resourceId);
    };

    // Calculate bar position and width as percentages, clamped to visible window
    const calculateBarStyle = (alloc: LineAllocation) => {
        if (timelineData.length === 0) return null;
        const firstDate = timelineData[0].iso;
        const lastDate = timelineData[timelineData.length - 1].iso;

        // If bar is entirely outside the window, hide it
        if (alloc.endDate < firstDate || alloc.startDate > lastDate) return null;

        // Clamp start and end to visible window
        const clampedStart = alloc.startDate < firstDate ? firstDate : alloc.startDate;
        const clampedEnd = alloc.endDate > lastDate ? lastDate : alloc.endDate;

        const startIdx = timelineData.findIndex(d => d.iso === clampedStart);
        const endIdx = timelineData.findIndex(d => d.iso === clampedEnd);
        if (startIdx === -1 || endIdx === -1) return null;

        const left = (startIdx / timelineData.length) * 100;
        const width = ((endIdx - startIdx + 1) / timelineData.length) * 100;
        const isClippedLeft = alloc.startDate < firstDate;
        const isClippedRight = alloc.endDate > lastDate;

        return { left, width, isClippedLeft, isClippedRight };
    };

    // Check if bar starts before previous dept ends
    const hasSequenceViolation = (alloc: LineAllocation, deptName: string) => {
        const deptIdx = flowSteps.findIndex((s: any) => 
            (s.dept_name || s.deptName || s) === deptName
        );
        if (deptIdx === 0) return false;

        const prevDeptStep = flowSteps[deptIdx - 1];
        const prevDeptName = prevDeptStep.dept_name || prevDeptStep.deptName || prevDeptStep;
        const prevDeptId = prevDeptStep.dept_id || prevDeptStep.deptId;

        // Get all allocations for previous department
        const prevDeptAllocs = allAllocations.filter(a => {
            if ((a.colorwayId || a.orderId) !== selectedColorData?.id) return false;
            if (a.departmentId) {
                if (prevDeptId && a.departmentId === prevDeptId) return true;
                const dept = assignedResources.find(r => r.id === a.lineId);
                return dept?.departmentName === prevDeptName;
            }
            const line = assignedResources.find(l => l.id === a.lineId);
            return line && (line.departmentId === prevDeptId || line.departmentName === prevDeptName);
        });

        if (prevDeptAllocs.length === 0) return false;

        // Find latest end date in previous dept
        const latestPrevEnd = prevDeptAllocs.reduce((max, a) => 
            a.endDate > max ? a.endDate : max, prevDeptAllocs[0].endDate
        );

        return alloc.startDate < latestPrevEnd;
    };

    return (
        <div className="flex-1 overflow-x-hidden relative">
            {/* Timeline Header */}
            <div className="flex border-b border-slate-200 bg-slate-50 h-10 sticky top-0 z-30 shadow-sm">
                <div className="w-[140px] flex-shrink-0 p-2 border-r border-slate-200 font-bold text-slate-500 text-[10px] uppercase tracking-wider flex items-center pl-4 bg-slate-50">
                    Resource
                </div>
                <div className="flex-1 flex relative">
                    {timelineData.map((d, i) => (
                        <div 
                            key={i} 
                            className={`border-r border-slate-100 flex flex-col items-center justify-center flex-1 min-w-0 ${d.isWeekend ? 'bg-red-50/50' : ''} ${d.iso === deliveryDate ? 'bg-red-100' : ''}`}
                        >
                            <span className={`text-[9px] font-bold ${d.isWeekend || d.iso === deliveryDate ? 'text-red-600' : 'text-slate-600'}`}>
                                {d.weekday[0]}
                            </span>
                            <span className={`text-[10px] ${d.isWeekend || d.iso === deliveryDate ? 'text-red-800' : 'text-slate-400'}`}>
                                {d.day}
                            </span>
                        </div>
                    ))}
                    
                    {/* Delivery Date Indicator */}
                    {deliveryDatePosition !== null && (
                        <div 
                            className="absolute top-0 bottom-0 w-0.5 bg-red-500 z-50 pointer-events-none"
                            style={{ left: `calc(${deliveryDatePosition}% + ${100 / timelineData.length / 2}%)` }}
                        >
                            <div className="absolute -top-1 left-1/2 -translate-x-1/2 bg-red-500 text-white text-[8px] px-1 py-0.5 rounded whitespace-nowrap font-bold">
                                DELIVERY
                            </div>
                        </div>
                    )}

                    {/* Task 8.2: Today Indicator in Header */}
                    {todayPosition !== null && (
                        <div 
                            className="absolute top-0 bottom-0 w-0.5 bg-blue-500 z-40 pointer-events-none"
                            style={{ left: `calc(${todayPosition}% + ${100 / timelineData.length / 2}%)` }}
                        >
                            <div className="absolute -top-1 left-1/2 -translate-x-1/2 bg-blue-500 text-white text-[8px] px-1 py-0.5 rounded whitespace-nowrap font-bold">
                                TODAY
                            </div>
                        </div>
                    )}
                </div>
            </div>

            {/* Department Groups */}
            {departmentGroups.map((dept, deptIdx) => {
                const isCollapsed = collapsedDepts.has(dept.name);

                return (
                    <div key={dept.id || dept.name}>
                        {/* Department Header */}
                        <div 
                            className="flex items-center bg-slate-100 border-b border-slate-200 cursor-pointer hover:bg-slate-150"
                            onClick={() => toggleDept(dept.name)}
                        >
                            <div className="w-[140px] flex-shrink-0 px-3 py-2 flex items-center gap-2 border-r border-slate-200 bg-slate-100">
                                {isCollapsed ? <ChevronRight size={14} /> : <ChevronDown size={14} />}
                                <span className="font-bold text-xs text-slate-700">{dept.name}</span>
                                <span className="ml-auto px-1.5 py-0.5 bg-slate-200 text-slate-600 text-[10px] rounded-full font-bold">
                                    {dept.resources.length}
                                </span>
                            </div>
                            <div className="flex-1" />
                        </div>

                        {/* Resource Rows */}
                        {!isCollapsed && dept.resources.map((resource, resIdx) => {
                            const bars = getResourceBars(resource.id);
                            const barRows = calculateBarRows(bars);
                            const maxRows = Math.max(1, ...Array.from(barRows.values()).map(v => v + 1));

                            return (
                                <div 
                                    key={resource.id}
                                    className="flex border-b border-slate-100 hover:bg-slate-50/50 relative"
                                    style={{ minHeight: `${Math.max(40, maxRows * 36 + 8)}px` }}
                                >
                                    {/* Resource Name Column */}
                                    <div className="w-[140px] flex-shrink-0 px-3 py-2 border-r border-slate-200 flex items-center bg-white">
                                        <span className="text-xs text-slate-700 truncate">{resource.resourceName}</span>
                                    </div>

                                    {/* Timeline Grid */}
                                    <div className="flex-1 relative min-w-0">
                                        {/* Grid cells - clickable for creating new allocations */}
                                        <div className="absolute inset-0 flex">
                                            {timelineData.map((d, i) => (
                                                <div 
                                                    key={i}
                                                    className={`border-r border-slate-100 hover:bg-blue-50/50 cursor-pointer transition-colors flex-1 min-w-0 ${d.isWeekend ? 'bg-red-50/30' : ''}`}
                                                    onClick={() => onTimelineClick?.(resource.id, d.iso)}
                                                    title={`Click to plan on ${d.display}`}
                                                />
                                            ))}
                                        </div>

                                        {/* Delivery Date Line */}
                                        {deliveryDatePosition !== null && (
                                            <div 
                                                className="absolute top-0 bottom-0 w-0.5 bg-red-500/30 z-10 pointer-events-none"
                                                style={{ left: `calc(${deliveryDatePosition}% + ${100 / timelineData.length / 2}%)` }}
                                            />
                                        )}

                                        {/* Task 8.2: Today Line in Resource Rows */}
                                        {todayPosition !== null && (
                                            <div 
                                                className="absolute top-0 bottom-0 w-0.5 bg-blue-500/30 z-10 pointer-events-none"
                                                style={{ left: `calc(${todayPosition}% + ${100 / timelineData.length / 2}%)` }}
                                            />
                                        )}

                                        {/* Allocation Bars */}
                                        {bars.map(bar => {
                                            const barStyle = calculateBarStyle(bar);
                                            if (!barStyle) return null;

                                            const hasViolation = hasSequenceViolation(bar, dept.name);
                                            const isHovered = hoveredBar === bar.id;
                                            const isPending = bar.id?.startsWith('temp-');
                                            
                                            // Check if this bar is for the selected colorway
                                            const isSelectedColorway = selectedColorData && (
                                                bar.orderId === selectedColorData.id || 
                                                bar.colorway === selectedColorData.name
                                            );

                                            // Color logic: pending=yellow, saved+selected=green, other styles=grey
                                            const isSaved = !isPending && isSelectedColorway;

                                            return (
                                                <div
                                                    key={bar.id || `pending-${bar.lineId}-${bar.startDate}`}
                                                    className={`absolute h-[32px] pointer-events-auto ${
                                                        barStyle.isClippedLeft ? 'rounded-r' : barStyle.isClippedRight ? 'rounded-l' : 'rounded'
                                                    } ${
                                                        isPending 
                                                            ? 'bg-amber-100 border-2 border-amber-400' 
                                                            : isSaved
                                                                ? 'bg-emerald-100 border-2 border-emerald-500'
                                                                : 'bg-slate-200 border border-slate-300'
                                                    } ${isHovered ? 'ring-2 ring-blue-400 shadow-lg z-30' : 'z-20'} ${hasViolation ? 'ring-1 ring-red-500' : ''}`}
                                                    style={{
                                                        left: `${barStyle.left}%`,
                                                        width: `${barStyle.width}%`,
                                                        top: `${4 + (barRows.get(bar.id) || 0) * 36}px`
                                                    }}
                                                    onMouseEnter={(e) => {
                                                        setHoveredBar(bar.id || null);
                                                        onBarHover?.(bar, e.currentTarget.getBoundingClientRect());
                                                    }}
                                                    onMouseLeave={() => {
                                                        setHoveredBar(null);
                                                        onBarHover?.(null);
                                                    }}
                                                >
                                                    {/* Task 8.5: Progress indicator for completed bars */}
                                                    {bar.completed_is_true && (
                                                        <div className="absolute inset-0 bg-black/15 rounded pointer-events-none" />
                                                    )}

                                                    {/* Violation Indicator */}
                                                    {hasViolation && (
                                                        <div className="absolute -left-1 top-0 bottom-0 w-1 bg-red-500 rounded-l" />
                                                    )}

                                                    {/* Task 8.3: Left drag handle */}
                                                    <div 
                                                        className="absolute left-0 top-0 bottom-0 w-2 cursor-col-resize z-10 hover:bg-black/10 rounded-l"
                                                        onMouseDown={(e) => { e.stopPropagation(); onBarDragStart(bar, 'left'); }}
                                                    />
                                                    {/* Task 8.3: Right drag handle */}
                                                    <div 
                                                        className="absolute right-0 top-0 bottom-0 w-2 cursor-col-resize z-10 hover:bg-black/10 rounded-r"
                                                        onMouseDown={(e) => { e.stopPropagation(); onBarDragStart(bar, 'right'); }}
                                                    />

                                                    {/* Bar Content */}
                                                    <div className="px-2 py-1 flex items-center justify-between h-full text-[10px] font-medium overflow-hidden">
                                                        <span className={`truncate font-semibold ${
                                                            isPending ? 'text-amber-700' : isSaved ? 'text-emerald-700' : 'text-slate-500'
                                                        }`}>
                                                            {bar.colorway || bar.styleName}
                                                        </span>
                                                        {/* Daily target inside bar when wide enough */}
                                                        {barStyle.width > 5 && bar.dailyTarget > 0 && (
                                                            <span className="text-[9px] opacity-70">{bar.dailyTarget}/d</span>
                                                        )}
                                                        <span className={`ml-1 font-bold ${
                                                            isPending ? 'text-amber-700' : isSaved ? 'text-emerald-700' : 'text-slate-500'
                                                        }`}>
                                                            {bar.qty}
                                                        </span>
                                                    </div>
                                                </div>
                                            );
                                        })}
                                    </div>
                                </div>
                            );
                        })}
                    </div>
                );
            })}
            {/* Bottom padding for breathing room */}
            <div className="h-8" />
        </div>
    );
};

// Helper function to get department color
function getDeptColor(deptName: string): string {
    const colors: Record<string, string> = {
        'Cutting': '#3b82f6',      // blue
        'Sewing': '#8b5cf6',        // purple
        'Embroidery': '#f59e0b',    // amber
        'Print': '#f59e0b',         // amber
        'Finishing': '#10b981',     // emerald
        'Packing': '#6366f1'        // indigo
    };

    for (const [key, color] of Object.entries(colors)) {
        if (deptName.toLowerCase().includes(key.toLowerCase())) {
            return color;
        }
    }

    return '#64748b'; // slate as default
}