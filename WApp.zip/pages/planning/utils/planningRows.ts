import type { AssignedResource, LineAllocation } from '../../../types';
import { allocationsForColorway } from '../../../lib/allocationUtils';
import type { PlanningRow } from '../types';
import { calculateDailyAverage, calculateWorkingDays } from './planningCalculations';

export function allocationsToPlanningRows(
  colorwayId: string,
  allocations: LineAllocation[],
  assignedResources: AssignedResource[],
): PlanningRow[] {
  return allocationsForColorway(allocations, colorwayId)
    .filter((a) => !a.id?.startsWith('temp-'))
    .map((a) => {
      const resource = assignedResources.find((r) => r.id === a.lineId);
      const workingDays =
        a.startDate && a.endDate
          ? Math.max(1, calculateWorkingDays(a.startDate, a.endDate))
          : 1;
      const qty = a.qty || 0;
      const autoDaily =
        qty > 0 && a.startDate && a.endDate ? calculateDailyAverage(qty, workingDays) : 0;
      const storedDaily = a.dailyTarget || 0;
      return {
        id: a.id,
        department: resource?.departmentName || '',
        resourceId: a.lineId,
        resourceName: resource?.resourceName || '',
        plannedQty: qty,
        startDate: a.startDate || '',
        endDate: a.endDate || '',
        dailyTarget: storedDaily > 0 ? storedDaily : autoDaily,
        dailyTargetOverridden:
          storedDaily > 0 && autoDaily > 0 && storedDaily !== autoDaily,
        workforce: a.kpiInputs?.workforce,
        sam: a.sam ?? a.kpiInputs?.sam,
      };
    });
}
