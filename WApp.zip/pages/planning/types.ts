/** One resource allocation row in the production planning table. */
export interface PlanningRow {
  id: string;
  department: string;
  resourceId: string;
  resourceName: string;
  plannedQty: number;
  startDate: string;
  endDate: string;
  dailyTarget: number;
  /** When true, daily target was manually set and is not auto-recalculated from qty/dates. */
  dailyTargetOverridden?: boolean;
  workforce?: number;
  sam?: number;
}
