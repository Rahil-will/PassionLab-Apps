import React, { useState, useMemo, useEffect } from 'react';
import { useDataStore, useNavigationStore, useSettingsStore, useNotificationStore } from '../../stores';
import { RoutePath } from '../../types';
import { LineAllocation } from '../../types';
import { Button, Modal, Card } from '../../components/ui';
import type { PlanningRow } from './types';
import { X, AlertTriangle } from 'lucide-react';
import { PlanningToolbar } from '../../components/planning/PlanningToolbar';
import { PageShell } from '../../components/layout/PageShell';

// Import refactored components
import { OrderInfoCard } from './components/OrderInfoCard';
import { ResourceAllocationSection } from './components/ResourceAllocationSection';
import { GanttAllocTooltip, type GanttAlloc } from '../../components/production/GanttResourceRows';
import { SummaryModal } from './components/SummaryModal';
import { usePlanningState } from './hooks';
import * as calc from './utils';
import { getRegularShiftHours, getRegularShiftMinutes } from '../../lib/shiftHours';
import { buildColorwayPlanPayloads } from '../../lib/buildLinePlanPayload';
import { saveLinePlanAtomic } from '../../lib/saveLinePlan';

const cellWidth = 40;

function lineAllocationToGanttAlloc(alloc: LineAllocation): GanttAlloc {
    return {
        id: alloc.id,
        startDate: alloc.startDate,
        endDate: alloc.endDate,
        qty: alloc.qty,
        actualQty: alloc.actualQty,
        actualEndDate: alloc.actualEndDate,
        colorway: alloc.colorway,
        styleName: alloc.styleName,
        poNumber: alloc.poNumber,
        dailyTarget: alloc.dailyTarget,
        status: alloc.status,
    };
}

export const ProductionPlanning: React.FC = () => {
    const { orders, assignedResources, allocations, loading: dataLoading, fetchData } = useDataStore();
    const { processFlows, departments, shifts } = useSettingsStore();
    const { navigate, routeParams, goBack, setUnsaved, setPendingSaveAction, factoryId } = useNavigationStore();
    const { showNotification } = useNotificationStore();

    // Use refactored state hook
    const state = usePlanningState();

    const regularShiftHours = useMemo(() => getRegularShiftHours(shifts), [shifts]);
    const regularShiftMinsPerDay = useMemo(() => getRegularShiftMinutes(shifts), [shifts]);

    // Planning rows state - lifted from ResourceAllocationSection
    // planningRows holds the CURRENT color's rows for the table
    const [planningRows, setPlanningRows] = useState<PlanningRow[]>([]);
    const [planningBuffer, setPlanningBuffer] = useState<Record<string, PlanningRow[]>>({});
    const [isSummaryModalOpen, setIsSummaryModalOpen] = useState<boolean>(false);
    const [isOrderCardCollapsed, setIsOrderCardCollapsed] = useState<boolean>(false);
    const [pendingColorSwitch, setPendingColorSwitch] = useState<string | null>(null);
    const [showColorUnsavedModal, setShowColorUnsavedModal] = useState(false);
    const [showDiscardPlanModal, setShowDiscardPlanModal] = useState(false);
    const [saving, setSaving] = useState(false);

    // Track which colorway IDs have been modified (dirty)
    const [dirtyColorIds, setDirtyColorIds] = useState<Set<string>>(new Set());

    // Refs for stable handler references (avoids stale closures in breadcrumb buttons)
    const planningRowsRef = React.useRef(planningRows);
    planningRowsRef.current = planningRows;
    const planningBufferRef = React.useRef(planningBuffer);
    planningBufferRef.current = planningBuffer;
    const dirtyColorIdsRef = React.useRef(dirtyColorIds);
    dirtyColorIdsRef.current = dirtyColorIds;

    // Track changes — now includes buffered changes across colors
    const hasChanges = useMemo(() => {
        return dirtyColorIds.size > 0 || state.pendingAllocations.length > 0 || state.deletedAllocationIds.length > 0;
    }, [dirtyColorIds, state.pendingAllocations, state.deletedAllocationIds]);

    useEffect(() => {
        setUnsaved(hasChanges);
    }, [hasChanges, setUnsaved]);

    const handleSavePlanRef = React.useRef<() => Promise<boolean>>(async () => false);

    // Handle route params
    useEffect(() => {
        if (routeParams?.orderId && routeParams?.color) {
            state.setSelectedOrderId(routeParams.orderId);
            state.setSelectedColor(routeParams.color);
        }
        if (routeParams?.orderId && routeParams?.colorId) {
            const order = orders.find(o => o.id === routeParams.orderId);
            const colorway = order?.colorways.find(c => c.id === routeParams.colorId);
            if (order && colorway) {
                state.setSelectedOrderId(order.id);
                state.setSelectedColor(colorway.name);
                if (routeParams?.openPrint === 'true') {
                    setTimeout(() => setIsSummaryModalOpen(true), 300);
                }
            }
        }
    }, [routeParams, orders]);

    // Selected order and color data
    const selectedOrder = useMemo(() => {
        return orders.find(o => o.id === state.selectedOrderId) || null;
    }, [orders, state.selectedOrderId]);

    const selectedColorData = useMemo(() => {
        if (!selectedOrder) return null;
        return selectedOrder.colorways.find(c => c.name === state.selectedColor) || null;
    }, [selectedOrder, state.selectedColor]);

    // All allocations (pending + saved)
    const allAllocations = useMemo(() => {
        const saved = allocations.filter(a => !state.deletedAllocationIds.includes(a.id));
        return [...saved, ...state.pendingAllocations];
    }, [allocations, state.pendingAllocations, state.deletedAllocationIds]);

    // Planning totals
    const planningTotals = useMemo(() => {
        if (!selectedColorData) return { targetTotal: 0, plannedTotal: 0, remainingTotal: 0 };
        const targetTotal = calc.calculateTargetQty(selectedColorData.sizes);
        const plannedTotal = calc.calculatePlannedQty(allAllocations, selectedColorData.id);
        return { targetTotal, plannedTotal, remainingTotal: targetTotal - plannedTotal };
    }, [selectedColorData, allAllocations]);

    // Process flow steps
    const flowSteps = useMemo(() => {
        if (!selectedOrder?.processFlow) return [];
        const flow = processFlows.find(f => f.id === selectedOrder.processFlow);
        return flow?.steps || [];
    }, [selectedOrder, processFlows]);

    // Timeline data - 30 days fits without scrolling
    const TIMELINE_DAYS = 30;
    const timelineData = useMemo(() => {
        return calc.generateTimelineData(state.viewStartDate, TIMELINE_DAYS);
    }, [state.viewStartDate]);

    // Track the previous colorway ID to buffer rows on switch
    const prevColorIdRef = React.useRef<string | null>(null);

    // When color changes: buffer current rows, then load new color's rows
    useEffect(() => {
        const newColorId = selectedColorData?.id || null;
        const prevColorId = prevColorIdRef.current;

        // Buffer the outgoing color's planning rows (if any were modified)
        if (prevColorId && prevColorId !== newColorId && planningRows.length > 0) {
            setPlanningBuffer(prev => ({ ...prev, [prevColorId]: planningRows }));
        }

        // Load the incoming color's rows
        if (!newColorId) {
            setPlanningRows([]);
            prevColorIdRef.current = null;
            return;
        }

        // Check buffer first (user may have unsaved edits for this color)
        if (planningBuffer[newColorId]) {
            setPlanningRows(planningBuffer[newColorId]);
        } else {
            setPlanningRows(
                calc.allocationsToPlanningRows(newColorId, allAllocations, assignedResources),
            );
        }

        prevColorIdRef.current = newColorId;
    }, [selectedColorData?.id]);

    // Wrap setPlanningRows to also mark the current color as dirty
    const handleSetPlanningRows = React.useCallback((updater: any) => {
        setPlanningRows(updater);
        if (selectedColorData?.id) {
            setDirtyColorIds(prev => {
                const next = new Set(prev);
                next.add(selectedColorData.id);
                return next;
            });
        }
    }, [selectedColorData?.id]);

    // Auto-set viewStartDate so delivery date is the last column when order changes
    useEffect(() => {
        if (selectedOrder?.deliveryDate) {
            const delivery = new Date(selectedOrder.deliveryDate);
            delivery.setDate(delivery.getDate() - (TIMELINE_DAYS - 1));
            const newStart = delivery.toISOString().split('T')[0];
            if (newStart !== state.viewStartDate) {
                state.setViewStartDate(newStart);
            }
        }
    }, [selectedOrder?.id, selectedOrder?.deliveryDate]);

    // Handlers - move by 7 days
    const handlePrev = () => {
        const d = new Date(state.viewStartDate);
        d.setDate(d.getDate() - 7);
        state.setViewStartDate(d.toISOString().split('T')[0]);
    };

    const handleNext = () => {
        const d = new Date(state.viewStartDate);
        d.setDate(d.getDate() + 7);
        state.setViewStartDate(d.toISOString().split('T')[0]);
    };

    const handleSavePlan = async (): Promise<boolean> => {
        const liveOrders = useDataStore.getState().orders;
        const liveResources = useDataStore.getState().assignedResources;
        const liveAllocations = useDataStore.getState().allocations;
        const order = liveOrders.find((o) => o.id === state.selectedOrderId);
        const colorData = order?.colorways.find((c) => c.name === state.selectedColor);

        if (!order || !colorData) {
            showNotification('Select an order and color first', 'error');
            return false;
        }
        if (!hasChanges) {
            showNotification('No planning changes to save.', 'error');
            return false;
        }
        if (saving) return false;
        setSaving(true);
        try {
            const currentPlanningRows = planningRowsRef.current;
            const pendingDeletes = state.deletedAllocationIds;
            const pendingAllocs = state.pendingAllocations;
            const mergedAllocations = [
                ...liveAllocations.filter((a) => !pendingDeletes.includes(a.id)),
                ...pendingAllocs,
            ];

            const workingBuffer = {
                ...planningBufferRef.current,
                [colorData.id]: currentPlanningRows,
            };
            const workingDirty = new Set(dirtyColorIdsRef.current);

            if (pendingDeletes.length > 0 || pendingAllocs.length > 0) {
                const affectedColorIds = new Set<string>();
                for (const id of pendingDeletes) {
                    const alloc = liveAllocations.find((a) => a.id === id);
                    if (alloc?.colorwayId) affectedColorIds.add(alloc.colorwayId);
                }
                for (const alloc of pendingAllocs) {
                    if (alloc.colorwayId) affectedColorIds.add(alloc.colorwayId);
                }
                for (const colorId of affectedColorIds) {
                    workingBuffer[colorId] = calc.allocationsToPlanningRows(
                        colorId,
                        mergedAllocations,
                        liveResources,
                    );
                    workingDirty.add(colorId);
                }
            }

            const allColorRows: { colorId: string; colorName: string; rows: PlanningRow[] }[] = [];

            for (const [colorId, rows] of Object.entries(workingBuffer)) {
                if (!workingDirty.has(colorId)) continue;
                const colorway = order.colorways.find((c) => c.id === colorId);
                if (!colorway) continue;

                allColorRows.push({ colorId, colorName: colorway.name, rows });
            }

            if (allColorRows.length === 0) {
                showNotification('No colorways with planning data to save.', 'error');
                return false;
            }

            let totalSaved = 0;
            let colorsSaved = 0;

            const built = buildColorwayPlanPayloads(
                order,
                allColorRows,
                liveResources,
                regularShiftHours,
                regularShiftMinsPerDay,
            );
            totalSaved = built.totalSaved;
            colorsSaved = built.colorsSaved;

            if (!factoryId) {
                showNotification('No factory selected', 'error');
                return false;
            }

            await saveLinePlanAtomic(factoryId, order.id, built.colorwayPlans);
            await fetchData({ silent: true });

            setPlanningBuffer({});
            setDirtyColorIds(new Set());
            state.setPendingAllocations([]);
            state.setDeletedAllocationIds([]);
            setUnsaved(false);

            const freshState = useDataStore.getState();
            setPlanningRows(
                calc.allocationsToPlanningRows(
                    colorData.id,
                    freshState.allocations,
                    freshState.assignedResources,
                ),
            );

            if (totalSaved > 0) {
                showNotification(
                    `Plan saved: ${totalSaved} allocation(s) across ${colorsSaved} colorway(s)`,
                    'success',
                );
            } else if (colorsSaved > 0) {
                showNotification('Cleared planning for modified colorway(s).', 'success');
            } else {
                showNotification('No valid planning rows to save. Fill in resource, dates, and quantity.', 'error');
                return false;
            }
            return true;
        } catch (error) {
            console.error('Save plan error:', error);
            showNotification('Failed to save plan: ' + (error instanceof Error ? error.message : 'Unknown error'), 'error');
            return false;
        } finally {
            setSaving(false);
        }
    };

    handleSavePlanRef.current = handleSavePlan;

    useEffect(() => {
        setPendingSaveAction(async () => {
            await handleSavePlanRef.current();
        });
        return () => {
            setPendingSaveAction(null);
            setUnsaved(false);
        };
    }, [setPendingSaveAction, setUnsaved]);

    const applyColorSwitch = (colorName: string) => {
        state.setSelectedColor(colorName);
        setPendingColorSwitch(null);
        setShowColorUnsavedModal(false);
    };

    const discardColorSwitch = () => {
        const currentId = selectedColorData?.id;
        if (currentId) {
            setPlanningBuffer((prev) => {
                const next = { ...prev };
                delete next[currentId];
                return next;
            });
            setDirtyColorIds((prev) => {
                const next = new Set(prev);
                next.delete(currentId);
                return next;
            });
        }
        state.setPendingAllocations([]);
        state.setDeletedAllocationIds([]);
        if (pendingColorSwitch) applyColorSwitch(pendingColorSwitch);
    };

    const executeDiscardPlan = () => {
        setPlanningBuffer({});
        setDirtyColorIds(new Set());
        state.setPendingAllocations([]);
        state.setDeletedAllocationIds([]);
        setUnsaved(false);
        goBack();
    };

    const requestDiscardPlan = () => {
        if (hasChanges) {
            setShowDiscardPlanModal(true);
            return;
        }
        executeDiscardPlan();
    };

    const cancelDiscardPlan = () => {
        setShowDiscardPlanModal(false);
    };

    const confirmDiscardPlan = () => {
        setShowDiscardPlanModal(false);
        executeDiscardPlan();
    };

    const confirmSaveAndDiscardPlan = async () => {
        const saved = await handleSavePlanRef.current();
        if (saved) {
            setShowDiscardPlanModal(false);
            executeDiscardPlan();
        }
    };

    const handlePrintReport = () => {
        setIsSummaryModalOpen(true);
    };

    const colorwayPlansForSummary = useMemo(() => {
        if (!selectedOrder) return [];
        const buffer = { ...planningBuffer, ...(selectedColorData ? { [selectedColorData.id]: planningRows } : {}) };
        return selectedOrder.colorways.map((cw) => ({
            colorId: cw.id,
            colorName: cw.name,
            colorData: cw,
            rows: buffer[cw.id] ?? calc.allocationsToPlanningRows(cw.id, allAllocations, assignedResources),
        }));
    }, [selectedOrder, selectedColorData, planningBuffer, planningRows, allAllocations, assignedResources]);

    const handleEditBooking = () => {
        if (!state.editingAlloc) return;
        
        const alloc: LineAllocation = {
            id: state.editingAlloc.id || `temp-${Date.now()}`,
            orderId: selectedOrder!.id,
            colorwayId: selectedColorData!.id,
            lineId: state.editingAlloc.lineId,
            departmentId: '',
            startDate: state.editingAlloc.startDate,
            endDate: state.editingAlloc.endDate,
            qty: state.editingAlloc.qty,
            styleName: selectedOrder!.styleName,
            colorway: state.selectedColor,
            poNumber: selectedOrder!.poNumber
        } as any;

        const existing = state.pendingAllocations.findIndex(a => a.id === alloc.id);
        if (existing >= 0) {
            const updated = [...state.pendingAllocations];
            updated[existing] = alloc;
            state.setPendingAllocations(updated);
        } else {
            state.setPendingAllocations([...state.pendingAllocations, alloc]);
        }
        
        state.setEditingAlloc(null);
        showNotification('Allocation updated', 'success');
    };

    const handleRemoveAllocation = () => {
        if (!state.editingAlloc?.id) return;
        
        if (state.editingAlloc.id.startsWith('temp-')) {
            state.setPendingAllocations(state.pendingAllocations.filter(a => a.id !== state.editingAlloc!.id));
        } else {
            state.setDeletedAllocationIds([...state.deletedAllocationIds, state.editingAlloc.id]);
        }
        
        state.setEditingAlloc(null);
        showNotification('Allocation removed', 'success');
    };

    const handleDiscardChanges = () => {
        state.setEditingAlloc(null);
    };

    if (!selectedOrder || !selectedColorData) {
        return (
            <PageShell loading={dataLoading && orders.length === 0} skeleton="spinner" className="w-full pb-20">
                <Card className="max-w-lg mx-auto mt-12 text-center p-8">
                    <h2 className="text-sm font-bold text-slate-800 mb-2">No order selected</h2>
                    <p className="text-xs text-slate-500 mb-6">
                        Open Production Planning from the Planning Board and pick an order colorway.
                    </p>
                    <Button variant="primary" onClick={() => navigate(RoutePath.LINE_ASSIGNMENT)}>
                        Go to Planning Board
                    </Button>
                </Card>
            </PageShell>
        );
    }

    return (
        <PageShell loading={dataLoading && orders.length === 0} skeleton="spinner" className="w-full pb-20">
            {/* Order Info Card with Collapse */}
            {selectedOrder && selectedColorData && (
                <div className="mb-4">
                    {/* Collapse toggle in meta row */}
                    <OrderInfoCard
                        selectedOrder={selectedOrder}
                        selectedColorData={selectedColorData}
                        flowSteps={flowSteps}
                        allAllocations={allAllocations}
                        planningTotals={planningTotals}
                        departments={departments}
                        assignedResources={assignedResources}
                        processFlows={processFlows}
                        selectedColor={state.selectedColor}
                        onColorSelect={(colorName) => {
                            if (colorName === state.selectedColor) return;
                            if (hasChanges) {
                                setPendingColorSwitch(colorName);
                                setShowColorUnsavedModal(true);
                                return;
                            }
                            state.setSelectedColor(colorName);
                        }}
                        isCollapsed={isOrderCardCollapsed}
                        onToggleCollapse={() => setIsOrderCardCollapsed(!isOrderCardCollapsed)}
                        onStyleClick={() => navigate(RoutePath.STYLE_DETAILS, { id: selectedOrder.id })}
                        toolbar={
                            <PlanningToolbar
                                hasChanges={hasChanges}
                                saving={saving}
                                saveDisabled={!hasChanges}
                                onSave={() => void handleSavePlanRef.current()}
                                onDiscard={requestDiscardPlan}
                                onSummary={handlePrintReport}
                            />
                        }
                    />
                </div>
            )}

            {/* Resource Allocation Section */}
            <ResourceAllocationSection
                isFullScreen={state.isFullScreen}
                viewStartDate={state.viewStartDate}
                selectedOrderId={state.selectedOrderId}
                selectedColor={state.selectedColor}
                flowSteps={flowSteps}
                assignedResources={assignedResources}
                allAllocations={allAllocations}
                selectedColorData={selectedColorData}
                timelineData={timelineData}
                cellWidth={cellWidth}
                deliveryDate={selectedOrder?.deliveryDate}
                editingAlloc={state.editingAlloc}
                planningTotals={planningTotals}
                selectedOrder={selectedOrder}
                regularShiftHours={regularShiftHours}
                onToggleFullScreen={() => state.setIsFullScreen(!state.isFullScreen)}
                onViewStartDateChange={(date) => state.setViewStartDate(date)}
                onPrev={handlePrev}
                onNext={handleNext}
                onBarClick={(alloc) => {
                    const resource = assignedResources.find(r => r.id === alloc.lineId);
                    state.setEditingAlloc({
                        id: alloc.id,
                        processName: resource?.departmentName || '',
                        lineId: alloc.lineId,
                        startDate: alloc.startDate,
                        endDate: alloc.endDate,
                        qty: alloc.qty,
                        dailyTarget: alloc.dailyTarget,
                        learningCurve: alloc.learningCurveId,
                        completed_is_true: alloc.completed_is_true
                    });
                }}
                onBarDragStart={(alloc, edge) => {
                }}
                onBarHover={(alloc, anchorRect) => {
                    if (alloc && anchorRect) {
                        state.setHoveredAlloc({ alloc, anchorRect });
                    } else {
                        state.setHoveredAlloc(null);
                    }
                }}
                onTimelineClick={(resourceId, date) => {
                    if (!selectedColorData || planningTotals.remainingTotal <= 0) return;
                    const resource = assignedResources.find(r => r.id === resourceId);
                    if (!resource) return;
                    
                    // Create new allocation starting on clicked date
                    state.setEditingAlloc({
                        id: `temp-${Date.now()}`,
                        processName: resource.departmentName || '',
                        lineId: resourceId,
                        startDate: date,
                        endDate: date,
                        qty: Math.min(100, planningTotals.remainingTotal),
                        dailyTarget: 0,
                        learningCurve: null,
                        completed_is_true: false
                    });
                }}
                onEditingAllocChange={(alloc) => state.setEditingAlloc(alloc)}
                onSave={handleEditBooking}
                onRemove={handleRemoveAllocation}
                onCancel={handleDiscardChanges}
                planningRows={planningRows}
                setPlanningRows={handleSetPlanningRows}
            />

            {/* Allocation Tooltip - Using Refactored Component */}
            {state.hoveredAlloc && (
                <GanttAllocTooltip
                    alloc={lineAllocationToGanttAlloc(state.hoveredAlloc.alloc)}
                    anchorRect={state.hoveredAlloc.anchorRect}
                    mode="planned"
                />
            )}

            {/* Summary Modal */}
            <SummaryModal
                isOpen={isSummaryModalOpen}
                onClose={() => setIsSummaryModalOpen(false)}
                flowSteps={flowSteps}
                selectedOrder={selectedOrder}
                colorwayPlans={colorwayPlansForSummary}
                assignedResources={assignedResources}
                regularShiftHours={regularShiftHours}
                orderId={selectedOrder?.id}
            />

            <Modal isOpen={showColorUnsavedModal} onClose={() => { setShowColorUnsavedModal(false); setPendingColorSwitch(null); }}>
                <div className="relative">
                    <button
                        onClick={() => { setShowColorUnsavedModal(false); setPendingColorSwitch(null); }}
                        className="absolute top-4 right-4 text-red-400 hover:text-red-600 transition-colors p-1 hover:bg-red-50 rounded-full"
                    >
                        <X size={20} />
                    </button>
                    <div className="flex flex-col items-center p-8 pb-4 text-center">
                        <div className="w-16 h-16 bg-amber-100 text-amber-600 rounded-2xl flex items-center justify-center mb-4 shadow-sm ring-4 ring-amber-50">
                            <AlertTriangle size={32} />
                        </div>
                        <h3 className="text-xs font-bold text-slate-900 mb-2">Unsaved Changes</h3>
                        <p className="text-slate-500 text-[10px] max-w-[260px] leading-relaxed">
                            You have unsaved planning changes. Save or discard before switching colorway.
                        </p>
                    </div>
                    <div className="p-6 pt-2 flex flex-col gap-3">
                        <Button
                            onClick={async () => {
                                const saved = await handleSavePlanRef.current();
                                if (saved && pendingColorSwitch) applyColorSwitch(pendingColorSwitch);
                            }}
                            disabled={saving}
                            className="w-full shadow-lg shadow-blue-100 py-2.5 text-sm"
                        >
                            {saving ? 'Saving…' : 'Save Changes'}
                        </Button>
                        <Button variant="danger-light" onClick={discardColorSwitch} className="w-full text-xs">
                            Discard &amp; Switch
                        </Button>
                    </div>
                </div>
            </Modal>

            <Modal isOpen={showDiscardPlanModal} onClose={cancelDiscardPlan}>
                <div className="relative">
                    <button
                        onClick={cancelDiscardPlan}
                        className="absolute top-4 right-4 text-red-400 hover:text-red-600 transition-colors p-1 hover:bg-red-50 rounded-full"
                    >
                        <X size={20} />
                    </button>
                    <div className="flex flex-col items-center p-8 pb-4 text-center">
                        <div className="w-16 h-16 bg-amber-100 text-amber-600 rounded-2xl flex items-center justify-center mb-4 shadow-sm ring-4 ring-amber-50">
                            <AlertTriangle size={32} />
                        </div>
                        <h3 className="text-xs font-bold text-slate-900 mb-2">Unsaved Changes</h3>
                        <p className="text-slate-500 text-[10px] max-w-[260px] leading-relaxed">
                            You have unsaved planning changes. Save or discard before leaving this page.
                        </p>
                    </div>
                    <div className="p-6 pt-2 flex flex-col gap-3">
                        <Button
                            onClick={confirmSaveAndDiscardPlan}
                            disabled={saving}
                            className="w-full shadow-lg shadow-blue-100 py-2.5 text-sm"
                        >
                            {saving ? 'Saving…' : 'Save Changes'}
                        </Button>
                        <Button variant="danger-light" onClick={confirmDiscardPlan} className="w-full text-xs">
                            Discard &amp; Leave
                        </Button>
                    </div>
                </div>
            </Modal>
        </PageShell>
    );
};
