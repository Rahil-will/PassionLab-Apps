import React, { useState, useMemo } from "react";
import {
  useDataStore,
  useNavigationStore,
  useSettingsStore,
} from "../../stores";
import { RoutePath } from "../../types";
import { Search, ChevronRight, Filter } from "lucide-react";
import { Card, SelectDropdown } from '../../components/ui';
import { PageShell } from '../../components/layout/PageShell';
import { sizeAdjQty } from '../../lib/colorwaySizesUtils';
import { OrderPriorityChip } from '../../lib/orderPriority';

const PAGE_SIZE = 20;

type PlanningRowStatus = 'Unplanned' | 'Partial' | 'Planned';

const PLANNING_STATUS_RANK: Record<PlanningRowStatus, number> = {
  Unplanned: 0,
  Partial: 1,
  Planned: 2,
};

function deliverySortKey(deliveryDate: string | undefined): string {
  return deliveryDate?.split('T')[0] || '9999-12-31';
}

export const PlanningOrderList: React.FC = () => {
  const { orders, allocations, productionLines, loading } = useDataStore();
  const { processFlows } = useSettingsStore();
  const { navigate } = useNavigationStore();
  const [searchQuery, setSearchQuery] = useState("");
  const [filterBuyer, setFilterBuyer] = useState("");
  const [filterStatus, setFilterStatus] = useState("");

  // Get unique buyers
  const allBuyers = useMemo(() => {
    return Array.from(new Set(orders.map(o => o.buyer))).sort();
  }, [orders]);

  // Flatten Order > Colorways into rows with Planning Data
  const tableData = useMemo(() => {
    const rows: any[] = [];
    orders.forEach((order) => {
      // Get process steps for this order
      const flow = processFlows.find((f) => f.id === order.processFlow);
      const steps = flow
        ? flow.steps
        : ["Cutting", "Sewing", "Finishing", "Packing"];

      order.colorways.forEach((cw) => {
        // Calculate total adjusted requirement
        const totalReq = cw.sizes.reduce((acc, s) => acc + sizeAdjQty(s), 0);

        const relevantAllocations = allocations.filter(
          (a) => (a.colorwayId || a.orderId) === cw.id,
        );

        // Calculate total allocated PER DEPARTMENT
        const stepAllocations = steps.map((step: any) => {
          const deptName = typeof step === "string" ? step : step.dept_name;
          return relevantAllocations
            .filter((a) => {
              const line = productionLines.find((l) => l.id === a.lineId);
              return line && line.departmentName === deptName;
            })
            .reduce((sum, a) => sum + a.qty, 0);
        });

        // Logic: Planned Qty is the minimum of non-zero planned departments.
        // E.g. Cut 50, Sew 50 -> 50. Cut 50, Sew 40 -> 40.
        const nonZeroAllocations = stepAllocations.filter((q) => q > 0);
        const plannedQty =
          nonZeroAllocations.length > 0 ? Math.min(...nonZeroAllocations) : 0;

        const isPlanned = plannedQty > 0;

        // Status Determination
        let status = "Unplanned";
        if (isPlanned) {
          // Check if ALL steps meet the requirement
          const allStepsMet = stepAllocations.every((q) => q >= totalReq);
          // Or if simply the bottleneck (plannedQty) matches totalReq (simplified view)
          if (allStepsMet) status = "Planned";
          else status = "Partial";
        }

        rows.push({
          id: `${order.id}-${cw.id}`,
          orderId: order.id,
          styleName: order.styleName,
          priority: order.priority ?? 'normal',
          styleRef: order.styleRef,
          poNumber: order.poNumber,
          buyer: order.buyer,
          deliveryDate: order.deliveryDate,
          colorway: cw.name,
          totalQty: totalReq,
          plannedQty: plannedQty,
          hasAllocations: isPlanned,
          allocationCount: relevantAllocations.length,
          status: status,
        });
      });
    });
    return rows;
  }, [orders, allocations, productionLines, processFlows]);

  const filteredRowsAll = useMemo(
    () =>
      tableData
        .filter((row) => {
          const matchesSearch = !searchQuery ||
            row.styleName.toLowerCase().includes(searchQuery.toLowerCase()) ||
            row.poNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
            row.styleRef.toLowerCase().includes(searchQuery.toLowerCase()) ||
            row.buyer.toLowerCase().includes(searchQuery.toLowerCase());
          const matchesBuyer = !filterBuyer || row.buyer === filterBuyer;
          const matchesStatus = !filterStatus || row.status === filterStatus;
          return matchesSearch && matchesBuyer && matchesStatus;
        })
        .sort((a, b) => {
          const rankA = PLANNING_STATUS_RANK[a.status as PlanningRowStatus] ?? 9;
          const rankB = PLANNING_STATUS_RANK[b.status as PlanningRowStatus] ?? 9;
          if (rankA !== rankB) return rankA - rankB;
          return deliverySortKey(a.deliveryDate).localeCompare(deliverySortKey(b.deliveryDate));
        }),
    [tableData, searchQuery, filterBuyer, filterStatus],
  );

  const displayRows = useMemo(
    () => filteredRowsAll.slice(0, PAGE_SIZE),
    [filteredRowsAll],
  );

  const handleNavigate = (orderId: string, color: string) => {
    navigate(RoutePath.PLANNING_DETAIL, { orderId, color });
  };

  return (
    <PageShell loading={loading} skeleton="list" className="w-full pb-20">
      <Card noPadding className="shadow-sm border-slate-200">
        {/* Filter Bar - Standard Pattern */}
        <div className="px-4 py-3 border-b border-slate-100 flex items-center justify-between bg-slate-50/50 gap-4">
          {/* Left: Search */}
          <div className="flex items-center gap-2 flex-1 max-w-sm">
            <Search size={14} className="text-slate-400" />
            <input
              className="text-xs bg-transparent border-b border-slate-200 focus:border-blue-500 focus:outline-none py-1 flex-1"
              placeholder="Search style, PO, buyer..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>

          {/* Right: Filter Pills */}
          <div className="flex items-center gap-3">
            <SelectDropdown
              value={filterBuyer}
              onChange={setFilterBuyer}
              options={[
                { value: '', label: 'All Buyers' },
                ...allBuyers.map(b => ({ value: b, label: b }))
              ]}
              icon={Filter}
              className="w-36"
            />
            <SelectDropdown
              value={filterStatus}
              onChange={setFilterStatus}
              options={[
                { value: '', label: 'All Status' },
                { value: 'Unplanned', label: 'Unplanned' },
                { value: 'Partial', label: 'Partial' },
                { value: 'Planned', label: 'Planned' }
              ]}
              className="w-32"
            />
          </div>
        </div>

        {filteredRowsAll.length > PAGE_SIZE && (
          <div className="px-4 py-1.5 border-b border-slate-100 bg-white text-[10px] text-slate-500">
            Showing {displayRows.length} of {filteredRowsAll.length} colorways (unplanned first)
          </div>
        )}

      <div className="overflow-x-auto">
          <table className="w-full text-[10px] text-left border-collapse">
            <thead className="bg-slate-50 text-slate-500 font-semibold text-[9px] uppercase border-b border-slate-200">
              <tr>
                <th className="px-4 py-2.5 w-[18%] border-r border-blue-100 text-left">
                  Style
                </th>
                <th className="px-4 py-2.5 w-[12%] border-r border-blue-100 text-left">
                  Colorway
                </th>
                <th className="px-4 py-2.5 w-[10%] border-r border-blue-100 text-center">
                  Buyer
                </th>
                <th className="px-4 py-2.5 w-[10%] border-r border-blue-100 text-center">
                  PO Number
                </th>
                <th className="px-4 py-2.5 w-[10%] border-r border-blue-100 text-center">
                  Delivery
                </th>
                <th className="px-4 py-2.5 w-[10%] border-r border-blue-100 text-center">
                  Order Qty
                </th>
                <th className="px-4 py-2.5 w-[10%] border-r border-blue-100 text-center">
                  Planned Qty
                </th>
                <th className="px-4 py-2.5 w-[12%] border-r border-blue-100 text-center">
                  Status
                </th>
                <th className="px-4 py-2.5 w-[8%] text-center"></th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {displayRows.map((row) => (
                <tr
                  key={row.id}
                  onClick={() => handleNavigate(row.orderId, row.colorway)}
                  className="hover:bg-blue-50/50 cursor-pointer group transition-colors"
                >
                  <td className="px-4 py-1.5 border-r border-blue-50 group-hover:border-blue-100 transition-colors">
                    <div className="text-xs font-bold text-slate-800 inline-flex items-center gap-2 flex-wrap">
                      <span>{row.styleName}</span>
                      <OrderPriorityChip priority={row.priority} />
                    </div>
                    <div className="text-[10px] text-slate-500">
                      {row.styleRef}
                    </div>
                  </td>
                  <td className="px-4 py-1.5 border-r border-blue-50 group-hover:border-blue-100 transition-colors">
                    <div className="flex items-center gap-2">
                      <div className="w-2 h-2 rounded-full bg-blue-500 shadow-sm"></div>
                      <span className="text-xs text-slate-700">
                        {row.colorway}
                      </span>
                    </div>
                  </td>
                  <td className="px-4 py-1.5 text-center text-xs text-slate-700 border-r border-blue-50 group-hover:border-blue-100 transition-colors">
                    {row.buyer}
                  </td>
                  <td className="px-4 py-1.5 text-center text-xs text-slate-600 border-r border-blue-50 group-hover:border-blue-100 transition-colors">
                    {row.poNumber}
                  </td>
                  <td className="px-4 py-1.5 text-center text-xs text-slate-600 border-r border-blue-50 group-hover:border-blue-100 transition-colors">
                    {row.deliveryDate}
                  </td>
                  <td className="px-4 py-1.5 text-center text-xs text-slate-700 border-r border-blue-50 group-hover:border-blue-100 transition-colors">
                    {row.totalQty.toLocaleString()}
                  </td>
                  <td className="px-4 py-1.5 text-center text-xs text-blue-600 border-r border-blue-50 group-hover:border-blue-100 transition-colors">
                    {row.plannedQty > 0 ? row.plannedQty.toLocaleString() : "-"}
                  </td>
                  <td className="px-4 py-1.5 border-r border-blue-50 group-hover:border-blue-100 transition-colors">
                    <div className="flex items-center justify-center gap-1.5">
                      {row.status === "Unplanned" && (
                        <>
                          <div className="w-1.5 h-1.5 rounded-full bg-slate-300"></div>
                          <span className="text-[10px] text-slate-400">
                            Unplanned
                          </span>
                        </>
                      )}
                      {row.status === "Partial" && (
                        <>
                          <div className="w-1.5 h-1.5 rounded-full bg-amber-500 animate-pulse"></div>
                          <span className="text-xs text-amber-600">
                            Partial
                          </span>
                        </>
                      )}
                      {row.status === "Planned" && (
                        <>
                          <div className="w-1.5 h-1.5 rounded-full bg-emerald-500"></div>
                          <span className="text-xs text-emerald-700">
                            Planned
                          </span>
                        </>
                      )}
                    </div>
                  </td>
                  <td className="px-4 py-1.5 text-center">
                    <ChevronRight
                      size={14}
                      className="text-slate-300 group-hover:text-blue-500 transition-colors mx-auto"
                    />
                  </td>
                </tr>
              ))}
              {filteredRowsAll.length === 0 && (
                <tr>
                  <td
                    colSpan={9}
                    className="p-8 text-center text-slate-400 italic"
                  >
                    No orders found. Create a new order to get started.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </Card>
    </PageShell>
  );
};
