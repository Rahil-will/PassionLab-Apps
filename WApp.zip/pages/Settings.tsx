﻿import React, { useState, useMemo, useRef, useCallback } from 'react';
import {
  useSettingsStore,
  useNavigationStore,
  useNotificationStore,
  useDataStore,
} from '../stores';
import {
  User,
  Clock,
  GitMerge,
  Plus,
  Trash2,
  Save,
  ChevronRight,
  LayoutList,
  Building2,
  X,
  AlertTriangle,
  Loader2,
  Users,
  ListChecks,
  Bug,
} from 'lucide-react';
import { Button, Spinner, Modal } from '../components/ui';
import { PageShell } from '../components/layout/PageShell';
import {
  BuyerEditor,
  DepartmentEditor,
  ShiftEditor,
  ProcessFlowEditor,
  WorkforceEditor,
  SupportDropdownEditor,
  DefectsEditor,
} from '../components/settings';
import { SUPPORT_DROPDOWN_CATALOG } from '../lib/supportDropdownCatalog';
import { duplicateNameError, duplicateNamesInList, validateShiftHourBlocks, validateShiftTimeOverlap } from '../lib/settingsValidation';
import { getErrorMessage } from '../lib/assignedResourceDb';

type Tab = 'Buyers' | 'Departments' | 'Shifts' | 'ProcessFlow' | 'Workforce' | 'SupportDropdowns' | 'Defects';

const TABS = [
  { id: 'Buyers' as Tab, icon: User, label: 'Buyers' },
  { id: 'Departments' as Tab, icon: Building2, label: 'Departments' },
  { id: 'Shifts' as Tab, icon: Clock, label: 'Shifts' },
  { id: 'ProcessFlow' as Tab, icon: GitMerge, label: 'Process Flows' },
  { id: 'Workforce' as Tab, icon: Users, label: 'Workforce' },
  { id: 'Defects' as Tab, icon: Bug, label: 'Defects' },
  { id: 'SupportDropdowns' as Tab, icon: ListChecks, label: 'Dropdowns' },
];

function isProcessFlowCurrent(flow: { is_current?: boolean | null }): boolean {
  return flow.is_current !== false;
}

export function Settings() {
  const store = useSettingsStore();
  const refreshAssignedResources = useDataStore((s) => s.refreshAssignedResources);
  const departmentResourceSession = useSettingsStore((s) => s.departmentResourceSession);
  const { factoryId } = useNavigationStore();
  const { showNotification } = useNotificationStore();

  const [activeTab, setActiveTab] = useState<Tab>('Buyers');
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [formData, setFormData] = useState<any>(null);
  const [isUnsaved, setIsUnsaved] = useState(false);
  const [saving, setSaving] = useState(false);
  const [showUnsavedDialog, setShowUnsavedDialog] = useState(false);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<{ id: string; label: string } | null>(null);
  const [deleting, setDeleting] = useState(false);
  const [pendingAction, setPendingAction] = useState<(() => void) | null>(null);
  const [processFlowTab, setProcessFlowTab] = useState<'Current' | 'Archived'>('Current');
  const [workforceDeptId, setWorkforceDeptId] = useState<string | null>(null);
  const [defectsDeptId, setDefectsDeptId] = useState<string | null>(null);
  const [workforceDirty, setWorkforceDirty] = useState(false);
  const defectsSaveRef = useRef<(() => Promise<void>) | null>(null);

  const registerDefectsSave = useCallback((save: (() => Promise<void>) | null) => {
    defectsSaveRef.current = save;
  }, []);

  // Get list items based on active tab
  const listItems = useMemo(() => {
    switch (activeTab) {
      case 'Buyers':
        return store.buyers;
      case 'Departments':
        return store.departments;
      case 'Shifts':
        return [...store.shifts].sort((a: any, b: any) => {
          if ((a.type || 'Regular') === 'Regular' && (b.type || 'Regular') !== 'Regular') return -1;
          if ((a.type || 'Regular') !== 'Regular' && (b.type || 'Regular') === 'Regular') return 1;
          return 0;
        });
      case 'ProcessFlow':
        return store.processFlows.filter((pf: { is_current?: boolean | null }) =>
          processFlowTab === 'Current' ? isProcessFlowCurrent(pf) : pf.is_current === false,
        );
      case 'Workforce':
        return store.departments.filter((d: any) => !d.isOutsourced);
      case 'Defects':
        return store.departments;
      case 'SupportDropdowns':
        return store.supportDropdowns;
      default:
        return [];
    }
  }, [activeTab, store, processFlowTab]);

  const hasPendingUnsaved = isUnsaved || (activeTab === 'Workforce' && workforceDirty);

  // Handle tab change with unsaved check
  const handleTabChange = (tab: Tab) => {
    if (hasPendingUnsaved) {
      setPendingAction(() => () => doTabChange(tab));
      setShowUnsavedDialog(true);
    } else {
      doTabChange(tab);
    }
  };

  const doTabChange = (tab: Tab) => {
    setActiveTab(tab);
    setSelectedId(null);
    setFormData(null);
    setIsUnsaved(false);
    store.clearDepartmentResourceSession();
    setWorkforceDeptId(null);
    setWorkforceDirty(false);
    setDefectsDeptId(null);
    if (tab !== 'ProcessFlow') {
      setProcessFlowTab('Current');
    }
  };

  const doProcessFlowTabChange = (tab: 'Current' | 'Archived') => {
    setProcessFlowTab(tab);
    setSelectedId(null);
    setFormData(null);
    setIsUnsaved(false);
  };

  const handleProcessFlowTabChange = (tab: 'Current' | 'Archived') => {
    if (hasPendingUnsaved) {
      setPendingAction(() => () => doProcessFlowTabChange(tab));
      setShowUnsavedDialog(true);
      return;
    }
    doProcessFlowTabChange(tab);
  };

  const doWorkforceDeptSelect = (id: string) => {
    setWorkforceDeptId(id);
    setWorkforceDirty(false);
  };

  const handleWorkforceDeptSelect = (id: string) => {
    if (workforceDirty) {
      setPendingAction(() => () => doWorkforceDeptSelect(id));
      setShowUnsavedDialog(true);
      return;
    }
    doWorkforceDeptSelect(id);
  };

  const doDefectsDeptSelect = (id: string) => {
    setDefectsDeptId(id);
    setIsUnsaved(false);
  };

  const handleDefectsDeptSelect = (id: string) => {
    if (isUnsaved) {
      setPendingAction(() => () => doDefectsDeptSelect(id));
      setShowUnsavedDialog(true);
      return;
    }
    doDefectsDeptSelect(id);
  };

  // Handle select item
  const handleSelect = (id: string, item: any) => {
    if (hasPendingUnsaved) {
      setPendingAction(() => () => doSelect(id, item));
      setShowUnsavedDialog(true);
      return;
    }
    doSelect(id, item);
  };

  const doSelect = (id: string, item: any) => {
    const data = JSON.parse(JSON.stringify(item));

    if (activeTab === 'Buyers') {
      data._sizeGroups = id.startsWith('temp_')
        ? (data._sizeGroups || [])
        : store.sizeGroups
            .filter((sg) => sg.buyerId === id)
            .map((sg) => ({ ...sg, sizes: [...sg.sizes] }));
    }

    if (activeTab === 'Departments') {
      store.selectDepartmentForEdit(id);
      if (!id.startsWith('temp_')) {
        void store.loadDepartmentResources(id, data.name as string).catch((err) => {
          showNotification(getErrorMessage(err, 'Failed to load department resources'), 'error');
        });
      }
    }

    setSelectedId(id);
    setFormData(data);
    setIsUnsaved(false);
  };

  // Handle create new
  const handleCreate = () => {
    if (hasPendingUnsaved) {
      setPendingAction(() => () => doCreate());
      setShowUnsavedDialog(true);
      return;
    }
    doCreate();
  };

  const doCreate = () => {
    const base = { factory_id: factoryId };
    let newItem: any = { ...base };

    switch (activeTab) {
      case 'Buyers':
        newItem = { ...base, name: '', code: '', _sizeGroups: [] };
        break;
      case 'Departments':
        newItem = {
          ...base,
          name: '',
          isOutsourced: false,
          apps: ['transaction'],
          workerRoles: [],
        };
        break;
      case 'Shifts': {
        const hasRegular = store.shifts.some((s: any) => (s.type || 'Regular') === 'Regular');
        newItem = { ...base, name: '', type: hasRegular ? 'OT' : 'Regular', startTime: '09:00', endTime: '17:00', hours: [] };
        break;
      }
      case 'ProcessFlow':
        newItem = { ...base, name: '', description: '', steps: [], version: 1, is_current: true };
        if (processFlowTab === 'Archived') {
          setProcessFlowTab('Current');
        }
        break;
      case 'SupportDropdowns': {
        const missing = SUPPORT_DROPDOWN_CATALOG.find(
          def => !store.supportDropdowns.some((sd: { category: string }) => sd.category === def.category),
        );
        if (!missing) {
          showNotification('All standard dropdowns are already configured.', 'error');
          return;
        }
        newItem = { ...base, category: missing.category, app_name: missing.appName, values: [...missing.defaultValues] };
        break;
      }
    }

    const tempId = 'temp_' + crypto.randomUUID();
    newItem.id = tempId;

    if (activeTab === 'Departments') {
      store.selectDepartmentForEdit(tempId);
    }

    setSelectedId(tempId);
    setFormData(newItem);
    setIsUnsaved(true);
  };

  // Handle form data changes
  const handleSetFormData = (newData: any) => {
    // Skip marking as dirty for internal initialization (e.g. _sizeGroups, default apps)
    if (newData._init) {
      const { _init, ...rest } = newData;
      setFormData(rest);
      return;
    }
    setFormData(newData);
    setIsUnsaved(true);
  };

  const validateBeforeSave = (): string | null => {
    if (!formData) return null;
    switch (activeTab) {
      case 'Buyers': {
        const err = duplicateNameError(store.buyers, formData.name, formData.id, 'Buyer name');
        if (err) return err;
        const sgErr = duplicateNamesInList(formData._sizeGroups || [], 'Size group name');
        if (sgErr) return sgErr;
        return null;
      }
      case 'Departments': {
        const err = duplicateNameError(store.departments, formData.name, formData.id, 'Department name');
        if (err) return err;
        const draftResources =
          departmentResourceSession?.deptId === formData.id
            ? departmentResourceSession.draft
            : [];
        const resErr = duplicateNamesInList(draftResources, 'Resource name');
        if (resErr) return resErr;
        const apps: string[] = formData.apps || [];
        if (apps.includes('workforce_log') && (!(formData.workerRoles as string[])?.length)) {
          return 'Add at least one workforce category when Workforce Log is enabled';
        }
        return null;
      }
      case 'Shifts': {
        const nameErr = duplicateNameError(store.shifts, formData.name, formData.id, 'Shift name');
        if (nameErr) return nameErr;
        const blockErr = validateShiftHourBlocks(formData.hours || []);
        if (blockErr) return blockErr;
        return validateShiftTimeOverlap(
          formData.id,
          formData.name,
          formData.hours || [],
          store.shifts,
        );
      }
      case 'ProcessFlow': {
        const peers = store.processFlows.filter((pf: { is_current?: boolean | null }) =>
          processFlowTab === 'Current' ? isProcessFlowCurrent(pf) : pf.is_current === false,
        );
        return duplicateNameError(peers, formData.name, formData.id, 'Process flow name');
      }
      case 'SupportDropdowns': {
        const category = (formData.category as string) || '';
        const peers = store.supportDropdowns.filter(
          (d: { app_name?: string }) => d.app_name === formData.app_name,
        );
        return duplicateNameError(peers, category, formData.id, 'Dropdown category');
      }
      default:
        return null;
    }
  };

  const handleSaveDefects = async (): Promise<boolean> => {
    if (!defectsSaveRef.current) return false;
    setSaving(true);
    try {
      await defectsSaveRef.current();
      setIsUnsaved(false);
      return true;
    } catch (error) {
      showNotification(getErrorMessage(error, 'Failed to save defects'), 'error');
      return false;
    } finally {
      setSaving(false);
    }
  };

  // Handle save — returns true only when persistence succeeded
  const handleSave = async (): Promise<boolean> => {
    if (activeTab === 'Defects') {
      return handleSaveDefects();
    }
    if (!formData) return false;
    if (!factoryId) {
      showNotification('Select a factory before saving', 'error');
      return false;
    }

    const validationError = validateBeforeSave();
    if (validationError) {
      showNotification(validationError, 'error');
      return false;
    }

    setSaving(true);
    const dataToSave = { ...formData, factory_id: factoryId };

    try {
      switch (activeTab) {
        case 'Buyers': {
          let buyerId = dataToSave.id as string;
          const sizeGroupsToSave = (dataToSave._sizeGroups || []) as Array<{
            id: string;
            name: string;
            sizes: string[];
          }>;

          if (buyerId?.startsWith('temp_')) {
            const { id, _sizeGroups, ...rest } = dataToSave;
            buyerId = await store.addBuyer({ ...rest, factory_id: factoryId });
          } else {
            await store.updateBuyer(buyerId, dataToSave);
          }

          const existingForBuyer = useSettingsStore
            .getState()
            .sizeGroups.filter((sg) => sg.buyerId === buyerId);
          const newIds = new Set(sizeGroupsToSave.map((sg) => sg.id));

          for (const sg of existingForBuyer) {
            if (!newIds.has(sg.id)) await store.deleteSizeGroup(sg.id);
          }

          for (const sg of sizeGroupsToSave) {
            const payload = {
              id: sg.id,
              factory_id: factoryId,
              buyerId,
              name: sg.name,
              sizes: sg.sizes,
            };
            const existsInDb = useSettingsStore.getState().sizeGroups.some((ex) => ex.id === sg.id);
            if (existsInDb) {
              await store.updateSizeGroup(sg.id, payload);
            } else {
              await store.addSizeGroup(payload);
            }
          }

          await store.fetchSettings();
          const refreshedBuyer = useSettingsStore.getState().buyers.find((b) => b.id === buyerId);
          const refreshedGroups = useSettingsStore.getState().sizeGroups.filter((sg) => sg.buyerId === buyerId);
          if (refreshedBuyer) {
            setSelectedId(buyerId);
            setFormData({ ...refreshedBuyer, _sizeGroups: refreshedGroups });
          }
          break;
        }
        case 'Departments': {
          if (!factoryId) throw new Error('No factory selected');
          const isNew = dataToSave.id?.startsWith('temp_');
          let deptId = dataToSave.id as string;

          if (isNew) {
            const { id, ...rest } = dataToSave;
            deptId = await store.addDepartment({ ...rest, factory_id: factoryId });
            store.promoteDepartmentResourceSession(deptId);
          } else {
            await store.updateDepartment(deptId, dataToSave);
          }

          const resourceSession = useSettingsStore.getState().departmentResourceSession;
          if (resourceSession?.deptId === deptId) {
            await store.syncDepartmentResources(
              deptId,
              factoryId,
              Boolean(dataToSave.isOutsourced),
            );
          }

          await refreshAssignedResources();

          const refreshedDept = useSettingsStore.getState().departments.find((d) => d.id === deptId);
          if (refreshedDept) {
            setSelectedId(deptId);
            setFormData({ ...refreshedDept });
          }
          break;
        }
        case 'Shifts':
          if (dataToSave.id?.startsWith('temp_')) {
            const { id, ...rest } = dataToSave;
            await store.addShift(rest);
          } else {
            await store.updateShift(dataToSave.id, dataToSave);
          }
          break;
        case 'ProcessFlow':
          if (dataToSave.id?.startsWith('temp_')) {
            const { id, ...rest } = dataToSave;
            await store.addProcessFlow(rest);
          } else {
            const oldFlow = store.processFlows.find((pf: { id: string; is_current?: boolean; version?: number }) => pf.id === dataToSave.id);
            if (oldFlow?.is_current === false) {
              showNotification('Archived flows are read-only. Open the current version to edit.', 'error');
              return false;
            }
            if (oldFlow && isProcessFlowCurrent(oldFlow)) {
              const newId = crypto.randomUUID();
              const { id: _oldId, ...newFlowData } = dataToSave;
              const nextVersion = (oldFlow.version || 1) + 1;
              await store.versionCurrentProcessFlow(oldFlow.id, {
                ...newFlowData,
                id: newId,
                is_current: true,
                version: nextVersion,
                parent_flow_id: oldFlow.id,
              });
              setSelectedId(newId);
              setFormData({
                ...newFlowData,
                id: newId,
                is_current: true,
                version: nextVersion,
                parent_flow_id: oldFlow.id,
              });
            } else {
              await store.updateProcessFlow(dataToSave.id, dataToSave);
            }
          }
          break;
        case 'SupportDropdowns':
          if (dataToSave.id?.startsWith('temp_')) {
            const { id, ...rest } = dataToSave;
            await store.addSupportDropdown(rest);
          } else {
            await store.updateSupportDropdown(dataToSave.id, dataToSave);
          }
          break;
      }

      showNotification('Changes saved successfully', 'success');
      setIsUnsaved(false);
      return true;
    } catch (error) {
      const message = getErrorMessage(error, 'Failed to save changes');
      showNotification(message, 'error');
      return false;
    } finally {
      setSaving(false);
    }
  };

  const requestDelete = (id: string) => {
    const label =
      activeTab === 'SupportDropdowns'
        ? (formData?.category as string) || 'this dropdown'
        : (formData?.name as string) || 'this item';
    setDeleteTarget({ id, label });
    setShowDeleteDialog(true);
  };

  const cancelDelete = () => {
    setShowDeleteDialog(false);
    setDeleteTarget(null);
  };

  const confirmDelete = async () => {
    if (!deleteTarget) return;
    const { id } = deleteTarget;

    if (id.startsWith('temp_')) {
      if (selectedId === id) {
        setSelectedId(null);
        setFormData(null);
        setIsUnsaved(false);
        store.clearDepartmentResourceSession();
      }
      setShowDeleteDialog(false);
      setDeleteTarget(null);
      return;
    }

    setDeleting(true);
    try {
      switch (activeTab) {
        case 'Buyers':
          await store.deleteBuyer(id);
          break;
        case 'Departments':
          await store.deleteDepartment(id);
          await refreshAssignedResources();
          break;
        case 'Shifts':
          await store.deleteShift(id);
          break;
        case 'ProcessFlow':
          await store.deleteProcessFlow(id);
          break;
        case 'SupportDropdowns':
          await store.deleteSupportDropdown(id);
          break;
      }

      if (selectedId === id) {
        setSelectedId(null);
        setFormData(null);
        setIsUnsaved(false);
      }

      showNotification('Item deleted successfully', 'success');
      setShowDeleteDialog(false);
      setDeleteTarget(null);
    } catch (error) {
      showNotification('Failed to delete item', 'error');
    } finally {
      setDeleting(false);
    }
  };

  // Unsaved changes dialog handlers
  const confirmSave = async () => {
    const saved = await handleSave();
    if (!saved) return;
    setShowUnsavedDialog(false);
    setWorkforceDirty(false);
    if (pendingAction) {
      pendingAction();
      setPendingAction(null);
    }
  };

  const confirmDiscard = () => {
    setShowUnsavedDialog(false);
    setIsUnsaved(false);
    setWorkforceDirty(false);
    if (pendingAction) {
      pendingAction();
      setPendingAction(null);
    }
  };

  const cancelNavigation = () => {
    setShowUnsavedDialog(false);
    setPendingAction(null);
  };

  return (
    <PageShell className="min-h-[calc(100vh-2rem)] bg-slate-50 pb-6 relative">
      {/* Tabs Header with Action Buttons */}
      <div className="sticky top-0 z-20 bg-slate-50 pt-3 pb-3 before:content-[''] before:absolute before:inset-x-0 before:-top-1 before:h-4 before:bg-slate-50">
        <div className="flex items-center justify-between bg-white p-1.5 rounded-xl border border-slate-200 shadow-sm">
          <div className="flex gap-1 flex-wrap">
            {TABS.map((tab) => (
              <button
                key={tab.id}
                onClick={() => handleTabChange(tab.id)}
                className={`flex items-center gap-2 px-3 py-2 rounded-lg text-xs font-medium transition-all ${
                  activeTab === tab.id
                    ? 'bg-blue-50 text-blue-700 shadow-sm'
                    : 'text-slate-500 hover:text-slate-900 hover:bg-slate-50'
                }`}
              >
                <tab.icon size={16} />
                {tab.label}
              </button>
            ))}
          </div>
          
          {/* Global Save/Delete Buttons */}
          {activeTab === 'Defects' && defectsDeptId ? (
            <div className="flex items-center gap-2 px-2">
              <button
                onClick={handleSaveDefects}
                disabled={saving || !isUnsaved}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors text-xs font-medium"
              >
                {saving ? <Loader2 size={14} className="animate-spin" /> : <Save size={14} />}
                Save Changes
              </button>
            </div>
          ) : formData && activeTab !== 'Workforce' ? (
            <div className="flex items-center gap-2 px-2">
              {activeTab !== 'SupportDropdowns' && (
                <button
                  onClick={() => requestDelete(formData.id)}
                  className="flex items-center gap-1.5 px-3 py-1.5 bg-red-50 text-red-600 rounded-lg hover:bg-red-100 transition-colors text-xs font-medium"
                >
                  <Trash2 size={14} />
                  Delete
                </button>
              )}
              <button
                onClick={handleSave}
                disabled={saving || !(activeTab === 'SupportDropdowns' ? formData.category?.trim() : formData.name?.trim())}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors text-xs font-medium"
              >
                {saving ? <Loader2 size={14} className="animate-spin" /> : <Save size={14} />}
                Save Changes
              </button>
            </div>
          ) : null}
        </div>
      </div>

      <div className="flex gap-6 h-[calc(100vh-120px)]">
        {/* Left Sidebar: List */}
        <div className="w-72 bg-white border border-slate-200 rounded-xl shadow-sm flex flex-col sticky top-16 shrink-0 h-full overflow-hidden">
          <div className="p-4 border-b border-slate-100 flex flex-col gap-3 bg-slate-50/50">
            <div className="flex justify-between items-center">
              <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
                {activeTab === 'Workforce' ? 'Departments' : activeTab === 'Defects' ? 'Departments' : activeTab === 'SupportDropdowns' ? 'Dropdowns' : `${activeTab} List`}
              </span>
              {activeTab !== 'Workforce' && activeTab !== 'SupportDropdowns' && activeTab !== 'Defects' && (
                <button
                  onClick={handleCreate}
                  className="p-1.5 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors shadow-sm"
                >
                  <Plus size={16} />
                </button>
              )}
            </div>

            {/* Process Flow Sub-tabs */}
            {activeTab === 'ProcessFlow' && (
              <div className="flex gap-1 bg-white p-1 rounded-lg border border-slate-200">
                <button
                  onClick={() => handleProcessFlowTabChange('Current')}
                  className={`flex-1 px-3 py-1.5 rounded text-[11px] font-medium transition-all ${
                    processFlowTab === 'Current'
                      ? 'bg-blue-50 text-blue-700 shadow-sm'
                      : 'text-slate-500 hover:text-slate-700 hover:bg-slate-50'
                  }`}
                >
                  Current ({store.processFlows.filter((pf: { is_current?: boolean | null }) => isProcessFlowCurrent(pf)).length})
                </button>
                <button
                  onClick={() => handleProcessFlowTabChange('Archived')}
                  className={`flex-1 px-3 py-1.5 rounded text-[11px] font-medium transition-all ${
                    processFlowTab === 'Archived'
                      ? 'bg-slate-200 text-slate-700 shadow-sm'
                      : 'text-slate-500 hover:text-slate-700 hover:bg-slate-50'
                  }`}
                >
                  Archived ({store.processFlows.filter((pf: { is_current?: boolean | null }) => pf.is_current === false).length})
                </button>
              </div>
            )}
          </div>

          <div className="flex-1 overflow-y-auto p-2 space-y-1">
            {store.loading ? (
              <div className="flex items-center justify-center py-10">
                <Spinner size="md" />
              </div>
            ) : listItems.length > 0 ? (
              listItems.map((item: any) => (
                <div
                  key={item.id}
                  onClick={() => {
                    if (activeTab === 'Workforce') handleWorkforceDeptSelect(item.id);
                    else if (activeTab === 'Defects') handleDefectsDeptSelect(item.id);
                    else handleSelect(item.id, item);
                  }}
                  className={`p-3 rounded-lg cursor-pointer text-xs transition-all group ${
                    (activeTab === 'Workforce' ? workforceDeptId === item.id : activeTab === 'Defects' ? defectsDeptId === item.id : selectedId === item.id)
                      ? 'bg-blue-50 text-blue-700 border-blue-200 border'
                      : activeTab === 'ProcessFlow' && item.is_current === false
                      ? 'bg-slate-100 text-slate-400 border border-transparent'
                      : 'text-slate-700 hover:bg-slate-50 border border-transparent'
                  }`}
                >
                  <div className="font-bold flex justify-between items-center">
                    <span className={activeTab === 'ProcessFlow' && item.is_current === false ? 'opacity-60' : ''}>
                      {(activeTab === 'SupportDropdowns' ? (item.app_name || item.category) : item.name) || <span className="text-slate-400 italic">Untitled</span>}
                    </span>
                    <ChevronRight
                      size={14}
                      className={`opacity-0 group-hover:opacity-100 transition-opacity ${
                        (activeTab === 'Workforce' ? workforceDeptId === item.id : activeTab === 'Defects' ? defectsDeptId === item.id : selectedId === item.id) ? 'opacity-100 text-blue-500' : 'text-slate-400'
                      }`}
                    />
                  </div>
                  {item.code && <div className="text-[10px] opacity-70 mt-0.5 font-mono">{item.code}</div>}
                  {activeTab === 'Shifts' && item.type && (
                    <span className={`text-[9px] font-medium mt-0.5 inline-block px-1.5 py-0.5 rounded ${item.type === 'OT' ? 'bg-amber-50 text-amber-600' : 'bg-blue-50 text-blue-600'}`}>
                      {item.type}
                    </span>
                  )}
                  {item.steps && <div className="text-[10px] opacity-70 mt-0.5">{item.steps.length} Steps</div>}
                  {activeTab === 'SupportDropdowns' && item.values && <div className="text-[10px] opacity-70 mt-0.5">{item.values.length} values</div>}
                </div>
              ))
            ) : (
              <div className="p-4 text-center text-xs text-slate-400 italic">
                No {activeTab.toLowerCase()} found. Click + to add.
              </div>
            )}
          </div>
        </div>

        {/* Right Main: Editor */}
        <div className="flex-1 w-full min-w-0 overflow-y-auto">
          {activeTab === 'Workforce' ? (
            <WorkforceEditor
              selectedDeptId={workforceDeptId}
              onDirtyChange={setWorkforceDirty}
            />
          ) : activeTab === 'Defects' ? (
            <DefectsEditor
              selectedDeptId={defectsDeptId}
              onDirtyChange={setIsUnsaved}
              onRegisterSave={registerDefectsSave}
            />
          ) : formData ? (
            <div className="w-full animate-in fade-in zoom-in-95 duration-200" key={formData.id}>
              {activeTab === 'Buyers' && (
                <BuyerEditor
                  formData={formData}
                  setFormData={handleSetFormData}
                  onSave={handleSave}
                  onDelete={() => requestDelete(formData.id)}
                />
              )}
              {activeTab === 'Departments' && (
                <DepartmentEditor
                  formData={formData}
                  resources={
                    departmentResourceSession?.deptId === formData.id
                      ? departmentResourceSession.draft
                      : []
                  }
                  resourcesLoading={
                    departmentResourceSession?.deptId === formData.id
                    && departmentResourceSession.status === 'loading'
                  }
                  onResourcesChange={(resources) => {
                    store.setDepartmentResourceDraft(resources);
                    setIsUnsaved(true);
                  }}
                  setFormData={handleSetFormData}
                  onSave={handleSave}
                  onDelete={() => requestDelete(formData.id)}
                />
              )}
              {activeTab === 'Shifts' && (
                <ShiftEditor
                  formData={formData}
                  setFormData={handleSetFormData}
                  onSave={handleSave}
                  onDelete={() => requestDelete(formData.id)}
                />
              )}
              {activeTab === 'ProcessFlow' && (
                <ProcessFlowEditor
                  formData={formData}
                  setFormData={handleSetFormData}
                  onSave={handleSave}
                  onDelete={() => requestDelete(formData.id)}
                />
              )}
              {activeTab === 'SupportDropdowns' && (
                <SupportDropdownEditor
                  formData={formData}
                  setFormData={handleSetFormData}
                  onSave={handleSave}
                  onDelete={() => requestDelete(formData.id)}
                />
              )}
            </div>
          ) : (
            <div className="h-full flex flex-col items-center justify-center text-slate-300 border-2 border-dashed border-slate-200 rounded-xl bg-slate-50/50">
              <LayoutList size={64} className="mb-4 opacity-20" />
              <p className="text-xs font-medium text-slate-400">
                Select an item from the list to configure
              </p>
            </div>
          )}
        </div>
      </div>

      {/* Delete Confirmation Modal */}
      <Modal isOpen={showDeleteDialog} onClose={cancelDelete}>
        <div className="relative">
          <button
            onClick={cancelDelete}
            className="absolute top-4 right-4 text-slate-400 hover:text-red-600 transition-colors p-1 hover:bg-red-50 rounded-full"
          >
            <X size={20} />
          </button>

          <div className="flex flex-col items-center p-8 pb-4 text-center">
            <div className="w-16 h-16 bg-red-100 text-red-600 rounded-2xl flex items-center justify-center mb-4 shadow-sm ring-4 ring-red-50">
              <Trash2 size={32} />
            </div>
            <h3 className="text-base font-bold text-slate-900 mb-2">Delete {activeTab.slice(0, -1)}?</h3>
            <p className="text-slate-500 text-xs max-w-[280px] leading-relaxed">
              <span className="font-medium text-slate-700">{deleteTarget?.label}</span> will be
              permanently removed. This cannot be undone.
              {activeTab === 'Departments' && (
                <span className="block mt-2 text-amber-700 font-medium">
                  Workers, defect catalogs, and assigned resources for this department will also be
                  deleted.
                </span>
              )}
            </p>
          </div>

          <div className="p-6 pt-2 flex flex-col gap-3">
            <Button
              variant="danger"
              onClick={confirmDelete}
              disabled={deleting}
              className="w-full py-2.5 text-xs"
            >
              {deleting ? <Loader2 size={14} className="animate-spin mx-auto" /> : 'Delete'}
            </Button>
            <Button variant="secondary" onClick={cancelDelete} className="w-full text-xs">
              Cancel
            </Button>
          </div>
        </div>
      </Modal>

      {/* Unsaved Changes Modal */}
      <Modal isOpen={showUnsavedDialog} onClose={cancelNavigation}>
        <div className="relative">
          <button
            onClick={cancelNavigation}
            className="absolute top-4 right-4 text-slate-400 hover:text-red-600 transition-colors p-1 hover:bg-red-50 rounded-full"
          >
            <X size={20} />
          </button>

          <div className="flex flex-col items-center p-8 pb-4 text-center">
            <div className="w-16 h-16 bg-amber-100 text-amber-600 rounded-2xl flex items-center justify-center mb-4 shadow-sm ring-4 ring-amber-50">
              <AlertTriangle size={32} />
            </div>
            <h3 className="text-base font-bold text-slate-900 mb-2">Unsaved Changes</h3>
            <p className="text-slate-500 text-xs max-w-[260px] leading-relaxed">
              You have unsaved modifications. What would you like to do?
            </p>
          </div>

          <div className="p-6 pt-2 flex flex-col gap-3">
            <Button
              onClick={confirmSave}
              className="w-full shadow-lg shadow-blue-100 py-2.5 text-xs"
            >
              Save Changes
            </Button>
            <Button
              variant="danger-light"
              onClick={confirmDiscard}
              className="w-full text-xs"
            >
              Discard & Continue
            </Button>
          </div>
        </div>
      </Modal>
    </PageShell>
  );
}

