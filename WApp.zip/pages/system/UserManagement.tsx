import React, { useState, useMemo } from 'react';
import { useDataStore, useNotificationStore, useSettingsStore, useNavigationStore } from '../../stores';
import { Users, Plus, Search, Trash2, X, Mail, User, Shield, CheckCircle, XCircle, Lock, Check, AlertTriangle, Loader2, Filter } from 'lucide-react';
import { Button, Modal, SelectDropdown } from '../../components/ui';
import { PageShell } from '../../components/layout/PageShell';
import { supabase } from '../../lib/supabase';
import { createFactoryUser } from '../../lib/createFactoryUser';
import { deleteFactoryUser } from '../../lib/deleteFactoryUser';
import { DEPT_APP_OPTIONS, defaultAssignedApps, departmentFloorApps, labelForDeptApp, sortAssignedApps, type DeptAppId } from '../../lib/floorApps';
import {
    appsForAssignmentMode,
    clampAssignedAppsToDepartment,
    clampAssignedAppsToFactoryFunction,
    formatAssignedAppsLabel,
    hasShipmentQaApps,
    inferAssignmentMode,
    isFloorLoginRole,
    SHIPMENT_QA_LABEL,
    type UserAssignmentMode,
    validateFloorUserPayload,
} from '../../lib/floorUserUtils';
import { defaultShipmentFunctionApps, isFactoryFunctionEnabled } from '../../lib/factoryEntitlements';

interface UserProfile {
    id: string;
    fullName: string;
    email: string;
    userRole: 'superadmin' | 'admin' | 'quality_manager' | 'supervisor' | 'auditor' | 'operator';
    factoryId: string;
    status: 'Active' | 'Inactive';
    departmentId: string | null;
    employeeId: string;
    floorPin: string;
    assignedApps: DeptAppId[];
    createdAt: string;
    updatedAt: string | null;
}

export const UserManagement: React.FC = () => {
    const { showNotification } = useNotificationStore();
    const { departments, factoryEntitlements, fetchSettings } = useSettingsStore();
    const { userProfile: currentUser, factoryId } = useNavigationStore();
    const [users, setUsers] = useState<UserProfile[]>([]);
    const [loading, setLoading] = useState(true);
    const [saving, setSaving] = useState(false);
    const [showPanel, setShowPanel] = useState(false);
    const [panelDirty, setPanelDirty] = useState(false);
    const [showDiscardDialog, setShowDiscardDialog] = useState(false);
    const [showDeleteDialog, setShowDeleteDialog] = useState(false);
    const [deleteTarget, setDeleteTarget] = useState<{ id: string; userRole: string; label: string } | null>(null);
    const [editingUser, setEditingUser] = useState<UserProfile | null>(null);
    const [searchQuery, setSearchQuery] = useState('');
    const [filterRole, setFilterRole] = useState<string>('All');
    const [filterStatus, setFilterStatus] = useState<string>('All');
    // Form state
    const [assignmentMode, setAssignmentMode] = useState<UserAssignmentMode>('department');
    const [formData, setFormData] = useState({
        fullName: '',
        email: '',
        userRole: 'operator' as UserProfile['userRole'],
        departmentId: '',
        floorPin: '',
        assignedApps: [] as DeptAppId[],
        status: 'Active' as UserProfile['status']
    });

    // Check if editing an admin
    const isEditingAdmin = editingUser?.userRole === 'admin';

    // Fetch departments once; reload users when factory changes
    React.useEffect(() => {
        void fetchSettings();
    }, [fetchSettings]);

    React.useEffect(() => {
        void fetchUsers();
    }, [factoryId]);

    const fetchUsers = async () => {
        if (!factoryId) {
            setUsers([]);
            setLoading(false);
            return;
        }
        setLoading(true);
        try {
            const { data, error } = await supabase
                .from('profiles')
                .select('*')
                .eq('factory_id', factoryId)
                .order('created_at', { ascending: false });
            
            if (error) throw error;
            
            const mappedUsers: UserProfile[] = (data || []).map(u => ({
                id: u.id,
                fullName: u.full_name || '',
                email: u.email || '',
                userRole: u.user_role || 'operator',
                factoryId: u.factory_id || '',
                status: u.status || 'Active',
                departmentId: u.department_id,
                employeeId: u.employee_id || '',
                floorPin: u.floor_pin || '',
                assignedApps: (u.assigned_apps as DeptAppId[]) || [],
                createdAt: u.created_at,
                updatedAt: u.updated_at
            }));
            
            setUsers(mappedUsers);
        } catch (error) {
            console.error('Error fetching users:', error);
            showNotification('Failed to fetch users', 'error');
        } finally {
            setLoading(false);
        }
    };

    const selectedDept = departments.find((d) => d.id === formData.departmentId);

    const patchFormData = (patch: Partial<typeof formData>) => {
        setPanelDirty(true);
        setFormData((prev) => ({ ...prev, ...patch }));
    };

    const forceClosePanel = () => {
        setShowPanel(false);
        setPanelDirty(false);
        setEditingUser(null);
        resetForm();
    };

    const requestClosePanel = () => {
        if (panelDirty) {
            setShowDiscardDialog(true);
            return;
        }
        forceClosePanel();
    };

    const cancelDiscardDialog = () => {
        setShowDiscardDialog(false);
    };

    const confirmDiscardPanel = () => {
        setShowDiscardDialog(false);
        forceClosePanel();
    };

    const confirmSaveAndClosePanel = async () => {
        const saved = editingUser ? await handleUpdateUser() : await handleCreateUser();
        if (saved) {
            setShowDiscardDialog(false);
        }
    };

    const handleCreateUser = async (): Promise<boolean> => {
        const dept = selectedDept;
        const validationError = validateFloorUserPayload({
            fullName: formData.fullName,
            email: formData.email,
            floorPin: formData.floorPin,
            departmentId: assignmentMode === 'factory_function' ? null : formData.departmentId,
            assignedApps: formData.assignedApps,
            deptApps: dept?.apps,
            entitlements: factoryEntitlements,
        });
        if (validationError) {
            showNotification(validationError, 'error');
            return false;
        }

        setSaving(true);
        try {
            if (!factoryId) throw new Error('No factory selected');

            const normalizedEmail = formData.email.trim().toLowerCase();
            const { data: existingEmail } = await supabase
                .from('profiles')
                .select('id')
                .eq('factory_id', factoryId)
                .ilike('email', normalizedEmail)
                .maybeSingle();
            if (existingEmail) {
                showNotification('A user with this email already exists in this factory', 'error');
                return false;
            }

            const assignedApps =
                assignmentMode === 'department'
                    ? sortAssignedApps(formData.assignedApps, availableApps)
                    : sortAssignedApps(formData.assignedApps);

            await createFactoryUser({
                factoryId,
                fullName: formData.fullName,
                email: normalizedEmail,
                floorPin: formData.floorPin,
                departmentId: assignmentMode === 'factory_function' ? null : formData.departmentId,
                assignedApps,
                userRole: formData.userRole,
                status: formData.status,
            });

            showNotification('User created successfully', 'success');
            forceClosePanel();
            void fetchUsers();
            return true;
        } catch (error: unknown) {
            console.error('Error creating user:', error);
            const msg = error instanceof Error ? error.message : 'Failed to create user';
            const hint =
              msg.includes('Function not found') ||
              msg.includes('Failed to send a request to the Edge Function')
                ? ' Deploy Supabase Edge Functions: supabase functions deploy admin-create-user admin-delete-user'
                : '';
            showNotification(msg + hint, 'error');
            return false;
        } finally {
            setSaving(false);
        }
    };

    const requestDeleteUser = (userId: string, userRole: string, label: string) => {
        if (userId === currentUser?.id) {
            showNotification('You cannot delete your own account', 'error');
            return;
        }
        if (userRole === 'admin') {
            showNotification('Cannot delete admin users', 'error');
            return;
        }
        setDeleteTarget({ id: userId, userRole, label });
        setShowDeleteDialog(true);
    };

    const cancelDeleteUser = () => {
        setShowDeleteDialog(false);
        setDeleteTarget(null);
    };

    const confirmDeleteUser = async () => {
        if (!deleteTarget) return;
        const { id: userId } = deleteTarget;

        setSaving(true);
        try {
            if (!factoryId) throw new Error('No factory selected');

            const { authDeleted } = await deleteFactoryUser(userId, factoryId);

            showNotification(
                authDeleted
                    ? 'User deleted successfully'
                    : 'Profile removed. Auth account may still exist — configure admin API for full delete.',
                authDeleted ? 'success' : 'error',
            );
            setShowDeleteDialog(false);
            setDeleteTarget(null);
            forceClosePanel();
            void fetchUsers();
        } catch (error: unknown) {
            console.error('Error deleting user:', error);
            const message = error instanceof Error ? error.message : 'Failed to delete user';
            showNotification(message, 'error');
        } finally {
            setSaving(false);
        }
    };

    const handleDeleteUser = (userId: string, userRole: string, label: string) => {
        requestDeleteUser(userId, userRole, label);
    };

    const handleToggleStatus = async (userId: string, currentStatus: string) => {
        if (userId === currentUser?.id) {
            showNotification('You cannot deactivate your own account', 'error');
            return;
        }
        const newStatus = currentStatus === 'Active' ? 'Inactive' : 'Active';
        try {
            if (!factoryId) throw new Error('No factory selected');
            const { error } = await supabase
                .from('profiles')
                .update({ status: newStatus })
                .eq('id', userId)
                .eq('factory_id', factoryId);
            
            if (error) throw error;

            // Update local state
            setUsers(prev => prev.map(u => u.id === userId ? { ...u, status: newStatus as 'Active' | 'Inactive' } : u));
            showNotification(`User ${newStatus === 'Active' ? 'activated' : 'deactivated'}`, 'success');
        } catch (error: any) {
            console.error('Error toggling user status:', error);
            showNotification(error.message || 'Failed to update status', 'error');
        }
    };

    const openEditPanel = (user: UserProfile) => {
        setEditingUser(user);
        const mode = inferAssignmentMode(user.departmentId);
        setAssignmentMode(mode);
        const dept = departments.find((d) => d.id === user.departmentId);
        const assignedApps = mode === 'factory_function'
            ? clampAssignedAppsToFactoryFunction(user.assignedApps, factoryEntitlements)
            : clampAssignedAppsToDepartment(user.assignedApps, dept?.apps, factoryEntitlements);
        setFormData({
            fullName: user.fullName,
            email: user.email,
            userRole: user.userRole,
            departmentId: user.departmentId || '',
            floorPin: user.floorPin,
            assignedApps,
            status: user.status
        });
        setPanelDirty(false);
        setShowPanel(true);
    };

    const openAddPanel = () => {
        setEditingUser(null);
        resetForm();
        setSearchQuery('');
        setPanelDirty(false);
        setShowPanel(true);
    };

    const handleUpdateUser = async (): Promise<boolean> => {
        if (!editingUser) return false;

        if (editingUser.id === currentUser?.id && formData.status === 'Inactive') {
            showNotification('You cannot deactivate your own account', 'error');
            return false;
        }

        if (editingUser.userRole !== 'admin' && isFloorLoginRole(formData.userRole)) {
            const validationError = validateFloorUserPayload({
                fullName: formData.fullName,
                email: formData.email,
                floorPin: formData.floorPin,
                departmentId: assignmentMode === 'factory_function' ? null : formData.departmentId,
                assignedApps: formData.assignedApps,
                deptApps: selectedDept?.apps,
                entitlements: factoryEntitlements,
            });
            if (validationError) {
                showNotification(validationError, 'error');
                return false;
            }
        }

        setSaving(true);
        try {
            if (!factoryId) throw new Error('No factory selected');

            const updateData: Record<string, unknown> = {
                full_name: formData.fullName,
                status: formData.status
            };

            // Only update these fields for non-admin users
            if (editingUser.userRole !== 'admin') {
                updateData.department_id = assignmentMode === 'factory_function' ? null : (formData.departmentId || null);
                updateData.floor_pin = formData.floorPin || null;
                updateData.assigned_apps =
                    assignmentMode === 'department'
                        ? sortAssignedApps(formData.assignedApps, availableApps)
                        : sortAssignedApps(formData.assignedApps);
                updateData.user_role = formData.userRole;
            }

            const { error } = await supabase
                .from('profiles')
                .update(updateData)
                .eq('id', editingUser.id)
                .eq('factory_id', factoryId);

            if (error) throw error;

            showNotification('User updated successfully', 'success');
            forceClosePanel();
            void fetchUsers();
            return true;
        } catch (error: unknown) {
            console.error('Error updating user:', error);
            const message = error instanceof Error ? error.message : 'Failed to update user';
            showNotification(message, 'error');
            return false;
        } finally {
            setSaving(false);
        }
    };

    const resetForm = () => {
        setAssignmentMode('department');
        setFormData({
            fullName: '',
            email: '',
            userRole: 'operator',
            departmentId: '',
            floorPin: '',
            assignedApps: [],
            status: 'Active'
        });
    };

    const availableApps = appsForAssignmentMode(assignmentMode, selectedDept?.apps, factoryEntitlements);
    const factoryFunctionEnabled = isFactoryFunctionEnabled(factoryEntitlements);
    const shipmentQaSelected = hasShipmentQaApps(formData.assignedApps);

    const toggleAssignedApp = (appId: DeptAppId) => {
        setPanelDirty(true);
        setFormData((prev) => {
            const next = prev.assignedApps.includes(appId)
                ? prev.assignedApps.filter((a) => a !== appId)
                : [...prev.assignedApps, appId];
            const order =
                assignmentMode === 'department'
                    ? departmentFloorApps(selectedDept?.apps, factoryEntitlements)
                    : undefined;
            return {
                ...prev,
                assignedApps: sortAssignedApps(next, order),
            };
        });
    };

    // Get unique roles from users data
    const uniqueRoles = useMemo(() => {
        const roles = Array.from(new Set(users.map(u => u.userRole).filter(Boolean)));
        return roles.sort();
    }, [users]);

    const filteredUsers = useMemo(() => {
        return users.filter(u => {
            const matchesSearch = u.fullName.toLowerCase().includes(searchQuery.toLowerCase()) ||
                                  u.email.toLowerCase().includes(searchQuery.toLowerCase());
            const matchesRole = filterRole === 'All' || u.userRole === filterRole;
            const matchesStatus = filterStatus === 'All' || u.status === filterStatus;
            return matchesSearch && matchesRole && matchesStatus;
        });
    }, [users, searchQuery, filterRole, filterStatus]);

    return (
        <PageShell loading={loading} skeleton="table" className="w-full pb-20">

            {/* Table with integrated filters */}
            <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
                {/* Filters Bar */}
                <div className="px-4 py-2 border-b border-slate-100 flex items-center justify-between">
                    {/* Search - Left Side */}
                    <div className="flex items-center gap-1">
                        <Search size={14} className="text-slate-400" />
                        <input 
                            className="text-xs bg-transparent border-b border-slate-200 focus:border-blue-500 focus:outline-none py-1 w-80" 
                            placeholder="Search by name or email..." 
                            value={searchQuery}
                            onChange={(e) => setSearchQuery(e.target.value)}
                            autoComplete="off"
                        />
                    </div>
                    {/* Filters - Right Side */}
                    <div className="flex items-center gap-2">
                        <SelectDropdown
                            value={filterRole}
                            onChange={setFilterRole}
                            options={[
                                { value: 'All', label: 'All roles' },
                                ...uniqueRoles.map((role) => ({ value: role, label: role })),
                            ]}
                            icon={Shield}
                            className="w-[7.5rem]"
                        />
                        <SelectDropdown
                            value={filterStatus}
                            onChange={setFilterStatus}
                            options={[
                                { value: 'All', label: 'All status' },
                                { value: 'Active', label: 'Active' },
                                { value: 'Inactive', label: 'Inactive' },
                            ]}
                            icon={Filter}
                            className="w-[7rem]"
                        />
                        <button
                            onClick={openAddPanel}
                            className="p-1.5 hover:bg-blue-50 rounded-lg transition-colors text-blue-600"
                            title="Add New User"
                        >
                            <Plus size={16} />
                        </button>
                    </div>
                </div>
                <div className="overflow-x-auto">
                    <table className="w-full text-[10px] text-left border-collapse">
                        <thead className="bg-slate-50 text-slate-500 font-semibold text-[9px] uppercase border-b border-slate-200">
                            <tr>
                                <th className="px-4 py-3 text-left">Name</th>
                                <th className="px-4 py-3 text-center">Email</th>
                                <th className="px-4 py-3 text-center">Role</th>
                                <th className="px-4 py-3 text-center">Department</th>
                                <th className="px-4 py-3 text-center">Floor Apps</th>
                                <th className="px-4 py-3 text-center">Active</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100">
                            {filteredUsers.map(user => {
                                const dept = departments.find(d => d.id === user.departmentId);
                                return (
                                    <tr 
                                        key={user.id} 
                                        className="hover:bg-slate-50 cursor-pointer group"
                                        onClick={() => openEditPanel(user)}
                                    >
                                        <td className="px-4 py-3 text-left">
                                            <div className="flex items-center gap-2">
                                                <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${user.userRole === 'admin' ? 'bg-blue-600 text-white' : 'bg-slate-100 text-slate-600'}`}>
                                                    {user.userRole === 'admin' ? <Shield size={14} /> : <User size={14} />}
                                                </div>
                                                <span className="font-medium text-slate-900">{user.fullName}</span>
                                            </div>
                                        </td>
                                        <td className="px-4 py-3 text-center text-slate-600">{user.email}</td>
                                        <td className="px-4 py-3 text-center text-slate-600 capitalize">{user.userRole.replace(/_/g, ' ')}</td>
                                        <td className="px-4 py-3 text-center text-slate-600">{user.userRole === 'admin' ? '-' : (dept?.name || '-')}</td>
                                        <td className="px-4 py-3 text-center text-slate-500 text-[9px]">
                                            {user.userRole === 'admin' ? '-' : (
                                                user.assignedApps.length
                                                    ? formatAssignedAppsLabel(user.assignedApps)
                                                    : '-'
                                            )}
                                        </td>
                                        <td className="px-4 py-3 text-center">
                                            <div className="flex items-center justify-center gap-2">
                                                {user.userRole !== 'admin' ? (
                                                    <button
                                                        onClick={(e) => { e.stopPropagation(); handleToggleStatus(user.id, user.status); }}
                                                        className={`relative inline-flex h-5 w-9 items-center rounded-full transition-colors ${user.status === 'Active' ? 'bg-emerald-500' : 'bg-slate-300'}`}
                                                        title={user.status === 'Active' ? 'Click to deactivate' : 'Click to activate'}
                                                    >
                                                        <span className={`inline-block h-3.5 w-3.5 transform rounded-full bg-white shadow-sm transition-transform ${user.status === 'Active' ? 'translate-x-5' : 'translate-x-1'}`} />
                                                    </button>
                                                ) : (
                                                    <span className="inline-flex items-center gap-1 text-emerald-600 text-[10px] font-medium">
                                                        <CheckCircle size={14} /> Active
                                                    </span>
                                                )}
                                            </div>
                                        </td>
                                    </tr>
                                );
                            })}
                            {filteredUsers.length === 0 && (
                                <tr>
                                    <td colSpan={6} className="px-4 py-12 text-center text-slate-400">
                                        <Users size={48} className="mx-auto mb-3 text-slate-300" />
                                        <p>No users found</p>
                                    </td>
                                </tr>
                            )}
                        </tbody>
                    </table>
                </div>
            </div>

            {/* Side Panel - Add/Edit User */}
            {showPanel && (
                <>
                    <div className="fixed inset-0 bg-black/40 z-40 animate-in fade-in duration-200" onClick={requestClosePanel} />
                    <div className="fixed right-0 top-0 h-full w-96 bg-white shadow-2xl z-50 animate-in slide-in-from-right duration-300 flex flex-col">
                        {/* Header */}
                        <div className="p-5 border-b border-slate-100 bg-slate-50">
                            <div className="flex items-center justify-between">
                                <div className="flex items-center gap-3">
                                    <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${editingUser ? (isEditingAdmin ? 'bg-blue-600 text-white' : 'bg-slate-200 text-slate-600') : 'bg-emerald-100 text-emerald-600'}`}>
                                        {editingUser ? (isEditingAdmin ? <Shield size={20} /> : <User size={20} />) : <Plus size={20} />}
                                    </div>
                                    <div>
                                        <h3 className="font-bold text-slate-900">{editingUser ? 'Edit User' : 'Add New User'}</h3>
                                        <p className="text-[10px] text-slate-400">{editingUser ? editingUser.email : 'Create a new account'}</p>
                                    </div>
                                </div>
                                <div className="flex items-center gap-1">
                                    {editingUser && !isEditingAdmin && (
                                        <button 
                                            onClick={() => handleDeleteUser(editingUser.id, editingUser.userRole, editingUser.fullName || editingUser.email)}
                                            className="p-2 hover:bg-red-100 rounded-lg transition-colors text-slate-400 hover:text-red-500"
                                            title="Delete User"
                                        >
                                            <Trash2 size={18} />
                                        </button>
                                    )}
                                    <button onClick={requestClosePanel} className="p-2 hover:bg-slate-200 rounded-lg transition-colors">
                                        <X size={18} className="text-slate-500" />
                                    </button>
                                </div>
                            </div>
                        </div>

                        {/* Admin Badge */}
                        {isEditingAdmin && (
                            <div className="mx-5 mt-4 p-3 bg-blue-50 border border-blue-200 rounded-lg flex items-center gap-2">
                                <Lock size={14} className="text-blue-600" />
                                <span className="text-xs text-blue-700 font-medium">Admin account - Limited editing available</span>
                            </div>
                        )}

                        {/* Form */}
                        <form className="flex-1 overflow-y-auto p-5 space-y-4" autoComplete="off" onSubmit={(e) => e.preventDefault()}>
                            {/* Full Name */}
                            <div>
                                <label className="block text-xs font-semibold text-slate-600 mb-1.5">Full Name</label>
                                <div className="relative">
                                    <User className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
                                    <input
                                        type="text"
                                        className="pl-10 pr-4 py-2.5 w-full border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-100 focus:border-blue-400 text-xs"
                                        placeholder="John Doe"
                                        value={formData.fullName}
                                        onChange={(e) => patchFormData({ fullName: e.target.value })}
                                    />
                                </div>
                            </div>

                            {!isEditingAdmin && (
                                <p className="text-[10px] text-slate-500 bg-slate-50 border border-slate-200 rounded-lg px-3 py-2">
                                    Floor users sign in on the mobile app with <strong>email and PIN</strong>.
                                </p>
                            )}

                            {/* Email - Read only when editing */}
                            <div>
                                <label className="block text-xs font-semibold text-slate-600 mb-1.5">Email</label>
                                <div className="relative">
                                    <Mail className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
                                    <input
                                        type="email"
                                        className={`pl-10 pr-4 py-2.5 w-full border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-100 focus:border-blue-400 text-xs ${editingUser ? 'bg-slate-50 text-slate-500' : ''}`}
                                        placeholder="john@example.com"
                                        value={formData.email}
                                        onChange={(e) => patchFormData({ email: e.target.value })}
                                        disabled={!!editingUser}
                                        autoComplete="off"
                                    />
                                </div>
                            </div>

                            {isEditingAdmin ? (
                                <div>
                                    <label className="block text-xs font-semibold text-slate-600 mb-1.5">App Role</label>
                                    <div className="px-4 py-2.5 bg-blue-50 border border-blue-200 rounded-lg text-xs text-blue-700 font-medium flex items-center gap-2">
                                        <Shield size={14} /> Admin
                                    </div>
                                </div>
                            ) : (
                                <>
                                    <div>
                                        <label className="block text-xs font-semibold text-slate-600 mb-1.5">Assignment</label>
                                        <div className="grid grid-cols-2 gap-2 mb-3">
                                            <button
                                                type="button"
                                                onClick={() => {
                                                    setPanelDirty(true);
                                                    setAssignmentMode('department');
                                                    const dept = departments.find((d) => d.id === formData.departmentId);
                                                    setFormData((prev) => ({
                                                        ...prev,
                                                        assignedApps: defaultAssignedApps(dept?.apps, factoryEntitlements),
                                                    }));
                                                }}
                                                className={`px-3 py-2 text-xs rounded-lg border ${
                                                    assignmentMode === 'department'
                                                        ? 'border-blue-400 bg-blue-50 text-blue-800'
                                                        : 'border-slate-200'
                                                }`}
                                            >
                                                Floor department
                                            </button>
                                            {factoryFunctionEnabled && (
                                            <button
                                                type="button"
                                                onClick={() => {
                                                    setPanelDirty(true);
                                                    setAssignmentMode('factory_function');
                                                    setFormData((prev) => ({
                                                        ...prev,
                                                        departmentId: '',
                                                        userRole: 'quality_manager',
                                                        assignedApps: clampAssignedAppsToFactoryFunction(
                                                            defaultShipmentFunctionApps(factoryEntitlements),
                                                            factoryEntitlements,
                                                        ),
                                                    }));
                                                }}
                                                className={`px-3 py-2 text-xs rounded-lg border ${
                                                    assignmentMode === 'factory_function'
                                                        ? 'border-blue-400 bg-blue-50 text-blue-800'
                                                        : 'border-slate-200'
                                                }`}
                                            >
                                                {SHIPMENT_QA_LABEL}
                                            </button>
                                            )}
                                        </div>
                                    </div>

                                    {assignmentMode === 'department' && (
                                        <div>
                                            <label className="block text-xs font-semibold text-slate-600 mb-1.5">Department</label>
                                            <select
                                                className="w-full px-3 py-2.5 text-xs border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-100 focus:border-blue-400"
                                                value={formData.departmentId}
                                                onChange={(e) => {
                                                    const deptId = e.target.value;
                                                    const dept = departments.find((d) => d.id === deptId);
                                                    setPanelDirty(true);
                                                    setFormData({
                                                        ...formData,
                                                        departmentId: deptId,
                                                        userRole: 'operator',
                                                        assignedApps: defaultAssignedApps(dept?.apps, factoryEntitlements),
                                                    });
                                                }}
                                            >
                                                <option value="">Select department...</option>
                                                {departments.map(dept => (
                                                    <option key={dept.id} value={dept.id}>{dept.name}</option>
                                                ))}
                                            </select>
                                        </div>
                                    )}

                                    {assignmentMode === 'factory_function' && (
                                        <p className="text-[10px] text-slate-500 bg-violet-50 border border-violet-100 rounded-lg px-3 py-2">
                                            No department. User handles shipment logging and rejection for any order.
                                        </p>
                                    )}

                                    {assignmentMode === 'factory_function' && factoryFunctionEnabled && (
                                        <div>
                                            <label className="block text-xs font-semibold text-slate-600 mb-1.5">Floor App</label>
                                            <button
                                                type="button"
                                                onClick={() => {
                                                    setPanelDirty(true);
                                                    setFormData((prev) => ({
                                                        ...prev,
                                                        assignedApps: shipmentQaSelected
                                                            ? []
                                                            : clampAssignedAppsToFactoryFunction(
                                                                defaultShipmentFunctionApps(factoryEntitlements),
                                                                factoryEntitlements,
                                                            ),
                                                    }));
                                                }}
                                                className={`flex items-start gap-3 p-3 rounded-lg border text-left transition-colors w-full ${
                                                    shipmentQaSelected
                                                        ? 'border-blue-400 bg-blue-50'
                                                        : 'border-slate-200 bg-white hover:bg-slate-50'
                                                }`}
                                            >
                                                <div className={`w-4 h-4 rounded border flex-shrink-0 mt-0.5 flex items-center justify-center ${
                                                    shipmentQaSelected ? 'bg-blue-600 border-blue-600 text-white' : 'border-slate-300'
                                                }`}>
                                                    {shipmentQaSelected && <Check size={10} strokeWidth={3} />}
                                                </div>
                                                <div>
                                                    <div className="text-xs font-semibold text-slate-800">{SHIPMENT_QA_LABEL}</div>
                                                    <div className="text-[10px] text-slate-500 mt-0.5">
                                                        Shipment and rejection capture for the factory
                                                    </div>
                                                </div>
                                            </button>
                                        </div>
                                    )}

                                    {assignmentMode === 'department' && !isEditingAdmin && availableApps.length > 0 && (
                                        <div>
                                            <label className="block text-xs font-semibold text-slate-600 mb-1.5">Floor Apps</label>
                                            <p className="text-[10px] text-slate-400 mb-2">
                                                Apps enabled for this department and factory.
                                            </p>
                                            <div className="grid gap-2">
                                                {availableApps.map((appId) => {
                                                    const opt = DEPT_APP_OPTIONS.find((o) => o.id === appId);
                                                    const checked = formData.assignedApps.includes(appId);
                                                    return (
                                                        <button
                                                            key={appId}
                                                            type="button"
                                                            onClick={() => toggleAssignedApp(appId)}
                                                            className={`flex items-start gap-3 p-3 rounded-lg border text-left transition-colors ${
                                                                checked
                                                                    ? 'border-blue-400 bg-blue-50'
                                                                    : 'border-slate-200 bg-white hover:bg-slate-50'
                                                            }`}
                                                        >
                                                            <div className={`w-4 h-4 rounded border flex-shrink-0 mt-0.5 flex items-center justify-center ${
                                                                checked ? 'bg-blue-600 border-blue-600 text-white' : 'border-slate-300'
                                                            }`}>
                                                                {checked && <Check size={10} strokeWidth={3} />}
                                                            </div>
                                                            <div>
                                                                <div className="text-xs font-semibold text-slate-800">{opt?.label ?? labelForDeptApp(appId)}</div>
                                                                {opt?.description && (
                                                                    <div className="text-[10px] text-slate-500 mt-0.5">{opt.description}</div>
                                                                )}
                                                            </div>
                                                        </button>
                                                    );
                                                })}
                                            </div>
                                        </div>
                                    )}

                                    {!isEditingAdmin && (
                                        <div>
                                            <label className="block text-xs font-semibold text-slate-600 mb-1.5">Floor PIN (4 digits)</label>
                                            <input
                                                type="text"
                                                inputMode="numeric"
                                                maxLength={4}
                                                className="w-full px-3 py-2.5 text-xs border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-100 focus:border-blue-400 font-mono tracking-widest"
                                                placeholder="e.g. 1234"
                                                value={formData.floorPin}
                                                onChange={(e) => patchFormData({ floorPin: e.target.value.replace(/\D/g, '').slice(0, 4) })}
                                            />
                                        </div>
                                    )}
                                </>
                            )}

                            {/* Status */}
                            <div>
                                <label className="block text-xs font-semibold text-slate-600 mb-1.5">Status</label>
                                <div className="flex gap-2">
                                    <button
                                        type="button"
                                        onClick={() => patchFormData({ status: 'Active' })}
                                        className={`flex-1 py-2.5 rounded-lg text-[10px] font-medium transition-all ${formData.status === 'Active' ? 'bg-emerald-100 text-emerald-700 border-2 border-emerald-300' : 'bg-slate-50 text-slate-500 border border-slate-200 hover:bg-slate-100'}`}
                                    >
                                        <CheckCircle size={14} className="inline mr-1" /> Active
                                    </button>
                                    <button
                                        type="button"
                                        onClick={() => patchFormData({ status: 'Inactive' })}
                                        className={`flex-1 py-2.5 rounded-lg text-[10px] font-medium transition-all ${formData.status === 'Inactive' ? 'bg-red-100 text-red-700 border-2 border-red-300' : 'bg-slate-50 text-slate-500 border border-slate-200 hover:bg-slate-100'}`}
                                    >
                                        <XCircle size={14} className="inline mr-1" /> Inactive
                                    </button>
                                </div>
                            </div>
                        </form>

                        {/* Footer */}
                        <div className="p-5 border-t border-slate-100 bg-slate-50 space-y-2">
                            <Button
                                onClick={editingUser ? handleUpdateUser : handleCreateUser}
                                disabled={saving}
                                className="w-full"
                            >
                                {saving ? 'Saving...' : (editingUser ? 'Save Changes' : 'Create User')}
                            </Button>
                            <Button
                                variant="secondary"
                                onClick={requestClosePanel}
                                className="w-full"
                            >
                                Cancel
                            </Button>
                        </div>
                    </div>
                </>
            )}

            <Modal isOpen={showDiscardDialog} onClose={cancelDiscardDialog}>
                <div className="relative">
                    <button
                        onClick={cancelDiscardDialog}
                        className="absolute top-4 right-4 text-slate-400 hover:text-red-600 transition-colors p-1 hover:bg-red-50 rounded-full"
                    >
                        <X size={20} />
                    </button>

                    <div className="flex flex-col items-center p-8 pb-4 text-center">
                        <div className="w-16 h-16 bg-amber-100 text-amber-600 rounded-2xl flex items-center justify-center mb-4 shadow-sm ring-4 ring-amber-50">
                            <AlertTriangle size={32} />
                        </div>
                        <h3 className="text-base font-bold text-slate-900 mb-2">Unsaved Changes</h3>
                        <p className="text-slate-500 text-xs max-w-[260px] leading-relaxed">
                            You have unsaved modifications. What would you like to do?
                        </p>
                    </div>

                    <div className="p-6 pt-2 flex flex-col gap-3">
                        <Button
                            onClick={confirmSaveAndClosePanel}
                            disabled={saving}
                            className="w-full shadow-lg shadow-blue-100 py-2.5 text-xs"
                        >
                            {saving ? <Loader2 size={14} className="animate-spin mx-auto" /> : 'Save Changes'}
                        </Button>
                        <Button
                            variant="danger-light"
                            onClick={confirmDiscardPanel}
                            className="w-full text-xs"
                        >
                            Discard & Close
                        </Button>
                    </div>
                </div>
            </Modal>

            <Modal isOpen={showDeleteDialog} onClose={cancelDeleteUser}>
                <div className="relative">
                    <button
                        onClick={cancelDeleteUser}
                        className="absolute top-4 right-4 text-slate-400 hover:text-red-600 transition-colors p-1 hover:bg-red-50 rounded-full"
                    >
                        <X size={20} />
                    </button>

                    <div className="flex flex-col items-center p-8 pb-4 text-center">
                        <div className="w-16 h-16 bg-red-100 text-red-600 rounded-2xl flex items-center justify-center mb-4 shadow-sm ring-4 ring-red-50">
                            <Trash2 size={32} />
                        </div>
                        <h3 className="text-base font-bold text-slate-900 mb-2">Delete User?</h3>
                        <p className="text-slate-500 text-xs max-w-[280px] leading-relaxed">
                            <span className="font-medium text-slate-700">{deleteTarget?.label}</span> will be
                            permanently removed. This cannot be undone.
                        </p>
                    </div>

                    <div className="p-6 pt-2 flex flex-col gap-3">
                        <Button
                            variant="danger"
                            onClick={confirmDeleteUser}
                            disabled={saving}
                            className="w-full py-2.5 text-xs"
                        >
                            {saving ? <Loader2 size={14} className="animate-spin mx-auto" /> : 'Delete'}
                        </Button>
                        <Button variant="secondary" onClick={cancelDeleteUser} className="w-full text-xs">
                            Cancel
                        </Button>
                    </div>
                </div>
            </Modal>
        </PageShell>
    );
};
