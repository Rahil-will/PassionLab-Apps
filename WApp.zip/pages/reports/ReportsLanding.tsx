import React from 'react';
import { BarChart3, Shirt } from 'lucide-react';
import { useNavigationStore } from '../../stores';
import { RoutePath } from '../../types';
import { PageShell } from '../../components/layout/PageShell';

const CARDS = [
  {
    route: RoutePath.REPORTS_DAY,
    title: 'Day Report',
    subtitle: 'Department hourly output, handovers, and KPIs by date range',
    icon: BarChart3,
  },
  {
    route: RoutePath.REPORTS_STYLE,
    title: 'Style Report',
    subtitle: 'Full lifecycle and daily charts per colorway',
    icon: Shirt,
  },
] as const;

export const ReportsLanding: React.FC = () => {
  const navigate = useNavigationStore((s) => s.navigate);

  return (
    <PageShell className="pb-20">
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {CARDS.map(({ route, title, subtitle, icon: Icon }) => (
          <button
            key={route}
            type="button"
            onClick={() => navigate(route)}
            className="text-left bg-white border border-slate-200 rounded-2xl shadow-sm p-6 hover:border-slate-300 hover:shadow-md transition-all"
          >
            <div className="w-10 h-10 rounded-xl bg-slate-100 text-slate-700 flex items-center justify-center mb-4">
              <Icon size={20} strokeWidth={1.75} />
            </div>
            <h2 className="text-sm font-semibold text-slate-800">{title}</h2>
            <p className="text-xs text-slate-500 mt-1">{subtitle}</p>
          </button>
        ))}
      </div>
    </PageShell>
  );
};
