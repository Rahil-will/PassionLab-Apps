import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { format } from 'date-fns';
import { Download, Factory, RefreshCw } from 'lucide-react';
import { useNavigationStore } from '../../stores';
import { Button, Card, SelectDropdown } from '../../components/ui';
import { PageShell } from '../../components/layout/PageShell';
import { ReportToolbar } from '../../components/reports/ReportToolbar';
import { DayDeptCard } from '../../components/reports/DayDeptCard';
import { DateRangePicker, type DateRangeValue } from '../../components/DateRangePicker';
import { filterProductionDepartments } from '../../lib/departmentFilters';
import { downloadExcelWorkbook, type ExcelSheet } from '../../lib/csvExport';
import {
  orderExistsInMeta,
  resolveRouteColorwayId,
  resolveRouteOrderId,
} from '../../lib/reportPageUtils';
import {
  computeDayDeptMetricsFromRows,
  dayHandoverStatusLabel,
  fetchColorwayLabels,
  fetchDayResourceHourReportRange,
  fetchReportMeta,
  type ColorwayLabel,
  type DayHandoverSummary,
  type DayResourceHourReport,
  type DayResourceHourRow,
  type DayShiftHourSection,
  type ReportMeta,
} from '../../lib/mesReportsApi';

type DeptLoadState =
  | { status: 'loading' }
  | { status: 'error'; message: string }
  | { status: 'ok'; report: DayResourceHourReport };

const PLACEHOLDER_DEPT = '__loading__';

function todayRange(): DateRangeValue {
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const iso = today.toISOString();
  return { startDate: iso, endDate: iso };
}

function toYmd(iso: string): string {
  return format(new Date(iso), 'yyyy-MM-dd');
}

function matchesSearch(
  query: string,
  styleName: string,
  poNumber: string,
  styleRef = '',
  buyerName = '',
): boolean {
  if (!query.trim()) return true;
  const q = query.trim().toLowerCase();
  return (
    styleName.toLowerCase().includes(q) ||
    poNumber.toLowerCase().includes(q) ||
    styleRef.toLowerCase().includes(q) ||
    buyerName.toLowerCase().includes(q)
  );
}

function sortDayRows(rows: DayResourceHourRow[]): DayResourceHourRow[] {
  return [...rows].sort((a, b) => {
    const da = a.logDate ?? '';
    const db = b.logDate ?? '';
    if (da !== db) return da.localeCompare(db);
    return (
      a.resourceName.localeCompare(b.resourceName) ||
      a.styleName.localeCompare(b.styleName) ||
      a.colorName.localeCompare(b.colorName)
    );
  });
}

function filterRows(
  rows: DayResourceHourRow[],
  searchQuery: string,
  linkOrderId: string,
  linkColorwayId: string,
): DayResourceHourRow[] {
  return rows.filter((row) => {
    if (linkOrderId && row.orderId !== linkOrderId) return false;
    if (linkColorwayId && row.colorwayId !== linkColorwayId) return false;
    return matchesSearch(searchQuery, row.styleName, row.poNumber, row.styleRef, row.buyerName);
  });
}

function handoverSheetRows(
  handoverByDay: Array<{ date: string; handover: DayHandoverSummary }>,
): Array<Array<string | number | null | undefined>> {
  const rows: Array<Array<string | number | null | undefined>> = [];
  for (const { date, handover } of handoverByDay) {
    if (handover.received.length === 0 && handover.sent.length === 0) continue;
    rows.push([`— ${date} —`, '', '', '', '', '']);
    for (const row of handover.received) {
      rows.push([
        'Received',
        row.fromDepartmentName,
        row.styleName,
        row.colorName,
        dayHandoverStatusLabel(row.status),
        row.qty,
      ]);
    }
    for (const row of handover.sent) {
      rows.push([
        'Sent',
        row.toDepartmentName,
        row.styleName,
        row.colorName,
        dayHandoverStatusLabel(row.status),
        row.qty,
      ]);
    }
  }
  return rows;
}

function exportDeptWorkbook(
  deptName: string,
  dateFrom: string,
  dateTo: string,
  report: DayResourceHourReport,
  visibleRows: DayResourceHourRow[],
): void {
  const handoverByDay =
    report.handoverByDay ??
    (report.handover ? [{ date: dateFrom, handover: report.handover }] : []);

  const hours = report.hourColumns;
  const multiDay =
    visibleRows.some((r) => r.logDate) && new Set(visibleRows.map((r) => r.logDate)).size > 1;

  const hourlyHeaders = [
    ...(multiDay ? ['Date'] : []),
    'Resource',
    'Style',
    'Style Ref',
    'Buyer',
    'PO',
    'Color',
    'WF',
    'Planned End',
    'Hr Target',
    ...hours.flatMap((h) => [`${h} Actual`, `${h} Target`]),
    'Total',
    'Eff %',
    'Productivity',
  ];

  const hourlyRows: Array<Array<string | number | null | undefined>> = [];
  let lastDate: string | undefined;
  for (const row of visibleRows) {
    if (multiDay && row.logDate && row.logDate !== lastDate) {
      hourlyRows.push([`— ${row.logDate} —`]);
      lastDate = row.logDate;
    }
    hourlyRows.push([
      ...(multiDay ? [row.logDate ?? ''] : []),
      row.resourceName,
      row.styleName,
      row.styleRef,
      row.buyerName,
      row.poNumber,
      row.colorName,
      row.workforce ?? '',
      row.plannedEndDate ?? '',
      row.hourlyTarget || '',
      ...hours.flatMap((h) => [row.hours[h] || 0, row.hourTargets[h] || 0]),
      row.total,
      row.efficiencyPct != null ? row.efficiencyPct.toFixed(1) : '',
      row.productivity != null ? row.productivity.toFixed(1) : '',
    ]);
  }

  if (visibleRows.length > 0) {
    const metrics = computeDayDeptMetricsFromRows(visibleRows);
    hourlyRows.push([
      ...(multiDay ? [''] : []),
      'Totals',
      '',
      '',
      '',
      '',
      '',
      metrics.workforce > 0 ? metrics.workforce : '',
      '',
      '',
      ...hours.flatMap((h) => {
        let actual = 0;
        for (const row of visibleRows) actual += row.hours[h] || 0;
        return [actual, ''];
      }),
      visibleRows.reduce((s, r) => s + r.total, 0),
      metrics.efficiency != null ? metrics.efficiency.toFixed(1) : '',
      metrics.productivity != null ? metrics.productivity.toFixed(1) : '',
    ]);
  }

  const sheets: ExcelSheet[] = [
    {
      name: 'Handovers',
      headers: ['Direction', 'Department', 'Style', 'Color', 'Status', 'Qty'],
      rows: handoverSheetRows(handoverByDay),
    },
    {
      name: 'Hourly Output',
      headers: hourlyHeaders,
      rows: hourlyRows,
    },
  ];

  const slug = deptName.replace(/\s+/g, '-').toLowerCase();
  const rangeSlug = dateFrom === dateTo ? dateFrom : `${dateFrom}_to_${dateTo}`;
  downloadExcelWorkbook(`day-report-${slug}-${rangeSlug}`, sheets);
}

export const DayReport: React.FC = () => {
  const { factoryId, routeParams } = useNavigationStore();
  const [dateRange, setDateRange] = useState<DateRangeValue>(todayRange);
  const dateFrom = toYmd(dateRange.startDate);
  const dateTo = toYmd(dateRange.endDate);
  const [meta, setMeta] = useState<ReportMeta | null>(null);
  const [colorwayLabels, setColorwayLabels] = useState<ColorwayLabel[]>([]);
  const [metaLoading, setMetaLoading] = useState(true);
  const [deptStates, setDeptStates] = useState<Record<string, DeptLoadState>>({});
  const [selectedDeptId, setSelectedDeptId] = useState(PLACEHOLDER_DEPT);
  const [reportRefreshing, setReportRefreshing] = useState(false);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [linkOrderId, setLinkOrderId] = useState('');
  const [linkColorwayId, setLinkColorwayId] = useState('');
  const [lastUpdated, setLastUpdated] = useState<Date | null>(null);

  const departments = useMemo(
    () => (meta ? filterProductionDepartments(meta.departments) : []),
    [meta],
  );

  const deptOptions = useMemo(
    () => departments.map((d) => ({ value: d.id, label: d.name })),
    [departments],
  );

  const selectedDept = useMemo(
    () => departments.find((d) => d.id === selectedDeptId) ?? null,
    [departments, selectedDeptId],
  );

  useEffect(() => {
    setMeta(null);
    setColorwayLabels([]);
    setDeptStates({});
    setSelectedDeptId(PLACEHOLDER_DEPT);
    setSearchQuery('');
    setLinkOrderId('');
    setLinkColorwayId('');
    setLoadError(null);
    setLastUpdated(null);
    setDateRange(todayRange());
    setMetaLoading(true);
  }, [factoryId]);

  useEffect(() => {
    if (departments.length > 0 && selectedDeptId === PLACEHOLDER_DEPT) {
      setSelectedDeptId(departments[0].id);
    }
    if (selectedDeptId !== PLACEHOLDER_DEPT && !departments.some((d) => d.id === selectedDeptId)) {
      setSelectedDeptId(departments[0]?.id ?? PLACEHOLDER_DEPT);
    }
  }, [departments, selectedDeptId]);

  useEffect(() => {
    if (!meta) return;
    const orderId = resolveRouteOrderId(routeParams);
    const colorwayId = resolveRouteColorwayId(routeParams);
    if (!orderId) {
      setLinkOrderId('');
      setLinkColorwayId('');
      return;
    }
    if (orderExistsInMeta(orderId, meta.orders)) {
      setLinkOrderId(orderId);
      setLinkColorwayId(colorwayId);
    } else {
      setLinkOrderId('');
      setLinkColorwayId('');
    }
  }, [routeParams, meta]);

  useEffect(() => {
    if (!factoryId) {
      setMetaLoading(false);
      return;
    }
    setMetaLoading(true);
    Promise.all([
      fetchReportMeta(factoryId).then(setMeta),
      fetchColorwayLabels(factoryId).then(setColorwayLabels),
    ])
      .catch((err) => {
        console.error(err);
        setLoadError(err instanceof Error ? err.message : 'Failed to load report metadata');
      })
      .finally(() => setMetaLoading(false));
  }, [factoryId]);

  const loadDeptReport = useCallback(async () => {
    if (!factoryId || !meta || !selectedDeptId || selectedDeptId === PLACEHOLDER_DEPT) {
      return;
    }

    setReportRefreshing(true);
    setLoadError(null);
    setDeptStates((prev) => ({ ...prev, [selectedDeptId]: { status: 'loading' } }));

    try {
      const report = await fetchDayResourceHourReportRange(
        factoryId,
        dateFrom,
        dateTo,
        selectedDeptId,
        meta,
        colorwayLabels,
      );
      setDeptStates((prev) => ({
        ...prev,
        [selectedDeptId]: { status: 'ok', report },
      }));
      setLastUpdated(new Date());
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Failed to load department';
      setDeptStates((prev) => ({
        ...prev,
        [selectedDeptId]: { status: 'error', message },
      }));
    } finally {
      setReportRefreshing(false);
    }
  }, [factoryId, meta, selectedDeptId, dateFrom, dateTo, colorwayLabels]);

  useEffect(() => {
    void loadDeptReport();
  }, [loadDeptReport]);

  const exportAll = useCallback(() => {
    if (!selectedDept) return;
    const state = deptStates[selectedDept.id];
    if (state?.status !== 'ok') return;
    const visible = filterRows(state.report.rows, searchQuery, linkOrderId, linkColorwayId);
    exportDeptWorkbook(selectedDept.name, dateFrom, dateTo, state.report, visible);
  }, [selectedDept, deptStates, searchQuery, linkOrderId, linkColorwayId, dateFrom, dateTo]);

  const currentState =
    selectedDeptId && selectedDeptId !== PLACEHOLDER_DEPT ? deptStates[selectedDeptId] : undefined;
  const reportLoading =
    metaLoading ||
    reportRefreshing ||
    !currentState ||
    currentState.status === 'loading';
  const error = currentState?.status === 'error' ? currentState.message : null;
  const report = currentState?.status === 'ok' ? currentState.report : null;
  const visibleRows = useMemo(() => {
    if (report == null) return [];
    const filtered = filterRows(report.rows, searchQuery, linkOrderId, linkColorwayId);
    return sortDayRows(filtered);
  }, [report, searchQuery, linkOrderId, linkColorwayId]);

  const visibleShiftSections = useMemo((): DayShiftHourSection[] | undefined => {
    if (!report?.shiftSections?.length) return undefined;
    return report.shiftSections
      .map((sec) => ({
        ...sec,
        rows: sortDayRows(filterRows(sec.rows, searchQuery, linkOrderId, linkColorwayId)),
      }))
      .filter((sec) => sec.rows.length > 0);
  }, [report, searchQuery, linkOrderId, linkColorwayId]);

  const deptDropdownOptions = metaLoading
    ? [{ value: PLACEHOLDER_DEPT, label: 'Loading departments…' }]
    : deptOptions.length > 0
      ? deptOptions
      : [{ value: PLACEHOLDER_DEPT, label: 'No departments' }];

  if (!factoryId) {
    return (
      <PageShell className="pb-20">
        <Card className="p-8 text-center text-sm text-slate-500">
          Select a factory to view reports.
        </Card>
      </PageShell>
    );
  }

  return (
    <PageShell className="pb-4 flex flex-col gap-3 min-h-[calc(100vh-10rem)]">
      <Card noPadding className="shrink-0 overflow-visible">
        <ReportToolbar
          searchQuery={searchQuery}
          onSearchChange={setSearchQuery}
          searchPlaceholder="Filter style, ref, PO, buyer…"
          showDate={false}
          onRefresh={() => void loadDeptReport()}
          refreshing={reportRefreshing || metaLoading}
          lastUpdated={lastUpdated}
        >
          <DateRangePicker
            value={dateRange}
            onChange={setDateRange}
            variant="pill"
            className="w-[15.5rem]"
          />
          <SelectDropdown
            value={metaLoading ? PLACEHOLDER_DEPT : selectedDeptId}
            onChange={setSelectedDeptId}
            options={deptDropdownOptions}
            icon={Factory}
            className="w-44"
            disabled={metaLoading || deptOptions.length === 0}
          />
          <button
            type="button"
            onClick={exportAll}
            disabled={visibleRows.length === 0 || reportLoading}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-[10px] font-semibold border border-slate-200 bg-white text-slate-700 hover:bg-slate-50 hover:border-slate-300 disabled:opacity-40 disabled:pointer-events-none transition-colors"
          >
            <Download size={13} />
            Export
          </button>
        </ReportToolbar>

        {loadError && (
          <div className="mx-4 mb-3 px-4 py-3 bg-red-50 border border-red-200 rounded-xl text-xs text-red-700 flex items-center justify-between gap-3">
            <span>{loadError}</span>
            <Button
              size="sm"
              variant="secondary"
              icon={RefreshCw}
              onClick={() => void loadDeptReport()}
            >
              Retry
            </Button>
          </div>
        )}
      </Card>

      {meta && departments.length === 0 && !metaLoading && (
        <Card className="p-8 text-center text-sm text-slate-400">
          No production departments configured.
        </Card>
      )}

      {(selectedDept || metaLoading) && (
        <div className="flex-1 min-h-0 flex flex-col w-full">
          <DayDeptCard
            deptName={selectedDept?.name ?? 'Department'}
            loading={reportLoading}
            error={error}
            report={report}
            visibleRows={visibleRows}
            visibleShiftSections={visibleShiftSections}
            multiDay={dateFrom !== dateTo}
            fullHeight
          />
        </div>
      )}
    </PageShell>
  );
};
