import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { format } from 'date-fns';
import { Filter, Palette, Download, Printer, RefreshCw } from 'lucide-react';
import { useNavigationStore, useDataStore } from '../../stores';
import { Button, Card, SelectDropdown, Spinner } from '../../components/ui';
import { PageShell } from '../../components/layout/PageShell';
import { ReportToolbar } from '../../components/reports/ReportToolbar';
import { StyleOrderHeader } from '../../components/reports/StyleOrderHeader';
import { StyleFlowTable } from '../../components/reports/StyleFlowTable';
import { StyleDeptAnalysisSection } from '../../components/reports/StyleDeptAnalysisSection';
import { StyleFulfillmentSection } from '../../components/reports/StyleFulfillmentSection';
import { StyleFulfillmentMetricsBar } from '../../components/reports/StyleFulfillmentMetricsBar';
import { StyleProductionMatrixSection } from '../../components/reports/StyleProductionMatrixSection';
import { StyleReportSkeleton } from '../../components/reports/StyleReportSkeleton';
import {
  fetchCutToShipDetail,
  fetchReportMeta,
  fetchStyleDailyKpis,
  fetchStyleJourneyReport,
  type CutToShipRow,
  type ReportMeta,
  type StyleDeptDailyRow,
  type StyleDeptAuditSessionRow,
  type StyleJourneyReport,
} from '../../lib/mesReportsApi';
import { mergeCutToShipRows } from '../../lib/orderCompletionScope';
import type { ColorwayCompletionStatus } from '../../types';
import {
  filterStyleSearchOrders,
  orderExistsInMeta,
  orderLabel,
  resolveRouteColorwayId,
  resolveRouteOrderId,
} from '../../lib/reportPageUtils';
import { scopedOrderQuantities } from '../../lib/orderQtyScope';

const MAX_SEARCH_RESULTS = 8;
const ALL_DEPTS = '';
const ALL_COLORWAYS = '';

function reportLifetimeDateRange(): { dateFrom: string; dateTo: string } {
  return { dateFrom: '2000-01-01', dateTo: format(new Date(), 'yyyy-MM-dd') };
}

export const StyleReport: React.FC = () => {
  const { factoryId, routeParams } = useNavigationStore();
  const { orders } = useDataStore();

  const [meta, setMeta] = useState<ReportMeta | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [searchOpen, setSearchOpen] = useState(false);
  const [selectedOrderId, setSelectedOrderId] = useState('');
  const [selectedColorwayId, setSelectedColorwayId] = useState<string | null>(null);
  const [journey, setJourney] = useState<StyleJourneyReport | null>(null);
  const [dailyRows, setDailyRows] = useState<StyleDeptDailyRow[]>([]);
  const [selectedDeptId, setSelectedDeptId] = useState(ALL_DEPTS);
  const [journeyLoading, setJourneyLoading] = useState(false);
  const [dailyLoading, setDailyLoading] = useState(false);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [lastUpdated, setLastUpdated] = useState<Date | null>(null);
  const [loadedReportKey, setLoadedReportKey] = useState('');
  const [loadedDailyKey, setLoadedDailyKey] = useState('');
  const [reconRow, setReconRow] = useState<CutToShipRow | null>(null);

  const searchRef = useRef<HTMLDivElement>(null);
  const reportKey = `${selectedOrderId}:${selectedColorwayId ?? 'all'}`;
  const reportDataStale = Boolean(
    journey &&
      (loadedReportKey !== reportKey || loadedDailyKey !== reportKey || journeyLoading || dailyLoading),
  );
  const showReportContent = Boolean(
    selectedOrderId && journey && journey.order.id === selectedOrderId,
  );

  const searchResults = useMemo(() => {
    if (!meta) return [];
    return filterStyleSearchOrders(meta.orders, searchQuery, MAX_SEARCH_RESULTS);
  }, [meta, searchQuery]);

  const searchDropdownTitle = searchQuery.trim() ? 'Matches' : 'Recent styles';

  const deptOptions = useMemo(() => {
    if (!journey) return [{ value: ALL_DEPTS, label: 'All departments' }];
    return [
      { value: ALL_DEPTS, label: 'All departments' },
      ...journey.flowDepts.map((d) => ({ value: d.deptId, label: d.deptName })),
    ];
  }, [journey]);

  const colorwayOptions = useMemo(() => {
    if (!journey) return [{ value: ALL_COLORWAYS, label: 'All colorways' }];
    return [
      { value: ALL_COLORWAYS, label: 'All colorways' },
      ...journey.colorways.map((cw) => ({
        value: cw.id,
        label: `${cw.name} (${cw.qty.toLocaleString()})`,
      })),
    ];
  }, [journey]);

  const colorwayLabel = useMemo(() => {
    if (!selectedColorwayId || !journey) return null;
    return journey.colorways.find((c) => c.id === selectedColorwayId)?.name ?? null;
  }, [selectedColorwayId, journey]);

  const deptAuditsById = useMemo(() => {
    const map = new Map<string, StyleDeptAuditSessionRow[]>();
    for (const group of journey?.deptAudits ?? []) {
      map.set(group.deptId, group.sessions);
    }
    return map;
  }, [journey]);

  const invalidRouteOrder = useMemo(() => {
    const orderId = resolveRouteOrderId(routeParams);
    if (!orderId || !meta) return false;
    return !orderExistsInMeta(orderId, meta.orders);
  }, [routeParams, meta]);

  useEffect(() => {
    setMeta(null);
    setSearchQuery('');
    setSearchOpen(false);
    setSelectedOrderId('');
    setSelectedColorwayId(null);
    setJourney(null);
    setDailyRows([]);
    setSelectedDeptId(ALL_DEPTS);
    setLoadError(null);
    setLastUpdated(null);
    setLoadedReportKey('');
    setLoadedDailyKey('');
  }, [factoryId]);

  useEffect(() => {
    if (!factoryId) return;
    fetchReportMeta(factoryId)
      .then(setMeta)
      .catch((err) => {
        setLoadError(err instanceof Error ? err.message : 'Failed to load metadata');
      });
  }, [factoryId]);

  useEffect(() => {
    if (!meta) return;
    const orderId = resolveRouteOrderId(routeParams);
    const colorwayId = resolveRouteColorwayId(routeParams);
    if (!orderId) {
      setSelectedOrderId('');
      return;
    }
    const order = meta.orders.find((o) => o.id === orderId);
    if (order) {
      setSelectedOrderId(orderId);
      setSearchQuery(orderLabel(order.styleName, order.poNumber));
      setSelectedColorwayId(colorwayId || null);
    } else {
      setSelectedOrderId('');
      setJourney(null);
      setDailyRows([]);
      setSearchQuery('');
      setSelectedColorwayId(null);
    }
  }, [routeParams, meta]);

  useEffect(() => {
    const handleClick = (e: MouseEvent) => {
      if (searchRef.current && !searchRef.current.contains(e.target as Node)) {
        setSearchOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClick);
    return () => document.removeEventListener('mousedown', handleClick);
  }, []);

  const loadJourney = useCallback(async () => {
    if (!factoryId || !selectedOrderId) {
      setJourney(null);
      return;
    }
    setJourneyLoading(true);
    setLoadedReportKey('');
    setLoadError(null);
    try {
      const report = await fetchStyleJourneyReport(
        factoryId,
        selectedOrderId,
        selectedColorwayId,
      );
      setJourney(report);
      setLoadedReportKey(`${selectedOrderId}:${selectedColorwayId ?? 'all'}`);
      setSelectedDeptId((cur) => {
        if (!cur) return ALL_DEPTS;
        if (report.flowDepts.some((d) => d.deptId === cur)) return cur;
        return ALL_DEPTS;
      });
      const routeColorwayId = resolveRouteColorwayId(routeParams);
      if (
        routeColorwayId &&
        !report.colorways.some((c) => c.id === routeColorwayId)
      ) {
        setSelectedColorwayId(null);
      }
      setLastUpdated(new Date());
    } catch (err) {
      console.error(err);
      setLoadError(err instanceof Error ? err.message : 'Failed to load journey');
      setJourney(null);
    } finally {
      setJourneyLoading(false);
    }
  }, [factoryId, selectedOrderId, selectedColorwayId, routeParams]);

  const loadDaily = useCallback(async () => {
    if (!factoryId || !selectedOrderId) {
      setDailyRows([]);
      return;
    }
    setDailyLoading(true);
    setLoadedDailyKey('');
    try {
      const rows = await fetchStyleDailyKpis(
        factoryId,
        selectedOrderId,
        meta ?? undefined,
        selectedColorwayId,
      );
      setDailyRows(rows);
      setLoadedDailyKey(`${selectedOrderId}:${selectedColorwayId ?? 'all'}`);
    } catch (err) {
      console.error(err);
      setDailyRows([]);
    } finally {
      setDailyLoading(false);
    }
  }, [factoryId, selectedOrderId, selectedColorwayId, meta]);

  const refreshAll = useCallback(() => {
    void loadJourney();
    void loadDaily();
  }, [loadJourney, loadDaily]);

  useEffect(() => {
    void loadJourney();
  }, [loadJourney]);

  useEffect(() => {
    void loadDaily();
  }, [loadDaily]);

  useEffect(() => {
    if (!factoryId || !selectedOrderId) {
      setReconRow(null);
      return;
    }
    let cancelled = false;
    fetchCutToShipDetail(factoryId, selectedOrderId)
      .then((detail) => {
        if (cancelled) return;
        const rows = detail.reconciliation.filter((r) => r.order_id === selectedOrderId);
        const scoped = selectedColorwayId
          ? rows.filter((r) => r.colorway_id === selectedColorwayId)
          : rows;
        setReconRow(mergeCutToShipRows(scoped));
      })
      .catch(() => {
        if (!cancelled) setReconRow(null);
      });
    return () => {
      cancelled = true;
    };
  }, [factoryId, selectedOrderId, selectedColorwayId]);

  const storeOrder = useMemo(
    () => orders.find((o) => o.id === selectedOrderId) ?? null,
    [orders, selectedOrderId],
  );

  const { orderQty: scopedOrderQty, adjQty: scopedAdjQty } = useMemo(() => {
    const fromStore = scopedOrderQuantities(storeOrder, selectedColorwayId);
    if ((fromStore.adjQty > 0 || fromStore.orderQty > 0) || !journey) return fromStore;
    if (selectedColorwayId) {
      const cw = journey.colorways.find((c) => c.id === selectedColorwayId);
      return {
        orderQty: cw?.qty ?? journey.order.orderQty,
        adjQty: journey.order.adjQty || journey.order.orderQty,
      };
    }
    return { orderQty: journey.order.orderQty, adjQty: journey.order.adjQty || journey.order.orderQty };
  }, [storeOrder, selectedColorwayId, journey]);

  const { dateFrom, dateTo } = useMemo(() => reportLifetimeDateRange(), []);

  const completionStatus = useMemo((): ColorwayCompletionStatus => {
    const order = orders.find((o) => o.id === selectedOrderId);
    if (!order) return 'ongoing';
    if (selectedColorwayId) {
      return order.colorways.find((c) => c.id === selectedColorwayId)?.completionStatus ?? 'ongoing';
    }
    return 'ongoing';
  }, [orders, selectedOrderId, selectedColorwayId]);

  const resetFilters = useCallback(() => {
    setSelectedDeptId(ALL_DEPTS);
    setSelectedColorwayId(null);
  }, []);

  const handleSelectOrder = (orderId: string, styleName: string, poNumber: string) => {
    setSelectedOrderId(orderId);
    setSelectedColorwayId(null);
    setSelectedDeptId(ALL_DEPTS);
    setSearchQuery(orderLabel(styleName, poNumber));
    setSearchOpen(false);
  };

  const handleDownloadPdf = useCallback(() => {
    window.print();
  }, []);

  const showInitialSkeleton = Boolean(selectedOrderId && journeyLoading && !journey);
  const showReportBody = showReportContent;

  const showSearchDropdown = searchOpen && meta != null && searchResults.length > 0;

  if (!factoryId) {
    return (
      <PageShell className="pb-20">
        <Card className="p-8 text-center text-sm text-slate-500">
          Select a factory to view reports.
        </Card>
      </PageShell>
    );
  }

  return (
    <PageShell className="pb-20 space-y-4">
      <div ref={searchRef}>
        <Card noPadding className="overflow-visible">
          <ReportToolbar
            searchQuery={searchQuery}
            onSearchChange={(value) => {
              setSearchQuery(value);
              setSearchOpen(true);
            }}
            onSearchFocus={() => setSearchOpen(true)}
            searchPlaceholder="Search style, ref, PO, buyer…"
            showDate={false}
            onRefresh={selectedOrderId ? refreshAll : undefined}
            refreshing={journeyLoading || dailyLoading}
            lastUpdated={lastUpdated}
            onReset={selectedOrderId ? resetFilters : undefined}
          >
            {journey && journey.colorways.length > 0 && (
              <SelectDropdown
                value={selectedColorwayId ?? ALL_COLORWAYS}
                onChange={(v) => setSelectedColorwayId(v === ALL_COLORWAYS ? null : v)}
                options={colorwayOptions}
                icon={Palette}
                className="w-44"
              />
            )}
            {journey && journey.flowDepts.length > 0 && (
              <SelectDropdown
                value={selectedDeptId || ALL_DEPTS}
                onChange={(v) => setSelectedDeptId(v === ALL_DEPTS ? '' : v)}
                options={deptOptions}
                icon={Filter}
                className="w-44"
              />
            )}
            {showReportBody && (
              <>
                <button
                  type="button"
                  onClick={handleDownloadPdf}
                  className="no-print inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-[10px] font-semibold border border-slate-200 bg-white text-slate-700 hover:bg-slate-50 hover:border-slate-300 transition-colors"
                >
                  <Download size={13} />
                  PDF
                </button>
                <button
                  type="button"
                  onClick={handleDownloadPdf}
                  className="no-print inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-[10px] font-semibold border border-slate-200 bg-white text-slate-700 hover:bg-slate-50 hover:border-slate-300 transition-colors"
                >
                  <Printer size={13} />
                  Print
                </button>
              </>
            )}
          </ReportToolbar>

          {showSearchDropdown && (
            <div className="border-t border-slate-100 bg-white shadow-inner">
              <p className="px-4 pt-2 pb-1 text-[9px] font-semibold uppercase tracking-wider text-slate-400">
                {searchDropdownTitle}
              </p>
              <ul className="max-h-56 overflow-y-auto pb-1">
                {searchResults.map((o) => (
                  <li key={o.id}>
                    <button
                      type="button"
                      className={`w-full text-left px-4 py-2 text-[10px] hover:bg-slate-50 border-b border-slate-50 last:border-0 ${
                        o.id === selectedOrderId ? 'bg-slate-50' : ''
                      }`}
                      onMouseDown={(e) => e.preventDefault()}
                      onClick={() => handleSelectOrder(o.id, o.styleName, o.poNumber)}
                    >
                      <span className="font-medium text-slate-800">{o.styleName}</span>
                      {o.styleRef && (
                        <span className="text-slate-400 ml-2">{o.styleRef}</span>
                      )}
                      {o.poNumber && (
                        <span className="text-slate-400 ml-2 font-mono">{o.poNumber}</span>
                      )}
                      {o.buyerName && (
                        <span className="block text-[9px] text-slate-400 mt-0.5">{o.buyerName}</span>
                      )}
                    </button>
                  </li>
                ))}
              </ul>
            </div>
          )}

          {searchOpen && meta && searchResults.length === 0 && searchQuery.trim() && (
            <p className="border-t border-slate-100 px-4 py-3 text-[10px] text-slate-400">
              No styles match &ldquo;{searchQuery.trim()}&rdquo;
            </p>
          )}

          {loadError && (
            <div className="mx-4 my-3 px-4 py-3 bg-red-50 border border-red-200 rounded-xl text-[10px] text-red-700 flex items-center justify-between gap-3">
              <span>{loadError}</span>
              <Button size="sm" variant="secondary" icon={RefreshCw} onClick={() => void loadJourney()}>
                Retry
              </Button>
            </div>
          )}
        </Card>
      </div>

      {!selectedOrderId && !invalidRouteOrder && (
        <Card className="p-8 text-center text-[10px] text-slate-400">
          Search and select a style to view its production lifecycle.
        </Card>
      )}

      {invalidRouteOrder && (
        <Card className="px-4 py-3 text-[10px] text-amber-800 bg-amber-50 border border-amber-200">
          Order not found in this factory. Search to select a style.
        </Card>
      )}

      {showInitialSkeleton && <StyleReportSkeleton />}

      {showReportBody && journey && (
        <div id="style-report-print-root" className="mes-report space-y-5">
          <header className="print-only mes-report-header">
            <div>
              <div className="mes-report-logo">PRODIGI</div>
              <div className="mes-report-logo-sub">Style Report</div>
            </div>
            <div className="mes-report-title-block">
              <h1 className="mes-report-title">{journey.order.styleName}</h1>
              <div className="mes-report-meta">
                PO {journey.order.poNumber}
                {colorwayLabel ? ` · ${colorwayLabel}` : ''}
              </div>
            </div>
          </header>

          <div className="space-y-5">
            {showReportContent && reportDataStale && (
              <div className="no-print flex justify-center py-12">
                <Spinner size="lg" />
              </div>
            )}

            {showReportContent && journey && !reportDataStale && (
              <>
            <StyleOrderHeader
              journey={journey}
              colorwayLabel={colorwayLabel}
              orderQty={scopedOrderQty}
              adjQty={scopedAdjQty}
            />

            <StyleFulfillmentMetricsBar
              reconRow={reconRow}
              deliveryDate={journey.order.deliveryDate}
              completionStatus={completionStatus}
              scopedOrderQty={scopedOrderQty}
            />

            <div className="rounded-2xl border border-slate-200 bg-white p-5 sm:p-6 shadow-sm">
              <StyleFlowTable flowDepts={journey.flowDepts} adjQty={scopedAdjQty} />
            </div>

            <div className="rounded-2xl border border-slate-200 bg-white p-5 sm:p-6 shadow-sm">
              <StyleProductionMatrixSection
                key={reportKey}
                factoryId={factoryId}
                orderId={selectedOrderId}
                colorwayId={selectedColorwayId}
                journey={journey}
              />
            </div>

            <div className="rounded-2xl border border-slate-200 bg-white p-5 sm:p-6 shadow-sm relative">
              <StyleDeptAnalysisSection
                key={reportKey}
                factoryId={factoryId}
                orderId={selectedOrderId}
                colorwayId={selectedColorwayId}
                flowDepts={journey.flowDepts}
                dailyRows={dailyRows}
                deptAuditsById={deptAuditsById}
                dateFrom={dateFrom}
                dateTo={dateTo}
                selectedDeptId={selectedDeptId}
              />
            </div>

            <StyleFulfillmentSection
              key={reportKey}
              journey={journey}
              orderQty={scopedOrderQty}
              adjQty={scopedAdjQty}
            />
              </>
            )}
          </div>

          <footer className="print-only mes-report-footer">
            <span>Style Report</span>
            <span>{format(new Date(), 'dd/MM/yyyy, HH:mm')}</span>
          </footer>
        </div>
      )}
    </PageShell>
  );
};
