import React, { useState, useEffect, useMemo } from 'react';
import { useSettingsStore, useNavigationStore, useNotificationStore } from '../stores';
import { Button, Input, SelectDropdown as Select } from '../components/ui';
import { PageShell } from '../components/layout/PageShell';
import { Users, Plus, Search, X, Edit, UserMinus, Calendar } from 'lucide-react';
import { supabase } from '../lib/supabase';

interface Worker {
  id: string;
  factory_id: string;
  department_id: string;
  worker_id: string;
  name: string;
  role: string;
  is_active: boolean;
  date_of_joining?: string;
  date_of_leaving?: string;
  created_at?: string;
}

export const Workforce: React.FC = () => {
  const { departments } = useSettingsStore();
  const { factoryId } = useNavigationStore();
  const { showNotification } = useNotificationStore();

  const [workers, setWorkers] = useState<Worker[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [selectedDept, setSelectedDept] = useState<string>('all');
  const [search, setSearch] = useState('');
  const [showForm, setShowForm] = useState(false);
  const [editingWorker, setEditingWorker] = useState<Worker | null>(null);
  const [showLeaveModal, setShowLeaveModal] = useState<Worker | null>(null);
  const [leaveDate, setLeaveDate] = useState('');

  // Form state
  const [form, setForm] = useState({
    name: '',
    worker_id: '',
    role: '',
    department_id: '',
    date_of_joining: new Date().toISOString().split('T')[0],
  });

  // Fetch workers
  const fetchWorkers = async () => {
    if (!factoryId) return;
    setLoading(true);
    setLoadError(null);
    const { data, error } = await supabase
      .from('workers')
      .select('*')
      .eq('factory_id', factoryId)
      .order('name');
    if (error) {
      setLoadError(error.message);
      showNotification(`Failed to load workers: ${error.message}`, 'error');
    } else {
      setWorkers((data || []) as Worker[]);
    }
    setLoading(false);
  };

  useEffect(() => {
    fetchWorkers();
  }, [factoryId]);

  // Filtered workers
  const filteredWorkers = useMemo(() => {
    let result = workers;
    if (selectedDept !== 'all') {
      result = result.filter(w => w.department_id === selectedDept);
    }
    if (search.trim()) {
      const q = search.toLowerCase();
      result = result.filter(w =>
        w.name.toLowerCase().includes(q) ||
        w.worker_id.toLowerCase().includes(q) ||
        w.role.toLowerCase().includes(q)
      );
    }
    return result;
  }, [workers, selectedDept, search]);

  const activeWorkers = filteredWorkers.filter(w => w.is_active);
  const leftWorkers = filteredWorkers.filter(w => !w.is_active);

  // Add or update worker
  const handleSave = async () => {
    if (!form.name.trim() || !form.worker_id.trim() || !form.department_id) return;

    if (editingWorker) {
      const { error } = await supabase
        .from('workers')
        .update({
          name: form.name,
          worker_id: form.worker_id,
          role: form.role,
          department_id: form.department_id,
          date_of_joining: form.date_of_joining,
        })
        .eq('id', editingWorker.id);
      if (error) {
        showNotification(`Failed to update worker: ${error.message}`, 'error');
        return;
      }
      await fetchWorkers();
      resetForm();
      showNotification('Worker updated', 'success');
    } else {
      const { error } = await supabase
        .from('workers')
        .insert({
          factory_id: factoryId,
          name: form.name,
          worker_id: form.worker_id,
          role: form.role,
          department_id: form.department_id,
          date_of_joining: form.date_of_joining,
          is_active: true,
        });
      if (error) {
        showNotification(`Failed to add worker: ${error.message}`, 'error');
        return;
      }
      await fetchWorkers();
      resetForm();
      showNotification('Worker added', 'success');
    }
  };

  // Mark worker as left
  const handleMarkLeft = async () => {
    if (!showLeaveModal || !leaveDate) return;
    const { error } = await supabase
      .from('workers')
      .update({ is_active: false, date_of_leaving: leaveDate })
      .eq('id', showLeaveModal.id);
    if (error) {
      showNotification(`Failed to update worker: ${error.message}`, 'error');
      return;
    }
    await fetchWorkers();
    setShowLeaveModal(null);
    setLeaveDate('');
    showNotification('Worker marked as left', 'success');
  };

  const resetForm = () => {
    setForm({ name: '', worker_id: '', role: '', department_id: '', date_of_joining: new Date().toISOString().split('T')[0] });
    setEditingWorker(null);
    setShowForm(false);
  };

  const startEdit = (worker: Worker) => {
    setForm({
      name: worker.name,
      worker_id: worker.worker_id,
      role: worker.role,
      department_id: worker.department_id,
      date_of_joining: worker.date_of_joining || '',
    });
    setEditingWorker(worker);
    setShowForm(true);
  };

  const getDeptName = (deptId: string) => {
    return departments.find(d => d.id === deptId)?.name || 'Unknown';
  };

  return (
    <PageShell className="w-full pb-16">
      {/* Page Header */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 px-6 py-4 mb-5 flex items-center justify-between">
        <div>
          <h1 className="text-sm font-bold text-slate-900 flex items-center gap-2">
            <Users size={18} /> Workforce Registry
          </h1>
          <p className="text-[10px] text-slate-500 mt-0.5">Department-wise worker management</p>
        </div>
        <Button variant="primary" icon={Plus} onClick={() => { resetForm(); setShowForm(true); }}>
          Add Worker
        </Button>
      </div>

      {/* Filters */}
      <div className="flex items-center gap-4 mb-5 px-1">
        <div className="flex gap-2 flex-wrap">
          <button
            onClick={() => setSelectedDept('all')}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
              selectedDept === 'all'
                ? 'bg-blue-50 text-blue-700 border border-blue-200'
                : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
            }`}
          >
            All ({workers.length})
          </button>
          {departments.map(dept => {
            const count = workers.filter(w => w.department_id === dept.id).length;
            return (
              <button
                key={dept.id}
                onClick={() => setSelectedDept(dept.id)}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                  selectedDept === dept.id
                    ? 'bg-blue-50 text-blue-700 border border-blue-200'
                    : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
                }`}
              >
                {dept.name} ({count})
              </button>
            );
          })}
        </div>
        <div className="ml-auto relative">
          <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            placeholder="Search workers..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-8 pr-3 py-1.5 text-xs rounded-lg border border-slate-200 bg-white focus:outline-none focus:ring-2 focus:ring-blue-100 w-56"
          />
        </div>
      </div>

      {/* Add/Edit Form */}
      {showForm && (
        <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-6 mb-5">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-xs font-bold text-slate-800">
              {editingWorker ? 'Edit Worker' : 'Add New Worker'}
            </h3>
            <button onClick={resetForm} className="p-1 rounded hover:bg-slate-100">
              <X size={16} className="text-slate-400" />
            </button>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <Input
              label="Worker Name"
              placeholder="e.g. Ramesh Kumar"
              value={form.name}
              onChange={(e) => setForm({ ...form, name: e.target.value })}
              className="bg-white"
            />
            <Input
              label="Worker ID"
              placeholder="e.g. EMP-001"
              value={form.worker_id}
              onChange={(e) => setForm({ ...form, worker_id: e.target.value })}
              className="bg-white font-mono"
            />
            <Input
              label="Role / Title"
              placeholder="e.g. Operator, Tailor, Helper"
              value={form.role}
              onChange={(e) => setForm({ ...form, role: e.target.value })}
              className="bg-white"
            />
            <Select
              value={form.department_id}
              onChange={(value) => setForm({ ...form, department_id: value })}
              options={departments.map(d => ({ value: d.id, label: d.name }))}
              placeholder="Select Department"
              className="bg-white"
            />
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Date of Joining</label>
              <input
                type="date"
                value={form.date_of_joining}
                onChange={(e) => setForm({ ...form, date_of_joining: e.target.value })}
                className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200 bg-white focus:outline-none focus:ring-2 focus:ring-blue-100"
              />
            </div>
          </div>
          <div className="flex gap-2 mt-4">
            <Button variant="primary" onClick={handleSave} disabled={!form.name.trim() || !form.worker_id.trim() || !form.department_id}>
              {editingWorker ? 'Update Worker' : 'Add Worker'}
            </Button>
            <Button variant="ghost" onClick={resetForm}>Cancel</Button>
          </div>
        </div>
      )}

      {loadError && (
        <div className="mb-4 px-4 py-3 bg-red-50 border border-red-200 rounded-xl text-xs text-red-700">
          {loadError}
        </div>
      )}

      {/* Workers Table - Active */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden mb-5">
        <div className="px-5 py-3 border-b border-slate-100 bg-slate-50/50">
          <h3 className="text-xs font-bold text-slate-700">Active Workers ({activeWorkers.length})</h3>
        </div>
        {loading ? (
          <div className="flex items-center justify-center py-12 text-slate-400 text-xs">Loading...</div>
        ) : activeWorkers.length === 0 ? (
          <div className="flex items-center justify-center py-12 text-slate-400 text-xs italic">
            No active workers found.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead className="bg-slate-50 text-[9px] uppercase font-bold text-slate-500 tracking-wider">
                <tr>
                  <th className="px-5 py-3">ID</th>
                  <th className="px-5 py-3">Name</th>
                  <th className="px-5 py-3">Role / Title</th>
                  <th className="px-5 py-3">Department</th>
                  <th className="px-5 py-3">Date of Joining</th>
                  <th className="px-5 py-3">Status</th>
                  <th className="px-5 py-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {activeWorkers.map(worker => (
                  <tr key={worker.id} className="hover:bg-slate-50/50 group">
                    <td className="px-5 py-3 text-[11px] font-mono text-slate-600">{worker.worker_id}</td>
                    <td className="px-5 py-3 text-[11px] font-bold text-slate-800">{worker.name}</td>
                    <td className="px-5 py-3 text-[11px] text-slate-600">{worker.role}</td>
                    <td className="px-5 py-3 text-[11px] text-slate-600">
                      <span className="px-2 py-0.5 rounded-full bg-slate-100 text-slate-700 text-[10px] font-medium">
                        {getDeptName(worker.department_id)}
                      </span>
                    </td>
                    <td className="px-5 py-3 text-[11px] text-slate-500">
                      {worker.date_of_joining ? new Date(worker.date_of_joining).toLocaleDateString() : '—'}
                    </td>
                    <td className="px-5 py-3">
                      <span className="px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 text-[10px] font-bold">
                        Active
                      </span>
                    </td>
                    <td className="px-5 py-3 text-right">
                      <div className="flex gap-1 justify-end opacity-0 group-hover:opacity-100 transition-opacity">
                        <button
                          onClick={() => startEdit(worker)}
                          className="p-1.5 rounded-lg hover:bg-blue-50 text-blue-600 transition-colors"
                          title="Edit"
                        >
                          <Edit size={13} />
                        </button>
                        <button
                          onClick={() => { setShowLeaveModal(worker); setLeaveDate(new Date().toISOString().split('T')[0]); }}
                          className="p-1.5 rounded-lg hover:bg-red-50 text-red-500 transition-colors"
                          title="Mark as Left"
                        >
                          <UserMinus size={13} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Workers Table - Left */}
      {leftWorkers.length > 0 && (
        <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
          <div className="px-5 py-3 border-b border-slate-100 bg-slate-50/50">
            <h3 className="text-xs font-bold text-slate-500">Left Workers ({leftWorkers.length})</h3>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead className="bg-slate-50 text-[9px] uppercase font-bold text-slate-500 tracking-wider">
                <tr>
                  <th className="px-5 py-3">ID</th>
                  <th className="px-5 py-3">Name</th>
                  <th className="px-5 py-3">Role / Title</th>
                  <th className="px-5 py-3">Department</th>
                  <th className="px-5 py-3">Date of Joining</th>
                  <th className="px-5 py-3">Date of Leaving</th>
                  <th className="px-5 py-3">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {leftWorkers.map(worker => (
                  <tr key={worker.id} className="opacity-60">
                    <td className="px-5 py-3 text-[11px] font-mono text-slate-500">{worker.worker_id}</td>
                    <td className="px-5 py-3 text-[11px] font-bold text-slate-600">{worker.name}</td>
                    <td className="px-5 py-3 text-[11px] text-slate-500">{worker.role}</td>
                    <td className="px-5 py-3 text-[11px] text-slate-500">
                      <span className="px-2 py-0.5 rounded-full bg-slate-100 text-slate-600 text-[10px] font-medium">
                        {getDeptName(worker.department_id)}
                      </span>
                    </td>
                    <td className="px-5 py-3 text-[11px] text-slate-500">
                      {worker.date_of_joining ? new Date(worker.date_of_joining).toLocaleDateString() : '—'}
                    </td>
                    <td className="px-5 py-3 text-[11px] text-slate-500">
                      {worker.date_of_leaving ? new Date(worker.date_of_leaving).toLocaleDateString() : '—'}
                    </td>
                    <td className="px-5 py-3">
                      <span className="px-2 py-0.5 rounded-full bg-red-50 text-red-600 text-[10px] font-bold">
                        Left
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Mark as Left Modal */}
      {showLeaveModal && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl shadow-xl p-6 w-96 animate-in fade-in zoom-in duration-200">
            <h3 className="text-xs font-bold text-slate-800 mb-4 flex items-center gap-2">
              <UserMinus size={16} className="text-red-500" /> Mark Worker as Left
            </h3>
            <p className="text-[11px] text-slate-600 mb-4">
              Marking <span className="font-bold">{showLeaveModal.name}</span> ({showLeaveModal.worker_id}) as left.
            </p>
            <div className="mb-4">
              <label className="block text-xs font-medium text-slate-700 mb-1 flex items-center gap-1">
                <Calendar size={12} /> Date of Leaving
              </label>
              <input
                type="date"
                value={leaveDate}
                onChange={(e) => setLeaveDate(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200 bg-white focus:outline-none focus:ring-2 focus:ring-red-100"
              />
            </div>
            <div className="flex gap-2 justify-end">
              <Button variant="ghost" onClick={() => { setShowLeaveModal(null); setLeaveDate(''); }}>Cancel</Button>
              <button
                onClick={handleMarkLeft}
                disabled={!leaveDate}
                className="px-4 py-2 bg-red-600 text-white rounded-lg text-xs font-medium hover:bg-red-700 disabled:opacity-50 transition-colors"
              >
                Confirm
              </button>
            </div>
          </div>
        </div>
      )}
    </PageShell>
  );
};
