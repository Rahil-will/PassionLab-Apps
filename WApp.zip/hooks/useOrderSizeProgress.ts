import { useEffect, useState } from 'react';
import {
  buildSizeProgressLookup,
  type FlowStepRef,
  type SizeProgressLookup,
} from '../lib/orderSizeProgress';

export function useOrderSizeProgress(
  factoryId: string | null | undefined,
  orderId: string | undefined,
  colorwayIds: string[],
  flowSteps: FlowStepRef[],
): { lookup: SizeProgressLookup | null; loading: boolean } {
  const [lookup, setLookup] = useState<SizeProgressLookup | null>(null);
  const [loading, setLoading] = useState(false);

  const stepKey = flowSteps.map((s) => `${s.dept_id}:${s.dept_name}`).join('|');
  const colorwayKey = colorwayIds.join(',');

  useEffect(() => {
    if (!factoryId || !orderId || colorwayIds.length === 0 || flowSteps.every((s) => !s.dept_id)) {
      setLookup(null);
      setLoading(false);
      return;
    }

    let cancelled = false;
    setLoading(true);

    buildSizeProgressLookup(factoryId, orderId, colorwayIds, flowSteps)
      .then((result) => {
        if (!cancelled) setLookup(result);
      })
      .catch(() => {
        if (!cancelled) setLookup(null);
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });

    return () => {
      cancelled = true;
    };
  }, [factoryId, orderId, colorwayKey, stepKey]);

  return { lookup, loading };
}
