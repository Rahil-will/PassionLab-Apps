import { useEffect } from 'react';
import { useDataStore, useNavigationStore } from '../stores';

/** Silent refresh of orders, allocations, and production summary when a page mounts. */
export function useRefreshProductionDataOnMount(): void {
  const factoryId = useNavigationStore((s) => s.factoryId);

  useEffect(() => {
    if (!factoryId) return;
    void useDataStore.getState().fetchData({ silent: true });
  }, [factoryId]);
}
