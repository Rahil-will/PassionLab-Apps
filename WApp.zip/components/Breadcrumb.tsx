import React from 'react';
import { useNavigationStore } from '../stores';
import { getRouteEntry } from '../lib/routeMap';
import { tokens } from '../lib/designTokens';
import { usePageHeaderContext } from './PageHeaderContext';

interface BreadcrumbProps {
  titleOverride?: string;
  subtitleOverride?: string;
  actions?: React.ReactNode;
}

export const Breadcrumb: React.FC<BreadcrumbProps> = ({ titleOverride, subtitleOverride, actions: propActions }) => {
  const { currentRoute } = useNavigationStore();
  const { actionsRef, version } = usePageHeaderContext();
  const entry = getRouteEntry(currentRoute);
  const actions = propActions || (version >= 0 ? actionsRef.current : null);

  const pageTitle = titleOverride || entry?.displayName || 'Page';
  const pageSubtitle = subtitleOverride || entry?.subtitle;

  return (
    <div className="bg-gray-100 rounded-l-xl shadow-md border border-slate-200 px-6 py-4 mb-3 flex-shrink-0 min-h-[60px]">
      <h1
        className="font-bold text-slate-900 leading-tight"
        style={{ fontSize: tokens.fontSize.display }}
      >
        {pageTitle}
      </h1>

      <div className="flex items-center justify-between mt-0.5">
        {pageSubtitle ? (
          <p
            className="text-slate-500"
            style={{ fontSize: tokens.fontSize.bodySmall }}
          >
            {pageSubtitle}
          </p>
        ) : <span />}
        {actions && (
          <div className="flex items-center gap-3">
            {actions}
          </div>
        )}
      </div>
    </div>
  );
};

export { PageHeaderProvider, usePageActions } from './PageHeaderContext';
