import React, { useEffect, useLayoutEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { Calendar } from 'react-date-range';
import {
  addMonths,
  format,
  parseISO,
  startOfMonth,
  subMonths,
} from 'date-fns';
import { Calendar as CalendarIcon, ChevronDown, ChevronLeft, ChevronRight } from 'lucide-react';
import { computeDropdownBelowPosition } from '../lib/popoverPosition';
import 'react-date-range/dist/styles.css';
import 'react-date-range/dist/theme/default.css';

export interface SingleDatePickerProps {
  value: string;
  onChange: (isoDate: string) => void;
  className?: string;
  minDate?: string;
  maxDate?: string;
}

function toDate(iso: string): Date {
  return parseISO(`${iso}T12:00:00`);
}

function toIso(d: Date): string {
  return format(d, 'yyyy-MM-dd');
}

export const SingleDatePicker: React.FC<SingleDatePickerProps> = ({
  value,
  onChange,
  className = '',
  minDate,
  maxDate,
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [viewMonth, setViewMonth] = useState(() => startOfMonth(toDate(value)));
  const containerRef = useRef<HTMLDivElement>(null);
  const menuRef = useRef<HTMLDivElement>(null);
  const [menuPos, setMenuPos] = useState({ top: 0, left: 0 });

  const selected = toDate(value);

  useEffect(() => {
    if (!isOpen) setViewMonth(startOfMonth(selected));
  }, [value, isOpen, selected]);

  const updateMenuPosition = () => {
    if (!containerRef.current || !menuRef.current) return;
    const trigger = containerRef.current.getBoundingClientRect();
    const panelW = menuRef.current.offsetWidth;
    const panelH = menuRef.current.offsetHeight;
    const { left, top } = computeDropdownBelowPosition(trigger, panelW, panelH, 6);
    setMenuPos({ top, left });
  };

  useLayoutEffect(() => {
    if (!isOpen) return;
    updateMenuPosition();
    window.addEventListener('resize', updateMenuPosition);
    window.addEventListener('scroll', updateMenuPosition, true);
    return () => {
      window.removeEventListener('resize', updateMenuPosition);
      window.removeEventListener('scroll', updateMenuPosition, true);
    };
  }, [isOpen]);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      const t = event.target as Node;
      if (containerRef.current?.contains(t) || menuRef.current?.contains(t)) return;
      setIsOpen(false);
    };
    if (isOpen) document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [isOpen]);

  const min = minDate ? toDate(minDate) : undefined;
  const max = maxDate ? toDate(maxDate) : undefined;

  const dropdown = isOpen ? (
    <div
      ref={menuRef}
      className="fixed z-[300] bg-white rounded-xl shadow-lg border border-slate-200 p-2 max-w-[calc(100vw-1rem)] [&_.rdrCalendarWrapper]:text-[11px] [&_.rdrMonth]:w-[15.5rem] [&_.rdrMonthAndYearWrapper]:min-h-[1.75rem] [&_.rdrWeekDay]:text-[9px] [&_.rdrWeekDay]:leading-none [&_.rdrDay]:h-8 [&_.rdrDay]:w-8 [&_.rdrDayNumber]:text-[11px] [&_.rdrDays]:gap-0"
      style={{ top: menuPos.top, left: menuPos.left }}
    >
      <div className="flex items-center justify-between gap-2 mb-1 px-0.5">
        <button
          type="button"
          onClick={() => setViewMonth((m) => subMonths(m, 1))}
          className="w-6 h-6 rounded-md flex items-center justify-center text-slate-500 hover:bg-slate-100"
          aria-label="Previous month"
        >
          <ChevronLeft size={14} />
        </button>
        <span className="text-[11px] font-semibold text-slate-800">{format(viewMonth, 'MMM yyyy')}</span>
        <button
          type="button"
          onClick={() => setViewMonth((m) => addMonths(m, 1))}
          className="w-6 h-6 rounded-md flex items-center justify-center text-slate-500 hover:bg-slate-100"
          aria-label="Next month"
        >
          <ChevronRight size={14} />
        </button>
      </div>
      <Calendar
        date={selected}
        onChange={(d) => {
          if (!d) return;
          onChange(toIso(d));
          setIsOpen(false);
        }}
        shownDate={viewMonth}
        minDate={min}
        maxDate={max}
        color="#3b82f6"
        showDateDisplay={false}
      />
    </div>
  ) : null;

  return (
    <div ref={containerRef} className={`relative ${className}`}>
      <button
        type="button"
        onClick={() => setIsOpen((o) => !o)}
        className={`flex items-center gap-1.5 px-2 py-1 rounded-lg text-[11px] font-medium transition-colors min-w-[7.5rem] ${
          isOpen
            ? 'bg-blue-50 text-blue-800'
            : 'text-slate-700 hover:bg-slate-50'
        }`}
      >
        <CalendarIcon size={12} className="text-blue-500 shrink-0" />
        <span className="tabular-nums">{format(selected, 'EEE, d MMM')}</span>
        <ChevronDown
          size={12}
          className={`text-slate-400 ml-auto shrink-0 transition-transform ${isOpen ? 'rotate-180' : ''}`}
        />
      </button>
      {dropdown && createPortal(dropdown, document.body)}
    </div>
  );
};
