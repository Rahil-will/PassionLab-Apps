import React, { useState } from 'react';
import { Database, RefreshCw, CheckCircle, AlertCircle } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { Spinner, Toast } from './ui';

interface RefreshButtonProps {
    date?: string;
    onRefresh?: () => void;
    className?: string;
    showLabel?: boolean;
}

export const RefreshButton: React.FC<RefreshButtonProps> = ({
    date,
    onRefresh,
    className = '',
    showLabel = true
}) => {
    const [refreshing, setRefreshing] = useState(false);
    const [lastRefresh, setLastRefresh] = useState<Date | null>(null);
    const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' } | null>(null);

    const handleRefresh = async () => {
        setRefreshing(true);
        const refreshDate = date || new Date().toISOString().split('T')[0];
        
        try {
            const { data, error } = await supabase.rpc('refresh_daily_summaries', {
                p_date: refreshDate
            });
            
            if (error) throw error;
            
            setLastRefresh(new Date());
            setToast({ 
                message: `Updated: ${data?.rows ?? 0} summary rows for ${data?.date ?? refreshDate}`, 
                type: 'success' 
            });
            
            onRefresh?.();
        } catch (err: any) {
            setToast({ message: `Failed: ${err.message}`, type: 'error' });
        } finally {
            setRefreshing(false);
        }
    };

    return (
        <>
            <div className={`flex items-center gap-2 ${className}`}>
                <button 
                    onClick={handleRefresh} 
                    disabled={refreshing}
                    className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold rounded-lg transition-colors ${
                        refreshing 
                            ? 'bg-slate-200 text-slate-500 cursor-not-allowed' 
                            : 'bg-emerald-600 text-white hover:bg-emerald-700 shadow-sm'
                    }`}
                    title="Force refresh summary tables from scan logs (auto-runs every 5 min)"
                >
                    {refreshing ? (
                        <Spinner size="sm" />
                    ) : (
                        <Database size={12} />
                    )}
                    {showLabel && (refreshing ? 'Updating...' : 'Update DB')}
                </button>
                
                {lastRefresh && (
                    <span className="flex items-center gap-1 text-[10px] text-slate-500">
                        <CheckCircle size={10} className="text-emerald-500" />
                        {lastRefresh.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                )}
            </div>
            
            {toast && (
                <Toast 
                    message={toast.message} 
                    type={toast.type} 
                    onClose={() => setToast(null)} 
                />
            )}
        </>
    );
};

// Compact version with just icon
export const RefreshIconButton: React.FC<RefreshButtonProps> = ({
    date,
    onRefresh,
    className = ''
}) => {
    const [refreshing, setRefreshing] = useState(false);
    const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' } | null>(null);

    const handleRefresh = async () => {
        setRefreshing(true);
        const refreshDate = date || new Date().toISOString().split('T')[0];
        
        try {
            const { data, error } = await supabase.rpc('refresh_daily_summaries', {
                p_date: refreshDate
            });
            
            if (error) throw error;
            
            setToast({ 
                message: `Updated ${data?.production_rows ?? 0} prod, ${data?.quality_rows ?? 0} quality rows`, 
                type: 'success' 
            });
            
            onRefresh?.();
        } catch (err: any) {
            setToast({ message: `Failed: ${err.message}`, type: 'error' });
        } finally {
            setRefreshing(false);
        }
    };

    return (
        <>
            <button
                onClick={handleRefresh}
                disabled={refreshing}
                className={`p-2 rounded-lg transition-colors ${
                    refreshing 
                        ? 'bg-slate-100 text-slate-400 cursor-not-allowed' 
                        : 'bg-white border border-slate-200 text-emerald-600 hover:bg-emerald-50 hover:border-emerald-200'
                } ${className}`}
                title="Refresh summary tables"
            >
                {refreshing ? <Spinner size="sm" /> : <RefreshCw size={16} />}
            </button>
            {toast && <Toast message={toast.message} type={toast.type} onClose={() => setToast(null)} />}
        </>
    );
};
