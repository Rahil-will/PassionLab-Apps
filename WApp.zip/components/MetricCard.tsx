import React from 'react';
import { LucideIcon } from 'lucide-react';
import { tokens } from '../lib/designTokens';

interface MetricCardProps {
  icon?: LucideIcon;
  label: string;
  value: string | number;
  sublabel?: string;
  gradient: string; // e.g., "from-blue-500 to-blue-600"
}

export const MetricCard: React.FC<MetricCardProps> = ({ icon: Icon, label, value, sublabel, gradient }) => (
  <div className={`bg-gradient-to-br ${gradient} rounded-xl p-4 text-white shadow-sm`}>
    <div className="flex items-center justify-between mb-2">
      <span className="font-medium opacity-90" style={{ fontSize: tokens.fontSize.bodySmall }}>
        {label}
      </span>
      {Icon && <Icon size={18} className="opacity-70" />}
    </div>
    <div className="font-bold" style={{ fontSize: tokens.fontSize.metric }}>
      {value}
    </div>
    {sublabel && (
      <p className="opacity-75 mt-1" style={{ fontSize: tokens.fontSize.caption }}>
        {sublabel}
      </p>
    )}
  </div>
);
