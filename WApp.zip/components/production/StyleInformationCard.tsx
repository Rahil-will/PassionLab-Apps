import React from 'react';
import { ArrowRight, Calendar, Clock, Droplets, Edit2, Image as ImageIcon, Layers, Ruler, FileText, User } from 'lucide-react';
import { Button, Card, StatusPoint } from '../ui';
import { tokens } from '../../lib/designTokens';
import { daysBetween, formatDateDDMMYYYY } from '../../lib/orderDateUtils';
import { OrderPriorityChip } from '../../lib/orderPriority';
import type { StyleOrder } from '../../types';

export interface StyleInfoStats {
    orderQty: number;
    cutAllow: number;
    shipAllow: number;
    totalAdjusted: number;
}

interface StyleInformationCardProps {
    order: StyleOrder;
    sizeGroupName: string;
    flowSteps: string[];
    flowLabel: string;
    stats: StyleInfoStats;
    onEdit?: () => void;
    colorwayName?: string;
}

const Field: React.FC<{ label: string; children: React.ReactNode }> = ({ label, children }) => (
    <div>
        <label className="font-bold text-slate-400 uppercase tracking-wider block mb-1" style={{ fontSize: tokens.fontSize.caption }}>
            {label}
        </label>
        <div className="font-medium text-slate-900" style={{ fontSize: tokens.fontSize.bodySmall }}>
            {children}
        </div>
    </div>
);

export const StyleInformationCard: React.FC<StyleInformationCardProps> = ({
    order,
    sizeGroupName,
    flowSteps,
    flowLabel,
    stats,
    onEdit,
    colorwayName,
}) => {
    const jobCardDate = order.jobCardDate || order.orderDate;
    const overallLead = daysBetween(order.orderDate, order.deliveryDate);
    const productionLead = daysBetween(jobCardDate, order.deliveryDate);

    return (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            <div className="lg:col-span-8">
                <Card
                    title="Style Information"
                    subtitle="Style and order details"
                    className="shadow-sm border-slate-200 h-full"
                    action={
                        onEdit ? (
                            <Button variant="primary" size="sm" icon={Edit2} onClick={onEdit}>
                                Edit Order
                            </Button>
                        ) : undefined
                    }
                >
                    <div className="flex flex-col gap-5">
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
                            <Field label="Style Name">
                                <span className="font-bold text-slate-900 inline-flex flex-wrap items-center gap-2">
                                    {order.styleName}
                                    <OrderPriorityChip priority={order.priority} />
                                    {colorwayName && (
                                        <span className="font-bold text-slate-900">· {colorwayName}</span>
                                    )}
                                </span>
                            </Field>
                            <Field label="Style Ref"><span className="flex items-center gap-1.5"><Ruler size={13} className="text-slate-400" />{order.styleRef}</span></Field>
                            <Field label="PO Number"><span className="flex items-center gap-1.5"><FileText size={13} className="text-slate-400" />{order.poNumber}</span></Field>
                            <Field label="Buyer"><span className="flex items-center gap-1.5"><User size={13} className="text-slate-400" />{order.buyer}</span></Field>
                        </div>

                        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 border-t border-slate-100 pt-4">
                            <Field label="Garment Type">{order.garmentType || 'Standard'}</Field>
                            <Field label="Size Group">{sizeGroupName}</Field>
                            <Field label="Sewing SAM (ref)">
                                {order.sewingSam ?? order.sam ? `${order.sewingSam ?? order.sam} mins` : '—'}
                            </Field>
                            <Field label="Wash Type"><span className="flex items-center gap-1"><Droplets size={13} className="text-blue-400" />{order.washType || 'None'}</span></Field>
                        </div>

                        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 border-t border-slate-100 pt-4">
                            <Field label="Order Received"><span className="flex items-center gap-2"><Calendar size={13} className="text-slate-400" />{formatDateDDMMYYYY(order.orderDate)}</span></Field>
                            <Field label="Job Card Date"><span className="flex items-center gap-2"><Calendar size={13} className="text-slate-400" />{formatDateDDMMYYYY(jobCardDate)}</span></Field>
                            <Field label="Delivery Date"><span className="flex items-center gap-2"><Calendar size={13} className="text-slate-400" />{formatDateDDMMYYYY(order.deliveryDate)}</span></Field>
                            <Field label="Lead Time">
                                <span className="flex items-center gap-2 text-blue-600">
                                    <Clock size={13} />
                                    Overall {overallLead}d <span className="text-slate-300">|</span> Production {productionLead}d
                                </span>
                            </Field>
                        </div>

                        <div className="pt-4 border-t border-slate-100">
                            <label className="font-bold text-slate-400 uppercase tracking-wider block mb-3" style={{ fontSize: tokens.fontSize.caption }}>
                                Process Visualization
                            </label>
                            <div className="flex flex-wrap items-center gap-3">
                                <div className="flex items-center gap-2 text-slate-700 font-semibold shrink-0" style={{ fontSize: tokens.fontSize.bodySmall }}>
                                    <Layers size={13} className="text-slate-500" />
                                    {flowLabel}
                                </div>
                                <span className="text-slate-300">|</span>
                                <div className="flex items-center gap-2 overflow-x-auto pb-1 no-scrollbar flex-1 min-w-0">
                                    {flowSteps.map((step, idx) => (
                                        <React.Fragment key={step}>
                                            <div className="flex items-center justify-center px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-lg font-bold text-slate-700 min-w-[72px] text-[10px]">
                                                {step}
                                            </div>
                                            {idx < flowSteps.length - 1 && <ArrowRight size={12} className="text-slate-300 flex-shrink-0" />}
                                        </React.Fragment>
                                    ))}
                                </div>
                            </div>
                        </div>

                        <div className="pt-4 border-t border-slate-100">
                            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                                <div className="bg-slate-50 border border-slate-200 rounded-lg px-3 py-2.5">
                                    <div className="text-[9px] font-bold text-slate-400 uppercase mb-0.5">Order Qty</div>
                                    <div className="text-xs font-bold text-slate-800">{stats.orderQty.toLocaleString()}</div>
                                </div>
                                <div className="bg-blue-50 border border-blue-100 rounded-lg px-3 py-2.5">
                                    <div className="text-[9px] font-bold text-blue-400 uppercase mb-0.5">Cut Allow</div>
                                    <div className="text-xs font-bold text-blue-700">{stats.cutAllow}%</div>
                                </div>
                                <div className="bg-purple-50 border border-purple-100 rounded-lg px-3 py-2.5">
                                    <div className="text-[9px] font-bold text-purple-400 uppercase mb-0.5">Ship Allow</div>
                                    <div className="text-xs font-bold text-purple-700">{stats.shipAllow}%</div>
                                </div>
                                <div className="bg-emerald-50 border border-emerald-100 rounded-lg px-3 py-2.5">
                                    <div className="text-[9px] font-bold text-emerald-600 uppercase mb-0.5">Total Adjusted</div>
                                    <div className="text-xs font-bold text-emerald-800">{stats.totalAdjusted.toLocaleString()}</div>
                                </div>
                            </div>
                        </div>

                        <div className="pt-4 border-t border-slate-100 flex flex-col md:flex-row gap-4">
                            <div className="md:w-[80%] min-w-0">
                                <label className="font-bold text-slate-400 uppercase tracking-wider block mb-2" style={{ fontSize: tokens.fontSize.caption }}>
                                    Remarks
                                </label>
                                <p className="text-slate-700 bg-slate-50 border border-slate-200 rounded-lg px-4 py-3 whitespace-pre-wrap min-h-[48px]" style={{ fontSize: tokens.fontSize.bodySmall }}>
                                    {order.remarks?.trim() || 'No remarks'}
                                </p>
                            </div>
                            <div className="md:w-[20%] min-w-[120px] flex flex-col justify-center">
                                <label className="font-bold text-slate-400 uppercase tracking-wider block mb-2" style={{ fontSize: tokens.fontSize.caption }}>
                                    Status
                                </label>
                                <div className="bg-slate-50 border border-slate-200 rounded-lg px-4 py-3 flex items-center justify-center min-h-[48px]">
                                    <StatusPoint status={order.status} type={order.status === 'In Progress' ? 'primary' : 'success'} />
                                </div>
                            </div>
                        </div>
                    </div>
                </Card>
            </div>

            <div className="lg:col-span-4 h-full">
                <div className="bg-white rounded-xl shadow-sm border border-slate-200 h-full flex flex-col overflow-hidden">
                    <div className="px-4 py-3 border-b border-slate-100 bg-slate-50/50">
                        <h4 className="text-xs font-bold text-slate-500 uppercase flex items-center gap-2">
                            <ImageIcon size={14} /> Style Reference
                        </h4>
                    </div>
                    <div className="flex-1 bg-slate-100 relative min-h-[300px] flex items-center justify-center">
                        {order.image ? (
                            <img src={order.image} alt="Style" className="absolute inset-0 w-full h-full object-cover" />
                        ) : (
                            <div className="flex flex-col items-center justify-center text-slate-300">
                                <ImageIcon size={48} className="mb-2 opacity-50" />
                                <span className="text-xs font-bold uppercase">No Image</span>
                            </div>
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
};
