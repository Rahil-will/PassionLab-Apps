import React from 'react';
import { Grid3x3 } from 'lucide-react';
import { flowTableClasses as t } from '../../lib/productionFlowTable';
import type { SizeMap } from '../../lib/mesSizeDisplay';

export interface ProductionMatrixDeptCol {
  deptId: string;
  deptName: string;
}

export interface ProductionMatrixTableProps {
  sizeKeys: string[];
  processFlowRows: ProductionMatrixDeptCol[];
  orderQtyBySize: SizeMap;
  adjQtyBySize: SizeMap;
  rejectedBySize: SizeMap;
  readyToShipBySize: SizeMap;
  shippedBySize: SizeMap;
  balanceBySize: SizeMap;
  sumDeptSize: (deptName: string, size: string) => number;
  sumDeptTotal: (deptName: string) => number;
  totals: {
    order: number;
    adj: number;
    rejected: number;
    ready: number;
    shipped: number;
    balance: number;
  };
  loading?: boolean;
}

export const ProductionMatrixTable: React.FC<ProductionMatrixTableProps> = ({
  sizeKeys,
  processFlowRows,
  orderQtyBySize,
  adjQtyBySize,
  rejectedBySize,
  readyToShipBySize,
  shippedBySize,
  balanceBySize,
  sumDeptSize,
  sumDeptTotal,
  totals,
  loading = false,
}) => (
  <section>
    <div className="flex items-center gap-2 mb-2 px-1">
      <Grid3x3 size={14} className="text-blue-500" />
      <h2 className="text-[10px] font-bold uppercase tracking-wide text-slate-700">
        Production matrix
      </h2>
      {loading && (
        <span className="no-print text-[9px] font-normal text-slate-400">Loading sizes…</span>
      )}
      <span className="ml-auto text-[9px] text-slate-500 tabular-nums">
        Adj qty: <strong className="text-slate-800">{totals.adj.toLocaleString()}</strong>
      </span>
    </div>
    <div className={`${t.wrapper} rounded-2xl`}>
      <div className={t.scroll}>
        <table className={`${t.table} mes-report-matrix`}>
          <thead className={t.thead}>
            <tr>
              <th className={t.firstHead}>Size</th>
              <th className={t.numHead}>Order qty</th>
              <th className={t.adjHead}>Adj qty</th>
              {processFlowRows.map((d) => (
                <th key={d.deptId} className={t.deptHead}>
                  {d.deptName}
                </th>
              ))}
              <th className={t.numHead}>Rejected</th>
              <th className={t.numHead}>Ready to ship</th>
              <th className={t.numHead}>Shipped</th>
              <th className={`${t.numHead} border-r-0`}>Balance</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {sizeKeys.map((size) => (
              <tr key={size} className="hover:bg-slate-50/80">
                <td className={`${t.firstCell} font-bold text-slate-800`}>{size}</td>
                <td className={t.numCell}>{orderQtyBySize[size] ?? 0}</td>
                <td className={t.adjCell}>{adjQtyBySize[size] ?? 0}</td>
                {processFlowRows.map((d) => (
                  <td key={d.deptId} className={t.deptCell}>
                    {sumDeptSize(d.deptName, size) || '—'}
                  </td>
                ))}
                <td className={t.numCell}>{rejectedBySize[size] ?? 0}</td>
                <td className={`${t.numCell} text-slate-800`}>{readyToShipBySize[size] ?? 0}</td>
                <td className={t.numCell}>{shippedBySize[size] ?? 0}</td>
                <td className={`${t.numCell} border-r-0 font-semibold text-slate-800`}>
                  {balanceBySize[size] ?? 0}
                </td>
              </tr>
            ))}
          </tbody>
          <tfoot>
            <tr className="bg-slate-50 border-t-2 border-slate-200">
              <td className={t.footFirst}>Total</td>
              <td className={t.footNum}>{totals.order.toLocaleString()}</td>
              <td className={t.footAdj}>{totals.adj.toLocaleString()}</td>
              {processFlowRows.map((d) => (
                <td key={d.deptId} className={t.footDept}>
                  {sumDeptTotal(d.deptName) || '—'}
                </td>
              ))}
              <td className={t.footNum}>{totals.rejected.toLocaleString()}</td>
              <td className={t.footNum}>{totals.ready.toLocaleString()}</td>
              <td className={t.footNum}>{totals.shipped.toLocaleString()}</td>
              <td className={`${t.footNum} border-r-0 font-bold`}>{totals.balance.toLocaleString()}</td>
            </tr>
          </tfoot>
        </table>
      </div>
    </div>
  </section>
);
