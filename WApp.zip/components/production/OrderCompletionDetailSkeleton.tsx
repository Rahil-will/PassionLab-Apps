import React from 'react';
import { Skeleton } from '../Skeleton';

export const OrderCompletionDetailSkeleton: React.FC = () => (
  <div className="space-y-5 animate-pulse" aria-hidden>
    <div className="border border-slate-200 rounded-xl overflow-hidden">
      <div className="flex flex-col xl:flex-row p-4 gap-4">
        <Skeleton variant="rectangular" className="w-20 h-20 rounded-lg shrink-0" />
        <div className="flex-1 space-y-2">
          <Skeleton className="h-3 w-20" />
          <Skeleton className="h-6 w-48" />
          <Skeleton className="h-4 w-32" />
        </div>
      </div>
      <div className="grid grid-cols-4 gap-px bg-slate-100 border-t border-slate-100">
        {Array.from({ length: 4 }).map((_, i) => (
          <div key={i} className="bg-white p-3 space-y-1">
            <Skeleton className="h-2 w-12" />
            <Skeleton className="h-4 w-16" />
          </div>
        ))}
      </div>
    </div>
    <div className="space-y-2">
      <Skeleton className="h-3 w-40" />
      <Skeleton variant="rectangular" className="h-36 w-full rounded-2xl" />
    </div>
    <div className="space-y-2">
      <Skeleton className="h-3 w-36" />
      <Skeleton variant="rectangular" className="h-48 w-full rounded-2xl" />
    </div>
  </div>
);
