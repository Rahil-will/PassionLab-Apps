import React, { useCallback, useEffect, useLayoutEffect, useMemo, useRef, useState } from 'react';
import { format } from 'date-fns';
import { Download, Printer, RefreshCw, Trash2, X, AlertTriangle, Loader2 } from 'lucide-react';
import { useDataStore, useSettingsStore } from '../../stores';
import { Button, SelectDropdown, ListSkeleton, Modal } from '../ui';
import {
  fetchColorwayLabels,
  fetchCutToShipDetail,
  fetchCutToShipReport,
  type CutToShipDetail,
  type CutToShipRow,
} from '../../lib/mesReportsApi';
import { sumSizeAdjQty, sumSizeOrderQty, orderedSizeKeys, sizeOrderQty, sizeAdjQty } from '../../lib/colorwaySizesUtils';
import { sumSizeMap, type SizeMap } from '../../lib/mesSizeDisplay';
import {
  balanceToShipBySize,
  buildProcessFlowDeptRows,
  processFlowRowsToJourneyDepts,
} from '../../lib/cutToShipOps';
import {
  buildColorwayCutShipItems,
  matchesColorwaySearch,
  matchesCompletionFilter,
  type CompletionListFilter,
} from '../../lib/cutToShipList';
import {
  aggregateSizeMaps,
  disputedQtyByDepartment,
  groupColorwayItemsByOrder,
  mergeCutToShipRows,
} from '../../lib/orderCompletionScope';
import { scopedOrderQuantities } from '../../lib/orderQtyScope';
import { supabase } from '../../lib/supabase';
import {
  buildFulfillmentSnapshot,
  formatFulfillmentBool,
  formatFulfillmentPct,
  type FulfillmentSnapshot,
} from '../../lib/fulfillmentMetrics';
import { logRejectionCapture, logShipmentCapture, deleteShipmentRecord, MesCaptureError } from '../../lib/mesCapture';
import { canCaptureOnDesktop } from '../../lib/floorApps';
import {
  isColorwayClosed,
} from '../../lib/orderCompletionRules';
import { useOrderSizeProgress } from '../../hooks/useOrderSizeProgress';
import { OrderPriorityChip } from '../../lib/orderPriority';
import {
  REJECTION_AUDIT_DB_VALUE,
  SHIPMENT_TYPE_DB_VALUE,
} from '../../lib/supportDropdownCatalog';
import {
  supportDropdownLabel,
  supportDropdownSelectOptions,
} from '../../lib/supportDropdownValues';
import { StyleFlowTable } from '../reports/StyleFlowTable';
import { ProductionMatrixTable } from './ProductionMatrixTable';
import { OrderCompletionDetailSkeleton } from './OrderCompletionDetailSkeleton';
import { parseDeptApps } from '../../lib/reportDeptUtils';

interface RejectionTemplate {
  date: string;
  auditType: string;
  defectType: string;
  qtyBySize: SizeMap;
  comments: string;
}

interface ShipmentTemplate {
  date: string;
  shipmentType: string;
  qtyBySize: SizeMap;
  comments: string;
}

function emptySizeMap(sizes: string[]): SizeMap {
  const m: SizeMap = {};
  for (const s of sizes) m[s] = 0;
  return m;
}

function buildRejectionTemplate(
  sizeKeys: string[],
  auditDefault: string,
  defectDefault: string,
  partial?: Partial<RejectionTemplate>,
): RejectionTemplate {
  return {
    date: partial?.date ?? format(new Date(), 'yyyy-MM-dd'),
    auditType: partial?.auditType ?? auditDefault,
    defectType: partial?.defectType ?? defectDefault,
    comments: partial?.comments ?? '',
    qtyBySize: { ...emptySizeMap(sizeKeys), ...(partial?.qtyBySize ?? {}) },
  };
}

function buildShipmentTemplate(
  sizeKeys: string[],
  typeDefault: string,
  partial?: Partial<ShipmentTemplate>,
): ShipmentTemplate {
  return {
    date: partial?.date ?? format(new Date(), 'yyyy-MM-dd'),
    shipmentType: partial?.shipmentType ?? typeDefault,
    comments: partial?.comments ?? '',
    qtyBySize: { ...(partial?.qtyBySize ?? {}) },
  };
}

function matchesColorwayRow(rowColorwayId: unknown, colorwayId: string | undefined): boolean {
  if (!colorwayId) return true;
  return String(rowColorwayId ?? '') === colorwayId;
}

function summarizeSizeMap(map: Record<string, unknown> | SizeMap | null | undefined): string {
  if (!map || typeof map !== 'object') return '—';
  const entries = Object.entries(map as Record<string, unknown>)
    .map(([k, v]) => [k, typeof v === 'number' ? v : parseInt(String(v ?? '0'), 10) || 0] as const)
    .filter(([, qty]) => qty > 0)
    .sort(([a], [b]) => a.localeCompare(b));
  if (entries.length === 0) return '—';
  return entries.map(([s, q]) => `${s}:${q}`).join(', ');
}

function mergeSizeMaps(a: SizeMap, b: SizeMap): SizeMap {
  const out: SizeMap = { ...a };
  for (const [k, v] of Object.entries(b)) out[k] = (out[k] || 0) + (v || 0);
  return out;
}

const TEMPLATE_GRID = 'cut-to-ship-log-grid grid grid-cols-1 lg:grid-cols-[18rem_1fr] gap-4';
const SIDEBAR_PAGE_SIZE = 20;

const LOG_TH =
  'px-2 py-2 text-[10px] font-semibold text-slate-600 uppercase border border-slate-200 bg-slate-50 text-left whitespace-nowrap';
const LOG_TD =
  'px-2 py-2 text-[11px] text-slate-700 align-top border border-slate-200 text-left';

function FieldLabel({ children }: { children: React.ReactNode }) {
  return (
    <span className="text-[9px] font-bold text-slate-500 uppercase tracking-wide block mb-1">{children}</span>
  );
}

interface OrderCompletionWorkspaceProps {
  factoryId: string;
  userId: string;
  userRole: string;
  buyerFilter: string;
  completionFilter: CompletionListFilter;
  searchQuery: string;
  filterOrderId?: string;
  filterColorwayId?: string;
}

export const OrderCompletionWorkspace: React.FC<OrderCompletionWorkspaceProps> = ({
  factoryId,
  userId,
  userRole,
  buyerFilter,
  completionFilter,
  searchQuery,
  filterOrderId,
  filterColorwayId,
}) => {
  const canCaptureRole = canCaptureOnDesktop(userRole);
  const { orders, productionSummary, fetchData, loading: ordersLoading } = useDataStore();
  const { processFlows, supportDropdowns, departmentDefects, departments } = useSettingsStore();

  const [listLoading, setListLoading] = useState(true);
  const [reportLoading, setReportLoading] = useState(false);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [detailLoading, setDetailLoading] = useState(false);
  const [detailError, setDetailError] = useState<string | null>(null);
  const [cutRows, setCutRows] = useState<CutToShipRow[]>([]);
  const [colorwayMap, setColorwayMap] = useState<Map<string, import('../../lib/mesReportsApi').ColorwayLabel>>(new Map());
  const [selectedOrderId, setSelectedOrderId] = useState<string | null>(null);
  const [colorwayFilter, setColorwayFilter] = useState('');
  const [detail, setDetail] = useState<CutToShipDetail | null>(null);
  const [handoverSlips, setHandoverSlips] = useState<Array<Record<string, unknown>>>([]);
  const [saveError, setSaveError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [deleteShipmentTarget, setDeleteShipmentTarget] = useState<{ id: string; label: string } | null>(null);

  const [rejectionTemplate, setRejectionTemplate] = useState<RejectionTemplate | null>(null);
  const [shipmentTemplate, setShipmentTemplate] = useState<ShipmentTemplate | null>(null);
  const detailCacheRef = useRef<Map<string, CutToShipDetail>>(new Map());

  const auditTypeOptions = useMemo(
    () => supportDropdownSelectOptions(supportDropdowns, 'rejection_audit_type', REJECTION_AUDIT_DB_VALUE),
    [supportDropdowns],
  );

  const shipmentTypeOptions = useMemo(
    () => supportDropdownSelectOptions(supportDropdowns, 'shipment_type', SHIPMENT_TYPE_DB_VALUE),
    [supportDropdowns],
  );

  const defectOptions = useMemo(() => {
    const names = new Set<string>();
    for (const rec of departmentDefects) {
      for (const d of rec.defects) names.add(d.name);
    }
    const sorted = [...names].sort();
    const fallback = ['Damaged', 'Stained', 'Wrong size', 'Shading', 'Broken stitch', 'Print defect', 'Other'];
    const list = sorted.length > 0 ? sorted : fallback;
    return list.map((name) => ({ value: name, label: name }));
  }, [departmentDefects]);

  useEffect(() => {
    void fetchData();
  }, [fetchData]);

  const loadList = useCallback(async () => {
    setListLoading(true);
    setLoadError(null);
    try {
      const colorways = await fetchColorwayLabels(factoryId);
      setColorwayMap(new Map(colorways.map((c) => [c.id, c])));
    } catch (err) {
      setLoadError(err instanceof Error ? err.message : 'Failed to load orders');
    } finally {
      setListLoading(false);
    }
  }, [factoryId]);

  const loadReport = useCallback(async () => {
    setReportLoading(true);
    try {
      const rows = await fetchCutToShipReport(factoryId, {
        buyerId: buyerFilter || null,
      });
      setCutRows(rows);
    } catch (err) {
      setLoadError(err instanceof Error ? err.message : 'Failed to load cut-to-ship summary');
      setCutRows([]);
    } finally {
      setReportLoading(false);
    }
  }, [factoryId, buyerFilter]);

  const refreshAll = useCallback(() => {
    void fetchData({ silent: true });
    void loadList();
    void loadReport();
  }, [fetchData, loadList, loadReport]);

  useEffect(() => {
    void loadList();
  }, [loadList]);

  useEffect(() => {
    if (!ordersLoading && !listLoading) void loadReport();
  }, [ordersLoading, listLoading, loadReport]);

  const scopedOrders = useMemo(() => {
    if (!buyerFilter) return orders;
    return orders.filter((o) => o.buyerId === buyerFilter);
  }, [orders, buyerFilter]);

  const colorwayItems = useMemo(
    () => buildColorwayCutShipItems(cutRows, scopedOrders, colorwayMap),
    [cutRows, scopedOrders, colorwayMap],
  );

  const orderGroupsAll = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    const filtered = colorwayItems.filter(
      (i) => matchesColorwaySearch(i, q) && matchesCompletionFilter(i, completionFilter),
    );
    return groupColorwayItemsByOrder(filtered);
  }, [colorwayItems, searchQuery, completionFilter]);

  const orderGroups = useMemo(
    () => orderGroupsAll.slice(0, SIDEBAR_PAGE_SIZE),
    [orderGroupsAll],
  );

  const sidebarLoading = listLoading || ordersLoading;

  useEffect(() => {
    if (filterOrderId && orderGroups.some((g) => g.orderId === filterOrderId)) {
      setSelectedOrderId(filterOrderId);
      if (filterColorwayId) setColorwayFilter(filterColorwayId);
      return;
    }
    if (selectedOrderId && !orderGroups.some((g) => g.orderId === selectedOrderId)) {
      setSelectedOrderId(null);
      setColorwayFilter('');
    }
  }, [filterOrderId, filterColorwayId, orderGroups, selectedOrderId]);

  const selectedOrder = useMemo(
    () => (selectedOrderId ? orders.find((o) => o.id === selectedOrderId) ?? null : null),
    [orders, selectedOrderId],
  );

  const selectedGroup = useMemo(
    () => orderGroups.find((g) => g.orderId === selectedOrderId) ?? null,
    [orderGroups, selectedOrderId],
  );

  const activeColorwayId = colorwayFilter || null;

  const scopedReconRows = useMemo(() => {
    if (!detail || !selectedOrderId) return [] as CutToShipRow[];
    const rows = detail.reconciliation.filter((r) => r.order_id === selectedOrderId);
    if (!activeColorwayId) return rows;
    return rows.filter((r) => r.colorway_id === activeColorwayId);
  }, [detail, selectedOrderId, activeColorwayId]);

  const selectedRecon = useMemo(
    () => mergeCutToShipRows(scopedReconRows),
    [scopedReconRows],
  );

  useLayoutEffect(() => {
    if (!factoryId || !selectedOrderId) {
      setDetail(null);
      setDetailLoading(false);
      return;
    }

    setDetail(null);
    setDetailError(null);

    const cached = detailCacheRef.current.get(selectedOrderId);
    if (cached) {
      setDetail(cached);
      setDetailLoading(false);
      return;
    }

    setDetailLoading(true);
  }, [factoryId, selectedOrderId]);

  useEffect(() => {
    if (!factoryId || !selectedOrderId) return;

    const cached = detailCacheRef.current.get(selectedOrderId);
    if (cached) {
      setHandoverSlips([]);
      void supabase
        .from('handover_slips')
        .select('from_department_id, colorway_id, status, sent_qty, received_qty')
        .eq('factory_id', factoryId)
        .eq('order_id', selectedOrderId)
        .then((slipsRes) => {
          setHandoverSlips((slipsRes.data || []) as Array<Record<string, unknown>>);
        });
      return;
    }

    let cancelled = false;
    setDetailLoading(true);

    Promise.all([
      fetchCutToShipDetail(factoryId, selectedOrderId),
      supabase
        .from('handover_slips')
        .select('from_department_id, colorway_id, status, sent_qty, received_qty')
        .eq('factory_id', factoryId)
        .eq('order_id', selectedOrderId),
    ])
      .then(([d, slipsRes]) => {
        if (cancelled) return;
        detailCacheRef.current.set(selectedOrderId, d);
        setDetail(d);
        setHandoverSlips((slipsRes.data || []) as Array<Record<string, unknown>>);
        setDetailError(null);
      })
      .catch((err) => {
        if (cancelled) return;
        setDetail(null);
        setDetailError(err instanceof Error ? err.message : 'Failed to load order detail');
      })
      .finally(() => {
        if (!cancelled) setDetailLoading(false);
      });

    return () => {
      cancelled = true;
    };
  }, [factoryId, selectedOrderId]);

  const flowSteps = useMemo(() => {
    if (!selectedOrder) return [] as Array<{ dept_id: string; dept_name: string }>;
    const flow = processFlows.find((f) => f.id === selectedOrder.processFlow);
    if (!flow?.steps?.length) {
      return [
        { dept_id: '', dept_name: 'Cutting' },
        { dept_id: '', dept_name: 'Sewing' },
        { dept_id: '', dept_name: 'Finishing' },
        { dept_id: '', dept_name: 'Packing' },
      ];
    }
    return flow.steps.map((s: { dept_id?: string; dept_name?: string; name?: string }) => ({
      dept_id: s.dept_id || '',
      dept_name: s.dept_name || s.name || String(s.dept_id),
    }));
  }, [selectedOrder, processFlows]);

  const colorwayIdsForProgress = useMemo(() => {
    if (!selectedOrder) return [] as string[];
    if (activeColorwayId) return [activeColorwayId];
    return selectedOrder.colorways.map((c) => c.id);
  }, [selectedOrder, activeColorwayId]);

  const { lookup: sizeProgress, loading: sizeProgressLoading } = useOrderSizeProgress(
    factoryId,
    selectedOrderId ?? undefined,
    colorwayIdsForProgress,
    flowSteps,
  );

  const disputedByDept = useMemo(
    () => disputedQtyByDepartment(handoverSlips, activeColorwayId),
    [handoverSlips, activeColorwayId],
  );

  const processFlowRows = useMemo(
    () =>
      selectedOrderId
        ? buildProcessFlowDeptRows(
            flowSteps,
            detail?.journey ?? [],
            activeColorwayId,
            productionSummary,
            selectedOrderId,
            disputedByDept,
          )
        : [],
    [flowSteps, detail?.journey, activeColorwayId, productionSummary, selectedOrderId, disputedByDept],
  );

  const deptAppsById = useMemo(
    () =>
      new Map(
        departments.map((d) => [d.id, parseDeptApps(d.apps) ?? []] as const),
      ),
    [departments],
  );

  const plannedSizes = useMemo(() => {
    const base = selectedRecon?.cut_qty_by_size ?? {};
    return Object.keys(base).length ? base : { TOTAL: selectedRecon?.cut_qty ?? 0 };
  }, [selectedRecon]);

  const selectedColorway = useMemo(
    () =>
      activeColorwayId
        ? selectedOrder?.colorways.find((c) => c.id === activeColorwayId) ?? null
        : null,
    [selectedOrder, activeColorwayId],
  );

  const allColorwaysForSizes = useMemo(() => {
    if (!selectedOrder) return [];
    if (activeColorwayId) {
      const cw = selectedOrder.colorways.find((c) => c.id === activeColorwayId);
      return cw ? [cw] : [];
    }
    return selectedOrder.colorways;
  }, [selectedOrder, activeColorwayId]);

  const sizeKeys = useMemo(
    () =>
      orderedSizeKeys(
        allColorwaysForSizes.flatMap((cw) => cw.sizes ?? []),
        [
          ...Object.keys(plannedSizes),
          ...Object.keys(selectedRecon?.shipped_qty_by_size ?? {}),
          ...Object.keys(selectedRecon?.rejected_qty_by_size ?? {}),
        ],
      ),
    [allColorwaysForSizes, plannedSizes, selectedRecon],
  );

  const orderQtyBySize = useMemo(() => {
    const out: SizeMap = {};
    for (const cw of allColorwaysForSizes) {
      for (const row of cw.sizes ?? []) {
        const size = String(row.size ?? '').trim();
        if (size) out[size] = (out[size] ?? 0) + sizeOrderQty(row);
      }
    }
    for (const size of sizeKeys) {
      if (out[size] === undefined) out[size] = plannedSizes[size] ?? 0;
    }
    return out;
  }, [allColorwaysForSizes, sizeKeys, plannedSizes]);

  const adjQtyBySize = useMemo(() => {
    const out: SizeMap = {};
    for (const cw of allColorwaysForSizes) {
      for (const row of cw.sizes ?? []) {
        const size = String(row.size ?? '').trim();
        if (size) out[size] = (out[size] ?? 0) + (sizeAdjQty(row) || sizeOrderQty(row));
      }
    }
    for (const size of sizeKeys) {
      out[size] = out[size] ?? plannedSizes[size] ?? 0;
    }
    return out;
  }, [allColorwaysForSizes, sizeKeys, plannedSizes]);

  const adjQtyTotal = useMemo(() => sumSizeMap(adjQtyBySize), [adjQtyBySize]);

  const journeyFlowDepts = useMemo(
    () => processFlowRowsToJourneyDepts(processFlowRows, deptAppsById, adjQtyTotal),
    [processFlowRows, deptAppsById, adjQtyTotal],
  );

  const lastFlowDept = processFlowRows.length > 0 ? processFlowRows[processFlowRows.length - 1] : null;

  const readyToShipBySize = useMemo(() => {
    const out: SizeMap = {};
    if (!lastFlowDept || !selectedOrderId) return out;
    for (const size of sizeKeys) {
      let total = 0;
      for (const cwId of colorwayIdsForProgress) {
        const n = sizeProgress?.getSizeCount(cwId, lastFlowDept.deptName, size);
        total += typeof n === 'number' ? n : 0;
      }
      out[size] = total;
    }
    return out;
  }, [lastFlowDept, selectedOrderId, sizeKeys, sizeProgress, colorwayIdsForProgress]);

  const rejectedBySize = useMemo(
    () => selectedRecon?.rejected_qty_by_size ?? aggregateSizeMaps(scopedReconRows, (r) => r.rejected_qty_by_size),
    [selectedRecon, scopedReconRows],
  );

  const shippedBySize = useMemo(
    () => selectedRecon?.shipped_qty_by_size ?? aggregateSizeMaps(scopedReconRows, (r) => r.shipped_qty_by_size),
    [selectedRecon, scopedReconRows],
  );

  const balanceBySize = useMemo(
    () => balanceToShipBySize(sizeKeys, readyToShipBySize, rejectedBySize, shippedBySize),
    [sizeKeys, readyToShipBySize, rejectedBySize, shippedBySize],
  );

  const colorwayAdjQty = useMemo(() => sumSizeMap(adjQtyBySize), [adjQtyBySize]);

  const { orderQty: scopedOrderQty, adjQty: scopedAdjQty } = useMemo(
    () => scopedOrderQuantities(selectedOrder, activeColorwayId),
    [selectedOrder, activeColorwayId],
  );

  const activeColorwayItem = useMemo(
    () => (activeColorwayId ? selectedGroup?.items.find((i) => i.colorwayId === activeColorwayId) : null),
    [activeColorwayId, selectedGroup],
  );

  const fulfillment = useMemo((): FulfillmentSnapshot | null => {
    if (!selectedRecon || !selectedOrderId) return null;
    const status = activeColorwayItem?.completionStatus ?? 'ongoing';
    return buildFulfillmentSnapshot(selectedRecon, selectedOrder?.deliveryDate, status);
  }, [selectedRecon, selectedOrder?.deliveryDate, selectedOrderId, activeColorwayItem]);

  const selectedClosed = activeColorwayItem ? isColorwayClosed(activeColorwayItem.completionStatus) : false;

  const defaultAuditType = auditTypeOptions[0]?.value ?? 'final_audit';
  const defaultShipmentType = shipmentTypeOptions[0]?.value ?? 'main';
  const defaultDefect = defectOptions[0]?.value ?? 'Damaged';

  const clearRejectionTemplate = useCallback(() => {
    setRejectionTemplate(buildRejectionTemplate(sizeKeys, defaultAuditType, defaultDefect));
  }, [sizeKeys, defaultAuditType, defaultDefect]);

  const clearShipmentTemplate = useCallback(() => {
    setShipmentTemplate(buildShipmentTemplate(sizeKeys, defaultShipmentType));
  }, [sizeKeys, defaultShipmentType]);

  const resetTemplates = useCallback(() => {
    if (sizeKeys.length === 0) {
      setRejectionTemplate(null);
      setShipmentTemplate(null);
      return;
    }
    setRejectionTemplate(buildRejectionTemplate(sizeKeys, defaultAuditType, defaultDefect));
    setShipmentTemplate(buildShipmentTemplate(sizeKeys, defaultShipmentType));
  }, [sizeKeys, defaultAuditType, defaultDefect, defaultShipmentType]);

  useEffect(() => {
    resetTemplates();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedOrderId, colorwayFilter]);

  const draftShipTotal = shipmentTemplate ? sumSizeMap(shipmentTemplate.qtyBySize) : 0;
  const readyTotal = sumSizeMap(readyToShipBySize);
  const balanceTotal = sumSizeMap(balanceBySize);
  const loggedShip = selectedRecon?.shipped_qty ?? 0;
  const loggedRej = selectedRecon?.rejected_qty ?? 0;
  const cutQty = colorwayAdjQty || selectedRecon?.cut_qty || 0;

  const colorwayLabel = (id: string) =>
    selectedOrder?.colorways.find((c) => c.id === id)?.name ?? id.slice(0, 8);

  const canLog = canCaptureRole && !!activeColorwayId && !selectedClosed;
  const needsColorForLog = canCaptureRole && !activeColorwayId;

  const shipmentHistory = useMemo(() => {
    const list = (detail?.shipments || []) as Array<Record<string, unknown>>;
    return list
      .filter((s) => matchesColorwayRow(s.colorway_id, activeColorwayId))
      .map((s) => ({
        id: String(s.id ?? ''),
        date: String((s.shipment_date as string) ?? ''),
        type: String((s.shipment_type as string) ?? ''),
        colorwayId: String(s.colorway_id ?? ''),
        colorLabel: colorwayLabel(String(s.colorway_id ?? '')),
        qtyBySize: (s.shipped_qty_by_size as Record<string, unknown>) || {},
        notes: String((s.notes as string) ?? ''),
        total: Number(s.shipped_qty ?? 0) || 0,
      }))
      .filter((x) => x.id)
      .sort((a, b) => (b.date || '').localeCompare(a.date || ''));
  }, [detail?.shipments, activeColorwayId, colorwayLabel]);

  const rejectionHistory = useMemo(() => {
    const rows = (detail?.rejections || []) as Array<Record<string, unknown>>;
    const filtered = rows.filter((r) => matchesColorwayRow(r.colorway_id, activeColorwayId));
    const groups = new Map<string, { id: string; date: string; colorwayId: string; stage: string; reason: string; notes: string; qtyBySize: SizeMap; total: number }>();

    for (const r of filtered) {
      const id = String(r.id ?? '');
      const colorwayId = String(r.colorway_id ?? '');
      const date = String((r.rejected_date as string) ?? '');
      const stage = String((r.stage as string) ?? '');
      const reason = String((r.reason_code as string) ?? '');
      const notes = String((r.notes as string) ?? '');
      const size = String((r.size as string) ?? '');
      const qty = Number(r.qty ?? 0) || 0;

      const key = `${colorwayId}::${date}::${stage}::${reason}::${notes}`;
      const existing = groups.get(key);
      const nextMap: SizeMap = size ? { [size]: qty } : {};
      if (!existing) {
        groups.set(key, {
          id,
          date,
          colorwayId,
          stage,
          reason,
          notes,
          qtyBySize: nextMap,
          total: qty,
        });
      } else {
        existing.qtyBySize = mergeSizeMaps(existing.qtyBySize, nextMap);
        existing.total += qty;
      }
    }

    return [...groups.values()]
      .map((g) => ({ ...g, colorLabel: colorwayLabel(g.colorwayId) }))
      .sort((a, b) => (b.date || '').localeCompare(a.date || ''));
  }, [detail?.rejections, activeColorwayId, colorwayLabel]);

  const colorwayOptions = useMemo(() => {
    if (!selectedOrder) return [{ value: '', label: 'All colors' }];
    return [
      { value: '', label: 'All colors' },
      ...selectedOrder.colorways.map((cw) => ({ value: cw.id, label: cw.name })),
    ];
  }, [selectedOrder]);

  const handleSaveShipment = async () => {
    if (!selectedOrderId || !activeColorwayId || !shipmentTemplate) return;
    if (draftShipTotal <= 0) return;

    for (const size of sizeKeys) {
      const qty = shipmentTemplate.qtyBySize[size] ?? 0;
      const avail = balanceBySize[size] ?? 0;
      if (qty > avail) {
        setSaveError(`Ship qty for size ${size} (${qty}) exceeds available (${avail}).`);
        return;
      }
    }

    setSaving(true);
    setSaveError(null);
    try {
      await logShipmentCapture(factoryId, userId, {
        orderId: selectedOrderId,
        colorwayId: activeColorwayId,
        shippedQty: draftShipTotal,
        shippedQtyBySize: shipmentTemplate.qtyBySize,
        shipmentType: shipmentTemplate.shipmentType,
        shipmentDate: shipmentTemplate.date,
        notes: shipmentTemplate.comments,
      });
      await Promise.all([loadReport(), fetchData({ silent: true })]);
      const fresh = await fetchCutToShipDetail(factoryId, selectedOrderId);
      detailCacheRef.current.set(selectedOrderId, fresh);
      setDetail(fresh);
      setShipmentTemplate(buildShipmentTemplate(sizeKeys, defaultShipmentType));
    } catch (e) {
      setSaveError(e instanceof MesCaptureError ? e.message : 'Shipment save failed');
    } finally {
      setSaving(false);
    }
  };

  const handleSaveRejections = async () => {
    if (!selectedOrderId || !activeColorwayId || !rejectionTemplate) return;
    setSaving(true);
    setSaveError(null);
    try {
      for (const [size, qty] of Object.entries(rejectionTemplate.qtyBySize)) {
        if (!qty || qty <= 0) continue;
        await logRejectionCapture(factoryId, userId, {
          orderId: selectedOrderId,
          colorwayId: activeColorwayId,
          size,
          qty,
          reasonCode: rejectionTemplate.defectType,
          reasonDetail: rejectionTemplate.comments,
          stage: rejectionTemplate.auditType,
          rejectedDate: rejectionTemplate.date,
          notes: rejectionTemplate.comments,
        });
      }
      await Promise.all([loadReport(), fetchData({ silent: true })]);
      const fresh = await fetchCutToShipDetail(factoryId, selectedOrderId);
      detailCacheRef.current.set(selectedOrderId, fresh);
      setDetail(fresh);
      setRejectionTemplate(buildRejectionTemplate(sizeKeys, defaultAuditType, defaultDefect));
    } catch (e) {
      setSaveError(e instanceof MesCaptureError ? e.message : 'Rejection save failed');
    } finally {
      setSaving(false);
    }
  };

  const requestDeleteShipment = (shipmentId: string, label: string) => {
    if (!selectedOrderId || !shipmentId) return;
    setDeleteShipmentTarget({ id: shipmentId, label });
  };

  const cancelDeleteShipment = () => {
    setDeleteShipmentTarget(null);
  };

  const confirmDeleteShipment = async () => {
    if (!selectedOrderId || !deleteShipmentTarget) return;
    const shipmentId = deleteShipmentTarget.id;
    setSaving(true);
    setSaveError(null);
    try {
      await deleteShipmentRecord(factoryId, shipmentId);
      detailCacheRef.current.delete(selectedOrderId);
      await Promise.all([loadReport(), fetchData({ silent: true })]);
      const fresh = await fetchCutToShipDetail(factoryId, selectedOrderId);
      detailCacheRef.current.set(selectedOrderId, fresh);
      setDetail(fresh);
      setDeleteShipmentTarget(null);
    } catch (e) {
      setSaveError(e instanceof MesCaptureError ? e.message : 'Delete failed');
    } finally {
      setSaving(false);
    }
  };

  const handleDeleteShipment = (shipmentId: string, label: string) => {
    requestDeleteShipment(shipmentId, label);
  };

  const sumDeptSize = (deptName: string, size: string): number => {
    let total = 0;
    for (const cwId of colorwayIdsForProgress) {
      const n = sizeProgress?.getSizeCount(cwId, deptName, size);
      total += typeof n === 'number' ? n : 0;
    }
    return total;
  };

  const sumDeptTotal = (deptName: string): number => {
    let total = 0;
    for (const cwId of colorwayIdsForProgress) {
      total += sizeProgress?.getDeptTotal(cwId, deptName) ?? 0;
    }
    return total;
  };

  const handlePrint = () => window.print();

  const printMeta = format(new Date(), 'dd/MM/yyyy, HH:mm');

  return (
    <div id="order-completion-print-root" className="mes-report order-completion-report">
      <header className="print-only mes-report-header">
        <div>
          <div className="mes-report-logo">PRODIGI</div>
          <div className="mes-report-logo-sub">Textile Manufacturing</div>
        </div>
        <div className="mes-report-title-block">
          <h1 className="mes-report-title">ORDER COMPLETION REPORT</h1>
          <div className="mes-report-meta">Printed: {printMeta}</div>
        </div>
      </header>

      {selectedOrder && selectedGroup && (
        <div className="print-only oc-print-product-bar">
          <div>
            <div className="oc-print-product-label">Style</div>
            <div className="oc-print-product-value">{selectedGroup.styleName}</div>
          </div>
          <div>
            <div className="oc-print-product-label">PO number</div>
            <div className="oc-print-product-value">{selectedGroup.poNumber}</div>
          </div>
          <div>
            <div className="oc-print-product-label">Color</div>
            <div className="oc-print-product-value">
              {activeColorwayId ? colorwayLabel(activeColorwayId) : 'All colors'}
            </div>
          </div>
        </div>
      )}

      <div className="oc-layout-grid grid grid-cols-1 lg:grid-cols-[280px_1fr] gap-4 min-h-[520px]">
        <div className="oc-screen-sidebar no-print bg-white border border-slate-200 rounded-xl overflow-hidden flex flex-col">
          <div className="px-4 py-3 border-b border-slate-100 flex items-center justify-between">
            <span className="text-xs font-bold text-slate-700 uppercase">Orders</span>
            <button type="button" onClick={refreshAll} className="text-slate-400 hover:text-slate-600" title="Refresh" disabled={sidebarLoading || reportLoading}>
              <RefreshCw size={14} className={sidebarLoading || reportLoading ? 'animate-spin' : ''} />
            </button>
          </div>
          {orderGroupsAll.length > SIDEBAR_PAGE_SIZE && (
            <div className="px-4 py-1.5 border-b border-slate-100 bg-slate-50 text-[10px] text-slate-500">
              Showing {orderGroups.length} of {orderGroupsAll.length} orders
            </div>
          )}
          <div className="flex-1 overflow-y-auto min-h-[200px]">
            {sidebarLoading && <ListSkeleton />}
            {loadError && !sidebarLoading && <p className="p-4 text-xs text-red-600">{loadError}</p>}
            {!sidebarLoading && orderGroups.length === 0 && (
              <p className="p-4 text-xs text-slate-400">No matching orders</p>
            )}
            {!sidebarLoading && orderGroups.map((group) => (
              <button
                key={group.orderId}
                type="button"
                onClick={() => {
                  setSelectedOrderId(group.orderId);
                  setColorwayFilter('');
                }}
                className={`w-full text-left px-4 py-3 border-b border-slate-50 hover:bg-slate-50 transition-colors ${
                  selectedOrderId === group.orderId ? 'bg-blue-50 border-l-2 border-l-blue-500' : ''
                }`}
              >
                <div className="text-xs font-semibold text-slate-800">{group.styleName}</div>
                <div className="text-[10px] text-slate-500">PO {group.poNumber} · {group.buyerName}</div>
                <div className="mt-1 text-[10px] text-slate-500 flex flex-wrap gap-x-2 gap-y-0.5">
                  <span>{group.items.length} color{group.items.length !== 1 ? 's' : ''}</span>
                  <span>Cut {group.cutQty.toLocaleString()}</span>
                  <span>Ship {group.shippedQty.toLocaleString()}</span>
                  <span>Rej {group.rejectedQty.toLocaleString()}</span>
                </div>
              </button>
            ))}
          </div>
        </div>

        <div className="oc-detail-panel cut-to-ship-detail bg-white border border-slate-200 rounded-xl overflow-hidden print:border-0 print:rounded-none min-h-[520px]">
          {!sidebarLoading && !selectedOrder && (
            <p className="text-sm text-slate-400 py-12 text-center">Select an order from the list</p>
          )}

          {selectedOrder && selectedGroup && (
            <div className="p-4 space-y-5 print:p-0 print:space-y-4 relative">
              {detailLoading || !detail ? (
                <OrderCompletionDetailSkeleton />
              ) : selectedRecon ? (
              <>

              {detailError && (
                <p className="no-print text-xs text-amber-700 bg-amber-50 border border-amber-100 rounded-lg px-3 py-2">
                  Detail API unavailable ({detailError}). Showing cached order data.
                </p>
              )}

              <div className="border border-slate-200 rounded-xl overflow-hidden mes-report-section-allow-break print:border-0">
                <div className="flex flex-col xl:flex-row xl:items-stretch">
                  <div className="flex gap-4 p-4 xl:p-5 flex-1 min-w-0 border-b xl:border-b-0 xl:border-r border-slate-100">
                    <div className="w-20 h-20 xl:w-24 xl:h-24 bg-slate-100 rounded-lg border border-slate-200 overflow-hidden shrink-0 flex items-center justify-center print:w-16 print:h-16">
                      {selectedOrder?.image ? (
                        <img src={selectedOrder.image} alt="" className="w-full h-full object-cover" />
                      ) : (
                        <span className="text-[9px] text-slate-400">No image</span>
                      )}
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wide">Style details</p>
                      <h3 className="text-base xl:text-lg font-bold text-slate-900 mt-1 leading-tight inline-flex flex-wrap items-center gap-2">
                        <span>{selectedGroup.styleName}</span>
                        <OrderPriorityChip priority={selectedOrder?.priority} />
                      </h3>
                      {selectedOrder?.styleRef ? (
                        <p className="text-xs font-semibold text-slate-600 mt-0.5">{selectedOrder.styleRef}</p>
                      ) : null}
                      <div className="mt-2 flex flex-wrap gap-2 items-center">
                        <span className="inline-flex items-center rounded-md bg-slate-100 px-2 py-1 text-[11px] font-semibold text-slate-700">
                          PO {selectedGroup.poNumber}
                        </span>
                        <span className="inline-flex items-center rounded-md bg-slate-50 px-2 py-1 text-[11px] text-slate-600">
                          {selectedGroup.buyerName}
                        </span>
                      </div>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 lg:grid-cols-4 xl:grid-cols-4 gap-px bg-slate-100 flex-1">
                    {[
                      { label: 'Delivery', value: selectedOrder?.deliveryDate ?? '—', accent: true },
                      { label: 'Order qty', value: `${scopedOrderQty.toLocaleString()} pcs`, accent: true },
                      { label: 'Sewing SAM (ref)', value: (selectedOrder?.sewingSam ?? selectedOrder?.sam) ? `${selectedOrder?.sewingSam ?? selectedOrder?.sam} min` : '—' },
                      { label: 'Garment', value: selectedOrder?.garmentType ?? '—' },
                      { label: 'Wash', value: selectedOrder?.washType ?? '—' },
                      { label: 'Adj qty', value: `${(activeColorwayId ? scopedAdjQty : colorwayAdjQty).toLocaleString()} pcs` },
                      { label: 'Balance to ship', value: `${balanceTotal.toLocaleString()} pcs` },
                      { label: 'Ready to ship', value: `${readyTotal.toLocaleString()} pcs` },
                    ].map((cell) => (
                      <div key={cell.label} className="bg-white px-3 py-3 xl:py-4">
                        <div className="text-[9px] font-bold text-slate-400 uppercase tracking-wide">{cell.label}</div>
                        <div className={`text-sm font-bold mt-1 tabular-nums ${cell.accent ? 'text-blue-700' : 'text-slate-800'}`}>
                          {cell.value}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
                <div className="no-print flex flex-col sm:flex-row sm:items-center gap-3 px-4 py-3 border-t border-b border-slate-100 bg-slate-50/70">
                  <SelectDropdown
                    label="Color"
                    value={colorwayFilter}
                    onChange={setColorwayFilter}
                    options={colorwayOptions}
                    className="w-full sm:flex-1 sm:max-w-xl"
                  />
                  <p className="text-[11px] text-slate-500 sm:ml-auto shrink-0">
                    {activeColorwayId
                      ? `Showing ${colorwayLabel(activeColorwayId)} only`
                      : 'All colors summed — pick a color to log shipment or rejection'}
                  </p>
                </div>
                {fulfillment && (
                  <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-7 gap-px bg-slate-100 border-t border-slate-100">
                    {[
                      { label: 'Order → Cut', value: formatFulfillmentPct(fulfillment.orderToCutPct) },
                      { label: 'Order → Ship', value: formatFulfillmentPct(fulfillment.orderToShipPct) },
                      { label: 'Cut → Ship', value: formatFulfillmentPct(fulfillment.cutToShipPct) },
                      { label: 'On time', value: formatFulfillmentBool(fulfillment.onTime, selectedClosed) },
                      { label: 'In full', value: formatFulfillmentBool(fulfillment.inFull, selectedClosed) },
                      {
                        label: 'On time in full',
                        value: formatFulfillmentBool(fulfillment.onTimeInFull, selectedClosed),
                      },
                      {
                        label: 'Last shipment',
                        value: selectedRecon?.last_shipment_date?.slice(0, 10) ?? '—',
                      },
                    ].map((cell) => (
                      <div key={cell.label} className="bg-white px-3 py-3">
                        <div className="text-[9px] font-bold text-slate-400 uppercase tracking-wide">{cell.label}</div>
                        <div className="text-sm font-bold mt-1 tabular-nums text-slate-800">{cell.value}</div>
                      </div>
                    ))}
                  </div>
                )}
                <div className="no-print flex justify-end gap-2 px-4 py-3 border-t border-slate-100 bg-slate-50/50">
                  <Button size="sm" variant="secondary" icon={Printer} onClick={handlePrint}>
                    Print
                  </Button>
                  <Button size="sm" variant="secondary" icon={Download} onClick={handlePrint}>
                    PDF
                  </Button>
                </div>
              </div>

              {selectedRecon && (
            <>
              <div className="mes-report-section-allow-break">
                <StyleFlowTable flowDepts={journeyFlowDepts} adjQty={adjQtyTotal} />
              </div>

              <div className="mes-report-section-allow-break">
                <ProductionMatrixTable
                  sizeKeys={sizeKeys}
                  processFlowRows={processFlowRows}
                  orderQtyBySize={orderQtyBySize}
                  adjQtyBySize={adjQtyBySize}
                  rejectedBySize={rejectedBySize}
                  readyToShipBySize={readyToShipBySize}
                  shippedBySize={shippedBySize}
                  balanceBySize={balanceBySize}
                  sumDeptSize={sumDeptSize}
                  sumDeptTotal={sumDeptTotal}
                  loading={sizeProgressLoading}
                  totals={{
                    order: sumSizeMap(orderQtyBySize),
                    adj: sumSizeMap(adjQtyBySize),
                    rejected: loggedRej,
                    ready: readyTotal,
                    shipped: loggedShip,
                    balance: balanceTotal,
                  }}
                />
              </div>

              {saveError && canLog && (
                <p className="no-print text-xs text-red-600 bg-red-50 rounded px-3 py-2">{saveError}</p>
              )}

              <div className="space-y-6 border-t border-slate-100 pt-4 mes-report-section-allow-break">
                <div>
                  <h3 className="no-print cut-to-ship-section-title text-xs font-bold text-slate-800 uppercase tracking-wide border-b border-slate-200 pb-2 mb-3">
                    Log rejection
                  </h3>
                  {needsColorForLog && (
                    <p className="no-print text-xs text-amber-800 bg-amber-50 border border-amber-100 rounded-lg px-3 py-2 mb-3">
                      Select a color above to log rejections. History below shows all colors for this PO.
                    </p>
                  )}
                  <div className={canLog ? TEMPLATE_GRID : ''}>
                  {canLog && (
                      <div className="no-print border border-slate-200 rounded-xl p-3 bg-slate-50/40 shrink-0">
                        <h4 className="text-[10px] font-bold text-slate-500 uppercase mb-3">Entry template</h4>
                        {rejectionTemplate && (
                          <div className="space-y-3">
                            <div className="grid grid-cols-1 gap-2">
                              <div>
                                <FieldLabel>Date</FieldLabel>
                                <input
                                  type="date"
                                  value={rejectionTemplate.date}
                                  onChange={(e) =>
                                    setRejectionTemplate((t) => (t ? { ...t, date: e.target.value } : t))
                                  }
                                  className="w-full text-xs border border-slate-200 rounded-lg px-3 py-2 bg-white"
                                />
                              </div>
                              <div>
                                <FieldLabel>Audit type</FieldLabel>
                                <SelectDropdown
                                  value={rejectionTemplate.auditType}
                                  onChange={(v) =>
                                    setRejectionTemplate((t) => (t ? { ...t, auditType: v } : t))
                                  }
                                  options={auditTypeOptions}
                                  className="w-full"
                                />
                              </div>
                              <div>
                                <FieldLabel>Reason</FieldLabel>
                                <SelectDropdown
                                  value={rejectionTemplate.defectType}
                                  onChange={(v) =>
                                    setRejectionTemplate((t) => (t ? { ...t, defectType: v } : t))
                                  }
                                  options={defectOptions}
                                  className="w-full"
                                />
                              </div>
                            </div>

                            <div className="overflow-x-auto border border-slate-200 rounded-lg bg-white">
                              <table className="w-full text-[11px] table-fixed min-w-[200px]">
                                <thead className="bg-slate-50 border-b border-slate-200">
                                  <tr>
                                    {sizeKeys.map((s) => (
                                      <th key={s} className="text-center px-1 py-2 font-semibold text-slate-600">{s}</th>
                                    ))}
                                  </tr>
                                </thead>
                                <tbody>
                                  <tr>
                                    {sizeKeys.map((size) => (
                                      <td key={size} className="px-1 py-1.5">
                                        <input
                                          type="number"
                                          min={0}
                                          value={rejectionTemplate.qtyBySize[size] || ''}
                                          onChange={(e) =>
                                            setRejectionTemplate((t) =>
                                              t
                                                ? {
                                                    ...t,
                                                    qtyBySize: {
                                                      ...t.qtyBySize,
                                                      [size]: parseInt(e.target.value, 10) || 0,
                                                    },
                                                  }
                                                : t,
                                            )
                                          }
                                          className="w-full text-center border border-slate-200 rounded px-1 py-1.5 text-xs tabular-nums"
                                        />
                                      </td>
                                    ))}
                                  </tr>
                                </tbody>
                              </table>
                            </div>

                            <textarea
                              value={rejectionTemplate.comments}
                              onChange={(e) =>
                                setRejectionTemplate((t) => (t ? { ...t, comments: e.target.value } : t))
                              }
                              placeholder="Comments…"
                              rows={2}
                              className="w-full text-xs border border-slate-200 rounded-lg px-3 py-2 bg-white resize-none"
                            />

                            <div className="flex gap-2 pt-1">
                              <Button size="sm" variant="secondary" className="flex-1" onClick={clearRejectionTemplate} disabled={saving}>
                                Clear
                              </Button>
                              <Button size="sm" className="flex-1" onClick={handleSaveRejections} disabled={saving}>
                                Save
                              </Button>
                            </div>
                          </div>
                        )}
                      </div>
                  )}

                      <div className="border border-slate-200 rounded-lg p-3 bg-white min-w-0 print:border-0 print:p-0">
                        <h4 className="cut-to-ship-section-title text-xs font-bold text-slate-800 mb-3">Rejection history</h4>
                        <div className="overflow-x-auto border border-slate-200 rounded-lg">
                          <table className="w-full border-collapse min-w-[40rem]">
                            <thead>
                              <tr>
                                <th className={LOG_TH}>Date</th>
                                {!activeColorwayId && <th className={LOG_TH}>Color</th>}
                                <th className={LOG_TH}>Audit type</th>
                                <th className={LOG_TH}>Reason</th>
                                <th className={LOG_TH}>Size pcs</th>
                                <th className={LOG_TH}>Total pcs</th>
                                <th className={LOG_TH}>Comments</th>
                              </tr>
                            </thead>
                            <tbody>
                              {rejectionHistory.length === 0 && (
                                <tr>
                                  <td
                                    colSpan={activeColorwayId ? 6 : 7}
                                    className={`${LOG_TD} text-slate-400 text-center py-6`}
                                  >
                                    No rejections logged
                                  </td>
                                </tr>
                              )}
                              {rejectionHistory.map((h) => (
                                <tr
                                  key={`${h.colorwayId}-${h.date}-${h.stage}-${h.reason}-${h.notes}`}
                                  className={canLog ? 'hover:bg-slate-50/60 cursor-pointer' : ''}
                                  onClick={canLog ? () =>
                                    setRejectionTemplate(
                                      buildRejectionTemplate(sizeKeys, defaultAuditType, defaultDefect, {
                                        date: h.date,
                                        auditType: h.stage,
                                        defectType: h.reason || defaultDefect,
                                        qtyBySize: h.qtyBySize,
                                        comments: h.notes,
                                      }),
                                    )
                                  : undefined}
                                >
                                  <td className={`${LOG_TD} whitespace-nowrap`}>{h.date || '—'}</td>
                                  {!activeColorwayId && (
                                    <td className={`${LOG_TD} whitespace-nowrap`}>{h.colorLabel || '—'}</td>
                                  )}
                                  <td className={`${LOG_TD} truncate`}>{supportDropdownLabel(auditTypeOptions, h.stage) || h.stage}</td>
                                  <td className={`${LOG_TD} truncate`}>{h.reason || '—'}</td>
                                  <td className={`${LOG_TD} truncate`}>{summarizeSizeMap(h.qtyBySize)}</td>
                                  <td className={`${LOG_TD} tabular-nums font-semibold`}>{h.total.toLocaleString()}</td>
                                  <td className={`${LOG_TD} break-words`}>{h.notes || '—'}</td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      </div>
                    </div>
                    </div>

                <div>
                  <h3 className="no-print cut-to-ship-section-title text-xs font-bold text-slate-800 uppercase tracking-wide border-b border-slate-200 pb-2 mb-3">
                    Log shipment
                  </h3>
                  {needsColorForLog && (
                    <p className="no-print text-xs text-amber-800 bg-amber-50 border border-amber-100 rounded-lg px-3 py-2 mb-3">
                      Select a color above to log shipments. History below shows all colors for this PO.
                    </p>
                  )}
                  <div className={canLog ? TEMPLATE_GRID : ''}>
                  {canLog && (
                      <div className="no-print border border-slate-200 rounded-xl p-3 bg-slate-50/40 shrink-0">
                        <h4 className="text-[10px] font-bold text-slate-500 uppercase mb-3">Entry template</h4>
                        {shipmentTemplate && (
                          <div className="space-y-3">
                            <div className="grid grid-cols-1 gap-2">
                              <div>
                                <FieldLabel>Date</FieldLabel>
                                <input
                                  type="date"
                                  value={shipmentTemplate.date}
                                  onChange={(e) =>
                                    setShipmentTemplate((t) => (t ? { ...t, date: e.target.value } : t))
                                  }
                                  className="w-full text-xs border border-slate-200 rounded-lg px-3 py-2 bg-white"
                                />
                              </div>
                              <div>
                                <FieldLabel>Shipment type</FieldLabel>
                                <SelectDropdown
                                  value={shipmentTemplate.shipmentType}
                                  onChange={(v) =>
                                    setShipmentTemplate((t) => (t ? { ...t, shipmentType: v } : t))
                                  }
                                  options={shipmentTypeOptions}
                                  className="w-full"
                                />
                              </div>
                            </div>

                            <div className="overflow-x-auto border border-slate-200 rounded-lg bg-white">
                              <table className="w-full text-[11px]">
                                <thead className="bg-slate-50 border-b border-slate-200">
                                  <tr>
                                    <th className="text-left px-2 py-2 font-semibold text-slate-600">Size</th>
                                    <th className="text-right px-2 py-2 font-semibold text-slate-600">Avail</th>
                                    <th className="text-right px-2 py-2 font-semibold text-slate-800">Ship</th>
                                  </tr>
                                </thead>
                                <tbody>
                                  {sizeKeys.map((size) => (
                                    <tr key={size} className="border-t border-slate-100">
                                      <td className="px-2 py-1.5 font-bold">{size}</td>
                                      <td className="px-2 py-1.5 text-right tabular-nums text-slate-600">{balanceBySize[size] ?? 0}</td>
                                      <td className="px-2 py-1.5">
                                        <input
                                          type="number"
                                          min={0}
                                          max={balanceBySize[size] ?? 0}
                                          placeholder="—"
                                          value={
                                            shipmentTemplate.qtyBySize[size]
                                              ? String(shipmentTemplate.qtyBySize[size])
                                              : ''
                                          }
                                          onChange={(e) => {
                                            const avail = balanceBySize[size] ?? 0;
                                            const raw = e.target.value;
                                            let qty = raw === '' ? 0 : parseInt(raw, 10);
                                            if (!Number.isFinite(qty) || qty < 0) qty = 0;
                                            qty = Math.min(qty, avail);
                                            setShipmentTemplate((t) => {
                                              if (!t) return t;
                                              const next = { ...t.qtyBySize };
                                              if (qty <= 0) delete next[size];
                                              else next[size] = qty;
                                              return { ...t, qtyBySize: next };
                                            });
                                          }}
                                          className="w-full text-right border border-slate-200 rounded px-1.5 py-1 text-xs tabular-nums placeholder:text-slate-300"
                                        />
                                      </td>
                                    </tr>
                                  ))}
                                </tbody>
                                <tfoot className="bg-slate-50 border-t border-slate-200">
                                  <tr>
                                    <td className="px-2 py-1.5 font-bold">Total</td>
                                    <td className="px-2 py-1.5 text-right font-semibold tabular-nums">{balanceTotal}</td>
                                    <td className="px-2 py-1.5 text-right font-bold tabular-nums text-blue-700">{draftShipTotal}</td>
                                  </tr>
                                </tfoot>
                              </table>
                            </div>

                            <textarea
                              value={shipmentTemplate.comments}
                              onChange={(e) =>
                                setShipmentTemplate((t) => (t ? { ...t, comments: e.target.value } : t))
                              }
                              placeholder="Comments…"
                              rows={2}
                              className="w-full text-xs border border-slate-200 rounded-lg px-3 py-2 bg-white resize-none"
                            />

                            <div className="flex gap-2 pt-1">
                              <Button size="sm" variant="secondary" className="flex-1" onClick={clearShipmentTemplate} disabled={saving}>
                                Clear
                              </Button>
                              <Button
                                size="sm"
                                className="flex-1"
                                onClick={handleSaveShipment}
                                disabled={saving || draftShipTotal <= 0}
                              >
                                Save ({draftShipTotal})
                              </Button>
                            </div>
                          </div>
                        )}
                      </div>
                  )}

                      <div className="border border-slate-200 rounded-lg p-3 bg-white min-w-0 print:border-0 print:p-0">
                        <h4 className="cut-to-ship-section-title text-xs font-bold text-slate-800 mb-3">Shipment history</h4>
                        <div className="overflow-x-auto border border-slate-200 rounded-lg print:overflow-visible print:border-0">
                          <table className="w-full border-collapse min-w-[40rem] mes-report-table">
                            <thead>
                              <tr>
                                <th className={LOG_TH}>Date</th>
                                {!activeColorwayId && <th className={LOG_TH}>Color</th>}
                                <th className={LOG_TH}>Type</th>
                                <th className={LOG_TH}>Total pcs</th>
                                <th className={LOG_TH}>Size pcs</th>
                                <th className={LOG_TH}>Comments</th>
                                {canLog && <th className={`${LOG_TH} no-print w-10`}> </th>}
                              </tr>
                            </thead>
                            <tbody>
                              {shipmentHistory.length === 0 && (
                                <tr>
                                  <td
                                    colSpan={canLog ? (activeColorwayId ? 6 : 7) : (activeColorwayId ? 5 : 6)}
                                    className={`${LOG_TD} text-slate-400 text-center py-6`}
                                  >
                                    No shipments logged
                                  </td>
                                </tr>
                              )}
                              {shipmentHistory.map((h) => (
                                <tr
                                  key={h.id}
                                  className={`${canLog ? 'hover:bg-slate-50/60 cursor-pointer' : ''} print:cursor-default`}
                                  onClick={canLog ? () =>
                                    setShipmentTemplate(
                                      buildShipmentTemplate(sizeKeys, defaultShipmentType, {
                                        date: h.date,
                                        shipmentType: h.type,
                                        qtyBySize: h.qtyBySize as SizeMap,
                                        comments: h.notes,
                                      }),
                                    )
                                  : undefined}
                                >
                                  <td className={`${LOG_TD} whitespace-nowrap`}>{h.date || '—'}</td>
                                  {!activeColorwayId && (
                                    <td className={`${LOG_TD} whitespace-nowrap`}>{h.colorLabel || '—'}</td>
                                  )}
                                  <td className={`${LOG_TD} truncate`}>{supportDropdownLabel(shipmentTypeOptions, h.type) || h.type}</td>
                                  <td className={`${LOG_TD} tabular-nums font-semibold`}>{h.total.toLocaleString()}</td>
                                  <td className={`${LOG_TD} truncate`}>{summarizeSizeMap(h.qtyBySize)}</td>
                                  <td className={`${LOG_TD} break-words`}>{h.notes || '—'}</td>
                                  {canLog && (
                                    <td className={`${LOG_TD} no-print text-center`}>
                                      <button
                                        type="button"
                                        title="Delete shipment row"
                                        disabled={saving}
                                        className="p-1 rounded text-slate-400 hover:text-red-600 hover:bg-red-50 disabled:opacity-40"
                                        onClick={(e) => {
                                          e.stopPropagation();
                                          const label = `${h.date || 'Shipment'} · ${supportDropdownLabel(shipmentTypeOptions, h.type) || h.type}`;
                                          handleDeleteShipment(h.id, label);
                                        }}
                                      >
                                        <Trash2 size={14} />
                                      </button>
                                    </td>
                                  )}
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      </div>
                    </div>
                    </div>
              </div>

              {!canCaptureRole && (
                <p className="no-print text-xs text-slate-500">Shipment and rejection entry requires admin or quality manager role.</p>
              )}
            </>
              )}

            </>
              ) : (
                <p className="text-sm text-slate-400 py-8 text-center">Unable to load order detail.</p>
              )}
            </div>
          )}
        </div>
      </div>

      <footer className="print-only mes-report-footer">
        <span>Prepared by: Order Completion</span>
        <span>{printMeta}</span>
      </footer>

      <Modal isOpen={deleteShipmentTarget !== null} onClose={cancelDeleteShipment}>
        <div className="relative">
          <button
            onClick={cancelDeleteShipment}
            className="absolute top-4 right-4 text-slate-400 hover:text-red-600 transition-colors p-1 hover:bg-red-50 rounded-full"
          >
            <X size={20} />
          </button>
          <div className="flex flex-col items-center p-8 pb-4 text-center">
            <div className="w-16 h-16 bg-red-100 text-red-600 rounded-2xl flex items-center justify-center mb-4 shadow-sm ring-4 ring-red-50">
              <Trash2 size={32} />
            </div>
            <h3 className="text-base font-bold text-slate-900 mb-2">Delete shipment log?</h3>
            <p className="text-slate-500 text-xs max-w-[280px] leading-relaxed">
              <span className="font-medium text-slate-700">{deleteShipmentTarget?.label}</span> will be
              permanently removed. This cannot be undone.
            </p>
          </div>
          <div className="p-6 pt-2 flex flex-col gap-3">
            <Button
              variant="danger"
              onClick={() => void confirmDeleteShipment()}
              disabled={saving}
              className="w-full py-2.5 text-xs"
            >
              {saving ? <Loader2 size={14} className="animate-spin mx-auto" /> : 'Delete'}
            </Button>
            <Button variant="secondary" onClick={cancelDeleteShipment} className="w-full text-xs">
              Cancel
            </Button>
          </div>
        </div>
      </Modal>
    </div>
  );
};
