import React, { useMemo, useState } from 'react';
import { ChevronLeft, ChevronRight, Calendar, ExternalLink } from 'lucide-react';
import { Card, SelectDropdown } from '../ui';
import {
    GanttAllocTooltip,
    GanttDeptHeaderRow,
    GanttResourceRows,
    GanttScheduleViewBar,
    GanttTimelineHeader,
    GanttTimelineMarkers,
    type GanttAlloc,
} from './GanttResourceRows';
import { sortResourcesBySequence } from '../../lib/ganttSchedule';
import { enrichAllocationsWithActuals, buildDeptNameByLineId } from '../../lib/ganttActuals';
import { buildTimelineDays, formatTimelineRange, GANTT_VIEW_DAYS } from '../../lib/ganttTimeline';
import { isProductionDepartment } from '../../lib/departmentFilters';
import { allocationColorwayId } from '../../lib/allocationUtils';
import { buildPlanningDetailParams } from '../../lib/planningNavigation';
import { useDataStore, useNavigationStore, useSettingsStore } from '../../stores';
import { RoutePath } from '../../types';

interface DepartmentScheduleGanttProps {
    orderId: string;
    colorwayId?: string;
    poNumber?: string;
    deliveryDate?: string;
}

export const DepartmentScheduleGantt: React.FC<DepartmentScheduleGanttProps> = ({
    orderId,
    colorwayId,
    poNumber,
    deliveryDate,
}) => {
    const { orders, assignedResources, allocations = [], productionSummary } = useDataStore();
    const { departments } = useSettingsStore();
    const { navigate } = useNavigationStore();

    const [hoveredAlloc, setHoveredAlloc] = useState<{
        alloc: GanttAlloc;
        anchorRect: DOMRect;
        mode: 'planned' | 'actual';
    } | null>(null);

    const [viewStartDate, setViewStartDate] = useState(() => {
        const d = new Date();
        d.setDate(d.getDate() - 2);
        return d.toISOString().split('T')[0];
    });

    const [filterDepartment, setFilterDepartment] = useState('');
    const [rowView, setRowView] = useState<'both' | 'planned' | 'running'>('both');

    const orderAllocations = useMemo(
        () =>
            allocations.filter((a) => {
                if (a.orderId !== orderId) return false;
                if (colorwayId && allocationColorwayId(a) !== colorwayId) return false;
                return true;
            }),
        [allocations, orderId, colorwayId],
    );

    const scheduleDepartments = useMemo(() => {
        const fromSettings = (departments || [])
            .filter((d) => !d.isOutsourced && isProductionDepartment(d))
            .sort((a, b) => (a.sequence || 0) - (b.sequence || 0))
            .map((d) => d.name);
        if (fromSettings.length > 0) return fromSettings;
        const fromResources = [...new Set(assignedResources.map((r) => r.departmentName).filter(Boolean))];
        return fromResources.sort();
    }, [departments, assignedResources]);

    const departmentsWithOrderAllocs = useMemo(() => {
        const names = new Set<string>();
        for (const alloc of orderAllocations) {
            const line = assignedResources.find((l) => l.id === alloc.lineId);
            const deptName =
                line?.departmentName ||
                (alloc.departmentId ? departments.find((d) => d.id === alloc.departmentId)?.name : undefined);
            if (deptName) names.add(deptName);
        }
        return scheduleDepartments.filter((d) => names.has(d));
    }, [orderAllocations, assignedResources, departments, scheduleDepartments]);

    const timelineData = useMemo(
        () => buildTimelineDays(new Date(viewStartDate), GANTT_VIEW_DAYS, 0),
        [viewStartDate],
    );

    const handlePrev = () => {
        const d = new Date(viewStartDate);
        d.setDate(d.getDate() - 7);
        setViewStartDate(d.toISOString().split('T')[0]);
    };

    const handleNext = () => {
        const d = new Date(viewStartDate);
        d.setDate(d.getDate() + 7);
        setViewStartDate(d.toISOString().split('T')[0]);
    };

    const getPositionStyle = (startStr: string, endStr: string) => {
        const start = new Date(startStr);
        const end = new Date(endStr);
        const viewStart = timelineData[0].dateObj;
        const totalDays = timelineData.length;
        const oneDay = 24 * 60 * 60 * 1000;

        let startDiff = Math.round((start.getTime() - viewStart.getTime()) / oneDay);
        let duration = Math.round((end.getTime() - start.getTime()) / oneDay) + 1;

        if (startDiff < 0) {
            duration += startDiff;
            startDiff = 0;
        }
        if (startDiff >= totalDays || duration <= 0) return null;

        const leftPct = (startDiff / totalDays) * 100;
        const widthPct = (Math.min(duration, totalDays - startDiff) / totalDays) * 100;

        return { left: `${leftPct}%`, width: `${widthPct}%` };
    };

    const deptIdByName = useMemo(() => {
        const map = new Map<string, string>();
        for (const d of departments || []) map.set(d.name, d.id);
        return map;
    }, [departments]);

    const orderById = useMemo(() => new Map(orders.map((o) => [o.id, o])), [orders]);

    const deptNameById = useMemo(
        () => new Map((departments || []).map((d) => [d.id, d.name])),
        [departments],
    );

    const deptNameByLineId = useMemo(
        () => buildDeptNameByLineId(assignedResources, deptNameById),
        [assignedResources, deptNameById],
    );

    const enrichAllocation = (alloc: (typeof allocations)[0]) => {
        const order = orderById.get(alloc.orderId);
        const [enriched] = enrichAllocationsWithActuals(
            [alloc],
            productionSummary,
            deptNameByLineId,
            deptNameById,
        );
        return {
            ...enriched,
            styleRef: order?.styleRef || '',
            dailyTarget: alloc.dailyTarget,
        };
    };

    const groups = useMemo(() => {
        const pool = filterDepartment ? [filterDepartment] : departmentsWithOrderAllocs;
        const orderAllocIds = new Set(orderAllocations.map((a) => a.id));

        return pool
            .map((dept) => {
                const deptId = deptIdByName.get(dept);
                const lines = sortResourcesBySequence(
                    assignedResources.filter((line) => line.departmentName === dept),
                );

                return { title: dept, deptId, lines, orderAllocIds };
            })
            .filter((g) => g.lines.length > 0 || filterDepartment === g.title);
    }, [
        assignedResources,
        filterDepartment,
        departmentsWithOrderAllocs,
        deptIdByName,
        orderAllocations,
    ]);

    const subtitleParts = [
        poNumber,
        deliveryDate ? `Delivery ${deliveryDate}` : null,
    ].filter(Boolean);

    const toolbar = (
        <div className="flex items-center gap-2 flex-wrap justify-end">
            <SelectDropdown
                value={rowView}
                onChange={(v) => setRowView(v as 'both' | 'planned' | 'running')}
                options={[
                    { value: 'both', label: 'Planned + Running' },
                    { value: 'planned', label: 'Planned only' },
                    { value: 'running', label: 'Running only' },
                ]}
                className="w-48"
            />

            <SelectDropdown
                value={filterDepartment}
                onChange={setFilterDepartment}
                options={[
                    { value: '', label: 'All Departments' },
                    ...departmentsWithOrderAllocs.map((d) => ({ value: d, label: d })),
                ]}
                className="w-40"
            />

            <div className="flex items-center gap-1 bg-white p-0.5 rounded-lg border border-slate-200 shadow-sm">
                <button type="button" onClick={handlePrev} className="p-1 hover:bg-slate-100 rounded text-slate-500">
                    <ChevronLeft size={16} />
                </button>
                <div className="flex items-center gap-1.5 px-1.5 border-x border-slate-100">
                    <Calendar size={13} className="text-slate-400" />
                    <input
                        type="date"
                        value={viewStartDate}
                        onChange={(e) => setViewStartDate(e.target.value)}
                        className="text-xs border-none focus:ring-0 text-slate-700 font-medium cursor-pointer bg-white w-28"
                    />
                </div>
                <button type="button" onClick={handleNext} className="p-1 hover:bg-slate-100 rounded text-slate-500">
                    <ChevronRight size={16} />
                </button>
            </div>
        </div>
    );

    return (
        <Card
            title="Department Schedule"
            subtitle={subtitleParts.length > 0 ? subtitleParts.join(' · ') : undefined}
            action={toolbar}
            className="shadow-sm border-slate-200"
            noPadding
        >
            <GanttScheduleViewBar
                timelineRange={formatTimelineRange(timelineData)}
                deliveryDate={deliveryDate}
                className="mx-6 mt-3"
                trailingAction={
                    <button
                        type="button"
                        onClick={() =>
                            navigate(
                                RoutePath.PLANNING_DETAIL,
                                buildPlanningDetailParams(orderId, orders, colorwayId),
                            )
                        }
                        className="p-1 rounded-md border border-slate-200 bg-white text-slate-500 hover:bg-slate-50 hover:text-blue-600 transition-colors"
                        title="Open Production Planning"
                    >
                        <ExternalLink size={13} />
                    </button>
                }
            />

            <div className="p-6 pt-3">
                {orderAllocations.length === 0 ? (
                    <div className="border border-slate-200 rounded-lg px-4 py-10 text-center text-[11px] text-slate-400 italic">
                        No plans saved yet for this {colorwayId ? 'colorway' : 'order'}.
                    </div>
                ) : (
                <div className="border border-slate-200 rounded-lg overflow-hidden overflow-x-auto">
                    <div className="min-w-max relative">
                        <GanttTimelineHeader timelineData={timelineData} layout="wide" />

                        <GanttTimelineMarkers timelineData={timelineData} deliveryDate={deliveryDate} />

                        {groups.map((group) => (
                            <React.Fragment key={group.title}>
                                <GanttDeptHeaderRow deptName={group.title} />

                                {group.lines.map((line) => {
                                    const lineAllocations = orderAllocations
                                        .filter(
                                            (a) =>
                                                group.orderAllocIds.has(a.id) &&
                                                (a.lineId === line.id ||
                                                    (!!group.deptId && a.departmentId === group.deptId && !a.lineId)),
                                        )
                                        .map(enrichAllocation);

                                    if (lineAllocations.length === 0) return null;

                                    return (
                                        <div
                                            key={line.id}
                                            className="relative group"
                                            onMouseLeave={() => setHoveredAlloc(null)}
                                        >
                                            <GanttResourceRows
                                                deptName={group.title}
                                                showDept={false}
                                                resourceName={line.resourceName || ''}
                                                timelineData={timelineData}
                                                allocations={lineAllocations}
                                                getPositionStyle={getPositionStyle}
                                                layout="wide"
                                                rowMode={rowView}
                                                onAllocHover={(alloc, rect, mode) =>
                                                    setHoveredAlloc({ alloc, anchorRect: rect, mode })
                                                }
                                                onAllocLeave={() => setHoveredAlloc(null)}
                                            />
                                        </div>
                                    );
                                })}
                            </React.Fragment>
                        ))}

                        {groups.length === 0 && orderAllocations.length > 0 && (
                            <div className="p-8 text-center text-slate-400 italic text-xs">
                                No matching departments for the current filter.
                            </div>
                        )}
                    </div>
                </div>
                )}
            </div>

            {hoveredAlloc && (
                <GanttAllocTooltip
                    alloc={hoveredAlloc.alloc}
                    anchorRect={hoveredAlloc.anchorRect}
                    mode={hoveredAlloc.mode}
                />
            )}
        </Card>
    );
};
