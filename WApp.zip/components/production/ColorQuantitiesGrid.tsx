import React, { useMemo } from 'react';
import { Copy, Trash2 } from 'lucide-react';
import type { Colorway } from '../../types';
import { sizeAdjQty, sizeOrderQty } from '../../lib/colorwaySizesUtils';

interface ColorQuantitiesGridProps {
  colorways: Colorway[];
  displaySizes: string[];
  totalAllowancePct: number;
  onNameChange: (id: string, name: string) => void;
  onOrderChange: (id: string, size: string, qty: number) => void;
  onAdjChange: (id: string, size: string, qty: number) => void;
  onDuplicate: (id: string) => void;
  onDelete: (id: string) => void;
  rowOrderTotal: (cw: Colorway) => number;
  rowAdjTotal: (cw: Colorway) => number;
  aggregateBySize: Record<string, { order: number; adjusted: number }>;
  totalOrderQty: number;
  totalAdjustedQty: number;
  hasSizeContext: boolean;
}

function buildRowCols(sizeCount: number) {
  return `2rem minmax(8rem, 2fr) repeat(${sizeCount}, minmax(5.25rem, 1fr)) minmax(5.25rem, 1fr) 2.5rem`;
}

const colorNameInput =
  'w-full min-w-0 text-[11px] font-semibold text-slate-800 bg-transparent border-0 border-b border-slate-200 focus:border-blue-500 focus:outline-none py-1.5 placeholder:text-slate-400 shadow-none rounded-none';

function GridCell({
  children,
  className = '',
}: {
  children?: React.ReactNode;
  className?: string;
  last?: boolean;
}) {
  return (
    <div className={`flex items-center min-h-[2.5rem] px-2.5 py-1.5 ${className}`}>
      {children}
    </div>
  );
}

function InlineQtyCell({
  ord,
  adj,
  onOrderChange,
  onAdjChange,
}: {
  ord: number;
  adj: number;
  onOrderChange: (v: number) => void;
  onAdjChange: (v: number) => void;
}) {
  const showAdj = ord > 0;
  const inputCls =
    'min-w-0 text-center border-0 bg-transparent text-[10px] font-semibold focus:outline-none tabular-nums shadow-none rounded-none p-0';

  return (
    <div className={`flex items-center justify-center w-full ${showAdj ? 'gap-1' : ''}`}>
      <input
        type="number"
        min={0}
        value={ord || ''}
        placeholder="0"
        onChange={(e) => onOrderChange(parseInt(e.target.value, 10) || 0)}
        className={`${inputCls} text-slate-800 ${showAdj ? 'w-[2.75rem]' : 'w-full max-w-[5rem]'}`}
        aria-label="Order qty"
      />
      {showAdj && (
        <>
          <span className="text-[10px] text-slate-300 shrink-0">/</span>
          <input
            type="number"
            min={0}
            value={adj || ''}
            placeholder="0"
            onChange={(e) => onAdjChange(parseInt(e.target.value, 10) || 0)}
            className={`${inputCls} text-blue-700 w-[2.75rem]`}
            aria-label="Adjusted qty"
          />
        </>
      )}
    </div>
  );
}

function rowTotalLabel(ord: number, adj: number) {
  if (ord <= 0) return <span className="text-slate-300 text-[11px]">—</span>;
  if (adj <= 0 || adj === ord) {
    return <span className="text-[11px] font-bold text-slate-800 tracking-wide tabular-nums">{ord.toLocaleString()}</span>;
  }
  return (
    <span className="inline-flex items-center justify-center gap-1.5 text-[11px] font-bold tracking-wide tabular-nums">
      <span className="text-slate-800">{ord.toLocaleString()}</span>
      <span className="text-slate-300 font-normal">/</span>
      <span className="text-blue-700">{adj.toLocaleString()}</span>
    </span>
  );
}

const headerLabel = 'text-[9px] font-bold text-slate-500 uppercase tracking-wide';
const headerSub = 'text-[8px] font-medium text-slate-400 normal-case tracking-normal';
const qtyText = 'text-[10px] font-semibold tabular-nums';

export const ColorQuantitiesGrid: React.FC<ColorQuantitiesGridProps> = ({
  colorways,
  displaySizes,
  totalAllowancePct,
  onNameChange,
  onOrderChange,
  onAdjChange,
  onDuplicate,
  onDelete,
  rowOrderTotal,
  rowAdjTotal,
  aggregateBySize,
  totalOrderQty,
  totalAdjustedQty,
  hasSizeContext,
}) => {
  const rowCols = useMemo(() => buildRowCols(displaySizes.length), [displaySizes]);

  const body = !hasSizeContext ? (
    <div className="flex-1 flex items-center justify-center py-10 text-slate-400 text-[11px] italic px-4">
      Select a size group to enter quantities.
    </div>
  ) : colorways.length === 0 ? (
    <div className="flex-1 flex items-center justify-center px-4">
      <p className="text-[11px] text-slate-400 italic py-8 text-center w-full rounded-lg border border-dashed border-slate-200 bg-slate-50/40">
        No colors yet. Use Add color above.
      </p>
    </div>
  ) : (
    <div className="flex-1 min-h-0 overflow-x-auto overflow-y-auto no-scrollbar">
      <div className="w-full min-w-[36rem]">
        <div
          className="grid w-full border-b border-slate-200 bg-slate-50/95 backdrop-blur-sm sticky top-0 z-10 shadow-[0_1px_0_0_rgba(226,232,240,1)]"
          style={{ gridTemplateColumns: rowCols }}
        >
          <GridCell className="justify-center bg-slate-50/95">
            <span className={headerLabel}>#</span>
          </GridCell>
          <GridCell className="justify-start bg-slate-50/95">
            <span className={headerLabel}>Color</span>
          </GridCell>
          {displaySizes.map((s) => (
            <GridCell key={s} className="justify-center flex-col gap-0.5 py-2 bg-slate-50/95">
              <span className={`${headerLabel} truncate max-w-full`}>{s}</span>
              <span className={headerSub}>ord / adj</span>
            </GridCell>
          ))}
          <GridCell className="justify-center flex-col gap-0.5 py-2 bg-slate-50/95">
            <span className={headerLabel}>Tot</span>
            <span className={headerSub}>ord / adj</span>
          </GridCell>
          <GridCell last className="justify-center bg-slate-50/95">
            <span className="sr-only">Actions</span>
          </GridCell>
        </div>

        <div>
          {colorways.map((cw, idx) => (
            <div
              key={cw.id}
              className={`grid w-full border-b border-slate-100 ${
                idx % 2 === 1 ? 'bg-slate-50/60' : 'bg-white'
              }`}
              style={{ gridTemplateColumns: rowCols }}
            >
              <GridCell className="justify-center">
                <span className={`${qtyText} text-slate-400`}>{idx + 1}</span>
              </GridCell>
              <GridCell className="justify-start">
                <input
                  value={cw.name}
                  onChange={(e) => onNameChange(cw.id, e.target.value)}
                  placeholder="Color name"
                  className={colorNameInput}
                  title={cw.name}
                />
              </GridCell>
              {displaySizes.map((s) => {
                const row = cw.sizes.find((sz) => sz.size === s) ?? { size: s, order_qty: 0, adj_qty: 0 };
                return (
                  <GridCell key={s} className="justify-center">
                    <InlineQtyCell
                      ord={sizeOrderQty(row)}
                      adj={sizeAdjQty(row)}
                      onOrderChange={(v) => onOrderChange(cw.id, s, v)}
                      onAdjChange={(v) => onAdjChange(cw.id, s, v)}
                    />
                  </GridCell>
                );
              })}
              <GridCell className="justify-center">
                <div className="text-center leading-none py-0.5">
                  {rowTotalLabel(rowOrderTotal(cw), rowAdjTotal(cw))}
                </div>
              </GridCell>
              <GridCell last className="flex-col gap-0.5 justify-center py-1">
                <button
                  type="button"
                  title="Duplicate"
                  onClick={() => onDuplicate(cw.id)}
                  className="p-0.5 text-slate-400 hover:text-blue-600 rounded hover:bg-blue-50"
                >
                  <Copy size={12} />
                </button>
                <button
                  type="button"
                  title="Remove"
                  onClick={() => onDelete(cw.id)}
                  className="p-0.5 text-slate-300 hover:text-red-500 rounded hover:bg-red-50"
                >
                  <Trash2 size={12} />
                </button>
              </GridCell>
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  return (
    <div className="flex flex-col flex-1 min-h-0 h-full">
      <div className="flex-1 flex flex-col min-h-0 px-0 pt-0">
        {body}
      </div>
      <SummaryFooter
        displaySizes={displaySizes}
        rowCols={rowCols}
        aggregateBySize={aggregateBySize}
        totalOrderQty={totalOrderQty}
        totalAdjustedQty={totalAdjustedQty}
        totalAllowancePct={totalAllowancePct}
        colorCount={colorways.length}
      />
    </div>
  );
};

function SummaryFooter({
  displaySizes,
  rowCols,
  aggregateBySize,
  totalOrderQty,
  totalAdjustedQty,
  totalAllowancePct,
  colorCount,
}: {
  displaySizes: string[];
  rowCols: string;
  aggregateBySize: Record<string, { order: number; adjusted: number }>;
  totalOrderQty: number;
  totalAdjustedQty: number;
  totalAllowancePct: number;
  colorCount: number;
}) {
  const summaryLine = (
    label: string,
    labelClass: string,
    pick: 'order' | 'adjusted',
    total: number,
    totalClass: string,
  ) => (
    <div className="grid w-full min-w-[36rem] border-t border-slate-200" style={{ gridTemplateColumns: rowCols }}>
      <GridCell className="justify-center" />
      <GridCell className="justify-start">
        <span className={`text-[9px] font-bold uppercase ${labelClass}`}>{label}</span>
      </GridCell>
      {displaySizes.map((s) => (
        <GridCell key={`${label}-${s}`} className="justify-center">
          <span className={`${qtyText} ${pick === 'adjusted' ? 'text-blue-700' : 'text-slate-700'}`}>
            {(aggregateBySize[s]?.[pick] || 0) > 0 ? aggregateBySize[s][pick].toLocaleString() : '—'}
          </span>
        </GridCell>
      ))}
      <GridCell className="justify-center">
        <span className={`text-[11px] font-bold tracking-wide tabular-nums ${totalClass}`}>{total.toLocaleString()}</span>
      </GridCell>
      <GridCell last />
    </div>
  );

  return (
    <div className="mt-auto shrink-0 border-t border-slate-200 bg-slate-50/80 rounded-b-xl overflow-x-auto no-scrollbar">
      <div className="flex items-center justify-between gap-3 px-4 py-2 border-b border-slate-100 min-w-[36rem]">
        <div className="flex items-center gap-2 min-w-0">
          <span className="text-[9px] font-bold uppercase text-slate-500 shrink-0">Summary</span>
          <span className="text-[9px] text-slate-400 shrink-0">·</span>
          <span className="text-[9px] font-medium text-slate-600 truncate">
            {colorCount} {colorCount === 1 ? 'color' : 'colors'}
          </span>
        </div>
        <span className="text-[9px] font-medium text-slate-500 shrink-0">
          Allowance <span className="text-slate-700 font-semibold">+{totalAllowancePct}%</span>
        </span>
      </div>
      {summaryLine('Order', 'text-slate-500', 'order', totalOrderQty, 'text-slate-900')}
      {summaryLine('Adj', 'text-blue-600', 'adjusted', totalAdjustedQty, 'text-blue-800')}
    </div>
  );
}
