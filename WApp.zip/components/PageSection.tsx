import React from 'react';
import { tokens } from '../lib/designTokens';

interface PageSectionProps {
  title: string;
  subtitle?: string;
  action?: React.ReactNode;
  noPadding?: boolean;
  children: React.ReactNode;
}

export const PageSection: React.FC<PageSectionProps> = ({ title, subtitle, action, noPadding, children }) => (
  <div className="bg-white border border-slate-200 rounded-xl shadow-sm flex flex-col overflow-hidden">
    {/* Header bar */}
    <div className="px-6 py-4 border-b border-slate-100 flex justify-between items-center bg-slate-50/50 rounded-t-xl shrink-0">
      <div>
        <h3 className="font-semibold text-slate-900" style={{ fontSize: tokens.fontSize.h2 }}>
          {title}
        </h3>
        {subtitle && (
          <p className="text-slate-400 uppercase tracking-wider mt-0.5" style={{ fontSize: tokens.fontSize.caption }}>
            {subtitle}
          </p>
        )}
      </div>
      {action && <div>{action}</div>}
    </div>
    {/* Content */}
    <div className={`${noPadding ? 'p-0' : 'p-6'} flex-1 flex flex-col min-h-0`}>
      {children}
    </div>
  </div>
);
