import React, { useMemo } from 'react';
import type { CutToShipRow } from '../../lib/mesReportsApi';
import {
  buildFulfillmentSnapshot,
  formatFulfillmentBool,
  formatFulfillmentPct,
} from '../../lib/fulfillmentMetrics';
import { isColorwayClosed, type ColorwayCompletionStatus } from '../../lib/orderCompletionRules';

export interface StyleFulfillmentMetricsBarProps {
  reconRow: CutToShipRow | null;
  deliveryDate: string | null;
  completionStatus: ColorwayCompletionStatus;
  scopedOrderQty: number;
}

export const StyleFulfillmentMetricsBar: React.FC<StyleFulfillmentMetricsBarProps> = ({
  reconRow,
  deliveryDate,
  completionStatus,
  scopedOrderQty,
}) => {
  const fulfillment = useMemo(() => {
    if (!reconRow) return null;
    const row: CutToShipRow = {
      ...reconRow,
      order_qty: scopedOrderQty > 0 ? scopedOrderQty : reconRow.order_qty,
    };
    return buildFulfillmentSnapshot(row, deliveryDate, completionStatus);
  }, [reconRow, deliveryDate, completionStatus, scopedOrderQty]);

  const closed = isColorwayClosed(completionStatus);

  if (!fulfillment) return null;

  const cells = [
    { label: 'Order → Cut', value: formatFulfillmentPct(fulfillment.orderToCutPct) },
    { label: 'Order → Ship', value: formatFulfillmentPct(fulfillment.orderToShipPct) },
    { label: 'Cut → Ship', value: formatFulfillmentPct(fulfillment.cutToShipPct) },
    { label: 'On time', value: formatFulfillmentBool(fulfillment.onTime, closed) },
    { label: 'In full', value: formatFulfillmentBool(fulfillment.inFull, closed) },
    { label: 'On time in full', value: formatFulfillmentBool(fulfillment.onTimeInFull, closed) },
    {
      label: 'Last shipment',
      value: reconRow?.last_shipment_date?.slice(0, 10) ?? '—',
    },
  ];

  return (
    <div className="rounded-2xl border border-slate-200 bg-white overflow-hidden shadow-sm">
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-7 gap-px bg-slate-100">
        {cells.map((cell) => (
          <div key={cell.label} className="bg-white px-3 py-3">
            <div className="text-[9px] font-bold text-slate-400 uppercase tracking-wide">{cell.label}</div>
            <div className="text-sm font-bold mt-1 tabular-nums text-slate-800">{cell.value}</div>
          </div>
        ))}
      </div>
    </div>
  );
};
