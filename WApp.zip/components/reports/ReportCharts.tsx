import React from 'react';
import { format, parseISO } from 'date-fns';
import { BarChart } from 'recharts/es6/chart/BarChart';
import { LineChart } from 'recharts/es6/chart/LineChart';
import { ComposedChart } from 'recharts/es6/chart/ComposedChart';
import { Bar } from 'recharts/es6/cartesian/Bar';
import { Line } from 'recharts/es6/cartesian/Line';
import { XAxis } from 'recharts/es6/cartesian/XAxis';
import { YAxis } from 'recharts/es6/cartesian/YAxis';
import { CartesianGrid } from 'recharts/es6/cartesian/CartesianGrid';
import { Tooltip } from 'recharts/es6/component/Tooltip';
import { Legend } from 'recharts/es6/component/Legend';
import { LabelList } from 'recharts/es6/component/LabelList';
import { ReferenceLine } from 'recharts/es6/cartesian/ReferenceLine';
import { ResponsiveContainer } from 'recharts/es6/component/ResponsiveContainer';

const chartMargin = { top: 8, right: 8, left: 0, bottom: 0 };
const axisStyle = { fontSize: 10, fill: '#94a3b8' };
const tooltipStyle = {
  fontSize: 11,
  borderRadius: 12,
  border: '1px solid #e2e8f0',
  backgroundColor: '#fff',
  boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)',
};

function formatChartDate(date: string): string {
  try {
    return format(parseISO(date), 'dd MMM');
  } catch {
    return date;
  }
}

interface ChartCardProps {
  title: string;
  subtitle?: string;
  height?: number;
  empty?: boolean;
  emptyMessage?: string;
  children: React.ReactNode;
}

const ChartCard: React.FC<ChartCardProps> = ({
  title,
  subtitle,
  height = 220,
  empty = false,
  emptyMessage = 'No data for this period',
  children,
}) => (
  <div className="bg-white rounded-2xl border border-slate-100 shadow-sm p-4">
    <p className="text-xs font-semibold text-slate-700 mb-0.5">{title}</p>
    {subtitle && <p className="text-[10px] text-slate-400 mb-3">{subtitle}</p>}
    {!subtitle && <div className="mb-3" />}
    {empty ? (
      <div
        className="flex items-center justify-center text-xs text-slate-400"
        style={{ height }}
      >
        {emptyMessage}
      </div>
    ) : (
      <ResponsiveContainer width="100%" height={height}>
        {children}
      </ResponsiveContainer>
    )}
  </div>
);

interface HourlyBarChartProps {
  data: Array<{ label: string; output: number }>;
  title?: string;
}

export const HourlyBarChart: React.FC<HourlyBarChartProps> = ({ data, title }) => {
  if (data.length === 0) return null;
  return (
    <div className="p-4 border-b border-slate-100">
      {title && <p className="text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-3">{title}</p>}
      <ResponsiveContainer width="100%" height={200}>
        <BarChart data={data} margin={chartMargin}>
          <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
          <XAxis dataKey="label" tick={axisStyle} interval={0} angle={-35} textAnchor="end" height={50} />
          <YAxis tick={axisStyle} width={36} />
          <Tooltip contentStyle={tooltipStyle} />
          <Bar dataKey="output" name="Output" fill="#3b82f6" radius={[6, 6, 0, 0]} maxBarSize={40} />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
};

interface CompareBarChartProps {
  data: Array<{ name: string; output: number; target: number }>;
  title?: string;
}

export const OutputTargetBarChart: React.FC<CompareBarChartProps> = ({ data, title }) => {
  if (data.length === 0) return null;
  return (
    <div className="p-4 border-b border-slate-100">
      {title && <p className="text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-3">{title}</p>}
      <ResponsiveContainer width="100%" height={220}>
        <BarChart data={data} margin={chartMargin}>
          <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
          <XAxis dataKey="name" tick={axisStyle} interval={0} angle={-20} textAnchor="end" height={48} />
          <YAxis tick={axisStyle} width={36} />
          <Tooltip contentStyle={tooltipStyle} />
          <Legend wrapperStyle={{ fontSize: 10 }} />
          <Bar dataKey="output" name="Output" fill="#3b82f6" radius={[6, 6, 0, 0]} maxBarSize={32} />
          <Bar dataKey="target" name="Target" fill="#cbd5e1" radius={[6, 6, 0, 0]} maxBarSize={32} />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
};

interface ShiftLineChartProps {
  data: Array<{ slot: string; output: number }>;
  title?: string;
}

export const ShiftLineChart: React.FC<ShiftLineChartProps> = ({ data, title }) => {
  if (data.length === 0) return null;
  return (
    <div className="p-4 border-b border-slate-100">
      {title && <p className="text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-3">{title}</p>}
      <ResponsiveContainer width="100%" height={180}>
        <LineChart data={data} margin={chartMargin}>
          <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
          <XAxis dataKey="slot" tick={axisStyle} />
          <YAxis tick={axisStyle} width={36} />
          <Tooltip contentStyle={tooltipStyle} />
          <Line type="monotone" dataKey="output" name="Output" stroke="#3b82f6" strokeWidth={2} dot={{ r: 3 }} />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
};

interface KpiStripProps {
  items: Array<{ label: string; value: string; accent?: string }>;
  compact?: boolean;
}

export const KpiStrip: React.FC<KpiStripProps> = ({ items, compact = false }) => (
  <div
    className={`grid grid-cols-2 sm:grid-cols-4 gap-2 border-b border-slate-100 bg-slate-50/30 ${
      compact ? 'p-2' : 'p-4 gap-3'
    }`}
  >
    {items.map((item) => (
      <div
        key={item.label}
        className={`bg-white rounded-lg border border-slate-200 shadow-sm ${
          compact ? 'px-2 py-1.5' : 'px-3 py-2.5 rounded-xl'
        }`}
      >
        <p
          className={`font-semibold text-slate-400 uppercase tracking-wider ${
            compact ? 'text-[8px]' : 'text-[9px] font-bold'
          }`}
        >
          {item.label}
        </p>
        <p
          className={`font-semibold tabular-nums ${item.accent ?? 'text-slate-800'} ${
            compact ? 'text-xs' : 'text-lg font-bold'
          }`}
        >
          {item.value}
        </p>
      </div>
    ))}
  </div>
);

interface DailyTrendChartProps {
  data: Array<{ date: string; output: number; target: number }>;
  title?: string;
  subtitle?: string;
  height?: number;
  /** Renders chart only — no outer card; for embedding beside KPIs. */
  embedded?: boolean;
}

/** Daily trend chart in department performance cards. */
export const DAILY_TREND_CHART_HEIGHT = 240;

/** @deprecated use DAILY_TREND_CHART_HEIGHT */
export const DEPT_CHART_HEIGHT = DAILY_TREND_CHART_HEIGHT;

const embeddedChartMargin = { top: 8, right: 12, left: 0, bottom: 4 };

export const DailyTrendChart: React.FC<DailyTrendChartProps> = ({
  data,
  title = 'Daily Output Trend',
  subtitle = 'pieces per day',
  height = DEPT_CHART_HEIGHT,
  embedded = false,
}) => {
  const chartData = data.map((d) => ({ ...d, label: formatChartDate(d.date) }));
  const empty = chartData.length === 0;

  const chart = (
    <ComposedChart data={chartData} margin={embedded ? embeddedChartMargin : chartMargin}>
      <CartesianGrid strokeDasharray="3 3" stroke="#f8fafc" />
      <XAxis dataKey="label" tick={axisStyle} interval="preserveStartEnd" />
      <YAxis tick={axisStyle} width={40} />
      <Tooltip contentStyle={tooltipStyle} />
      <Legend wrapperStyle={{ fontSize: 10, color: '#64748b' }} />
      <Bar dataKey="output" name="Output" fill="#3b82f6" radius={[4, 4, 0, 0]} maxBarSize={52}>
        {embedded && (
          <LabelList dataKey="output" position="top" fontSize={9} fill="#64748b" formatter={(v: number) => (v > 0 ? v : '')} />
        )}
      </Bar>
      <Line
        type="monotone"
        dataKey="target"
        name="Target"
        stroke="#cbd5e1"
        strokeWidth={2}
        strokeDasharray="4 4"
        dot={false}
      />
    </ComposedChart>
  );

  if (embedded) {
    return empty ? (
      <div
        className="flex items-center justify-center text-[10px] text-slate-400"
        style={{ height }}
      >
        No daily capture data
      </div>
    ) : (
      <ResponsiveContainer width="100%" height={height}>
        {chart}
      </ResponsiveContainer>
    );
  }

  return (
    <ChartCard title={title} subtitle={subtitle} height={height} empty={empty}>
      {chart}
    </ChartCard>
  );
};

interface EfficiencyLineChartProps {
  data: Array<{ date: string; efficiency: number | null }>;
  title?: string;
  subtitle?: string;
  height?: number;
}

export const EfficiencyLineChart: React.FC<EfficiencyLineChartProps> = ({
  data,
  title = 'Efficiency %',
  subtitle = 'daily average',
  height = 200,
}) => {
  const chartData = data.map((d) => ({
    ...d,
    label: formatChartDate(d.date),
    efficiency: d.efficiency ?? undefined,
  }));
  const empty = chartData.every((d) => d.efficiency == null);
  const showDots = chartData.length <= 14;

  return (
    <ChartCard title={title} subtitle={subtitle} height={height} empty={empty}>
      <LineChart data={chartData} margin={chartMargin}>
        <CartesianGrid strokeDasharray="3 3" stroke="#f8fafc" />
        <XAxis dataKey="label" tick={axisStyle} interval="preserveStartEnd" />
        <YAxis tick={axisStyle} width={40} unit="%" />
        <Tooltip contentStyle={tooltipStyle} />
        <ReferenceLine y={100} stroke="#10b981" strokeDasharray="4 4" />
        <Line
          type="monotone"
          dataKey="efficiency"
          name="Efficiency"
          stroke="#3b82f6"
          strokeWidth={2}
          connectNulls={false}
          dot={showDots ? { r: 3, fill: '#fff', stroke: '#3b82f6', strokeWidth: 2 } : false}
        />
      </LineChart>
    </ChartCard>
  );
};

interface DhuLineChartProps {
  data: Array<{ date: string; dhu: number | null }>;
  title?: string;
  subtitle?: string;
  height?: number;
}

export const DhuLineChart: React.FC<DhuLineChartProps> = ({
  data,
  title = 'DHU by Day',
  subtitle = 'DHU (Defects Per Hundred Units)',
  height = 200,
}) => {
  const chartData = data.map((d) => ({
    ...d,
    label: formatChartDate(d.date),
    dhu: d.dhu ?? undefined,
  }));
  const empty = chartData.every((d) => d.dhu == null);
  const showDots = chartData.length <= 14;

  return (
    <ChartCard title={title} subtitle={subtitle} height={height} empty={empty}>
      <LineChart data={chartData} margin={chartMargin}>
        <CartesianGrid strokeDasharray="3 3" stroke="#f8fafc" />
        <XAxis dataKey="label" tick={axisStyle} interval="preserveStartEnd" />
        <YAxis tick={axisStyle} width={40} />
        <Tooltip contentStyle={tooltipStyle} />
        <Line
          type="monotone"
          dataKey="dhu"
          name="DHU"
          stroke="#f59e0b"
          strokeWidth={2}
          connectNulls={false}
          dot={showDots ? { r: 3, fill: '#fff', stroke: '#f59e0b', strokeWidth: 2 } : false}
        />
      </LineChart>
    </ChartCard>
  );
};

interface DefectivePctLineChartProps {
  data: Array<{ date: string; defectivePct: number | null }>;
  title?: string;
  subtitle?: string;
  height?: number;
}

export const DefectivePctLineChart: React.FC<DefectivePctLineChartProps> = ({
  data,
  title = 'Defective %',
  subtitle = 'failed + rework vs inspected',
  height = 200,
}) => {
  const chartData = data.map((d) => ({
    ...d,
    label: formatChartDate(d.date),
    defectivePct: d.defectivePct ?? undefined,
  }));
  const empty = chartData.every((d) => d.defectivePct == null);
  const showDots = chartData.length <= 14;

  return (
    <ChartCard title={title} subtitle={subtitle} height={height} empty={empty}>
      <LineChart data={chartData} margin={chartMargin}>
        <CartesianGrid strokeDasharray="3 3" stroke="#f8fafc" />
        <XAxis dataKey="label" tick={axisStyle} interval="preserveStartEnd" />
        <YAxis tick={axisStyle} width={40} unit="%" />
        <Tooltip contentStyle={tooltipStyle} />
        <ReferenceLine y={3} stroke="#ef4444" strokeDasharray="4 4" />
        <Line
          type="monotone"
          dataKey="defectivePct"
          name="Defective %"
          stroke="#ef4444"
          strokeWidth={2}
          connectNulls={false}
          dot={showDots ? { r: 3, fill: '#fff', stroke: '#ef4444', strokeWidth: 2 } : false}
        />
      </LineChart>
    </ChartCard>
  );
};
