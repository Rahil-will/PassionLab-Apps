import React, { useEffect, useMemo, useState } from 'react';
import { useDataStore } from '../../stores';
import {
  fetchCutToShipDetail,
  type CutToShipDetail,
  type StyleJourneyReport,
} from '../../lib/mesReportsApi';
import { mergeCutToShipRows, aggregateSizeMaps } from '../../lib/orderCompletionScope';
import { balanceToShipBySize } from '../../lib/cutToShipOps';
import { orderedSizeKeys, sizeAdjQty, sizeOrderQty } from '../../lib/colorwaySizesUtils';
import { sumSizeMap, type SizeMap } from '../../lib/mesSizeDisplay';
import { useOrderSizeProgress } from '../../hooks/useOrderSizeProgress';
import { ProductionMatrixTable } from '../production/ProductionMatrixTable';

export interface StyleProductionMatrixSectionProps {
  factoryId: string;
  orderId: string;
  colorwayId: string | null;
  journey: StyleJourneyReport;
}

export const StyleProductionMatrixSection: React.FC<StyleProductionMatrixSectionProps> = ({
  factoryId,
  orderId,
  colorwayId,
  journey,
}) => {
  const { orders } = useDataStore();
  const [detail, setDetail] = useState<CutToShipDetail | null>(null);
  const [loading, setLoading] = useState(false);

  const flowSteps = useMemo(
    () =>
      journey.flowDepts.map((d) => ({
        dept_id: d.deptId,
        dept_name: d.deptName,
      })),
    [journey.flowDepts],
  );

  const colorwayIds = useMemo(
    () => (colorwayId ? [colorwayId] : journey.colorways.map((c) => c.id)),
    [colorwayId, journey.colorways],
  );

  const { lookup: sizeProgress, loading: sizeProgressLoading } = useOrderSizeProgress(
    factoryId,
    orderId,
    colorwayIds,
    flowSteps,
  );

  useEffect(() => {
    if (!factoryId || !orderId) {
      setDetail(null);
      return;
    }
    let cancelled = false;
    setLoading(true);
    fetchCutToShipDetail(factoryId, orderId)
      .then((d) => {
        if (!cancelled) setDetail(d);
      })
      .catch(() => {
        if (!cancelled) setDetail(null);
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [factoryId, orderId, colorwayId]);

  const scopedReconRows = useMemo(() => {
    if (!detail) return [];
    const rows = detail.reconciliation.filter((r) => r.order_id === orderId);
    if (!colorwayId) return rows;
    return rows.filter((r) => r.colorway_id === colorwayId);
  }, [detail, orderId, colorwayId]);

  const recon = useMemo(() => mergeCutToShipRows(scopedReconRows), [scopedReconRows]);

  const selectedOrder = useMemo(
    () => orders.find((o) => o.id === orderId) ?? null,
    [orders, orderId],
  );

  const colorwaysForSizes = useMemo(() => {
    if (!selectedOrder) return [];
    if (colorwayId) {
      const cw = selectedOrder.colorways.find((c) => c.id === colorwayId);
      return cw ? [cw] : [];
    }
    return selectedOrder.colorways;
  }, [selectedOrder, colorwayId]);

  const plannedSizes = useMemo(() => {
    const base = recon?.cut_qty_by_size ?? {};
    return Object.keys(base).length ? base : { TOTAL: recon?.cut_qty ?? 0 };
  }, [recon]);

  const sizeKeys = useMemo(
    () =>
      orderedSizeKeys(
        colorwaysForSizes.flatMap((cw) => cw.sizes ?? []),
        [
          ...Object.keys(plannedSizes),
          ...Object.keys(recon?.shipped_qty_by_size ?? {}),
          ...Object.keys(recon?.rejected_qty_by_size ?? {}),
        ],
      ),
    [colorwaysForSizes, plannedSizes, recon],
  );

  const orderQtyBySize = useMemo(() => {
    const out: SizeMap = {};
    for (const cw of colorwaysForSizes) {
      for (const row of cw.sizes ?? []) {
        const size = String(row.size ?? '').trim();
        if (size) out[size] = (out[size] ?? 0) + sizeOrderQty(row);
      }
    }
    for (const size of sizeKeys) {
      if (out[size] === undefined) out[size] = plannedSizes[size] ?? 0;
    }
    return out;
  }, [colorwaysForSizes, sizeKeys, plannedSizes]);

  const adjQtyBySize = useMemo(() => {
    const out: SizeMap = {};
    for (const cw of colorwaysForSizes) {
      for (const row of cw.sizes ?? []) {
        const size = String(row.size ?? '').trim();
        if (size) out[size] = (out[size] ?? 0) + (sizeAdjQty(row) || sizeOrderQty(row));
      }
    }
    for (const size of sizeKeys) {
      out[size] = out[size] ?? plannedSizes[size] ?? 0;
    }
    return out;
  }, [colorwaysForSizes, sizeKeys, plannedSizes]);

  const lastDept = journey.flowDepts.length > 0 ? journey.flowDepts[journey.flowDepts.length - 1] : null;

  const readyToShipBySize = useMemo(() => {
    const out: SizeMap = {};
    if (!lastDept) return out;
    for (const size of sizeKeys) {
      let total = 0;
      for (const cwId of colorwayIds) {
        const n = sizeProgress?.getSizeCount(cwId, lastDept.deptName, size);
        total += typeof n === 'number' ? n : 0;
      }
      out[size] = total;
    }
    return out;
  }, [lastDept, sizeKeys, sizeProgress, colorwayIds]);

  const rejectedBySize = useMemo(
    () => recon?.rejected_qty_by_size ?? aggregateSizeMaps(scopedReconRows, (r) => r.rejected_qty_by_size),
    [recon, scopedReconRows],
  );

  const shippedBySize = useMemo(() => {
    const fromRecon = recon?.shipped_qty_by_size ?? aggregateSizeMaps(scopedReconRows, (r) => r.shipped_qty_by_size);
    if (Object.keys(fromRecon).length > 0) return fromRecon;
    const out: SizeMap = {};
    for (const ship of journey.shipmentSummary.shipments) {
      if (!ship.qtyBySize) continue;
      for (const [size, qty] of Object.entries(ship.qtyBySize)) {
        out[size] = (out[size] ?? 0) + (qty || 0);
      }
    }
    return out;
  }, [recon, scopedReconRows, journey.shipmentSummary.shipments]);

  const balanceBySize = useMemo(
    () => balanceToShipBySize(sizeKeys, readyToShipBySize, rejectedBySize, shippedBySize),
    [sizeKeys, readyToShipBySize, rejectedBySize, shippedBySize],
  );

  const processFlowRows = useMemo(
    () => journey.flowDepts.map((d) => ({ deptId: d.deptId, deptName: d.deptName })),
    [journey.flowDepts],
  );

  const sumDeptSize = (deptName: string, size: string) => {
    let total = 0;
    for (const cwId of colorwayIds) {
      const n = sizeProgress?.getSizeCount(cwId, deptName, size);
      total += typeof n === 'number' ? n : 0;
    }
    return total;
  };

  const sumDeptTotal = (deptName: string) =>
    sizeKeys.reduce((sum, size) => sum + sumDeptSize(deptName, size), 0);

  const totals = useMemo(
    () => ({
      order: sumSizeMap(orderQtyBySize),
      adj: sumSizeMap(adjQtyBySize),
      rejected: sumSizeMap(rejectedBySize),
      ready: sumSizeMap(readyToShipBySize),
      shipped: sumSizeMap(shippedBySize),
      balance: sumSizeMap(balanceBySize),
    }),
    [orderQtyBySize, adjQtyBySize, rejectedBySize, readyToShipBySize, shippedBySize, balanceBySize],
  );

  if (sizeKeys.length === 0 && !loading && !sizeProgressLoading) {
    return (
      <p className="text-[10px] text-slate-400 text-center py-6">No size breakdown for this style.</p>
    );
  }

  return (
    <ProductionMatrixTable
      sizeKeys={sizeKeys}
      processFlowRows={processFlowRows}
      orderQtyBySize={orderQtyBySize}
      adjQtyBySize={adjQtyBySize}
      rejectedBySize={rejectedBySize}
      readyToShipBySize={readyToShipBySize}
      shippedBySize={shippedBySize}
      balanceBySize={balanceBySize}
      sumDeptSize={sumDeptSize}
      sumDeptTotal={sumDeptTotal}
      totals={totals}
      loading={loading || sizeProgressLoading}
    />
  );
};
