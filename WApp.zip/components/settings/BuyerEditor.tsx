import React, { useState, useEffect } from 'react';
import { Input, Button, SelectDropdown as Select } from '../ui';
import { User, Truck, Briefcase, Ruler, Plus, Edit, X, Trash2 } from 'lucide-react';
import { tokens } from '../../lib/designTokens';
import { useSettingsStore, useNavigationStore } from '../../stores';

interface BuyerEditorProps {
  formData: any;
  setFormData: (d: any) => void;
  onSave?: () => void;
  onDelete?: () => void;
}

export const BuyerEditor: React.FC<BuyerEditorProps> = ({
  formData,
  setFormData,
  onSave,
  onDelete,
}) => {
  const store = useSettingsStore();
  const { factoryId } = useNavigationStore();

  const localSizeGroups = formData._sizeGroups || [];
  const [newSizeGroupName, setNewSizeGroupName] = useState("");
  const [newSizesStr, setNewSizesStr] = useState("");
  const [editingGroup, setEditingGroup] = useState<string | null>(null);

  useEffect(() => {
    if (formData.id?.startsWith('temp_')) {
      if (!formData._sizeGroups) {
        setFormData({ ...formData, _sizeGroups: [], _init: true });
      }
      return;
    }
    if (formData._sizeGroups !== undefined) return;
    const existing = store.sizeGroups.filter((sg) => sg.buyerId === formData.id);
    setFormData({
      ...formData,
      _sizeGroups: existing.map((sg) => ({ ...sg, sizes: [...sg.sizes] })),
      _init: true,
    });
  }, [formData.id, store.sizeGroups]);

  const addSizeGroup = () => {
    if (!newSizeGroupName || !newSizesStr) return;

    const exists = localSizeGroups.some(
      (sg: any) => sg.name.toLowerCase() === newSizeGroupName.toLowerCase() && sg.id !== editingGroup
    );
    if (exists) {
      alert(`Size Group name "${newSizeGroupName}" already exists for this buyer.`);
      return;
    }

    const sizesArray = newSizesStr.split(",").map((s) => s.trim()).filter((s) => s);

    if (editingGroup) {
      const updated = localSizeGroups.map((sg: any) =>
        sg.id === editingGroup ? { ...sg, name: newSizeGroupName, sizes: sizesArray } : sg
      );
      setFormData({ ...formData, _sizeGroups: updated });
      setEditingGroup(null);
    } else {
      const newGroup = {
        id: crypto.randomUUID(),
        factory_id: factoryId,
        buyerId: formData.id,
        name: newSizeGroupName,
        sizes: sizesArray,
      };
      setFormData({ ...formData, _sizeGroups: [...localSizeGroups, newGroup] });
    }
    setNewSizeGroupName("");
    setNewSizesStr("");
  };

  const deleteSizeGroup = (id: string) => {
    const updated = localSizeGroups.filter((sg: any) => sg.id !== id);
    setFormData({ ...formData, _sizeGroups: updated });
  };

  const startEditGroup = (sg: any) => {
    setEditingGroup(sg.id);
    setNewSizeGroupName(sg.name);
    setNewSizesStr((Array.isArray(sg.sizes) ? sg.sizes : []).join(', '));
  };

  return (
    <div className="space-y-6 w-full">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* 1. General Info */}
        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
          <h4 className="text-xs font-bold text-slate-800 mb-4 flex items-center gap-2">
            <User size={16} /> General Information
          </h4>
          <div className="grid grid-cols-2 gap-4">
            <div className="col-span-2">
              <Input
                label="Buyer Name"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="bg-white"
              />
            </div>
            <Input
              label="Short Code"
              placeholder="e.g. ZARA"
              value={formData.code}
              onChange={(e) => setFormData({ ...formData, code: e.target.value })}
              className="bg-white"
            />
            <Input
              label="Country / Region"
              placeholder="e.g. Spain"
              value={formData.country || ""}
              onChange={(e) => setFormData({ ...formData, country: e.target.value })}
              className="bg-white"
            />
            <div>
              <label className="block font-medium text-slate-700 mb-1.5" style={{ fontSize: tokens.fontSize.body }}>Buyer Type</label>
              <Select
                value={formData.type || "Retail"}
                onChange={(value) => setFormData({ ...formData, type: value })}
                options={[
                  { value: "Retail", label: "Retail" },
                  { value: "Brand", label: "Brand" },
                  { value: "Agent", label: "Agent" },
                ]}
                className="bg-white"
              />
            </div>
            <div>
              <label className="block font-medium text-slate-700 mb-1.5" style={{ fontSize: tokens.fontSize.body }}>Status</label>
              <Select
                value={formData.status || "Active"}
                onChange={(value) => setFormData({ ...formData, status: value })}
                options={[
                  { value: "Active", label: "Active" },
                  { value: "Inactive", label: "Inactive" },
                ]}
                className="bg-white"
              />
            </div>
          </div>
        </div>

        {/* 2. Shipment & Packing */}
        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
          <h4 className="text-xs font-bold text-slate-800 mb-4 flex items-center gap-2">
            <Truck size={16} /> Shipment & Packing Rules
          </h4>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <Input
                label="Over-Shipment (%)"
                type="number"
                placeholder="e.g. 5"
                value={formData.overShipmentAllowance || ""}
                onChange={(e) => setFormData({ ...formData, overShipmentAllowance: parseFloat(e.target.value) })}
                className="bg-white"
              />
              <Input
                label="Under-Shipment (%)"
                type="number"
                placeholder="e.g. 0"
                value={formData.underShipmentAllowance || ""}
                onChange={(e) => setFormData({ ...formData, underShipmentAllowance: parseFloat(e.target.value) })}
                className="bg-white"
              />
            </div>
            <div>
              <label className="block font-medium text-slate-700 mb-1.5" style={{ fontSize: tokens.fontSize.body }}>Packing Rule</label>
              <Select
                value={formData.packingRule || "Ratio"}
                onChange={(value) => setFormData({ ...formData, packingRule: value })}
                options={[
                  { value: "Ratio", label: "Ratio Packing" },
                  { value: "Solid", label: "Solid Packing" },
                  { value: "Assortment", label: "Assortment" },
                ]}
                className="bg-white"
              />
            </div>
          </div>
        </div>

        {/* 3. Commercial Contact */}
        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
          <h4 className="text-xs font-bold text-slate-800 mb-4 flex items-center gap-2">
            <Briefcase size={16} /> Commercial Contact (Minimal)
          </h4>
          <div className="space-y-4">
            <Input
              label="Primary Contact Name"
              placeholder="e.g. John Doe"
              value={formData.contactName || ""}
              onChange={(e) => setFormData({ ...formData, contactName: e.target.value })}
              className="bg-white"
            />
            <Input
              label="Email Address"
              placeholder="john@buyer.com"
              value={formData.contactEmail || ""}
              onChange={(e) => setFormData({ ...formData, contactEmail: e.target.value })}
              className="bg-white"
            />
            <div>
              <label className="block font-medium text-slate-700 mb-1.5" style={{ fontSize: tokens.fontSize.body }}>Contact Role</label>
              <Select
                value={formData.contactRole || "Merch"}
                onChange={(value) => setFormData({ ...formData, contactRole: value })}
                options={[
                  { value: "Merch", label: "Merchandiser" },
                  { value: "QC", label: "Quality Control" },
                  { value: "Sourcing", label: "Sourcing Manager" },
                ]}
                className="bg-white"
              />
            </div>
          </div>
        </div>

        {/* 4. Size Groups */}
        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm lg:col-span-1">
          <div className="flex justify-between items-center mb-4">
            <h4 className="text-xs font-bold text-slate-800 flex items-center gap-2">
              <Ruler size={16} /> Size Groups Management
            </h4>
          </div>

          <div className="space-y-3 mb-6">
            {localSizeGroups.map((sg: any) => (
              <div
                key={sg.id}
                className="flex justify-between items-center p-3 bg-slate-50 rounded-lg border border-slate-100 group hover:border-slate-300 transition-colors"
              >
                <div>
                  <div className="font-bold text-xs text-slate-700">{sg.name}</div>
                  <div className="flex gap-1 mt-1 flex-wrap">
                    {(Array.isArray(sg.sizes) ? sg.sizes : []).map((s: string) => (
                      <span
                        key={s}
                        className="px-2 py-0.5 bg-white border border-slate-200 rounded text-[11px] font-mono text-slate-600"
                      >
                        {s}
                      </span>
                    ))}
                  </div>
                </div>
                <div className="flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                  <Button size="sm" variant="ghost" icon={Edit} onClick={() => startEditGroup(sg)} />
                  <Button
                    size="sm"
                    variant="ghost"
                    className="text-red-500 hover:text-red-600"
                    icon={Trash2}
                    onClick={() => deleteSizeGroup(sg.id)}
                  />
                </div>
              </div>
            ))}
            {localSizeGroups.length === 0 && (
              <div className="text-center py-4 text-slate-400 text-xs italic">
                No size groups defined for this buyer.
              </div>
            )}
          </div>

          <div className="bg-slate-50 p-4 rounded-lg border border-slate-200">
            <label className="text-xs font-bold text-slate-500 uppercase mb-2 block">
              {editingGroup ? "Edit Size Group" : "Add New Size Group"}
            </label>
            <div className="grid grid-cols-12 gap-3 items-end">
              <div className="col-span-4">
                <Input
                  placeholder="Name"
                  value={newSizeGroupName}
                  onChange={(e) => setNewSizeGroupName(e.target.value)}
                  className="bg-white"
                />
              </div>
              <div className="col-span-6">
                <Input
                  placeholder="Sizes (e.g. S, M, L)"
                  value={newSizesStr}
                  onChange={(e) => setNewSizesStr(e.target.value)}
                  className="bg-white"
                />
              </div>
              <div className="col-span-2">
                <Button
                  className="w-full"
                  onClick={addSizeGroup}
                  disabled={!newSizeGroupName || !newSizesStr}
                >
                  {editingGroup ? "OK" : "Add"}
                </Button>
              </div>
            </div>
            <p className="text-[10px] text-slate-400 mt-2">
              Comma separated sizes. Ex: XS, S, M, L, XL
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
