import React, { useMemo, useState } from 'react';
import { useSettingsStore } from '../../stores';
import { Input } from '../ui';
import {
  GitMerge,
  Plus,
  GripVertical,
  ChevronUp,
  ChevronDown,
  X,
  FileText,
  ArrowDown,
  Factory,
} from 'lucide-react';

interface FlowStep {
  flow_step: number;
  dept_id: string;
  dept_name: string;
}

interface ProcessFlowEditorProps {
  formData: any;
  setFormData: (d: any) => void;
  onSave?: () => void;
  onDelete?: () => void;
}

function reorderSteps(steps: FlowStep[], from: number, to: number): FlowStep[] {
  if (from === to || from < 0 || to < 0 || from >= steps.length || to >= steps.length) {
    return steps;
  }
  const next = [...steps];
  const [removed] = next.splice(from, 1);
  next.splice(to, 0, removed);
  return next.map((s, i) => ({ ...s, flow_step: i + 1 }));
}

export const ProcessFlowEditor: React.FC<ProcessFlowEditorProps> = ({
  formData,
  setFormData,
}) => {
  const store = useSettingsStore();
  const [draggedIdx, setDraggedIdx] = useState<number | null>(null);
  const [dropIdx, setDropIdx] = useState<number | null>(null);

  const isReadOnly = formData.is_current === false;

  const steps: FlowStep[] = (formData.steps || []).map(
    (step: { flow_step?: number; dept_id?: string; dept_name?: string }, idx: number) => ({
      flow_step: step.flow_step || idx + 1,
      dept_id: step.dept_id || '',
      dept_name: step.dept_name || '',
    }),
  );

  const usedDeptIds = new Set(steps.map((s) => s.dept_id));

  const availableDepts = useMemo(
    () =>
      [...store.departments]
        .sort((a, b) => (a.sequence ?? 999) - (b.sequence ?? 999))
        .filter((d) => !usedDeptIds.has(d.id)),
    [store.departments, usedDeptIds],
  );

  const setSteps = (next: FlowStep[]) => {
    setFormData({
      ...formData,
      steps: next.map((s, i) => ({ ...s, flow_step: i + 1 })),
    });
  };

  const addDept = (deptId: string) => {
    const dept = store.departments.find((d) => d.id === deptId);
    if (!dept || usedDeptIds.has(deptId)) return;
    setSteps([...steps, { flow_step: steps.length + 1, dept_id: dept.id, dept_name: dept.name }]);
  };

  const removeStep = (idx: number) => {
    setSteps(steps.filter((_, i) => i !== idx));
  };

  const moveStep = (idx: number, direction: -1 | 1) => {
    const target = idx + direction;
    if (target < 0 || target >= steps.length) return;
    setSteps(reorderSteps(steps, idx, target));
  };

  const onDragStart = (e: React.DragEvent, index: number) => {
    if (isReadOnly) return;
    setDraggedIdx(index);
    e.dataTransfer.effectAllowed = 'move';
    e.dataTransfer.setData('text/plain', String(index));
  };

  const onDragOver = (e: React.DragEvent, index: number) => {
    e.preventDefault();
    if (draggedIdx === null || isReadOnly) return;
    setDropIdx(index);
  };

  const onDrop = (e: React.DragEvent, index: number) => {
    e.preventDefault();
    if (draggedIdx === null || isReadOnly) return;
    setSteps(reorderSteps(steps, draggedIdx, index));
    setDraggedIdx(null);
    setDropIdx(null);
  };

  const onDragEnd = () => {
    setDraggedIdx(null);
    setDropIdx(null);
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-[minmax(280px,340px)_1fr] gap-5 items-start">
      {/* Flow details */}
      <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm space-y-5 md:sticky md:top-4">
        <div className="space-y-3">
          <div>
            <h4 className="text-xs font-bold text-slate-800 flex items-center gap-2">
              <GitMerge size={16} /> Process flow
            </h4>
            <p className="text-[10px] text-slate-400 mt-1">
              Define the department order pieces follow. Saving archives the previous version.
            </p>
          </div>
          {formData.is_current && (
            <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-emerald-50 border border-emerald-200 text-[10px] font-semibold text-emerald-700">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
              Current
            </span>
          )}
          {isReadOnly && (
            <span className="inline-flex px-2.5 py-1 rounded-full bg-slate-100 border border-slate-200 text-[10px] font-semibold text-slate-500">
              Archived v{formData.version || 1}
            </span>
          )}
        </div>

        <Input
          label="Flow name"
          value={formData.name || ''}
          onChange={(e) => setFormData({ ...formData, name: e.target.value })}
          placeholder="e.g. Standard Production"
          disabled={isReadOnly}
        />

        <div>
          <label className="block font-medium text-slate-700 mb-1.5 text-xs">Version</label>
          <div className="w-full px-3 py-2 text-sm rounded-lg border bg-slate-50 border-slate-200 text-slate-500 text-center font-mono">
            v{formData.version || 1}
          </div>
        </div>

        <div>
          <label className="block text-xs font-medium text-slate-700 mb-1.5 flex items-center gap-1.5">
            <FileText size={13} className="text-slate-400" />
            Description
          </label>
          <textarea
            rows={5}
            placeholder="When should planners use this flow?"
            value={formData.description || ''}
            onChange={(e) => setFormData({ ...formData, description: e.target.value })}
            disabled={isReadOnly}
            className="w-full px-3 py-2 text-sm rounded-lg border bg-white border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-200 disabled:bg-slate-50 resize-none"
          />
        </div>
      </div>

      {/* Sequence builder */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden min-w-0">
        <div className="px-6 py-4 border-b border-slate-100 bg-slate-50/60 flex items-center justify-between gap-3">
          <div>
            <h4 className="text-xs font-bold text-slate-800">Department sequence</h4>
            <p className="text-[10px] text-slate-400 mt-0.5">
              {isReadOnly ? 'Read-only archived flow' : 'Drag to reorder, or use arrows'}
            </p>
          </div>
          <span className="text-[10px] font-semibold text-slate-500 bg-white border border-slate-200 px-2 py-1 rounded-full">
            {steps.length} {steps.length === 1 ? 'step' : 'steps'}
          </span>
        </div>

        <div className="px-6 pb-6 pt-4">
          {steps.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-12 px-4 border-2 border-dashed border-slate-200 rounded-xl bg-slate-50/50">
              <div className="w-12 h-12 rounded-2xl bg-slate-100 flex items-center justify-center mb-3">
                <Factory size={22} className="text-slate-400" />
              </div>
              <p className="text-xs font-medium text-slate-600 mb-1">No departments in this flow</p>
              <p className="text-[10px] text-slate-400 text-center max-w-xs">
                Add departments below to build the production pipeline from first to last.
              </p>
            </div>
          ) : (
            <div className="relative">
              {/* Timeline rail */}
              <div
                className="absolute left-[18px] top-6 bottom-6 w-0.5 bg-gradient-to-b from-blue-300 via-blue-200 to-slate-200 rounded-full"
                aria-hidden
              />

              <ul className="space-y-0">
                {steps.map((step, idx) => {
                  const isDragging = draggedIdx === idx;
                  const isDropTarget = dropIdx === idx && draggedIdx !== null && draggedIdx !== idx;

                  return (
                    <li key={`${step.dept_id}-${idx}`} className="relative">
                      {isDropTarget && (
                        <div className="h-1 mx-2 mb-1 rounded-full bg-blue-400 animate-pulse" />
                      )}

                      <div
                        draggable={!isReadOnly}
                        onDragStart={(e) => onDragStart(e, idx)}
                        onDragOver={(e) => onDragOver(e, idx)}
                        onDrop={(e) => onDrop(e, idx)}
                        onDragEnd={onDragEnd}
                        className={`group flex items-stretch gap-3 py-2 pl-0 pr-1 transition-all ${
                          isDragging ? 'opacity-40' : ''
                        }`}
                      >
                        {/* Step node */}
                        <div className="relative z-10 flex flex-col items-center pt-3 shrink-0 w-9">
                          <div
                            className={`w-9 h-9 rounded-xl flex items-center justify-center text-xs font-bold shadow-sm border-2 ${
                              idx === 0
                                ? 'bg-blue-600 border-blue-600 text-white'
                                : idx === steps.length - 1
                                  ? 'bg-emerald-600 border-emerald-600 text-white'
                                  : 'bg-white border-blue-200 text-blue-700'
                            }`}
                          >
                            {step.flow_step}
                          </div>
                          {idx < steps.length - 1 && (
                            <ArrowDown size={14} className="text-slate-300 mt-1 mb-0.5" />
                          )}
                        </div>

                        {/* Step card */}
                        <div
                          className={`flex-1 flex items-center gap-2 min-h-[52px] px-4 py-3 rounded-xl border transition-all ${
                            isReadOnly
                              ? 'bg-slate-50 border-slate-200'
                              : 'bg-white border-slate-200 hover:border-blue-200 hover:shadow-sm'
                          } ${!isReadOnly ? 'cursor-grab active:cursor-grabbing' : ''}`}
                        >
                          {!isReadOnly && (
                            <GripVertical
                              size={16}
                              className="text-slate-300 group-hover:text-slate-400 shrink-0"
                            />
                          )}
                          <div className="flex-1 min-w-0">
                            <p className="text-sm font-semibold text-slate-800 truncate">
                              {step.dept_name}
                            </p>
                            <p className="text-[10px] text-slate-400">
                              {idx === 0
                                ? 'Entry — production starts here'
                                : idx === steps.length - 1
                                  ? 'Exit — last in-house step'
                                  : `Handover to ${steps[idx + 1]?.dept_name || 'next'}`}
                            </p>
                          </div>

                          {!isReadOnly && (
                            <div className="flex items-center gap-0.5 shrink-0">
                              <button
                                type="button"
                                onClick={() => moveStep(idx, -1)}
                                disabled={idx === 0}
                                className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 disabled:opacity-30 disabled:pointer-events-none transition-colors"
                                title="Move up"
                              >
                                <ChevronUp size={16} />
                              </button>
                              <button
                                type="button"
                                onClick={() => moveStep(idx, 1)}
                                disabled={idx === steps.length - 1}
                                className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 disabled:opacity-30 disabled:pointer-events-none transition-colors"
                                title="Move down"
                              >
                                <ChevronDown size={16} />
                              </button>
                              <button
                                type="button"
                                onClick={() => removeStep(idx)}
                                className="p-1.5 rounded-lg text-slate-400 hover:text-red-600 hover:bg-red-50 transition-colors ml-1"
                                title="Remove"
                              >
                                <X size={16} />
                              </button>
                            </div>
                          )}
                        </div>
                      </div>
                    </li>
                  );
                })}
              </ul>
            </div>
          )}

          {/* Add departments */}
          {!isReadOnly && (
            <div className="mt-6 pt-6 border-t border-slate-100 space-y-4">
              <p className="text-[10px] font-bold uppercase tracking-wide text-slate-500">
                Add department
              </p>

              {availableDepts.length === 0 ? (
                <div className="text-[11px] text-slate-400">
                  All departments are already in this flow.
                </div>
              ) : (
                <div className="flex flex-wrap gap-2">
                  {availableDepts.map((d) => (
                    <button
                      key={d.id}
                      type="button"
                      onClick={() => addDept(d.id)}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full border border-slate-200 bg-white text-xs font-medium text-slate-700 hover:border-blue-300 hover:bg-blue-50 hover:text-blue-700 transition-colors"
                    >
                      <Plus size={12} />
                      {d.name}
                    </button>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
