import React, { useState, useEffect, useMemo } from 'react';
import { useSettingsStore, useNavigationStore, useNotificationStore } from '../../stores';
import { Button, Input, SelectDropdown as Select } from '../ui';
import { Search, X, Edit, UserMinus, Calendar } from 'lucide-react';
import { supabase } from '../../lib/supabase';
import { tokens } from '../../lib/designTokens';
import { getErrorMessage } from '../../lib/assignedResourceDb';

interface Worker {
  id: string;
  factory_id: string;
  department_id: string;
  worker_id: string;
  name: string;
  role: string;
  is_active: boolean;
  date_of_joining?: string;
  date_of_leaving?: string;
  created_at?: string;
}

interface WorkforceEditorProps {
  selectedDeptId: string | null;
  onDirtyChange?: (dirty: boolean) => void;
}

export const WorkforceEditor: React.FC<WorkforceEditorProps> = ({
  selectedDeptId,
  onDirtyChange,
}) => {
  const { departments, bumpDepartmentWorkerRevision } = useSettingsStore();
  const { factoryId } = useNavigationStore();
  const { showNotification } = useNotificationStore();

  const [workers, setWorkers] = useState<Worker[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [viewMode, setViewMode] = useState<'active' | 'left'>('active');
  const [editingWorker, setEditingWorker] = useState<Worker | null>(null);
  const [showLeaveModal, setShowLeaveModal] = useState<Worker | null>(null);
  const [leaveDate, setLeaveDate] = useState('');

  const [form, setForm] = useState({
    name: '',
    worker_id: '',
    role: '',
    date_of_joining: new Date().toISOString().split('T')[0],
  });

  const fetchWorkers = async () => {
    if (!factoryId) return;
    setLoading(true);
    let query = supabase.from('workers').select('*').eq('factory_id', factoryId);
    if (selectedDeptId) {
      query = query.eq('department_id', selectedDeptId);
    }
    const { data, error } = await query.order('name');
    if (!error && data) setWorkers(data as Worker[]);
    setLoading(false);
  };

  useEffect(() => { fetchWorkers(); }, [factoryId, selectedDeptId]);

  const formDirty = Boolean(
    editingWorker ||
      form.name.trim() ||
      form.worker_id.trim() ||
      form.role.trim(),
  );

  useEffect(() => {
    onDirtyChange?.(formDirty);
  }, [formDirty, onDirtyChange]);

  const filteredWorkers = useMemo(() => {
    if (!search.trim()) return workers;
    const q = search.toLowerCase();
    return workers.filter(w =>
      w.name.toLowerCase().includes(q) ||
      w.worker_id.toLowerCase().includes(q) ||
      w.role.toLowerCase().includes(q)
    );
  }, [workers, search]);

  const activeWorkers = filteredWorkers.filter(w => w.is_active);
  const leftWorkers = filteredWorkers.filter(w => !w.is_active);

  const handleSave = async () => {
    if (!form.name.trim() || !form.worker_id.trim() || !selectedDeptId) return;
    if (!factoryId) {
      showNotification('Select a factory before saving workers', 'error');
      return;
    }
    if (editingWorker) {
      const { error } = await supabase.from('workers').update({
        name: form.name, worker_id: form.worker_id, role: form.role,
        department_id: selectedDeptId, date_of_joining: form.date_of_joining,
      }).eq('id', editingWorker.id);
      if (error) {
        showNotification(getErrorMessage(error, 'Failed to update worker'), 'error');
        return;
      }
      bumpDepartmentWorkerRevision();
      await fetchWorkers();
      resetForm();
    } else {
      const { error } = await supabase.from('workers').insert({
        factory_id: factoryId, name: form.name, worker_id: form.worker_id,
        role: form.role, department_id: selectedDeptId,
        date_of_joining: form.date_of_joining, is_active: true,
      });
      if (error) {
        showNotification(getErrorMessage(error, 'Failed to add worker'), 'error');
        return;
      }
      bumpDepartmentWorkerRevision();
      await fetchWorkers();
      resetForm();
    }
  };

  const handleMarkLeft = async () => {
    if (!showLeaveModal || !leaveDate) return;
    const { error } = await supabase.from('workers')
      .update({ is_active: false, date_of_leaving: leaveDate })
      .eq('id', showLeaveModal.id);
    if (error) {
      showNotification(getErrorMessage(error, 'Failed to mark worker as left'), 'error');
      return;
    }
    bumpDepartmentWorkerRevision();
    await fetchWorkers();
    setShowLeaveModal(null);
    setLeaveDate('');
  };

  const resetForm = () => {
    setForm({ name: '', worker_id: '', role: '', date_of_joining: new Date().toISOString().split('T')[0] });
    setEditingWorker(null);
  };

  const startEdit = (worker: Worker) => {
    setForm({ name: worker.name, worker_id: worker.worker_id, role: worker.role, date_of_joining: worker.date_of_joining || '' });
    setEditingWorker(worker);
  };

  const getDeptName = (deptId: string) => departments.find(d => d.id === deptId)?.name || 'Unknown';

  if (!selectedDeptId) {
    return (
      <div className="h-full flex flex-col items-center justify-center text-slate-300 border-2 border-dashed border-slate-200 rounded-xl bg-slate-50/50 py-20">
        <p className="text-xs font-medium text-slate-400">Select a department from the list to manage workers</p>
      </div>
    );
  }

  return (
    <div className="space-y-4 w-full">
      {/* Toolbar */}
      <div className="flex items-center justify-between">
        <div className="relative">
          <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            placeholder="Search workers..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-8 pr-3 py-1.5 text-xs rounded-lg border border-slate-200 bg-white focus:outline-none focus:ring-2 focus:ring-blue-100 w-56"
          />
        </div>
      </div>

      {/* Add/Edit Form - always visible */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-5">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-xs font-bold text-slate-800">
              {editingWorker ? 'Edit Worker' : 'Add New Worker'}
            </h3>
            {editingWorker && (
              <button onClick={resetForm} className="p-1 rounded hover:bg-slate-100">
                <X size={14} className="text-slate-400" />
              </button>
            )}
          </div>
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
            <Input label="Worker Name" placeholder="e.g. Ramesh Kumar" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className="bg-white" />
            <Input label="Worker ID" placeholder="e.g. EMP-001" value={form.worker_id} onChange={(e) => setForm({ ...form, worker_id: e.target.value })} className="bg-white font-mono" />
            <Input label="Role / Title" placeholder="e.g. Operator" value={form.role} onChange={(e) => setForm({ ...form, role: e.target.value })} className="bg-white" />
            <div>
              <label className="block font-medium text-slate-700 mb-1.5" style={{ fontSize: tokens.fontSize.body }}>Date of Joining</label>
              <input type="date" value={form.date_of_joining} onChange={(e) => setForm({ ...form, date_of_joining: e.target.value })} className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200 bg-white focus:outline-none focus:ring-2 focus:ring-blue-100" />
            </div>
          </div>
          <div className="flex gap-2 mt-3">
            <Button variant="primary" onClick={handleSave} disabled={!form.name.trim() || !form.worker_id.trim()}>
              {editingWorker ? 'Update' : 'Add Worker'}
            </Button>
            {editingWorker && <Button variant="ghost" onClick={resetForm}>Cancel</Button>}
          </div>
      </div>

      {/* Workers Table */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="px-4 py-2.5 border-b border-slate-100 bg-slate-50/50 flex items-center justify-between">
          <div className="flex gap-1 bg-slate-100 p-0.5 rounded-lg">
            <button
              onClick={() => setViewMode('active')}
              className={`px-3 py-1 rounded text-[11px] font-medium transition-all ${
                viewMode === 'active' ? 'bg-white text-emerald-700 shadow-sm' : 'text-slate-500 hover:text-slate-700'
              }`}
            >
              Active ({activeWorkers.length})
            </button>
            <button
              onClick={() => setViewMode('left')}
              className={`px-3 py-1 rounded text-[11px] font-medium transition-all ${
                viewMode === 'left' ? 'bg-white text-red-600 shadow-sm' : 'text-slate-500 hover:text-slate-700'
              }`}
            >
              Left ({leftWorkers.length})
            </button>
          </div>
        </div>
        {loading ? (
          <div className="flex items-center justify-center py-10 text-slate-400 text-xs">Loading...</div>
        ) : (viewMode === 'active' ? activeWorkers : leftWorkers).length === 0 ? (
          <div className="flex items-center justify-center py-10 text-slate-400 text-xs italic">
            No {viewMode === 'active' ? 'active' : 'left'} workers found.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead className="bg-slate-50 text-[9px] uppercase font-bold text-slate-500 tracking-wider">
                <tr>
                  <th className="px-4 py-2.5">ID</th>
                  <th className="px-4 py-2.5">Name</th>
                  <th className="px-4 py-2.5">Role</th>
                  <th className="px-4 py-2.5">Joined</th>
                  {viewMode === 'left' && <th className="px-4 py-2.5">Left On</th>}
                  <th className="px-4 py-2.5">Status</th>
                  {viewMode === 'active' && <th className="px-4 py-2.5 text-center">Edit</th>}
                  {viewMode === 'active' && <th className="px-4 py-2.5 text-center">Mark as Left</th>}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {(viewMode === 'active' ? activeWorkers : leftWorkers).map(worker => (
                  <tr key={worker.id} className={`hover:bg-slate-50/50 group ${viewMode === 'left' ? 'opacity-60' : ''}`}>
                    <td className="px-4 py-2.5 text-[11px] font-mono text-slate-600 truncate">{worker.worker_id}</td>
                    <td className="px-4 py-2.5 text-[11px] font-bold text-slate-800 truncate">{worker.name}</td>
                    <td className="px-4 py-2.5 text-[11px] text-slate-600 truncate">{worker.role}</td>
                    <td className="px-4 py-2.5 text-[11px] text-slate-500">{worker.date_of_joining ? new Date(worker.date_of_joining).toLocaleDateString() : '—'}</td>
                    {viewMode === 'left' && (
                      <td className="px-4 py-2.5 text-[11px] text-slate-500">{worker.date_of_leaving ? new Date(worker.date_of_leaving).toLocaleDateString() : '—'}</td>
                    )}
                    <td className="px-4 py-2.5">
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                        worker.is_active ? 'bg-emerald-50 text-emerald-700' : 'bg-red-50 text-red-600'
                      }`}>
                        {worker.is_active ? 'Active' : 'Left'}
                      </span>
                    </td>
                    {viewMode === 'active' && (
                      <td className="px-4 py-2.5 text-center">
                        <button onClick={() => startEdit(worker)} className="p-1.5 rounded-lg hover:bg-blue-50 text-blue-600 transition-colors" title="Edit"><Edit size={13} /></button>
                      </td>
                    )}
                    {viewMode === 'active' && (
                      <td className="px-4 py-2.5 text-center">
                        <button onClick={() => { setShowLeaveModal(worker); setLeaveDate(new Date().toISOString().split('T')[0]); }} className="p-1.5 rounded-lg hover:bg-red-50 text-red-500 transition-colors" title="Mark as Left"><UserMinus size={13} /></button>
                      </td>
                    )}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Mark as Left Modal */}
      {showLeaveModal && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl shadow-xl p-6 w-96 animate-in fade-in zoom-in duration-200">
            <h3 className="text-xs font-bold text-slate-800 mb-4 flex items-center gap-2">
              <UserMinus size={16} className="text-red-500" /> Mark Worker as Left
            </h3>
            <p className="text-[11px] text-slate-600 mb-4">
              Marking <span className="font-bold">{showLeaveModal.name}</span> ({showLeaveModal.worker_id}) as left.
            </p>
            <div className="mb-4">
              <label className="block text-xs font-medium text-slate-700 mb-1 flex items-center gap-1">
                <Calendar size={12} /> Date of Leaving
              </label>
              <input type="date" value={leaveDate} onChange={(e) => setLeaveDate(e.target.value)} className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200 bg-white focus:outline-none focus:ring-2 focus:ring-red-100" />
            </div>
            <div className="flex gap-2 justify-end">
              <Button variant="ghost" onClick={() => { setShowLeaveModal(null); setLeaveDate(''); }}>Cancel</Button>
              <button onClick={handleMarkLeft} disabled={!leaveDate} className="px-4 py-2 bg-red-600 text-white rounded-lg text-xs font-medium hover:bg-red-700 disabled:opacity-50 transition-colors">Confirm</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
