import React, { useState, useEffect, useRef, useMemo } from 'react';
import { Input, Button, Spinner } from '../ui';
import { supabase } from '../../lib/supabase';
import { useSettingsStore, useNavigationStore } from '../../stores';
import type { DepartmentResource } from '../../types/settings';
import {
  Box,
  Users,
  FileText,
  ClipboardList,
  CheckCircle,
  Layers,
  Factory,
  Edit,
  Plus,
  Trash2,
  X,
  Building2,
} from 'lucide-react';

interface AssignedResource extends DepartmentResource {
  managerName?: string;
  contactPhone?: string;
  address?: string;
}

interface DepartmentEditorProps {
  formData: {
    id: string;
    name: string;
    isOutsourced?: boolean;
    apps?: string[];
    workerRoles?: string[];
  };
  resources: DepartmentResource[];
  resourcesLoading: boolean;
  onResourcesChange: (resources: DepartmentResource[]) => void;
  setFormData: (d: Record<string, unknown>) => void;
  onSave?: () => void;
  onDelete?: () => void;
}

const OUTPUT_OPTIONS = [
  { id: 'hourly', name: 'Hourly Output', icon: Factory },
  { id: 'qc_log', name: 'QC Log', icon: CheckCircle },
  { id: 'none', name: 'None', icon: X },
];

const WORKFORCE_OPTIONS = [
  { id: 'workforce_log', name: 'Workforce Log', icon: Users },
  { id: 'attendance', name: 'Attendance', icon: ClipboardList },
  { id: 'none', name: 'None', icon: X },
];

const OPTIONAL_APPS = [
  { id: 'audit', name: 'Audit App', icon: FileText },
];

export const DepartmentEditor: React.FC<DepartmentEditorProps> = ({
  formData,
  resources,
  resourcesLoading,
  onResourcesChange,
  setFormData,
}) => {
  const [lineForm, setLineForm] = useState<Partial<AssignedResource> | null>(null);
  const [workerCount, setWorkerCount] = useState(0);
  const [newWorkerRole, setNewWorkerRole] = useState('');
  const factoryEntitlements = useSettingsStore((s) => s.factoryEntitlements);
  const departmentWorkerRevision = useSettingsStore((s) => s.departmentWorkerRevision);
  const factoryId = useNavigationStore((s) => s.factoryId);
  const isOutsourced = formData.isOutsourced || false;
  const workerRoles: string[] = formData.workerRoles ?? [];
  const formDataRef = useRef(formData);
  formDataRef.current = formData;

  useEffect(() => {
    if (!formData.id || formData.id.startsWith('temp_') || !factoryId) {
      setWorkerCount(0);
      return;
    }
    let cancelled = false;
    supabase
      .from('workers')
      .select('id', { count: 'exact', head: true })
      .eq('department_id', formData.id)
      .eq('factory_id', factoryId ?? '')
      .eq('is_active', true)
      .then(({ count }) => {
        if (!cancelled) setWorkerCount(count || 0);
      });
    return () => { cancelled = true; };
  }, [formData.id, factoryId, departmentWorkerRevision]);

  const currentApps = formData.apps || [];
  const showTransaction = factoryEntitlements.transaction.includes('transaction');

  useEffect(() => {
    if (!showTransaction) return;
    const apps = formDataRef.current.apps || [];
    if (!apps.includes('transaction')) {
      setFormData({ ...formDataRef.current, apps: [...apps, 'transaction'], _init: true });
    }
  }, [formData.id, setFormData, showTransaction]);

  const toggleOptionalApp = (appId: string) => {
    const newApps = currentApps.includes(appId)
      ? currentApps.filter((a: string) => a !== appId)
      : [...currentApps, appId];
    setFormData({ ...formData, apps: newApps });
  };

  const setOutputTracking = (optionId: string) => {
    const filtered = currentApps.filter((a: string) => !['hourly', 'qc_log', 'none'].includes(a));
    if (optionId !== 'none') {
      setFormData({ ...formData, apps: [...filtered, optionId] });
    } else {
      setFormData({ ...formData, apps: filtered });
    }
  };

  const setWorkforceTracking = (optionId: string) => {
    const filtered = currentApps.filter((a: string) => !['workforce_log', 'attendance', 'none_workforce'].includes(a));
    if (optionId === 'workforce_log') {
      setFormData({
        ...formData,
        apps: [...filtered, optionId],
        workerRoles: formData.workerRoles ?? [],
      });
    } else if (optionId === 'attendance') {
      setFormData({ ...formData, apps: [...filtered, optionId], workerRoles: [] });
    } else {
      setFormData({ ...formData, apps: filtered, workerRoles: [] });
    }
  };

  const addResourceLocally = () => {
    if (!lineForm || !lineForm.resourceName?.trim()) return;
    const trimmedName = lineForm.resourceName.trim();
    const nameKey = trimmedName.toLowerCase();
    if (resources.some(
      (r) => r.id !== lineForm.id && String(r.resourceName).trim().toLowerCase() === nameKey,
    )) {
      return;
    }

    const newResource: DepartmentResource = {
      id: lineForm.id || crypto.randomUUID(),
      resourceName: trimmedName,
      departmentName: formData.name,
      departmentId: formData.id,
      defaultPcs: !isOutsourced ? (lineForm.defaultPcs || 500) : undefined,
    };

    const next = lineForm.id
      ? resources.map((r) => (r.id === lineForm.id ? newResource : r))
      : [...resources, newResource];
    onResourcesChange(next);
    setLineForm(null);
  };

  const deleteResourceLocally = (id: string) => {
    onResourcesChange(resources.filter((r) => r.id !== id));
  };

  const currentOutput = currentApps.find((a: string) => ['hourly', 'qc_log'].includes(a)) || 'none';
  const currentWorkforce = currentApps.find((a: string) => ['workforce_log', 'attendance'].includes(a)) || 'none';

  const outputOptions = useMemo(
    () => OUTPUT_OPTIONS.filter((o) => o.id === 'none' || factoryEntitlements.production.includes(o.id as 'hourly' | 'qc_log')),
    [factoryEntitlements.production],
  );
  const workforceOptions = useMemo(
    () => WORKFORCE_OPTIONS.filter(
      (o) => o.id === 'none' || factoryEntitlements.workforce.includes(o.id as 'workforce_log' | 'attendance'),
    ),
    [factoryEntitlements.workforce],
  );
  const optionalApps = useMemo(
    () => OPTIONAL_APPS.filter((o) => factoryEntitlements.audit.includes(o.id as 'audit')),
    [factoryEntitlements.audit],
  );
  const showProduction = factoryEntitlements.production.length > 0;
  const showWorkforce = factoryEntitlements.workforce.length > 0;

  return (
    <div className="space-y-6 w-full max-w-full">
      <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm w-full">
        <div className="flex items-center justify-between">
          <div className="flex-1">
            <Input
              label="Department Name"
              placeholder="e.g. Sewing"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              className="font-bold text-xs bg-white"
            />
          </div>

          <div className="flex items-center gap-3 pl-6 border-l border-slate-200 ml-6">
            <div className="text-right">
              <h4 className="text-xs font-bold text-slate-800">Outsourced</h4>
              <p className="text-[10px] text-slate-500">External vendor</p>
            </div>
            <input
              type="checkbox"
              id="is_outsourced"
              checked={isOutsourced}
              onChange={(e) => setFormData({ ...formData, isOutsourced: e.target.checked })}
              className="w-5 h-5 rounded border-slate-300 text-blue-600 focus:ring-blue-500 cursor-pointer"
            />
          </div>
        </div>
      </div>

      <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm w-full">
        <h4 className="text-xs font-bold text-slate-800 mb-4 flex items-center gap-2">
          <Layers size={16} /> Apps Configuration
        </h4>

        {showTransaction && (
        <div className="mb-6 p-3 bg-emerald-50 border border-emerald-200 rounded-lg flex items-center gap-3">
          <div className="w-8 h-8 bg-emerald-100 text-emerald-600 rounded-lg flex items-center justify-center">
            <Box size={16} />
          </div>
          <div className="flex-1">
            <div className="text-sm font-bold text-emerald-800">Transaction App</div>
            <div className="text-[10px] text-emerald-600">Always enabled - material movement tracking</div>
          </div>
          <div className="text-emerald-600">
            <CheckCircle size={20} />
          </div>
        </div>
        )}

        {showProduction && (
        <div className="mb-6">
          <h5 className="text-[10px] font-bold text-slate-500 uppercase mb-3">Production Tracking (Choose one)</h5>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {outputOptions.map((option) => {
              const isSelected = currentOutput === option.id;
              const Icon = option.icon;
              return (
                <button
                  key={option.id}
                  onClick={() => setOutputTracking(option.id)}
                  className={`relative flex items-center gap-3 p-3 rounded-lg border transition-all ${
                    isSelected
                      ? 'bg-blue-50 border-blue-300 text-blue-700'
                      : 'bg-slate-50 border-slate-200 text-slate-500 hover:border-slate-300'
                  }`}
                >
                  <Icon size={18} />
                  <span className="text-xs font-medium">{option.name}</span>
                  {isSelected && (
                    <div className="absolute top-2 right-2 w-4 h-4 bg-blue-500 text-white rounded-full flex items-center justify-center">
                      <CheckCircle size={10} />
                    </div>
                  )}
                </button>
              );
            })}
          </div>
        </div>
        )}

        {showWorkforce && (
        <div className="mb-6">
          <h5 className="text-[10px] font-bold text-slate-500 uppercase mb-3">Workforce Tracking (Choose one)</h5>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {workforceOptions.map((option) => {
              const isSelected = currentWorkforce === option.id;
              const Icon = option.icon;
              const isAttendance = option.id === 'attendance';
              const canSelectAttendance = !isAttendance || workerCount > 0;
              return (
                <button
                  key={option.id}
                  onClick={() => canSelectAttendance && setWorkforceTracking(option.id)}
                  className={`relative flex flex-col items-start gap-1 p-3 rounded-lg border transition-all ${
                    !canSelectAttendance
                      ? 'bg-slate-50 border-slate-200 text-slate-300 cursor-not-allowed'
                      : isSelected
                        ? 'bg-blue-50 border-blue-300 text-blue-700'
                        : 'bg-slate-50 border-slate-200 text-slate-500 hover:border-slate-300'
                  }`}
                  disabled={!canSelectAttendance}
                >
                  <div className="flex items-center gap-3">
                    <Icon size={18} />
                    <span className="text-xs font-medium">{option.name}</span>
                  </div>
                  {isAttendance && (
                    workerCount > 0 ? (
                      <span className="text-[10px] font-medium text-slate-400 ml-[30px]">{workerCount} worker{workerCount !== 1 ? 's' : ''}</span>
                    ) : (
                      <span className="text-[10px] text-amber-500 ml-[30px]">Add workforce first</span>
                    )
                  )}
                  {isSelected && (
                    <div className="absolute top-2 right-2 w-4 h-4 bg-blue-500 text-white rounded-full flex items-center justify-center">
                      <CheckCircle size={10} />
                    </div>
                  )}
                </button>
              );
            })}
          </div>
        </div>
        )}

        {currentWorkforce === 'workforce_log' && showWorkforce && (
          <div className="mt-4 mb-6 p-4 rounded-lg bg-violet-50 border border-violet-200">
            <h5 className="text-[10px] font-bold text-violet-700 uppercase mb-3">Workforce Categories</h5>
            <div className="flex flex-wrap gap-2 mb-3">
              {workerRoles.map((role, idx) => (
                <div
                  key={`${role}-${idx}`}
                  className="flex items-center gap-1.5 bg-violet-100 text-violet-800 border border-violet-200 rounded-lg px-2.5 py-1.5 text-xs font-medium"
                >
                  <span>{role}</span>
                  <button
                    type="button"
                    onClick={() => {
                      const next = workerRoles.filter((_, i) => i !== idx);
                      setFormData({ ...formData, workerRoles: next });
                    }}
                    className="text-violet-500 hover:text-violet-800"
                  >
                    <X size={12} />
                  </button>
                </div>
              ))}
            </div>
            <div className="flex gap-2">
              <input
                type="text"
                value={newWorkerRole}
                onChange={(e) => setNewWorkerRole(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key !== 'Enter') return;
                  e.preventDefault();
                  const trimmed = newWorkerRole.trim();
                  if (!trimmed || workerRoles.includes(trimmed)) return;
                  setFormData({ ...formData, workerRoles: [...workerRoles, trimmed] });
                  setNewWorkerRole('');
                }}
                placeholder="Add category"
                className="flex-1 px-3 py-2 text-xs rounded-lg border bg-white border-violet-200 focus:border-violet-500 focus:outline-none"
              />
              <Button
                size="sm"
                type="button"
                onClick={() => {
                  const trimmed = newWorkerRole.trim();
                  if (!trimmed || workerRoles.includes(trimmed)) return;
                  setFormData({ ...formData, workerRoles: [...workerRoles, trimmed] });
                  setNewWorkerRole('');
                }}
              >
                <Plus size={14} />
              </Button>
            </div>
            <p className="text-[10px] text-violet-500 mt-2">
              Define the groups your floor team will count. Saved only while Workforce Log is enabled.
            </p>
            {workerRoles.length === 0 && (
              <p className="text-[10px] text-amber-600 mt-2">Add at least one category before saving.</p>
            )}
          </div>
        )}

        {optionalApps.length > 0 && (
        <div>
          <h5 className="text-[10px] font-bold text-slate-500 uppercase mb-3">Optional Apps</h5>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {optionalApps.map((app) => {
              const isSelected = currentApps.includes(app.id);
              const Icon = app.icon;
              return (
                <button
                  key={app.id}
                  onClick={() => toggleOptionalApp(app.id)}
                  className={`relative flex items-center gap-3 p-3 rounded-lg border transition-all ${
                    isSelected
                      ? 'bg-blue-50 border-blue-300 text-blue-700'
                      : 'bg-slate-50 border-slate-200 text-slate-500 hover:border-slate-300'
                  }`}
                >
                  <Icon size={18} />
                  <span className="text-xs font-medium">{app.name}</span>
                  {isSelected && (
                    <div className="absolute top-2 right-2 w-4 h-4 bg-blue-500 text-white rounded-full flex items-center justify-center">
                      <CheckCircle size={10} />
                    </div>
                  )}
                </button>
              );
            })}
          </div>
        </div>
        )}
      </div>

      <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm w-full">
        <div className="flex justify-between items-center mb-4">
          <div>
            <h4 className="text-xs font-bold text-slate-800 flex items-center gap-2">
              <Factory size={16} /> Assigned Resources
            </h4>
            <p className="text-[10px] text-slate-500 mt-0.5">
              {isOutsourced
                ? 'Vendor lines for this outsourced department'
                : 'Planning uses Capacity (PCS/day) for each resource'}
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
          <div className="lg:col-span-1 p-4 rounded-xl border bg-slate-50 border-slate-200">
            <div className="text-xs font-bold mb-3 flex items-center gap-1.5 text-slate-700">
              {lineForm?.id ? <><Edit size={12} /> Edit Resource</> : <><Plus size={12} /> New Resource</>}
            </div>
            <div className="space-y-3">
              <div>
                <label className="block text-[10px] font-semibold mb-1 text-slate-600">
                  {isOutsourced ? 'Vendor Name' : 'Resource Name'}
                </label>
                <input
                  type="text"
                  placeholder={isOutsourced ? 'e.g. ABC Garments' : 'e.g. Line A'}
                  value={lineForm?.resourceName || ''}
                  onChange={(e) => setLineForm({
                    ...(lineForm || { departmentName: formData.name, departmentId: formData.id }),
                    resourceName: e.target.value,
                  })}
                  className="w-full px-3 py-2 text-xs rounded-lg border bg-white border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-200"
                />
              </div>

              {!isOutsourced && (
                <div>
                  <label className="block text-[10px] font-semibold mb-1 text-slate-600">Capacity (PCS/Day)</label>
                  <input
                    type="number"
                    placeholder="500"
                    value={lineForm?.defaultPcs || ''}
                    onChange={(e) => setLineForm({
                      ...(lineForm || { departmentName: formData.name, departmentId: formData.id }),
                      defaultPcs: parseInt(e.target.value, 10) || 0,
                    })}
                    className="w-full px-3 py-2 text-xs rounded-lg border bg-white border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-200"
                  />
                </div>
              )}

              <div className="flex gap-2">
                <Button
                  size="sm"
                  onClick={addResourceLocally}
                  disabled={
                    !lineForm?.resourceName?.trim()
                    || resources.some(
                      (r) =>
                        r.id !== lineForm?.id
                        && String(r.resourceName).trim().toLowerCase()
                          === String(lineForm?.resourceName).trim().toLowerCase(),
                    )
                  }
                  className="flex-1"
                >
                  {lineForm?.id ? 'Update' : 'Add'}
                </Button>
                {lineForm?.id && (
                  <Button size="sm" variant="ghost" onClick={() => setLineForm(null)}>
                    <X size={14} />
                  </Button>
                )}
              </div>
            </div>
          </div>

          <div className="lg:col-span-3">
            {resourcesLoading ? (
              <div className="flex items-center justify-center py-12">
                <Spinner size="md" />
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                {resources.map((res) => (
                  <div
                    key={res.id}
                    onClick={() => setLineForm(res)}
                    className="group cursor-pointer p-4 rounded-xl border bg-white border-slate-200 hover:border-blue-300 hover:shadow-sm transition-all"
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex items-center gap-2">
                        <div className="p-1.5 rounded bg-slate-100 text-slate-500">
                          {isOutsourced ? <Building2 size={14} /> : <Factory size={14} />}
                        </div>
                        <div>
                          <div className="font-bold text-slate-800 text-sm">{res.resourceName}</div>
                          {!isOutsourced && (
                            <div className="text-[10px] text-slate-500">
                              Capacity: {res.defaultPcs?.toLocaleString() || 0} pcs/day
                            </div>
                          )}
                        </div>
                      </div>
                      <button
                        type="button"
                        onClick={(e) => { e.stopPropagation(); deleteResourceLocally(res.id); }}
                        className="p-1 rounded hover:bg-red-100 hover:text-red-600 text-slate-400 opacity-0 group-hover:opacity-100 transition-opacity"
                      >
                        <Trash2 size={12} />
                      </button>
                    </div>
                  </div>
                ))}
                {resources.length === 0 && (
                  <div className="col-span-full py-8 text-center text-slate-400 text-xs italic bg-slate-50 rounded-lg border border-dashed border-slate-200">
                    No resources. Use the form to add one.
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
