import React from 'react';
import { Input, Button, SelectDropdown as Select } from '../ui';
import { Truck } from 'lucide-react';
import { tokens } from '../../lib/designTokens';

interface VendorEditorProps {
  formData: any;
  setFormData: (d: any) => void;
  onSave?: () => void;
  onDelete?: () => void;
}

export const VendorEditor: React.FC<VendorEditorProps> = ({
  formData,
  setFormData,
  onSave,
  onDelete,
}) => {
  return (
    <div className="space-y-6 w-full">
      <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
        <h4 className="text-xs font-bold text-slate-800 mb-6 flex items-center gap-2">
          <Truck size={16} /> Vendor Details
        </h4>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="md:col-span-2">
            <Input
              label="Vendor Name"
              placeholder="e.g. Jiangsu Textiles Ltd."
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              className="bg-white"
            />
          </div>

          <Input
            label="Vendor Code"
            placeholder="e.g. V-001"
            value={formData.code}
            onChange={(e) => setFormData({ ...formData, code: e.target.value })}
            className="bg-white"
          />

          <div>
            <label className="block font-medium text-slate-700 mb-1.5" style={{ fontSize: tokens.fontSize.body }}>Status</label>
            <Select
              value={formData.status || "Active"}
              onChange={(value) => setFormData({ ...formData, status: value })}
              options={[
                { value: "Active", label: "Active" },
                { value: "Inactive", label: "Inactive" },
              ]}
              className="bg-white"
            />
          </div>

          <div>
            <label className="block font-medium text-slate-700 mb-1.5" style={{ fontSize: tokens.fontSize.body }}>Vendor Type</label>
            <Select
              value={formData.type || "Fabric"}
              onChange={(value) => setFormData({ ...formData, type: value })}
              options={[
                { value: "Fabric", label: "Fabric Supplier" },
                { value: "Trims", label: "Trims / Accessories" },
              ]}
              className="bg-white"
            />
          </div>

          <Input
            label="Location / City"
            placeholder="e.g. Shanghai, China"
            value={formData.location || ""}
            onChange={(e) => setFormData({ ...formData, location: e.target.value })}
            className="bg-white"
          />
        </div>
      </div>
    </div>
  );
};
