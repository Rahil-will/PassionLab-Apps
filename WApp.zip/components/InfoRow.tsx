import React from 'react';
import { tokens } from '../lib/designTokens';

interface InfoRowProps {
  items: Array<{ label: string; value: React.ReactNode }>;
  dividers?: boolean;
}

export const InfoRow: React.FC<InfoRowProps> = ({ items, dividers = true }) => (
  <div className="flex items-center flex-wrap gap-y-2">
    {items.map((item, i) => (
      <React.Fragment key={i}>
        {i > 0 && dividers && (
          <span className="mx-3 text-slate-300">|</span>
        )}
        {i > 0 && !dividers && <div className="w-4" />}
        <div className="flex items-center gap-1.5">
          <span className="text-slate-500 font-medium" style={{ fontSize: tokens.fontSize.bodySmall }}>
            {item.label}:
          </span>
          <span className="text-slate-900" style={{ fontSize: tokens.fontSize.body }}>
            {item.value}
          </span>
        </div>
      </React.Fragment>
    ))}
  </div>
);
