import React, { useState } from 'react';
import { useSettingsStore } from '../stores';
import { Input, Button } from './ui';
import { 
  User, 
  Box, 
  Scissors, 
  Truck, 
  CheckCircle, 
  Layers,
  ShieldCheck,
  Factory,
  Edit,
  Plus,
  Trash2,
  Save,
  X
} from 'lucide-react';

interface AssignedResource {
  id: string;
  resourceName: string;
  departmentName: string;
  departmentId: string;
  avgWF?: number;
  defaultPcs?: number;
}

interface DepartmentEditorProps {
  formData: any;
  setFormData: (d: any) => void;
  onSave?: () => void;
  onDelete?: () => void;
}

const AVAILABLE_APPS = [
  { id: 'supervisor', name: 'Supervisor App', icon: User },
  { id: 'packing', name: 'Packing App', icon: Box },
  { id: 'cutting', name: 'Cutting App', icon: Scissors },
  { id: 'receiving', name: 'Receiving App', icon: Truck },
  { id: 'inspection', name: 'Inspection App', icon: CheckCircle },
];

export const DepartmentEditor: React.FC<DepartmentEditorProps> = ({
  formData,
  setFormData,
  onSave,
  onDelete,
}) => {
  const store = useSettingsStore();
  const [lineForm, setLineForm] = useState<Partial<AssignedResource> | null>(null);
  const [localResources, setLocalResources] = useState<any[]>(formData._resources || []);

  const isDetailedPlanDept = formData.isDetailedPlan === true;
  const isSewingOrFinishing = formData.name === "Sewing" || formData.name === "Finishing";

  const toggleApp = (appId: string) => {
    const currentApps = formData.apps || [];
    const newApps = currentApps.includes(appId)
      ? currentApps.filter((a: string) => a !== appId)
      : [...currentApps, appId];
    setFormData({ ...formData, apps: newApps });
  };

  const addResourceLocally = () => {
    if (!lineForm || !lineForm.resourceName) return;

    const newResource = {
      id: lineForm.id || crypto.randomUUID(),
      resourceName: lineForm.resourceName,
      departmentName: formData.name,
      departmentId: formData.id,
      avgWF: isSewingOrFinishing ? (lineForm.avgWF || 35) : undefined,
      defaultPcs: !isSewingOrFinishing ? (lineForm.defaultPcs || 500) : undefined,
    };

    if (lineForm.id) {
      setLocalResources(prev => prev.map(r => r.id === lineForm.id ? newResource : r));
    } else {
      setLocalResources(prev => [...prev, newResource]);
    }

    setFormData({ ...formData, _resources: [...(formData._resources || []).filter((r: any) => r.id !== newResource.id), newResource] });
    setLineForm(null);
  };

  const deleteResourceLocally = (id: string) => {
    setLocalResources(prev => prev.filter(r => r.id !== id));
    setFormData({ ...formData, _resources: (formData._resources || []).filter((r: any) => r.id !== id) });
  };

  const getAvailableMins = (wf: number) => {
    const firstShift = store.shifts[0];
    if (!firstShift) return 0;
    const [startH, startM] = firstShift.startTime.split(':').map(Number);
    const [endH, endM] = firstShift.endTime.split(':').map(Number);
    const totalMinutes = ((endH * 60 + endM) - (startH * 60 + startM)) * wf;
    return Math.round(totalMinutes * 0.85);
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-300 w-full max-w-full">
      {/* Header with Save/Delete */}
      <div className="flex justify-between items-center">
        <h3 className="text-sm font-bold text-slate-800">Department Configuration</h3>
        <div className="flex gap-2">
          {onDelete && (
            <Button variant="danger" size="sm" icon={Trash2} onClick={onDelete}>
              Delete
            </Button>
          )}
          {onSave && (
            <Button variant="primary" size="sm" icon={Save} onClick={onSave} disabled={!formData.name?.trim()}>
              Save Changes
            </Button>
          )}
        </div>
      </div>

      {/* Department Name */}
      <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm w-full">
        <div className="flex items-center gap-2">
          <Input
            label="Department Name"
            placeholder="e.g. Sewing"
            value={formData.name}
            onChange={(e) => setFormData({ ...formData, name: e.target.value })}
            className="font-bold text-xs bg-white flex-1"
            disabled={isDetailedPlanDept}
          />
          {isDetailedPlanDept && (
            <div className="text-amber-500 mt-6" title="Protected Department">
              <ShieldCheck size={24} />
            </div>
          )}
        </div>
        {isDetailedPlanDept && (
          <p className="text-xs text-slate-500 mt-2">
            Department name is locked for default departments
          </p>
        )}
      </div>

      {/* Outsourced Toggle */}
      <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm w-full">
        <div className="flex items-center justify-between">
          <div>
            <h4 className="text-xs font-bold text-slate-800 mb-1">Department Type</h4>
            <p className="text-[10px] text-slate-500">
              Mark if this department is outsourced
            </p>
          </div>
          <div className="flex items-center gap-2">
            <input
              type="checkbox"
              id="is_outsourced"
              checked={formData.isOutsourced || false}
              onChange={(e) => setFormData({ ...formData, isOutsourced: e.target.checked })}
              className="w-4 h-4 rounded border-slate-300 text-blue-600 focus:ring-blue-500"
            />
            <label htmlFor="is_outsourced" className="text-sm font-medium text-slate-700 cursor-pointer">
              Outsourced
            </label>
          </div>
        </div>
      </div>

      {/* Apps Selection */}
      <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm w-full">
        <h4 className="text-xs font-bold text-slate-800 mb-4 flex items-center gap-2">
          <Layers size={16} /> Apps Used
        </h4>
        <p className="text-[10px] text-slate-500 mb-4">
          Select which apps are used in this department
        </p>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-3">
          {AVAILABLE_APPS.map((app) => {
            const isSelected = (formData.apps || []).includes(app.id);
            const Icon = app.icon;
            return (
              <button
                key={app.id}
                onClick={() => toggleApp(app.id)}
                className={`relative flex flex-col items-center gap-2 p-4 rounded-xl border transition-all ${
                  isSelected
                    ? 'bg-blue-50 border-blue-300 text-blue-700'
                    : 'bg-slate-50 border-slate-200 text-slate-500 hover:border-slate-300'
                }`}
              >
                <Icon size={20} />
                <span className="text-[10px] font-medium text-center">{app.name}</span>
                {isSelected && (
                  <div className="absolute top-2 right-2 w-4 h-4 bg-blue-500 text-white rounded-full flex items-center justify-center">
                    <CheckCircle size={10} />
                  </div>
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* Assigned Resources */}
      <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm w-full">
        <div className="flex justify-between items-center mb-4">
          <div>
            <h4 className="text-xs font-bold text-slate-800 flex items-center gap-2">
              <Factory size={16} /> Assigned Resources
            </h4>
            <p className="text-[10px] text-slate-500 mt-0.5">
              {isSewingOrFinishing
                ? "Planning uses Workers (WF) for capacity"
                : "Planning uses Pieces (PCS) for capacity"}
            </p>
          </div>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
          {/* Add/Edit Form */}
          <div className="lg:col-span-1 p-4 rounded-xl border bg-slate-50 border-slate-200">
            <div className="text-xs font-bold mb-3 flex items-center gap-1.5 text-slate-700">
              {lineForm?.id ? <><Edit size={12} /> Edit Resource</> : <><Plus size={12} /> New Resource</>}
            </div>
            <div className="space-y-3">
              <div>
                <label className="block text-[10px] font-semibold mb-1 text-slate-600">Name</label>
                <input
                  type="text"
                  placeholder="e.g. Line A"
                  value={lineForm?.resourceName || ""}
                  onChange={(e) => setLineForm({
                    ...(lineForm || { departmentName: formData.name, departmentId: formData.id, avgWF: isSewingOrFinishing ? 35 : 0 }),
                    resourceName: e.target.value,
                  })}
                  className="w-full px-3 py-2 text-xs rounded-lg border bg-white border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-200"
                />
              </div>
              {isSewingOrFinishing ? (
                <div>
                  <label className="block text-[10px] font-semibold mb-1 text-slate-600">Avg. Workers (WF)</label>
                  <input
                    type="number"
                    placeholder="35"
                    value={lineForm?.avgWF || ""}
                    onChange={(e) => setLineForm({
                      ...(lineForm || { departmentName: formData.name, departmentId: formData.id }),
                      avgWF: parseInt(e.target.value) || 0,
                    })}
                    className="w-full px-3 py-2 text-xs rounded-lg border bg-white border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-200"
                  />
                </div>
              ) : (
                <div>
                  <label className="block text-[10px] font-semibold mb-1 text-slate-600">Default PCS/Day</label>
                  <input
                    type="number"
                    placeholder="500"
                    value={lineForm?.defaultPcs || ""}
                    onChange={(e) => setLineForm({
                      ...(lineForm || { departmentName: formData.name, departmentId: formData.id }),
                      defaultPcs: parseInt(e.target.value) || 0,
                    })}
                    className="w-full px-3 py-2 text-xs rounded-lg border bg-white border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-200"
                  />
                </div>
              )}
              <div className="flex gap-2">
                <Button size="sm" onClick={addResourceLocally} disabled={!lineForm?.resourceName} className="flex-1">
                  {lineForm?.id ? "Update" : "Add"}
                </Button>
                {lineForm?.id && (
                  <Button size="sm" variant="ghost" onClick={() => setLineForm(null)}>
                    <X size={14} />
                  </Button>
                )}
              </div>
            </div>
          </div>

          {/* Resource Cards */}
          <div className="lg:col-span-3">
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
              {localResources.map((res) => (
                <div
                  key={res.id}
                  onClick={() => setLineForm(res)}
                  className="group cursor-pointer p-3 rounded-xl border bg-white border-slate-200 hover:border-blue-300 hover:shadow-sm transition-all"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="p-1.5 rounded bg-slate-100 text-slate-500">
                        <Factory size={14} />
                      </div>
                      <div>
                        <div className="font-bold text-slate-800 text-base">{res.resourceName}</div>
                        {isSewingOrFinishing ? (
                          <div className="text-[10px] text-slate-500">
                            WF: {res.avgWF || 0} • {getAvailableMins(res.avgWF || 0).toLocaleString()} mins/day
                          </div>
                        ) : (
                          <div className="text-[10px] text-slate-500">
                            PCS: {res.defaultPcs?.toLocaleString() || 0}/day
                          </div>
                        )}
                      </div>
                    </div>
                    <button
                      onClick={(e) => { e.stopPropagation(); deleteResourceLocally(res.id); }}
                      className="p-1 rounded hover:bg-red-100 hover:text-red-600 text-slate-400 opacity-0 group-hover:opacity-100 transition-opacity"
                    >
                      <Trash2 size={12} />
                    </button>
                  </div>
                </div>
              ))}
              {localResources.length === 0 && (
                <div className="col-span-full py-8 text-center text-slate-400 text-xs italic bg-slate-50 rounded-lg border border-dashed border-slate-200">
                  No resources. Use the form to add one.
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
